<template>
  <div class="d-flex align-center">
    <combo-box
      v-bind="$attrs"
      v-model:search="searchText"
      :items="items"
      item-title="name"
      item-value="name"
      :return-object="false"
      :loading="loading"
      multiple
      @update:search="searchUpdated"
    >
      <template v-slot:append-item="">
        <div v-intersect="endIntersect"></div>
      </template>
    </combo-box>
    <template v-if="props.canAdd">
      <btn :primary="false" variant="text" icon="mdi-plus" max-height="47px" max-width="47px" class="ml-3" @click="showDialog = true" />
      <CustomEncounterDialog v-model="showDialog" :encounter-type="CustomEncounterType.Diagnosis" />
    </template>
  </div>
</template>

<script setup lang="ts">
import _ from 'lodash';
import { ref, computed, onMounted } from 'vue';
import { CustomEncounterType, IFilterQuery } from '@/types';
import { useCustomEncountersStore } from '@/store';
import CustomEncounterDialog from '@/components/configuration/CustomEncounterDialog.vue';

const customEncountersStore = useCustomEncountersStore();

const props = defineProps({
  canAdd: {
    type: Boolean,
    default: false,
  },
  multiple: {
    type: Boolean,
    default: false,
  },
});

const next = ref<string>('');
const page = ref<number>(1);
const items = ref<any[]>([]);
const searchText = ref<string>('');
const loading = ref<boolean>(false);
const showDialog = ref<boolean>(false);

onMounted(() => {
  searchItems();
});

const errors: any = computed(() => '');

const searchUpdated = async (query: string) => {
  page.value = 1;
  searchItems();
};

const searchItems = _.debounce(async (savePrevious = false) => {
  const query: IFilterQuery = {
    page: page.value,
    name: searchText.value ? searchText.value : undefined,
  };
  loading.value = true;
  const res = await customEncountersStore.searchCustomEncounters(CustomEncounterType.Diagnosis, query);
  if (savePrevious) items.value = [...items.value, ...res.results];
  else items.value = res.results;
  next.value = res.next;
  loading.value = false;
}, 600);

const endIntersect = (
  entries: boolean,
  observer: any[],
  isIntersecting: any,
) => {
  if (isIntersecting && next.value && !searchText.value) {
    page.value++;
    searchItems(true);
  }
};
</script>

<style lang="scss"></style>
