<template>
  <div class="d-flex flex-wrap pa-4">
    <bar-chart
      v-if="!loading"
      :chart-data="totalBarChart"
      :chart-options="chart1.chartOptions"
      class="mr-4 flex-1-1"
      :height="300"
    />
    <doughnut-chart
      v-if="!loading"
      :chart-data="totalDoughnutChart"
      :chart-options="chart2.chartOptions"
      :height="300"
    />
  </div>

  <div class="pa-4">
    <line-chart
      v-if="!loading"
      :chart-data="totalByStatusLineChart"
      :chart-options="chart3.chartOptions"
      :height="300"
    />
  </div>

  <div class="pa-4">
    <bar-chart
      v-if="!loading"
      :chart-data="totalByStatusBarChart"
      :chart-options="chart4.chartOptions"
      :height="300"
    />
  </div>
</template>

<script setup lang="ts">
import BarChart from '@/components/charts/BarChart.vue';
import DoughnutChart from '@/components/charts/DoughnutChart.vue';
import LineChart from '@/components/charts/LineChart.vue';
import { ChartData } from 'chart.js';
import { PropType } from 'vue';

const props = defineProps({
  loading: {
    type: Boolean,
    default: false,
  },
  totalBarChart: {
    required: true,
    type: Object as PropType<ChartData<'bar', number[], unknown>>,
  },
  totalDoughnutChart: {
    required: true,
    type: Object as PropType<ChartData<'doughnut', number[], unknown>>,
  },
  totalByStatusBarChart: {
    required: true,
    type: Object as PropType<ChartData<'bar', number[], unknown>>,
  },
  totalByStatusLineChart: {
    required: true,
    type: Object as PropType<ChartData<'line', number[], unknown>>,
  },
});

const chart1 = {
  chartData: {
    labels: ['January', 'February', 'March', 'April', 'May', 'June'],
    datasets: [
      {
        label: 'Patients treated by month',
        data: [12, 19, 3, 5, 2, 3],
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  },
  chartOptions: {
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  },
};

const chart2 = {
  chartData: {
    labels: ['Cancelled', 'Confirmed', 'No Show'],
    datasets: [
      {
        label: 'Addmission Rate',
        data: [10, 250, 300],
        // backgroundColor: [
        //   'rgb(255, 99, 132)',
        //   'rgb(54, 162, 235)',
        //   'rgb(255, 205, 86)',
        // ],
        // borderColor: 'rgba(75, 192, 192, 1)',
        // borderWidth: 1,
      },
    ],
  },
  chartOptions: {},
};

const chart3 = {
  chartData: {
    labels: [
      '2023-04-18',
      '2023-04-19',
      '2023-04-20',
      '2023-04-21',
      '2023-04-22',
    ],
    datasets: [
      {
        data: [20, 10, 5, 25, 12],
        label: 'Confirmed',
      },
      {
        data: [45, 10, 15, 65, 45],
        label: 'Cancelled',
      },
      {
        data: [30, 15, 45, 10, 5],
        label: 'No Show',
      },
    ],
  },
  chartOptions: {
    scales: {
      y: {
        stacked: true,
      },
    },
  },
};

const chart4 = {
  chartData: {
    datasets: [
      {
        label: 'Confirmed',
        data: [100, 65, 85, 120],
        order: 1,
        backgroundColor: 'rgb(54, 162, 235)',
      },
      {
        label: 'Cancelled',
        data: [10, 18, 22, 20],
        order: 2,
        backgroundColor: 'rgb(255, 99, 132)',
      },
      {
        label: 'No Shows',
        data: [55, 15, 2, 18],
        order: 3,
        backgroundColor: 'rgb(255, 205, 86)',
      },
    ],
    labels: ['January', 'February', 'March', 'April'],
  },
  chartOptions: {
    scales: {
      x: {
        stacked: true,
      },
      y: {
        stacked: true,
      },
    },
  },
};
</script>

<style scoped lang="scss"></style>
