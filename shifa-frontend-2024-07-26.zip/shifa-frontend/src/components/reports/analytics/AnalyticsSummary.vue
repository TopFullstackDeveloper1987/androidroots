<template>
  <div class="d-flex flex-wrap align-center ml-4 mb-4">
    <analytics-summary-card
      v-for="item of summaryData"
      :key="item.label"
      width="120"
      :status="item.label"
      :count="item.data"
      :color="getColor(item.label)"
      class="mr-4 mt-4 pa-4"
    />
  </div>
</template>

<script setup lang="ts">
import { IAppointmentData, IAppointmentSummary } from '@/types';
import { PropType } from 'vue';
import AnalyticsSummaryCard from './AnalyticsSummaryCard.vue';

const props = defineProps({
  summaryData: {
    type: Array as PropType<IAppointmentSummary[]>,
    required: true,
  },
});

const getColor = (label: string) => {
  switch (label) {
    case 'New':
      return 'skyblue';

    case 'Confirmed':
    case 'InProgress':
      return 'pink';

    case 'Cancelled':
    case 'OnHold':
      return 'orange';

    case 'NoShow':
    case 'Completed':
      return 'yellow';

    default:
      return 'green';
  }
};
</script>

<style lang="scss" scoped></style>
