<template>
  <div class="d-flex flex-wrap pa-4">
    <bar-chart
      v-if="!loading"
      :chart-data="totalBarChartData"
      :chart-options="chart1.chartOptions"
      class="mr-4 flex-1-1"
      :height="300"
    />
  </div>
</template>

<script setup lang="ts">
import BarChart from '@/components/charts/BarChart.vue';
import { ChartData } from 'chart.js';
import { PropType } from 'vue';

const props = defineProps({
  loading: {
    type: Boolean,
    default: false,
  },
  totalBarChartData: {
    required: true,
    type: Object as PropType<ChartData<'bar', number[], unknown>>,
  },
  title: {
    type: String,
  },
});

const chart1 = {
  chartData: {
    labels: ['January', 'February', 'March', 'April', 'May', 'June'],
    datasets: [
      {
        label: 'Patients treated by month',
        data: [12, 19, 3, 5, 2, 3],
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  },
  chartOptions: {
    indexAxis: 'y',
    plugins: {
      title: {
        display: true,
        text: props.title,
      },
    },
  },
};
</script>

<style scoped lang="scss"></style>
