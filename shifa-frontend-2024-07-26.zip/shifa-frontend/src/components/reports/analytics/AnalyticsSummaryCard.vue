<template>
  <v-card class="analytics-summary pa-3" :width="width" :height="height">
    <div class="d-flex flex-column align-center">
      <div class="count text-h4">{{ count }}</div>
      <div class="status">{{ status }}</div>
    </div>
  </v-card>
</template>

<script setup lang="ts">
defineProps({
  width: {
    type: String,
    default: 'auto',
  },
  height: {
    type: String,
    default: 'auto',
  },
  status: {
    type: String,
    default: '',
  },
  count: {
    type: Number,
    default: 0,
  },
  color: {
    type: String,
    required: true,
  },
});
</script>

<style lang="scss" scoped>
.analytics-summary {
  .count {
    color: v-bind(color);
  }

  .status {
    color: v-bind(color);
  }
}
</style>
