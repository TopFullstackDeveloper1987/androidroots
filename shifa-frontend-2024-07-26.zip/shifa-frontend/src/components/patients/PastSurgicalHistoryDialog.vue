<template>
  <form-dialog v-model="isShowDialog" @submit="save">
    <template v-slot:header>
      <div class="text-primary">
        {{
          isCreateAction ? $t('patient_record.add_surgery') : $t('patient_record.edit_surgery')
        }}
      </div>
    </template>
    <v-row>
      <v-col cols="12">
        <combo-box
          v-model="formData.surgery"
          :items="surgeries"
          :rules="[required]"
          item-title="name"
          item-value="id"
          :return-object="false"
          :label="$t('patient_record.surgery')"
          attr="alert"
        />
      </v-col>
      <v-col cols="12">
        <date-picker
          v-model="formData.surgery_date"
          :label="$t('patient_record.surgery_date')"
          :rules="[required]"
          required
          return-with-format
          attr="surgery_date"
        />
      </v-col>
      <v-col cols="12">
        <text-area
          v-model="formData.notes"
          :label="$t('patient.notes')"
          attr="notes"
          :rows="4"
        />
      </v-col>
    </v-row>
  </form-dialog>
</template>

<script setup lang="ts">
import {
  ref,
  computed,
  WritableComputedRef,
  PropType,
  watch,
} from 'vue';
import { required } from '@/utils/validations';
import {
  usePatientStore,
  usePatientRecordStore,
} from '@/store';
import { IPatientSurgicalHistory } from '@/types';
import { isNumber } from 'lodash';
// import { useI18n } from 'vue-i18n';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  surgery: {
    type: Object as PropType<IPatientSurgicalHistory>,
    default: () => {},
  },
  addedSurgeries: {
    type: Array as PropType<IPatientSurgicalHistory[]>,
    default: () => [],
  },
  isCreateAction: {
    type: Boolean,
    default: true,
  },
});

const patientStore = usePatientStore();
const patientRecordStore = usePatientRecordStore();

// const { t } = useI18n();

const emit = defineEmits(['update:modelValue', 'refresh']);

const formData = ref<IPatientSurgicalHistory>(<IPatientSurgicalHistory>{});

watch(
  () => props.modelValue,
  (newValue) => {
    if (newValue)
      if (props?.surgery?.id)
        formData.value = {
          ...props.surgery,
          id: props?.surgery?.id,
        };
      else
        formData.value = {
          id: null!,
          surgery: null!,
          surgery_date: null!,
          notes: '',
          patient: null!,

        };
  },
);

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

watch(() => isShowDialog.value, async (val) => {
  if(patientStore.currentPatientId && val) {
    await patientRecordStore.getSurgeries();
  }
});

const surgeries: WritableComputedRef<IPatientSurgicalHistory[] | undefined> = computed(() => {
  let tempSurgeries = props.addedSurgeries.map(
    (surgery: IPatientSurgicalHistory) => surgery && surgery?.surgery,
  );

  if(props.isCreateAction)
    return patientRecordStore.surgeries.filter(
      (surgery: IPatientSurgicalHistory) => !tempSurgeries.includes(surgery.id!),
    );

  return patientRecordStore.surgeries;

});

const save = async () => {

  const payload = formData.value;

  if(!isNumber(formData.value.surgery)) {
    payload.surgery_name = formData.value.surgery!;
    payload.surgery = null!;
  }

  if (props.surgery?.id) {
    await patientRecordStore.updatePastSurgeryHistory(formData.value);
  } else {
    formData.value.patient = patientStore.currentPatientId!;
    await patientRecordStore.addPastSurgicalHistory(formData.value);
  }

  emit('refresh');
  isShowDialog.value = false;
};
</script>

<style scoped></style>
