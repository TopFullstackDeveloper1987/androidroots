<template>
  <v-card class="px-4 py-5 summary-card" min-height="140px">
    <v-row no-gutters>
      <v-col cols="6">
        <div class="text-h6 text-secondary font-weight-medium encounter-date">
          {{ formatDate(details?.encounter_date) }}
        </div>
      </v-col>
      <v-col cols="6">
        <div class="text-h6 text-secondary font-weight-medium text-right">
          <v-chip
            variant="outlined"
            size="small"
            :color="getStatusColor(details?.encounter_status?.code)"
          >
            {{ details?.encounter_status?.name }}
          </v-chip>
        </div>
      </v-col>
      <v-col v-if="hasComplaints()" cols="12" class="mt-2">
        <div class="text-body-1 text-disabled">
          {{ $t('encounters.complains') }}
        </div>
        <div
          class="text-h6 text-secondary font-weight-medium d-flex flex-column mt-1"
        >
          <span
            v-for="item in details?.encounter_complaints"
            :key="item.id"
            class="compliants"
            >-{{ item.complaint }}</span
          >
        </div>
      </v-col>
      <v-col v-if="hasObservations()" cols="12" class="mt-2">
        <div class="text-body-1 text-disabled">
          {{ $t('encounters.observations') }}
        </div>
        <div
          class="text-h6 text-secondary font-weight-medium d-flex flex-column mt-1"
        >
          <span
            v-for="item in details?.encounter_observations"
            :key="item.id"
            class="observations"
            >-{{ item.observation }}</span
          >
        </div>
      </v-col>
      <v-col v-if="hasDiagnosis()" cols="12" class="mt-2">
        <div class="text-body-1 text-disabled">
          {{ $t('encounters.diagnosis') }}
        </div>
        <div
          class="text-h6 text-secondary font-weight-medium d-flex flex-column mt-1"
        >
          <span
            v-for="item in details?.encounter_diagnosis"
            :key="item.id"
            class="diagnosis"
            >-{{ item.diagnosis }}</span
          >
        </div>
      </v-col>
      <v-col v-if="hasMedicalOrders()" cols="12" class="mt-2">
        <div class="text-body-1 text-disabled">
          {{ $t('encounters.medication_orders') }}
        </div>
        <div
          class="text-h6 text-secondary font-weight-medium d-flex flex-column mt-1"
        >
          <span
            v-for="(medical_order, index) in medical_orders()"
            :key="index"
            class="diagnosis"
            >-{{ medical_order }}</span
          >
        </div>
      </v-col>
    </v-row>
    <btn
      :primary="false"
      secondary
      icon="mdi-square-edit-outline"
      icon-only
      size="x-small"
      class="edit-icon"
      @click="$router.push(`/medical-records/${patientStore.currentPatientId}/encounter-notes`);"
    />
  </v-card>
</template>

<script setup lang="ts">
import moment from 'moment-timezone';
import isEmpty from 'lodash/isEmpty';
import forEach from 'lodash/forEach';
import { usePatientStore } from '@/store';

const props = defineProps({
  details: {
    type: Object,
    default: () => {},
  },
});

const patientStore = usePatientStore();

const getStatusColor = (status: string) => {
  if (!status) return;
  if (status === 'new') return 'purple';
  else if (status === 'on-hold') return 'orange';
  else if (status === 'in-progress') return 'blue';
  else if (status === 'completed') return 'green';
  else return '';
};

const formatDate = (date: Date) => {
  return moment.utc(date).format('YYYY-MM-DD');
};

const hasComplaints = () => {
  return !isEmpty(props.details.encounter_complaints);
};

const hasObservations = () => {
  return !isEmpty(props.details.encounter_observations);
};

const hasDiagnosis = () => {
  return !isEmpty(props.details.encounter_diagnosis);
};

const hasMedicalOrders = () => {
  return !isEmpty(props.details.medical_orders);
};

const medical_orders = () => {
  let medications: string[] = [];
  forEach(props.details.medical_orders, medical_order => {
    forEach(medical_order.medication_order_items, medication_order_item => {
      medications.push(medication_order_item.medication.name);
    });
  });

  return medications;
};
</script>

<style lang="scss" scoped>
.summary-card {
  width: -webkit-fill-available;
}

.compliants,
.observations,
.diagnosis,
.encounter-date {
  font-size: 14px !important;
}

.edit-icon {
  position: absolute;
  bottom: 20px;
  right: 20px;
}
</style>
