<template>
  <div>
    <expansion-panel
      :title="$t('dashboard.appointments')"
      icon="appointment"
      v-model="panel"
    >
      <template #title-content>
        <btn class="ml-3 my-2" icon="mdi-plus" max-width="200" icon-before @click="onShowNewAppointmentDialog"> {{ $t('appointments.new_appointment') }} </btn>
      </template>
      <template #content>
        <appointment-table @edit="onShowUpdateAppointmentDialog" />
      </template>
    </expansion-panel>
    <new-appointment
      v-model="isShowNewAppointmentDialog"
      :practitioner-id="practitionerId"
      :current-appointment="currentAppointment"
    />
  </div>
</template>

<script lang="ts" setup>
import NewAppointment from '@/components/appointments/NewAppointment.vue';
import AppointmentTable from '@/components/appointments/AppointmentTable.vue';

import { IAppointment } from '@/types';
import { ref } from 'vue';

const panel = ref<number | undefined>();
const isShowNewAppointmentDialog = ref(false);
const practitionerId = ref<string>();
const currentAppointment = ref<IAppointment | null>(null);

const onShowNewAppointmentDialog = () => {
  currentAppointment.value = null;
  isShowNewAppointmentDialog.value = true;
};

const onShowUpdateAppointmentDialog = (appointment: IAppointment) => {
  currentAppointment.value = appointment;
  isShowNewAppointmentDialog.value = true;
};
</script>

<style lang="scss" scoped></style>
