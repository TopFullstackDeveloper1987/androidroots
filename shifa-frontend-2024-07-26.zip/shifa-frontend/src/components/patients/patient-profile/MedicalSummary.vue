<template>
  <div>
    <expansion-panel
      :title="$t('dashboard.encounter_summary')"
      icon="medical-notes"
      v-model="panel"
    >

      <template #title-content>
        <btn class="ml-3 my-2" icon="mdi-plus" max-width="200" icon-before @click="create">{{ $t('encounters.new_encounter') }}</btn>
      </template>
      <template #content>
        <v-sheet class="px-3 py-5 bg-whisper bordered">
          <div class="mt-6 d-flex flex-column">
            <SummaryCard
              v-for="(card, index) in summaryCard"
              :key="index"
              :details="card"
              class="mb-5 w-100"
            />
          </div>
        </v-sheet>
      </template>
    </expansion-panel>
    <encounter-dialog
      v-model="isEncounterDialog"
      :item="selectedEncounter"
      :practitioners="practitionerSearchStore.practitioners"
    />
  </div>
</template>

<script lang="ts" setup>
import { onMounted, ref, watch } from 'vue';
import SummaryCard from '@/components/patients/patient-profile/SummaryCard.vue';
import EncounterDialog from '@/components/medical-records/encounter-notes/EncounterDialog.vue';
import { usePatientMedicalSummariestore, usePatientStore, usePractitionerSearchStore, useFacilityStore } from '@/store';
import { IEncounterPayload, IPatientMedicalSummary } from '@/types';

const { getPatientMedicalSummaries } = usePatientMedicalSummariestore();
const patientStore = usePatientStore();
const practitionerSearchStore = usePractitionerSearchStore();
const facilityStore = useFacilityStore();

const panel = ref<number | undefined>();
const summaryCard = ref<IPatientMedicalSummary[]>([]);
const isEncounterDialog = ref<boolean>(false);
const selectedEncounter = ref<IEncounterPayload>();

const props = defineProps({
  openByDefault: {
    type: Boolean,
    required: false,
  },
});


const create = () => {
  selectedEncounter.value = undefined;
  isEncounterDialog.value = true;
};

const loadPractitioners = async () => {
  await practitionerSearchStore.searchPractitioners({
    fuuid: facilityStore.currentFacilityId!,
  });
};

watch(() => patientStore.currentPatientId, async (val) => {
  summaryCard.value = await getPatientMedicalSummaries(val!);
  summaryCard.value.sort((a, b) => {
    if(new Date(a.encounter_date) < new Date(b.encounter_date)) return -1;
    else if(new Date(a.encounter_date) > new Date(b.encounter_date)) return 1;
    else return 0;
  });
}, { immediate: true });

onMounted(() => {
  if(props.openByDefault) {
    panel.value = 0;
  }

  loadPractitioners();
});
</script>

<style lang="scss" scoped></style>
