<template>
  <div>
    <expansion-panel
      :title="$t('patient.upload_documents')"
      icon="attachment"
      v-model="panel"
    >
      <template #content>
        <div class="w-full">
          <upload-file-field v-model="files" :upload-loading="loading" />
          <div class="upload-button-wrapper d-flex justify-end">
            <btn
              v-if="files && files?.length > 0"
              icon="mdi-cloud"
              class="upload-button mt-4"
              :loading="loading"
              @click="upload"
            >
              {{ $t('patient.upload') }}
            </btn>
          </div>
        </div>
        <uploaded-documents-table ref="UploadDocumentsTableRef" class="px-0" />
      </template>
    </expansion-panel>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, computed, ComputedRef } from 'vue';
import UploadFileField from '@/components/common/UploadFileField.vue';
import UploadedDocumentsTable from '@/components/common/UploadedDocumentsTable.vue';
import {
  usePatientStore,
  usePatientDocumentsStore,
  useCommonStore,
} from '@/store';
import { ToastType } from '@/types';
import { useI18n } from 'vue-i18n';

const patientStore = usePatientStore();
const commonStore = useCommonStore();
const { UploadPatientDocument } = usePatientDocumentsStore();

const { t } = useI18n();

const panel = ref<number | undefined>();
const loading = ref<boolean>(false);
const files = ref<File[]>([]);
const UploadDocumentsTableRef = ref();

const currentPatientId: ComputedRef<string | null> = computed(() => {
  return patientStore.currentPatientId;
});

const upload = async () => {
  loading.value = true;
  let form = new FormData();

  form.append('patient', currentPatientId.value!);
  form.append('file', files.value[0]);
  form.append('document_subtype', 'other');

  await UploadPatientDocument(form, currentPatientId.value!);

  commonStore.showToast(ToastType.Success, t('notifications.file_uploaded'));
  files.value = [];
  loading.value = false;

  UploadDocumentsTableRef.value?.initialDocumentsLoad();
};

onMounted(() => {
  if (patientStore.currentPatientId) {
    patientStore.getCurrentPatient();
  }
});
</script>

<style lang="scss" scoped></style>
