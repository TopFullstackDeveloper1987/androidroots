<template>
  <div>
    <expansion-panel
      :title="$t('layouts.procedures')"
      icon="laboratory-drug-file"
      v-model="panel"
    >
      <template #title-content>
        <btn class="ml-3 my-2" icon="mdi-plus" max-width="200" icon-before @click="create"> {{ $t('medical_records.procedures.new_procedure') }} </btn>
      </template>
      <template #content>
        <procedures-table @edit="edit" />
      </template>
    </expansion-panel>
    <ProcedureDialog
      v-model="isProcedureDialog"
      :item="selectedProcedure"
      :practitioners="practitionerSearchStore.practitioners"
    />
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue';
import ProceduresTable from '@/components/medical-records/procedures/ProceduresTable.vue';
import ProcedureDialog from '@/components/medical-records/procedures/ProcedureDialog.vue';
import { useFacilityStore, usePractitionerSearchStore } from '@/store';
import { IProcedure } from '@/types';

const facilityStore = useFacilityStore();
const practitionerSearchStore = usePractitionerSearchStore();

const panel = ref<number | undefined>();
const isProcedureDialog = ref<boolean>(false);
const selectedProcedure = ref<IProcedure>();

const loadPractitioners = async () => {
  await practitionerSearchStore.searchPractitioners({
    fuuid: facilityStore.currentFacilityId!,
  });
};

const create = () => {
  selectedProcedure.value = undefined;
  isProcedureDialog.value = true;
};

const edit = (payload: IProcedure) => {
  selectedProcedure.value = payload;
  isProcedureDialog.value = true;
};

onMounted(() => {
  loadPractitioners();
});

</script>

<style lang="scss" scoped></style>
