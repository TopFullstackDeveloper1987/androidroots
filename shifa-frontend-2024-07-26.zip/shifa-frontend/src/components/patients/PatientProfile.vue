<template>
  <div v-if="!isEmpty(patientRecord)">
    <v-card v-if="props.vertical" :loading="loading" class="pa-6">
      <span class="text-h5">{{ $t('patient_record.medical_history') }}</span>
      <v-divider class="mt-2" />
      <expansion-panel
        :title="$t('layouts.encounter_history')"
        icon="medical-notes"
        v-model="panels.encounter_notes"
        no-border
        no-padding
      >
        <template #title-content>
          <div class="d-flex align-center">
            <btn
              icon="$add"
              icon-only
              :primary="false"
              size="small"
              variant="text"
              color="secondary"
              @click="addUpdateEncounterSummaryAlert"
            />

            <v-badge
              v-if="
                patientRecord.encounters &&
                patientRecord.encounters.length
              "
              class="ml-4"
              :content="patientRecord.encounters.length"
              color="error"
            />
          </div>
        </template>
        <template #content>
          <div
            v-for="(encounterSummary, index) in patientRecord.encounters"
            :key="index"
            class="d-flex justify-space-between align-center"
          >
              <v-list
                v-if="encounterSummary.encounter_complaints.length
                ||
                encounterSummary.encounter_observations.length
                ||
                encounterSummary.encounter_procedures.length
                ||
                encounterSummary.medical_orders.length"
              >
                <v-list-subheader>{{ formatDate(encounterSummary?.encounter_date?.toString()) }}</v-list-subheader>

                <v-list-item
                  v-for="(item, i) in encounterSummary.encounter_complaints"
                  :key="i"
                  :value="item"
                  color="primary"
                  rounded="shaped"
                  class="ml-5"
                  density="compact"
                >

                  <v-list-item-title class="text-subtitle-2">{{ item.complaint }}</v-list-item-title>
                </v-list-item>
                <v-list-item
                  v-for="(item, i) in encounterSummary.encounter_observations"
                  :key="i"
                  :value="item"
                  color="primary"
                  rounded="shaped"
                  class="ml-5"
                  density="compact"
                >
                  <v-list-item-title class="text-subtitle-2">{{ item.observation }}</v-list-item-title>
                </v-list-item>
                <v-list-item
                  v-for="(item, i) in encounterSummary.encounter_diagnosis"
                  :key="i"
                  :value="item"
                  color="primary"
                  rounded="shaped"
                  class="ml-5"
                  density="compact"
                >

                  <v-list-item-title class="text-subtitle-2">{{ item.diagnosis }}</v-list-item-title>
                </v-list-item>
                <v-list-item
                  v-for="(item, i) in encounterSummary.encounter_procedures"
                  :key="i"
                  :value="item"
                  color="primary"
                  rounded="shaped"
                  class="ml-5"
                  density="compact"
                >
                  <v-list-item-title class="text-subtitle-2">{{ item.procedure }}</v-list-item-title>
                </v-list-item>
                <v-list-item
                  v-for="(item, i) in medicationOrders(encounterSummary.medical_orders)"
                  :key="i"
                  :value="item"
                  color="primary"
                  rounded="shaped"
                  class="ml-5"
                  density="compact"
                >

                  <v-list-item-title class="text-subtitle-2">{{ item }}</v-list-item-title>
                </v-list-item>
              </v-list>
          </div>
        </template>
      </expansion-panel>
      <v-divider />
      <expansion-panel
        :title="$t('patient_record.psh')"
        :title-tooltip="$t('patient_record.past_surgical_history')"
        icon="medical-personnel-info"
        v-model="panels.past_surgical_history"
        no-border
        no-padding
      >
        <template #title-content>
          <div class="d-flex align-center">
            <btn
              icon="$add"
              icon-only
              :primary="false"
              size="small"
              variant="text"
              color="secondary"
              @click="addPastSurgicalHistory"
            />

            <v-badge
              v-if="
                patientRecord.patient_surgical_history &&
                patientRecord.patient_surgical_history.length
              "
              class="ml-4"
              :content="patientRecord.patient_surgical_history.length"
              color="error"
            />
          </div>
        </template>
        <template #content>
          <div
            v-for="(patient_surgical_history, index) in patientRecord.patient_surgical_history"
            :key="index"
            class="d-flex justify-space-between align-center"
          >
            <span class="text-h6 text-secondary font-weight-medium text-subtitle-2">
              {{ patient_surgical_history && patient_surgical_history.surgery_name }}
              <span class="text-caption">({{ formatDate(patient_surgical_history?.surgery_date) }})</span>
            </span>
            <EditDelete
              @edit="editPastSurgicalHistory(patient_surgical_history)"
              @delete="openPastSurgicalDeleteDialog(patient_surgical_history)"
            />
          </div>
        </template>
      </expansion-panel>
      <v-divider />
      <expansion-panel
        :title="$t('patient_record.family_history')"
        icon="medical-personnel-info"
        v-model="panels.patient_family_history"
        no-border
        no-padding
      >
        <template #title-content>
          <div class="d-flex align-center">
            <btn
              icon="$add"
              icon-only
              :primary="false"
              size="small"
              variant="text"
              color="secondary"
              @click="addFamilyHistory"
            />

            <v-badge
              v-if="
                patientRecord.patient_family_history &&
                patientRecord.patient_family_history.length
              "
              class="ml-4"
              :content="patientRecord.patient_family_history.length"
              color="error"
            />
          </div>
        </template>
        <template #content>
          <div
            v-for="(patient_family_history, index) in patientRecord.patient_family_history"
            :key="index"
            class="d-flex justify-space-between align-center"
          >
            <span class="text-h6 text-secondary font-weight-medium text-subtitle-2 text-capitalize">
              {{ patient_family_history && patient_family_history.condition_name }}
              <span class="text-caption">({{ patient_family_history.relationship }})</span>
            </span>
            <EditDelete
              @edit="editFamilyHistory(patient_family_history)"
              @delete="openFamilyHistoryDeleteDialog(patient_family_history)"
            />
          </div>
        </template>
      </expansion-panel>
      <v-divider />
      <expansion-panel
        :title="$t('layouts.medications')"
        icon="medical-personnel-info"
        v-model="panels.medications"
        no-border
        no-padding
      >
        <template #title-content>
          <div class="d-flex align-center">
            <btn
              icon="$add"
              icon-only
              :primary="false"
              size="small"
              variant="text"
              color="secondary"
              @click="addUpdateMedicationAlert"
            />

            <v-badge
              v-if="
                patientRecord.medication_orders &&
                patientRecord.medication_orders.length
              "
              class="ml-4"
              :content="patientRecord.medication_orders.length"
              color="error"
            />
          </div>
        </template>
        <template #content>
          <div
            v-for="(medication_order, index) in medicationOrders(patientRecord.medication_orders)"
            :key="index"
            class="d-flex justify-space-between align-center"
          >
            <span class="text-h6 text-secondary font-weight-medium text-subtitle-2">
              {{ medication_order }}
            </span>
            <EditDelete
              @edit="addUpdateMedicationAlert"
              @delete="addUpdateMedicationAlert"
            />
          </div>
        </template>
      </expansion-panel>
      <v-divider />
      <expansion-panel
        :title="$t('patient_record.vitals')"
        icon="medical-files-medical-check"
        v-model="panels.vitals"
        no-border
        no-padding
      >
        <template #content>
          <div class="apart text-h6 text-secondary font-weight-medium text-subtitle-2">
            <div>
              {{ $t('patient_record.pulse_rate') }}:
              {{ 'patientRecord.pulse_rate' }}
            </div>
            <EditDelete />
          </div>
          <div class="apart text-h6 text-secondary font-weight-medium text-subtitle-2">
            <div>
              {{ $t('patient_record.body_height') }}:
              {{ 'patientRecord.body_height' }}
            </div>
            <EditDelete />
          </div>
          <div class="apart text-h6 text-secondary font-weight-medium text-subtitle-2">
            <div>
              {{ $t('patient_record.blood_pressure') }}:
              {{ 'patientRecord.blood_pressure' }}
            </div>
            <EditDelete />
          </div>
          <div class="apart text-h6 text-secondary font-weight-medium text-subtitle-2">
            <div>
              {{ $t('patient_record.oxigen_sat') }}:
              {{ 'patientRecord.oxigen_sat' }}
            </div>
            <EditDelete />
          </div>
          <div class="apart text-h6 text-secondary font-weight-medium text-subtitle-2">
            <div>
              {{ $t('patient_record.body_weight') }}:
              {{ 'patientRecord.body_weight' }}
            </div>
            <EditDelete />
          </div>
          <div class="apart text-h6 text-secondary font-weight-medium text-subtitle-2">
            <div>
              {{ $t('patient_record.bmi_index') }}:
              {{ 'patientRecord.bmi_index' }}
            </div>
            <EditDelete />
          </div>
        </template>
      </expansion-panel>
      <v-divider />
      <div class="mt-4 text-h5 text-secondary">
        {{ $t('patient_record.messages') }}
      </div>
      <text-field
        class="mt-3"
        append-inner-icon="mdi-send"
        :label="$t('patient_record.write_message')"
      >
      </text-field>
    </v-card>
    <v-card v-else class="pa-3 d-flex flex-wrap">
      <div class="user-pic-container-large">
        <img
          v-if="patientRecord.image"
          :src="patientRecord.image"
          :alt="patientRecord.first_name"
        />
        <SvgLoader
          v-else
          :mdi-icon="
            patientRecord.gender && patientRecord.gender.code == 'M'
              ? 'mdi-face-man'
              : 'mdi-face-woman'
          "
        />
      </div>
      <div class="ml-4">
        <div class="d-flex align-center">
          <router-link :to="`/patients/${patientRecord.id}/profile`" class="text-h5 text-secondary patient-name">{{ patientRecord.id && patientRecord.first_name + ' ' + patientRecord.last_name }}</router-link>
          <v-chip
            v-if="patientRecord.gender && patientRecord.gender.code"
            size="x-small"
            class="ml-3"
            :color="patientRecord.gender.code == 'M' ? 'primary' : 'error'"
          >
            {{
              patientRecord.gender.code == 'M'
                ? $t('patient.male')
                : $t('patient.female')
            }}
          </v-chip>
        </div>
        <div class="text-body-1 text-disabled mt-n1">
          {{ patientAge }} {{ $t('patient.years') }}
        </div>
        <div class="mt-n2 ml-n3">
          <btn
            icon="$info"
            icon-only
            :primary="false"
            size="small"
            variant="text"
            color="primary"
          >
          </btn>
          <btn
            icon="$chat"
            icon-only
            :primary="false"
            size="small"
            variant="text"
            color="primary"
          >
            <v-tooltip activator="parent" location="top"> Notes </v-tooltip>
          </btn>
          <btn
            icon="$smoking"
            icon-only
            :primary="false"
            size="small"
            variant="text"
            color="primary"
          >
            <v-tooltip activator="parent" location="top">
              {{
                patientRecord.smoking_status &&
                patientRecord.smoking_status.name
              }}
            </v-tooltip>
          </btn>
          <btn
            icon="$wine"
            icon-only
            :primary="false"
            size="small"
            variant="text"
            color="primary"
          >
            <v-tooltip activator="parent" location="top">
              {{
                patientRecord.drinking_status &&
                patientRecord.drinking_status.name
              }}
            </v-tooltip>
          </btn>
        </div>
      </div>
      <v-divider vertical class="mx-6" />
      <div>
        <router-link :to="`/patients/${patientRecord.id}/profile`" class="text-h6 text-secondary font-weight-medium patient-health-id">{{ patientRecord.health_id_formatted }}</router-link>
        <div class="text-body-1 text-disabled">
          {{ $t('patient_record.last_visit') }}:
          {{ patientRecord.last_visit || $t('common.unknown') }}
        </div>
        <div class="text-h6 text-secondary font-weight-medium">
          {{
            patientRecord.preferred_language &&
            patientRecord.preferred_language.name
          }}
        </div>
      </div>
      <v-divider vertical class="mx-6" />
      <div class="d-flex align-center allergies-container">
        <SvgLoader icon="medical-notes-4" />

        <div class="ml-4">
          <div class="text-h5 text-secondary">
            {{ $t('patient_record.allergies') }}
          </div>
          <div class="d-flex align-center mt-n1">
            <v-chip
              v-for="(allergy, index) in patientRecord.patient_allergies"
              :key="index"
              size="x-small"
              color="warning"
              close-icon="mdi-close"
              class="mr-1"
            >
              {{ allergy.allergy && allergy.allergy.name }}
              <v-icon
                icon="mdi-close"
                @click="openAllergyDeleteDialog(allergy)"
              ></v-icon>
            </v-chip>
            <btn
              icon="$add"
              icon-only
              :primary="false"
              size="x-small"
              variant="text"
              color="secondary"
              @click="addAllergy"
            />
          </div>
        </div>
      </div>
      <v-divider vertical class="mx-6" />
      <div class="d-flex align-center flags-container">
        <SvgLoader icon="medical-personnel-info" />

        <div class="ml-4">
          <div class="text-h5 text-secondary">
            {{ $t('patient_record.alerts') }}
          </div>
          <div class="d-flex align-center mt-n1">
            <v-chip
              v-for="(flag, index) in patientRecord.patient_flags"
              :key="index"
              size="x-small"
              color="warning"
              class="mr-1"
            >
              {{ flag.flag && flag.flag.name }}
              <v-icon
                icon="mdi-close"
                @click="openAlertDeleteDialog(flag)"
              ></v-icon>
            </v-chip>
            <btn
              icon="$add"
              icon-only
              :primary="false"
              size="x-small"
              variant="text"
              color="secondary"
              @click="addAlert"
            />
          </div>
        </div>
      </div>
      <div v-if="showToggle" class="ml-auto">
        <div class="d-flex align-center">
          <!-- <div class="bordered-min action-icon centered cursor-pointer">
            <v-icon icon="$email" />
          </div>
          <div class="bordered-min action-icon centered cursor-pointer ml-3">
            <v-icon icon="$phone" />
          </div> -->
        </div>
        <div
          @click="$emit('toggle')"
          class="mt-1 bordered-min action-icon centered cursor-pointer"
        >
          <v-icon icon="mdi-menu" />
        </div>
      </div>
    </v-card>
    <AllergyDialog
      v-model="showAllergyDialog"
      :allergy="currentAllergy"
      :is-create-action="isCreateAction"
      :added-allergies="patientRecord.patient_allergies"
      @refresh="getMedicalRecord"
    />
    <AlertDialog
      v-model="showAlertDialog"
      :alert="currentAlert"
      :is-create-action="isCreateAction"
      :added-alerts="patientRecord.patient_flags"
      @refresh="getMedicalRecord"
    />
    <PastSurgicalHistoryDialog
      v-model="showSurgicalHistoryDialog"
      :surgery="currentSurgicalHistory"
      :is-create-action="isCreateAction"
      :added-surgeries="patientRecord.patient_surgical_history"
      @refresh="getMedicalRecord"
    />
    <FamilyHistoryDialog
      v-model="showFamilyHistoryDialog"
      :family-history="currentFamilyHistory"
      :is-create-action="isCreateAction"
      :added-family-histories="patientRecord.patient_family_history"
      @refresh="getMedicalRecord"
    />
    <BaseConfirmationDialog
      v-model="showDeleteDialog"
      :message="$t('common.are_you_sure_you_want_to_delete_this')"
      :type="DialogType.Warning"
      color="warning"
      @submit="deleteAlertAllergy"
    />
    <BaseConfirmationDialog
      v-model="showSurgicalHistoryDeleteDialog"
      :message="$t('common.are_you_sure_you_want_to_delete_this')"
      :type="DialogType.Warning"
      color="warning"
      @submit="deleteSurgicalHistory"
    />
    <BaseConfirmationDialog
      v-model="showFamilyHistoryDeleteDialog"
      :message="$t('common.are_you_sure_you_want_to_delete_this')"
      :type="DialogType.Warning"
      color="warning"
      @submit="deleteFamilyHistory"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, watch, computed, WritableComputedRef, onMounted, onBeforeUnmount } from 'vue';
import moment from 'moment-timezone';
import SvgLoader from '@/components/common/SvgLoader.vue';
import EditDelete from '@/components/common/EditDelete.vue';
import {
  useCommonStore,
  usePatientStore,
  usePatientRecordStore,
  usePatientMedicalSummariestore,
} from '@/store';
import AllergyDialog from '@/components/patients/AllergyDialog.vue';
import AlertDialog from '@/components/patients/AlertDialog.vue';
import PastSurgicalHistoryDialog from '@/components/patients/PastSurgicalHistoryDialog.vue';
import FamilyHistoryDialog from '@/components/patients/FamilyHistoryDialog.vue';
import BaseConfirmationDialog from '@/components/common/BaseConfirmationDialog.vue';
import {
  IPatientAllergy,
  IPatientAlert,
  IPatientRecord,
  ToastType,
  IPatientSurgicalHistory,
  IPatientFamilyHistory,
  DialogType,
  IEncounter,
  IEncounterMedicationOrder,
  ConfigurationEvents,
} from '@/types';
import isEmpty from 'lodash/isEmpty';

import { useI18n } from 'vue-i18n';
import { forEach } from 'lodash';
import { events } from '@/events';

const commonStore = useCommonStore();
const patientStore = usePatientStore();
const patientRecordStore = usePatientRecordStore();
const patientMedicalSummariestore = usePatientMedicalSummariestore();

const props = defineProps({
  vertical: {
    type: Boolean,
    default: false,
  },
  showToggle: {
    type: Boolean,
    default: true,
  },
});

const { t } = useI18n();

const loading = ref<boolean>(false);
const deleting = ref<any>(false);
const showSurgicalHistoryDialog = ref<boolean>(false);
const showFamilyHistoryDialog = ref<boolean>(false);
const showAllergyDialog = ref<boolean>(false);
const showAlertDialog = ref<boolean>(false);
const showAlertDeleteDialog = ref<boolean>(false);
const showAllergyDeleteDialog = ref<boolean>(false);
const showSurgicalHistoryDeleteDialog = ref<boolean>(false);
const showFamilyHistoryDeleteDialog = ref<boolean>(false);
const showDeleteDialog = ref<boolean>(false);
const isCreateAction = ref<boolean>(true);
const panels = ref<{
  allergies?: number;
  alerts?: number;
  vitals?: number;
  past_surgical_history?: number;
  patient_family_history?: number;
  medications?: number;
  encounter_notes?: number;
}>({});
const currentAllergy = ref<IPatientAllergy>(<IPatientAllergy>{});
const currentAlert = ref<IPatientAlert>(<IPatientAlert>{});
const currentSurgicalHistory = ref<IPatientSurgicalHistory>(<IPatientSurgicalHistory>{});
const currentFamilyHistory = ref<IPatientFamilyHistory>(<IPatientFamilyHistory>{});
const encounterSummaries = ref<IEncounter[]>([]);

const currentPatientId = computed(() => {
  return patientStore.currentPatientId;
});

const patientRecord: WritableComputedRef<IPatientRecord> = computed(() => {
  return patientRecordStore.patientRecord || <IPatientRecord>{};
});

const patientAge: WritableComputedRef<number> = computed(() => {
  const today = moment(new Date());
  const dob = moment(patientRecord.value.date_of_birth);
  return today.diff(dob, 'years');
});

watch(currentPatientId, async () => {
  getMedicalRecord();
});

const formatDate = (date: string) => {
  return date ? moment.utc(date).format('YYYY-MM-DD') : null;
};

const medicationOrders = (orders: IEncounterMedicationOrder[]) => {
  let medications: string[] = [];
  forEach(orders, medical_order => {
    forEach(medical_order.medication_order_items, medication_order_item => {
      medications.push(medication_order_item.medication.name || medication_order_item.medication_name!);
    });
  });

  return medications;
};

const addUpdateMedicationAlert = () => {
  commonStore.showToast(ToastType.Warning, t('patient_record.new_medical_prescribe_alert'));
};

const addUpdateEncounterSummaryAlert = () => {
  commonStore.showToast(ToastType.Warning, t('patient_record.new_encounter_summary_alert'));
};

const getMedicalRecord = () => {
  if (!currentPatientId.value) return;
  loading.value = true;
  patientRecordStore
    ?.getPatientRecord(currentPatientId.value)
    .then(() => {})
    .finally(() => {
      loading.value = false;
    });
};

const deleteAlertAllergy = () => {
  if (showAlertDeleteDialog.value) {
    deleteAlert();
  } else {
    deleteAllergy();
  }
};

watch(
  () => showDeleteDialog.value,
  (val) => {
    if (!val) {
      showAlertDeleteDialog.value = false;
      showAllergyDeleteDialog.value = false;
    }
  },
);

watch(
  () => showSurgicalHistoryDialog.value,
  (val) => {
    if (!val) {
      currentSurgicalHistory.value = null!;
    }
  },
);

watch(
  () => showFamilyHistoryDialog.value,
  (val) => {
    if (!val) {
      currentFamilyHistory.value = null!;
    }
  },
);

const addAllergy = () => {
  currentAllergy.value = Object.assign({}, <IPatientAllergy>{});
  isCreateAction.value = true;
  showAllergyDialog.value = true;
};

const addPastSurgicalHistory = () => {
  isCreateAction.value = true;
  currentSurgicalHistory.value = null!;
  showSurgicalHistoryDialog.value = true;
};

const addFamilyHistory = () => {
  isCreateAction.value = true;
  currentFamilyHistory.value = null!;
  showFamilyHistoryDialog.value = true;
};


const editAllergy = (allergy: IPatientAllergy) => {
  currentAllergy.value = Object.assign({}, allergy);
  isCreateAction.value = false;
  showAllergyDialog.value = true;
};

const editPastSurgicalHistory = (surgicalHistory: IPatientSurgicalHistory) => {
  currentSurgicalHistory.value = Object.assign({}, surgicalHistory);
  isCreateAction.value = false;
  showSurgicalHistoryDialog.value = true;
};

const editFamilyHistory = (familyHistory: IPatientFamilyHistory) => {
  currentFamilyHistory.value = Object.assign({}, familyHistory);
  isCreateAction.value = false;
  showFamilyHistoryDialog.value = true;
};

const deleteAllergy = async () => {
  deleting.value = currentAllergy.value.id;
  await patientRecordStore.deletePatientAllergy(currentAllergy.value);
  commonStore.showToast(ToastType.Success, t('notifications.allergy_deleted'));
  deleting.value = null;
  getMedicalRecord();
  showAllergyDeleteDialog.value = false;
  showDeleteDialog.value = false;
};

const deleteSurgicalHistory = async () => {
  deleting.value = currentSurgicalHistory.value.id;
  await patientRecordStore.deletePastSurgeryHistory(currentSurgicalHistory.value);
  deleting.value = null;
  getMedicalRecord();
  showSurgicalHistoryDialog.value = false;
  showDeleteDialog.value = false;
};

const deleteFamilyHistory = async () => {
  deleting.value = currentFamilyHistory.value.id;
  await patientRecordStore.deleteFamilyHistory(currentFamilyHistory.value);
  deleting.value = null;
  getMedicalRecord();
  showFamilyHistoryDeleteDialog.value = false;
};

const openPastSurgicalDeleteDialog = (surgery: IPatientSurgicalHistory) => {
  currentSurgicalHistory.value = surgery;
  showSurgicalHistoryDeleteDialog.value = true;
};

const openFamilyHistoryDeleteDialog = (familyHistory: IPatientFamilyHistory) => {
  currentFamilyHistory.value = familyHistory;
  showFamilyHistoryDeleteDialog.value = true;
};

const openAllergyDeleteDialog = (allergy: IPatientAllergy) => {
  currentAllergy.value = allergy;
  showAllergyDeleteDialog.value = true;
  showDeleteDialog.value = true;
};

const addAlert = () => {
  currentAlert.value = Object.assign({}, <IPatientAlert>{});
  isCreateAction.value = true;
  showAlertDialog.value = true;
};

const editAlert = (alert: IPatientAlert) => {
  currentAlert.value = Object.assign({}, alert);
  isCreateAction.value = false;
  showAlertDialog.value = true;
};

const deleteAlert = async () => {
  deleting.value = currentAlert.value.id;
  await patientRecordStore.deletePatientAlert(currentAlert.value);
  commonStore.showToast(ToastType.Success, t('notifications.alert_deleted'));
  deleting.value = null;
  getMedicalRecord();
  showAlertDeleteDialog.value = false;
  showDeleteDialog.value = false;
};

const openAlertDeleteDialog = (alert: IPatientAlert) => {
  currentAlert.value = alert;
  showAlertDeleteDialog.value = true;
  showDeleteDialog.value = true;
};

onMounted(async () => {
  bindEventHandlers();

  panels.value.past_surgical_history = 0;
  panels.value.patient_family_history = 0;
  panels.value.medications = 0;
  panels.value.encounter_notes = 0;

  getMedicalRecord();
});

onBeforeUnmount(() => {
  unbindEventHandlers();
});

const bindEventHandlers = () => {
  events.on(ConfigurationEvents.ReloadCustomEncounters, getMedicalRecord);
};

const unbindEventHandlers = () => {
  events.off(ConfigurationEvents.ReloadCustomEncounters, getMedicalRecord);
};
</script>

<style scoped lang="scss">
.action-icon {
  width: 40px !important;
  height: 40px;
}

.flags-container {
  @media (min-width: 839px) {
    margin-bottom: 28px;
  }

  @media (max-width: 839px) {
    margin-top: 28px;
  }
}

.patient-name, .patient-health-id {
  text-decoration: none;
}

.allergies-container {
  @media (min-width: 839px) {
    margin-bottom: 28px;
  }

  @media (max-width: 839px) {
    margin-top: 28px;
  }
}
</style>
