<template>
  <form-dialog v-model="isShowDialog" @submit="save">
    <template v-slot:header>
      <div class="text-primary">
        {{
          isCreateAction ? $t('patient_record.add_family_history') : $t('patient_record.edit_family_history')
        }}
      </div>
    </template>
    <v-row>
      <v-col cols="12">
        <combo-box
          v-model="formData.condition"
          :items="conditions"
          :rules="[required]"
          item-title="name"
          item-value="id"
          :return-object="false"
          :label="$t('patient_record.family_history')"
          attr="alert"
        />
      </v-col>
      <v-col cols="12">
        <select-field
          v-model="formData.relationship"
          :items="relationsMock"
          :rules="[required]"
          item-title="title"
          item-value="value"
          :label="$t('patient_record.relation')"
          attr="alert"
        />
      </v-col>
      <v-col cols="12">
        <text-area
          v-model="formData.notes"
          :label="$t('patient.notes')"
          attr="notes"
          :rows="4"
        />
      </v-col>
    </v-row>
  </form-dialog>
</template>

<script setup lang="ts">
import {
  ref,
  computed,
  onMounted,
  WritableComputedRef,
  PropType,
  watch,
} from 'vue';
import { required } from '@/utils/validations';
import {
  usePatientStore,
  usePatientRecordStore,
} from '@/store';
import { relationsMock } from '@/constants';
import { IAlert, IPatientFamilyHistory } from '@/types';
import { isNumber } from 'lodash';
// import { useI18n } from 'vue-i18n';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  familyHistory: {
    type: Object as PropType<IPatientFamilyHistory>,
    default: () => {},
  },
  addedFamilyHistories: {
    type: Array as PropType<IPatientFamilyHistory[]>,
    default: () => [],
  },
  isCreateAction: {
    type: Boolean,
    default: true,
  },
});

const patientStore = usePatientStore();
const patientRecordStore = usePatientRecordStore();

// const { t } = useI18n();

const emit = defineEmits(['update:modelValue', 'refresh']);

const formData = ref<IPatientFamilyHistory>(<IPatientFamilyHistory>{});

watch(
  () => props.modelValue,
  (newValue) => {
    if (newValue)
      if (props?.familyHistory?.id)
        formData.value = {
          id: props?.familyHistory?.id,
          condition: props.familyHistory.condition,
          relationship: props.familyHistory.relationship,
          notes: props.familyHistory.notes,
          patient: props.familyHistory.patient,
        };
      else
        formData.value = {
          patient: '',
          condition: null!,
          relationship: null!,
          notes: null!,
        };
  },
);

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

watch(() => isShowDialog.value, async (val) => {
  if(patientStore.currentPatientId && val) {
    await patientRecordStore.getFamilyHistories();
  }
});

const conditions: WritableComputedRef<IPatientFamilyHistory[] | undefined> = computed(() => {
  let tempFamilyHistories = props.addedFamilyHistories.map(
    (familyHistory: IPatientFamilyHistory) => familyHistory?.condition,
  );

  if(props.isCreateAction)
    return patientRecordStore.familyHistories.filter(
      (familyHistory: IPatientFamilyHistory) => !tempFamilyHistories.includes(familyHistory.id!),
    );

  return patientRecordStore.familyHistories;
});

onMounted(async () => {
  if(patientStore.currentPatientId) {
    await patientRecordStore.getAlerts();
  }
});

const save = async () => {
  const payload = formData.value;

  if(!isNumber(formData.value.condition)) {
    payload.condition_name = formData.value.condition!;
    payload.condition = null!;
  }

  if (props.familyHistory?.id) {
    await patientRecordStore.updatePatientFamilyHistory(payload);
  } else {
    formData.value.patient = patientStore.currentPatientId!;
    await patientRecordStore.addPatientFamilyHistory(payload);
  }

  emit('refresh');
  isShowDialog.value = false;
};
</script>

<style scoped></style>
