<template>
  <card-container class="w-100 pb-4 pr-4">
    <div class="d-flex align-center ml-4 mb-2">
      <select-field
        :items="childrenGenderMock"
        v-model="gender"
        class="mr-4 gender-select"
      />

      <select-field
        :items="childrenGrowthMetricMock"
        v-model="metric"
        class="flex-1-1"
      />
    </div>

    <line-chart
      v-if="!!chartData"
      :chart-options="chartOptions"
      :chart-data="chartData"
      :height="300"
      class="px-2"
    />
  </card-container>
</template>

<script setup lang="ts">
import { PropType, computed, ref, watch } from 'vue';

import LineChart from '@/components/charts/LineChart.vue';
import {
  IMetaDataChildGrowthPercentile,
  IMetaDataChildGrowthPercentileQuery,
  IPatientMeasureTableValue,
} from '@/types';
import { childrenGenderMock, childrenGrowthMetricMock } from '@/constants';
import { useMetaDataStore } from '@/store';
import { extractNumber } from '@/utils';

const metadataStore = useMetaDataStore();

const props = defineProps({
  measures: {
    type: Array as PropType<IPatientMeasureTableValue[]>,
    required: true,
  },
});

const chartOptions = {};

const gender = ref<string>(childrenGenderMock[0].value);
const metric = ref<string>(childrenGrowthMetricMock[0].value);
const childGrowthPercentiles = ref<IMetaDataChildGrowthPercentile[]>([]);

const ageMeasure = computed(() =>
  props.measures.find((measure) => measure.name === 'Age'),
);
const otherMeasures = computed(() =>
  props.measures.filter((measure) => measure.name !== 'Age'),
);

const chartData = computed(() => {
  if (!ageMeasure.value || childGrowthPercentiles.value.length === 0) {
    return null;
  }

  const measure = otherMeasures.value.find((m) =>
    metric.value.includes(m.name.replaceAll(' ', '_').toLowerCase()),
  );
  if (!measure) {
    return null;
  }

  const dates = Object.keys(ageMeasure.value)
    .filter((key) => isDateString(key))
    .sort();
  const weeks = dates.map((date) => ageMeasure.value![date]);
  const measureValues = dates.map((date) => measure[date]);

  const percentiles: Record<string, number[]> = {}; // date: number[]
  const percentileLabels = Object.keys(childGrowthPercentiles.value[0]).filter(
    (key) => key.startsWith('percentile_'),
  );
  percentileLabels.forEach((label) => {
    percentiles[label] = [];
  });

  weeks.forEach((week) => {
    // const growthPercentile = childGrowthPercentiles.value.find(p => p.week + 4 === week); // +4 for test
    const growthPercentile = childGrowthPercentiles.value.find(
      (p) => p.week === week,
    );
    percentileLabels.forEach((label) => {
      const percentileValue = growthPercentile
        ? Number(
            growthPercentile[
              label as string | number as keyof typeof growthPercentile
            ],
          )
        : 0;
      percentiles[label].push(percentileValue);
    });
  });
  const percentileDataSets = Object.entries(percentiles).map(
    ([label, data]) => ({
      label,
      data,
      borderColor: getColorFromPercentile(label),
      borderDash: getBorderDashFromPercentile(label),
      borderWidth: 2,
    }),
  );

  return {
    labels: weeks,
    datasets: [
      {
        label: measure.name,
        // data: [35, 36, 37], // test
        data: measureValues,
        borderColor: '#35a2eb', // blue
        borderWidth: 2,
      },
      ...percentileDataSets,
    ],
  };
});

watch([gender, metric], async () => {
  await getChildGrowthPercentileMetaData();
});

const isDateString = (str: string) => str?.match(/^\d{4}-\d{2}-\d{2}$/);

const getColorFromPercentile = (label: string) => {
  const percent = extractNumber(label);
  const offset = Math.abs(percent - 50);

  if (offset < 25) {
    return '#4bc0c0'; // green
  }

  if (offset < 45) {
    return '#ff9f40'; // orange
  }

  return '#ff6384'; // red
};

const getBorderDashFromPercentile = (label: string) => {
  const percent = extractNumber(label);
  const offset = Math.abs(percent - 50);

  if (offset < 25) {
    return [20, 5];
  }

  if (offset < 45) {
    return [10, 10];
  }

  return [5, 5];
};

const getChildGrowthPercentileMetaData = async () => {
  childGrowthPercentiles.value = await metadataStore.getMetaData<
    IMetaDataChildGrowthPercentileQuery,
    IMetaDataChildGrowthPercentile
  >('child-growth-percentile', {
    gender: gender.value,
    metric: metric.value,
  });
};
</script>

<style scoped lang="scss">
.gender-select {
  flex: 0 0 30%;
}
</style>
