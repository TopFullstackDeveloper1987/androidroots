<template>
  <form-dialog
    v-model="isShowDialog"
    @submit="submit"
    @opened="dialogOpened"
    width="600"
  >
    <template #header>
      {{ item ? $t(`patient_measure.edit_measure`) : $t(`patient_measure.new_measure`) }}
    </template>

    <select-field
      v-model="measureType"
      :items="measureTypes"
      :label="$t('patient_measure.measure_type')"
      :rules="[required]"
      attr="currency"
      class="mb-4"
    />

    <select-field
      v-model="formData.measure"
      :items="measures"
      :label="$t('patient_measure.measure')"
      :rules="[required]"
      class="mb-4"
    />

    <date-picker
      v-model="formData.measure_day"
      :rules="[required]"
      :placeholder="$t('patient_measure.date')"
      :maxDate="date"
      class="mb-4"
    />

    <text-field
      v-model="formData.value"
      :rules="[requiredPositiveNumber]"
      :label="$t('patient_measure.value')"
    />
  </form-dialog>
</template>

<script setup lang="ts">
import { WritableComputedRef, reactive, computed, ref, PropType, ComputedRef, onMounted, watch } from 'vue';
import { usePatientMeasureStore, usePatientStore } from '@/store';
import { IMeasure, IMeasureValue, ISelect } from '@/types';
import { required, requiredPositiveNumber } from '@/utils';
import { useI18n } from 'vue-i18n';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  item: {
    type: Object as PropType<IMeasure>,
    required: false,
  },
});

const emit = defineEmits(['update:modelValue', 'updated', 'submit']);

const loading = ref<boolean>(false);
const formData = reactive<IMeasureValue>(<IMeasureValue>{});
const measures = ref<ISelect<number>[]>();
const date = ref<Date>(new Date());
const measureType = ref<string>('vitals');

const { getPatientMeasures, addPatientMeasure } = usePatientMeasureStore();
const patientStore = usePatientStore();

const { t } = useI18n();

const measureTypes = [
  {
    title: t('patient_measure.gynecology'),
    value: 'gynecology',
  },
  {
    title: t('patient_measure.vitals'),
    value: 'vitals',
  },
];

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const currentPatientId: ComputedRef<string | null> = computed(() => {
  return patientStore.currentPatientId;
});


const dialogOpened = () => {
  formData.measure = null!;
  measureType.value = 'vitals';
  formData.value = '';
  formData.measure_day = null!;
};

const submit = async () => {
  loading.value = true;

  formData.patient = currentPatientId.value!;
  formData.index = measures.value?.findIndex(val => val.value === formData.measure);
  formData.is_abnormal = false;

  const payload = formData;

  await addPatientMeasure(payload);

  loading.value = false;
  emit('submit');
  isShowDialog.value = false;
};

const getMeasures = async () => {
  const { data } = await getPatientMeasures(
      currentPatientId.value!,
      measureType.value!,
  );

  measures.value = data.map(val => {
    return {
      title: val.name,
      value: val.id,
    };
  });
};

watch(() => measureType.value, () => {
  formData.measure = null!;
  getMeasures();
});

onMounted(() => {
  getMeasures();
  date.value.setDate(date.value.getDate() - 2);
});
</script>

<style lang="scss" scoped></style>
