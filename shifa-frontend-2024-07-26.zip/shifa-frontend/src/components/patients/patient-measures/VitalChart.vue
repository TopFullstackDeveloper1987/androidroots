<template>
  <card-container class="w-100">
    <select-field
      :items="names"
      v-model="measureId"
      class="ml-4 mb-2 measure-id-select"
    />

    <bar-chart
      v-if="chartData"
      :chart-options="chartOptions"
      :chart-data="chartData"
      class="px-2"
    />
  </card-container>
</template>

<script setup lang="ts">
import { PropType, computed, ComputedRef, ref, onBeforeMount } from 'vue';

import BarChart from '@/components/charts/BarChart.vue';
import { IPatientMeasureTableValue, ISelect } from '@/types';

const props = defineProps({
  measures: {
    type: Array as PropType<IPatientMeasureTableValue[]>,
    required: true,
  },
});

const chartOptions = {
  scales: {
    y: {
      beginAtZero: true,
    },
  },
};

const chartData = computed(() => {
  const measure = props.measures.find((m) => m.id === measureId.value);
  if (!measure) {
    return null;
  }

  const dates = Object.keys(measure).filter((key) =>
    key.match(/^\d{4}-\d{2}-\d{2}$/),
  );
  const dateValues = dates.map((date) => measure[date]);

  return {
    labels: dates,
    datasets: [
      {
        label: measure.name,
        data: dateValues,
      },
    ],
  };
});

const measureId = ref<number>();
const names: ComputedRef<ISelect<number>[]> = computed(() => {
  return props.measures.map((measure) => ({
    title: measure.name,
    value: measure.id,
  }));
});

onBeforeMount(() => {
  measureId.value = props.measures[0].id;
});
</script>

<style scoped lang="scss">
.measure-id-select {
  width: 200px;
}
</style>
