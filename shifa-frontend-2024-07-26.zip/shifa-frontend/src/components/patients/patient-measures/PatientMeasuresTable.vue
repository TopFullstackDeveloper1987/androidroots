<template>
  <data-table-server
    v-if="!loading"
    class="patient-measures-table"
    :headers="measureHeaders"
    :items="patientMeasureValues"
    :show-search-results-info="false"
    :show-pagination="false"
  >
    <template v-slot:top>
      <div class="d-flex justify-space-between pt-4 pl-4 pr-4">
        <select-field
          :items="measureTypes"
          v-model="measureType"
          item-title="title"
          item-value="key"
          class="measures-type-select max-width-250"
        />
        <btn icon="mdi-plus" :iconBefore="true" primary @click="isShowDialog = true">
          {{ $t('patient_measure.new_measure') }}
        </btn>
    </div>
    </template>

    <template #[`item.measure`]="{ item }">
      <h3 class="pb-0">{{ item?.selectable?.name }}</h3>
      <span class="text-subtitle-2 text-disabled">{{
        item?.selectable?.unit
      }}</span>
    </template>

    <template #[`item.today`]="{ item }">
      <text-field
        v-if="!loading"
        v-model="todaysMeasureValues[item.index].value"
        type="number"
        class="measure-value-input"
        @input.capture="onMeasureValueChange(todaysMeasureValues[item.index])"
      />
    </template>
  </data-table-server>

  <vital-chart v-if="vitalMeasures.length > 0" :measures="vitalMeasures" />

  <gynecology-chart
    v-if="gynecologyMeasures.length > 0"
    :measures="gynecologyMeasures"
  />
  <patient-measures-dialog v-model="isShowDialog" />
</template>
<script setup lang="ts">
import { onMounted, ref, ComputedRef, computed, watch } from 'vue';
import DataTableServer from '@/components/common/DataTableServer.vue';
import _ from 'lodash';
import moment from 'moment-timezone';

import { usePatientStore, usePatientMeasureStore } from '@/store';
import {
  IPatientMeasureValue,
  IMeasureValue,
  IPatientMeasureTableValue,
  ITableHeader,
} from '@/types';
import VitalChart from './VitalChart.vue';
import GynecologyChart from './GynecologyChart.vue';
import PatientMeasuresDialog from './PatientMeasuresDialog.vue';
import { useI18n } from 'vue-i18n';

const { getPatientMeasures, addPatientMeasure } = usePatientMeasureStore();
const patientStore = usePatientStore();

const { t } = useI18n();

const loading = ref<boolean>(true);
const isShowDialog = ref<boolean>(false);
const patientMeasureValues = ref<IPatientMeasureTableValue[]>([]);

const measureType = ref<string>('vitals');

const measureHeaders = ref<ITableHeader[]>([]);

const todaysDate = ref<string>('');

const todaysMeasureValues = ref<IMeasureValue[]>([]);

const currentPatientId: ComputedRef<string | null> = computed(() => {
  return patientStore.currentPatientId;
});

const measureTypes = [
  {
    title: t('patient_measure.gynecology'),
    key: 'gynecology',
  },
  {
    title: t('patient_measure.vitals'),
    key: 'vitals',
  },
];

const patientMeasureValuesRaw: ComputedRef<IPatientMeasureTableValue[]> =
  computed(() => {
    return patientMeasureValues.value.map((measure) => {
      const { today, ...other } = measure;

      if (today) {
        return {
          ...other,
          [moment.utc().format('YYYY-MM-DD')]: today,
        };
      }

      return measure;
    });
  });

const vitalMeasures = computed(() => {
  return measureType.value === 'vitals' ? patientMeasureValuesRaw.value : [];
});

const gynecologyMeasures = computed(() => {
  return measureType.value === 'gynecology'
    ? patientMeasureValuesRaw.value
    : [];
});

watch(
  () => measureType.value,
  () => {
    getAllMeasures();
  },
);

// Adding new measure values for selected patient
const onMeasureValueChange = _.debounce((payload: IMeasureValue) => {
  addPatientMeasure(payload);
}, 750);

const getAllMeasures = async () => {
  loading.value = true;

  // Clearing table column headers, measure values for refetching
  measureHeaders.value = [];
  patientMeasureValues.value = [];
  todaysMeasureValues.value = [];

  if (currentPatientId.value) {
    // Fetching columns and values for patient measurements
    const { column_headers, data } = await getPatientMeasures(
      currentPatientId.value,
      measureType.value,
    );

    // Assigning table column headers
    _.forEach(column_headers, (val: ITableHeader) => {
      measureHeaders.value.push({
        title: val.name,
        name: val.name,
        key:
          todaysDate.value !== val.name
            ? val.name.toLocaleLowerCase()
            : 'today',
        sortable: false,
      });
    });

    // Assigning values
    _.forEach(data, (val: IPatientMeasureValue, index: number) => {
      let dateValueString = val.data.includes(todaysDate.value)
        ? val.data.replaceAll(todaysDate.value, 'today')
        : val.data;
      let dateValueParsed = JSON.parse(dateValueString);

      patientMeasureValues.value.push({
        id: val.id,
        measure_type: val.measure_type,
        name: val.name,
        unit: val.unit,
        ...dateValueParsed,
      });

      // Assigning todays values for editing input
      todaysMeasureValues.value.push({
        measure: val.id,
        value: dateValueParsed['today'],
        is_abnormal: false,
        patient: currentPatientId.value ? currentPatientId.value : undefined,
        index,
      });
    });

    loading.value = false;
  }
};

onMounted(async () => {
  todaysDate.value = moment.utc().format('YYYY-MM-DD');
  await getAllMeasures();
});
</script>
<style lang="scss">
.patient-measures-table {
  padding-right: 0;
  padding-left: 0;
  border-radius: 20px !important;

  .v-select {
    width: 170px;
  }

  th {
    min-width: 117px;
  }

  .measure-value-input {
    width: 150px;
  }
}
</style>
