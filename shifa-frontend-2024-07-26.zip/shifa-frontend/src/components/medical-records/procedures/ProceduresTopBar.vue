<template>
  <div>
    <div class="d-flex justify-space-between mb-3">
      <div class="d-flex flex-1-1">
        <v-chip-group
          v-model="typeValue"
          class="text-primary pt-0"
          selected-class="bg-primary text-white"
        >
          <v-chip
            v-for="{ title, value } of types"
            :key="value"
            variant="outlined"
            size="large"
            :value="value"
          >
            {{ title }}
          </v-chip>
        </v-chip-group>
      </div>

      <div>
        <btn icon="mdi-plus" :iconBefore="true" primary @click="$emit('new')">
          {{ $t('medical_records.procedures.new_procedure') }}
        </btn>
      </div>
    </div>

    <div class="d-flex justify-space-between mb-3">
      <div class="d-flex flex-1-1 flex-wrap">
        <select-field
          :items="statuses"
          v-model="statusValue"
          :label="$t('common.statuses')"
          class="max-width-250 mr-4"
        />

        <select-field
          :items="practitioners"
          :item-title="getPractitionerFullName"
          item-value="id"
          v-model="practitionerIdValue"
          :label="$t('common.practitioners_doctors')"
          class="max-width-250 mr-4"
        />

        <div>
          <date-range-picker v-model="datesValue" class="align-start" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { PropType, computed, WritableComputedRef } from 'vue';

import { IPractitioner, ISelect } from '@/types';

const emit = defineEmits([
  'update:type',
  'update:dates',
  'update:status',
  'update:practitionerId',
  'new',
]);

const props = defineProps({
  types: {
    type: Array as PropType<ISelect<string>[]>,
    default: () => [],
  },
  statuses: {
    type: Array as PropType<ISelect<string | null>[]>,
    default: () => [],
  },
  practitioners: {
    type: Array as PropType<IPractitioner[]>,
    default: () => [],
  },
  type: {
    type: String,
  },
  status: {
    type: String,
  },
  dates: {
    type: Array as PropType<Date[]>,
    default: () => [],
  },
  practitionerId: {
    type: String,
  },
});

const typeValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.type;
  },
  set(value) {
    emit('update:type', value);
  },
});

const datesValue: WritableComputedRef<Date[] | undefined> = computed({
  get() {
    return props.dates;
  },
  set(value) {
    emit('update:dates', value);
  },
});

const statusValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.status;
  },
  set(value) {
    emit('update:status', value);
  },
});

const practitionerIdValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.practitionerId;
  },
  set(value) {
    emit('update:practitionerId', value);
  },
});

const getPractitionerFullName = (practitioner: IPractitioner) =>
  `${practitioner.first_name} ${practitioner.last_name}`;
</script>
