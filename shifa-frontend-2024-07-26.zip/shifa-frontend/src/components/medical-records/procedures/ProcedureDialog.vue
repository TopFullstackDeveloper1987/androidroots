<template>
  <form-dialog
    v-model="isShowDialog"
    max-width="650"
    @submit="submit"
    @opened="dialogOpened"
    :no-click-animation="true"
  >
    <template v-slot:header>
      <div class="text-primary">
        {{ $t('medical_records.procedures.add_new_procedure') }}
      </div>
    </template>

    <div class="text-h6 mb-3">
      {{
        $t('medical_records.procedures.procedure_for', {
          patient: patientStore?.currentPatient?.patient_name,
        })
      }}
    </div>

    <v-row>
      <v-col cols="6">
        <select-field
          v-model="formData.practitioner"
          :items="practitioners"
          :rules="[required]"
          item-title="practitioner_name"
          item-value="id"
          :label="$t('common.practitioner')"
          attr="practitioner"
        />
      </v-col>
      <v-col cols="6">
        <date-picker
          v-model="formData.procedure_date"
          :rules="[required]"
          attr="procedure_date"
          :placeholder="$t('medical_records.procedures.schedule_date')"
        />
      </v-col>
      <v-col cols="6">
        <select-field
          v-model="formData.procedure_status"
          :items="procedureStatuses"
          :rules="[required]"
          item-title="title"
          item-value="value"
          :label="$t('common.status')"
          attr="procedure_status"
        />
      </v-col>
      <v-col cols="6">
        <select-field
          v-model="formData.procedure_type"
          :items="procedureTypes"
          :rules="[required]"
          item-title="title"
          item-value="value"
          :label="$t('common.type')"
          attr="procedure_type"
        />
      </v-col>
      <v-col cols="12">
        <api-auto-complete
          v-model="formData.procedure"
          is-favored
          :rules="[required]"
          item-title="name"
          item-value="id"
          attr="procedure"
          :handler="procedureStore.getProcedureItems"
          :label="$t('medical_records.procedures.select_procedure')"
        />
      </v-col>
      <v-col cols="12">
        <text-area
          v-model="formData.notes"
          :label="$t('patient.notes')"
          attr="notes"
          :rows="4"
        />
      </v-col>
      <v-col cols="12">
        <v-divider />
      </v-col>
      <v-col cols="12">
        <div
          class="mb-4 d-flex"
          v-for="(item, index) in formData.order_items"
          :key="index"
        >
          <api-auto-complete
            v-model="item.product"
            is-favored
            item-title="name"
            item-value="id"
            attr="procedure"
            :handler="productStore.searchProducts"
            :label="$t('medical_records.procedures.select_product')"
          />
          <btn
            size="default"
            icon-only
            :primary="false"
            variant="text"
            icon="$delete"
            color="primary"
            @click="deleteItem(index)"
          />
        </div>

        <btn icon="mdi-plus" icon-before primary @click="addItem">
          {{ $t('billing.add_item') }}
        </btn>
      </v-col>
    </v-row>
  </form-dialog>
</template>

<script setup lang="ts">
import {
  ref,
  computed,
  onMounted,
  WritableComputedRef,
  PropType,
  reactive,
} from 'vue';
import { required } from '@/utils/validations';
import {
  useAuthStore,
  usePatientStore,
  useProcedureStore,
  useProductStore,
} from '@/store';
import { procedureTypes, procedureStatuses } from '@/constants';
import {
  IProcedurePayload,
  IPractitioner,
  IProcedureItem,
  ProcedureEvents,
  IProduct,
  IProcedure,
} from '@/types';
import { events } from '@/events';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  practitioners: {
    type: Array as PropType<IPractitioner[]>,
    default: () => [],
  },
  item: {
    type: Object as PropType<IProcedure>,
    required: false,
  },
});

const authStore = useAuthStore();
const patientStore = usePatientStore();
const productStore = useProductStore();
const procedureStore = useProcedureStore();

const emit = defineEmits(['update:modelValue', 'refresh']);

let formData = reactive<IProcedurePayload>(<IProcedurePayload>{});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const dialogOpened = () => {
  if (props.item) {
    formData.practitioner = props.item.practitioner;
    formData.procedure_date = props.item.procedure_date;
    formData.procedure_status = props.item.procedure_status.code;
    formData.procedure_type = props.item.procedure_type.code;
    formData.procedure = props.item.procedure;
    formData.notes = props.item.notes;
    formData.order_items = props.item.order_items as any;
  } else {
    formData.practitioner = null;
    formData.procedure_date = null;
    formData.procedure_status = 'pending';
    formData.procedure_type = null;
    formData.procedure = null;
    formData.order_items = [{ product: null }];
    if (patientStore.currentPatientId) {
      patientStore.getCurrentPatient();
    }
    if (authStore?.userInfo?.practitioner_id)
      formData.practitioner = authStore.userInfo.practitioner_id;
  }
};

const addItem = () => {
  formData.order_items.push({} as any);
};

const deleteItem = (index: number) => {
  formData.order_items.splice(index, 1);
};

const clearFormData = () => {
  formData = <IProcedurePayload>{};
};

const submit = async () => {
  const payload = {
    ...formData,
    order_items: formData.order_items.filter((item) => item.product),
  };

  if (props.item) await procedureStore.updateProcedure(props.item.id, payload);
  else await procedureStore.addProcedure(payload);

  events.emit(ProcedureEvents.ReloadProcedures);
  isShowDialog.value = false;
  clearFormData();
};
</script>

<style scoped></style>
