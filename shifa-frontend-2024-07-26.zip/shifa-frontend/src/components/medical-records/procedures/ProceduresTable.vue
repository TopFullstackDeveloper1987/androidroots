<template>
  <div>
    <data-table-server
      v-model:page="page"
      v-model:expanded="expanded"
      :items-length="searchResults?.count"
      :items="searchResults?.results"
      :headers="headers"
      :search="search"
      no-gutters
      @update:options="loadItems"
    >
      <template v-slot:item="{ item }">
        <tr>
          <td>
            {{ item.raw.order_number }}
          </td>
          <td>
            {{
              item.raw.procedure_date
                ? moment
                    .utc(item.raw.procedure_date)
                    .format('YYYY-MM-DD HH:mm:ss')
                : $t('medical_records.procedures.not_scheduled')
            }}
          </td>
          <td>
            {{ item.raw.procedure_name }}
          </td>
          <td>
            {{ item.raw.practitioner_name }}
          </td>
          <td>
            <v-chip
              variant="outlined"
              size="small"
              :color="getStatusColor(item.raw.procedure_status?.code)"
            >
              {{ item.raw.procedure_status?.name }}
            </v-chip>
          </td>
          <td>
            <btn
              :primary="false"
              secondary
              icon="mdi-receipt-text"
              icon-only
              icon-color="primary"
              size="x-small"
              class="my-3 mr-3"
              @click="onInvoice"
            >
              <tooltip>{{ $t('common.invoice') }}</tooltip>
            </btn>
            <btn
              :primary="false"
              secondary
              icon="mdi-square-edit-outline"
              icon-only
              icon-color="primary"
              size="x-small"
              class="my-3 mr-3"
              @click="onEdit(item.raw)"
            >
              <tooltip>{{ $t('common.edit') }}</tooltip>
            </btn>
            <btn
              :primary="isExpanded(item.raw.id)"
              secondary
              class="my-3 mr-3"
              :icon="
                isExpanded(item.raw.id)
                  ? 'mdi-chevron-down'
                  : 'mdi-chevron-right'
              "
              icon-only
              size="x-small"
              :loading="state.loadingDetailsId === item.raw.id"
              :disabled="!item.raw.item_count"
              @click="toggleDetails(item.raw.id)"
            >
              <tooltip>
                {{ $t('patient_list.see_quick_details') }}
              </tooltip>
            </btn>
          </td>
        </tr>
      </template>

      <template v-slot:expanded-row="{ columns, item }">
        <tr>
          <td :colspan="columns.length">
            <procedure-details :details="getLoadedDetails(item.raw.id)" />
          </td>
        </tr>
      </template>
    </data-table-server>
  </div>
</template>

<script setup lang="ts">
import {
  computed,
  ref,
  reactive,
  watch,
  PropType,
  onMounted,
  onBeforeUnmount,
} from 'vue';
import { useI18n } from 'vue-i18n';
import moment from 'moment-timezone';
import { useRoute } from 'vue-router';
import _ from 'lodash';

import DataTableServer from '@/components/common/DataTableServer.vue';
import ProcedureDetails from './ProcedureDetails.vue';
import { useProcedureStore, useEncounterStore, usePatientStore } from '@/store';
import {
  IProcedureQuery,
  IProcedureDetails,
  ITableUpdateOptions,
  ProcedureEvents,
  IProcedure,
} from '@/types';
import { events } from '@/events';
import router from '@/router';

const encounterStore = useEncounterStore();

const props = defineProps({
  type: {
    type: String,
    default: '',
  },
  status: {
    type: String,
    default: '',
  },
  practitionerId: {
    type: String,
    default: '',
  },
  dates: {
    type: Array as PropType<Date[]>,
    default: () => [],
  },
});

const { t } = useI18n();
const emit = defineEmits(['edit']);
const patientStore = usePatientStore();
const procedureStore = useProcedureStore();

const headers = [
  {
    title: t('common.order_number'),
    key: 'id',
    sortable: false,
  },
  {
    title: t('common.date'),
    key: 'created_date',
    sortable: false,
  },
  {
    title: t('common.procedure'),
    key: 'procedure',
    sortable: false,
  },
  {
    title: t('common.practitioner'),
    key: 'practitioner_name',
    sortable: false,
  },
  {
    title: t('common.status'),
    key: 'status',
    sortable: false,
  },
  {
    title: t('common.actions'),
    key: 'scan_count',
    sortable: false,
  },
];

const page = ref(1);
const expanded = ref<string[]>([]);

const search = ref('');

const procedureDetails = ref<Record<string, IProcedureDetails>>({});
const state = reactive<{
  loadingDetailsId: string | null;
}>({
  loadingDetailsId: null,
});

onMounted(async () => {
  bindEventHandlers();
});

onBeforeUnmount(() => {
  unbindEventHandlers();
});

const bindEventHandlers = () => {
  events.on(ProcedureEvents.ReloadProcedures, reloadItems);
};

const unbindEventHandlers = () => {
  events.off(ProcedureEvents.ReloadProcedures, reloadItems);
};

const reloadItems = async () => {
  await loadItems({ page: 1 });
  procedureDetails.value = {};
  expanded.value = [];
};

const searchResults = computed(() => {
  const results = _.cloneDeep(procedureStore.searchResults?.results || []);

  return {
    ...procedureStore.searchResults,
    results,
  };
});

const getLoadedDetails = (id: string) => {
  return procedureDetails.value[id];
};

const getStatusColor = (status: string) => {
  if (!status) return;
  if (status === 'pending') return 'orange';
  else if (status === 'postponed') return 'purple';
  else if (status === 'in-Progress') return 'blue';
  else if (status === 'completed') return 'green';
  else if (status === 'canceled') return 'red';
  else return '';
};

const clearDetails = () => {
  procedureDetails.value = {};
};

const triggerSearch = () => {
  page.value = 1;
  clearDetails();

  search.value = String(Date.now());
};

watch(
  () => [props.type, props.dates, props.status, props.practitionerId],
  () => {
    triggerSearch();
  },
);

watch(page, () => {
  clearDetails();
});

const isExpanded = (id: string) => expanded.value.includes(id);

const loadItems = async ({ page }: ITableUpdateOptions) => {
  const query: IProcedureQuery = {
    page,
    patient_id: patientStore.currentPatientId!,
    order_type: props.type || undefined,
    order_status: props.status || undefined,
    practitioner_id: props.practitionerId || undefined,
  };

  if (props.dates?.length > 0) {
    query.from_date = props.dates[0]
      ? moment.utc(props.dates[0]).format('YYYY-MM-DD')
      : undefined;
    query.to_date = props.dates[1]
      ? moment.utc(props.dates[1]).format('YYYY-MM-DD')
      : undefined;
  }

  await procedureStore.getProcedures(query);
};

const getDetails = async (id: string) => {
  const existingDetails = getLoadedDetails(id);
  if (!existingDetails) {
    const details = await procedureStore.getProcedureDetails(id);
    procedureDetails.value[id] = details;
  }
};

const toggleDetails = async (orderId: string) => {
  if (isExpanded(orderId)) {
    const index = expanded.value.findIndex((id) => id === orderId);
    expanded.value.splice(index, 1);
  } else {
    state.loadingDetailsId = orderId;
    try {
      await getDetails(orderId);
      expanded.value.push(orderId);
    } finally {
      state.loadingDetailsId = null;
    }
  }
};

const onEdit = async (payload: IProcedure) => {
  await getDetails(payload.id);
  const details = getLoadedDetails(payload.id);
  const orderItems = details.order_items.map((item) => {
    return {
      product: item?.product.id,
    };
  });
  const data = { ...payload, order_items: orderItems };

  emit('edit', data);
};

const onInvoice = () => {
  router.push({ name: 'Invoices' });
};
</script>
