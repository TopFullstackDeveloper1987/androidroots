<template>
  <v-container fluid class="detail-view">
    <v-row no-gutters>
      <v-col class="detail-view-th">
        <div class="px-2">{{ $t('common.name') }}:</div>
      </v-col>

      <v-col class="detail-view-th">
        <div class="px-2">{{ $t('common.code') }}:</div>
      </v-col>

      <v-col class="detail-view-th">
        <div class="px-2">{{ $t('common.brand') }}:</div>
      </v-col>
    </v-row>

    <v-row v-for="(item, index) of items" :key="item.id" no-gutters>
      <v-col
        class="detail-view-td"
        :class="{ 'last-child': index === items.length - 1 }"
      >
        <div class="px-2">
          {{ item.name }}
        </div>
      </v-col>

      <v-col
        class="detail-view-td"
        :class="{ 'last-child': index === items.length - 1 }"
      >
        <div class="px-2">
          {{ item.code }}
        </div>
      </v-col>

      <v-col
        class="detail-view-td"
        :class="{ 'last-child': index === items.length - 1 }"
      >
        <div class="d-flex align-items-center justify-space-between px-2">
          <div class="pr-2">
            {{ item.brand }}
          </div>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup lang="ts">
import { PropType, computed } from 'vue';

import { IProcedureDetails } from '@/types';

const props = defineProps({
  details: {
    type: Object as PropType<IProcedureDetails>,
    default: () => {},
  },
});

const items = computed(() => {
  return props.details.order_items;
});

const onEdit = (id: number) => {};

const onDelete = (id: number) => {};
</script>
