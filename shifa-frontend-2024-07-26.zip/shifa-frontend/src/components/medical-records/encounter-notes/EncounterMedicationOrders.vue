<template>
  <div>
    <expansion-panel
      :title="$t('encounters.medication_orders')"
      icon="orders"
      v-model="panel"
    >
      <template #content>
        <v-sheet class="px-3 py-5 bordered">
          <auto-complete
            :placeholder="$t('encounters.medication_orders_placeholder')"
            :items="customEncounters"
            v-model="selectedItem"
            :loading="loading"
            item-title="name"
            item-value="id"
            return-object
            v-model:search="searchKey"
            @update:search="searchUpdated"
            @keyup.enter="addMedicationOrder"
          >
            <template #append>
              <v-tooltip :text="$t('common.only_search_my_favorite')" location="top">
                <template v-slot:activator="{ props }">
                  <switch-btn
                    v-bind="props"
                    :indeterminate="false"
                    v-model="isMyFavorite"
                    class="mr-2 switch"
                  />
                </template>
              </v-tooltip>
              <v-tooltip :text="$t('common.add')" location="top">
                <template v-slot:activator="{ props }">
                  <btn
                    v-bind="props"
                    icon="mdi-plus"
                    icon-only
                    :primary="false"
                    size="small"
                    variant="text"
                    color="primary"
                    @click="addMedicationOrder"
                  />
                </template>
              </v-tooltip>
            </template>
          </auto-complete>

          <!-- <text-area
            :label="$t('encounters.note')"
            v-model="medicationOrderNotes"
            class="mt-3"
          />

          <div class="text-right mt-2">
            <btn
              :primary="false"
              secondary
              :disabled="!selectedItem"
              @click="addMedicationOrder"
              :loading="loading"
            >
              {{ $t('common.save') }}
            </btn>
          </div> -->

          <div
            v-if="currentEncounter.medication_orders?.length"
            class="mt-3 text-h6 bold"
          >
            {{ $t('encounters.medication_orders') }}
          </div>
          <v-card
            v-for="(
              medicationOrder, index
            ) in currentEncounter.medication_orders"
            :key="index"
            class="my-4 bg-water"
          >
            <v-card-title class="pa-4 pb-4 bg-primary">
              <span class="text-h6 bold">
                {{ medicationOrder.order_number }}
              </span>
              <v-tooltip :text="$t('common.delete')" location="top">
                <template v-slot:activator="{ props }">
                  <btn
                    v-bind="props"
                    size="x-small"
                    icon-only
                    :primary="false"
                    variant="flat"
                    icon="$delete"
                    color="white"
                    class="float-right mt-n1"
                    :loading="loading"
                    @click="openConfirmationDialog(medicationOrder)"
                  />
                </template>
              </v-tooltip>
              <v-tooltip :text="$t('common.print')" location="top">
                <template v-slot:activator="{ props }">
                  <btn
                    v-bind="props"
                    size="x-small"
                    icon="$print"
                    icon-only
                    variant="flat"
                    class="float-right mt-n1 mx-1"
                    :primary="false"
                    color="white"
                    :tooltip="$t('common.print')"
                    @click="printMedicationOrder(medicationOrder)"
                  />
                </template>
              </v-tooltip>
            </v-card-title>
            <div class="pa-4">
              <template
              v-for="(
                  medicationOrderItem, index
                ) in medicationOrder.medication_order_items"
                :key="index"
              >
              <div
              class="d-flex justify-space-between align-center"
              >
              <span>
                • {{ medicationOrderItem.medication.IQ_national_code }} :
                {{ medicationOrderItem.medication.name }}
              </span>
              <div class="d-flex dosage-field-wrapper">
              <text-field
                v-model="medicationOrderItem.instructions"
                :label="$t('encounters.dosage_and_instructions')"
                class="dosage-field"
                :class="{'focused': medicationOrderItem.is_dosage_field_focused}"
                @focus="medicationOrderItem.is_dosage_field_focused = true"
                @blur="medicationOrderItem.is_dosage_field_focused = false"
                @keyup.enter="openConfirmDialog(medicationOrder, medicationOrderItem.id)"
                >
                </text-field>
                <v-tooltip :text="$t('common.delete')" location="top">
                  <template v-slot:activator="{ props }">
                    <btn
                      v-bind="props"
                      icon-only
                      icon="mdi-delete"
                      size="small"
                      variant="text"
                      color="primary"
                      :loading="loading"
                      :tooltip="$t('common.delete')"
                      @click="openConfirmDialog(medicationOrder, medicationOrderItem.id)"
                    />
                  </template>
                </v-tooltip>
                <v-tooltip :text="$t('common.save')" location="top">
                  <template v-slot:activator="{ props }">
                    <btn
                      v-bind="props"
                      icon-only
                      icon="mdi-content-save"
                      size="small"
                      variant="text"
                      color="primary"
                      :loading="loading"
                      :tooltip="$t('common.save')"
                      @click="save(medicationOrder.id, medicationOrderItem, medicationOrderItem.instructions)"
                    />
                  </template>
                </v-tooltip>
              </div>
              </div>
                <v-divider
                  class="my-3"
                  v-if="
                    index !== medicationOrder.medication_order_items.length - 1
                  "
                />
            </template>
              <span
                v-if="medicationOrder.notes"
                class="text-body-1 font-italic"
              >
                <v-divider class="my-2" />
                {{ medicationOrder.notes }}
              </span>
            </div>
          </v-card>
        </v-sheet>
      </template>
      <template #actions>
        <slot name="actions"></slot>
      </template>
    </expansion-panel>
    <BaseConfirmationDialog
      v-model="showConfirmDialog"
      :message="$t('common.are_you_sure_you_want_to_delete_this')"
      @submit="deleteMedicationOrderItem"
    />
    <BaseConfirmationDialog
      v-model="showDeleteDialog"
      :message="$t('common.are_you_sure_you_want_to_delete_this')"
      @submit="deleteMedicationOrder"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import _ from 'lodash';
import BaseConfirmationDialog from '@/components/common/BaseConfirmationDialog.vue';

import {
  useAuthStore,
  usePatientStore,
  useFacilityStore,
  useEncounterStore,
  useCustomEncountersStore,
  useMedicationOrderStore,
} from '@/store';

import {
  ICustomEncounter,
  CustomEncounterType,
  IMedicationOrderPayload,
  IFilterQuery,
  IEncounterMedicationOrder,
  IMedicationOrderItem,
  ConfigurationEvents,
} from '@/types';
import { events } from '@/events';

const authStore = useAuthStore();
const patientStore = usePatientStore();
const facilityStore = useFacilityStore();
const encounterStore = useEncounterStore();
const customEncountersStore = useCustomEncountersStore();
const medicationOrderStore = useMedicationOrderStore();

const emit = defineEmits(['updated', 'print']);

const loading = ref<boolean>(false);
const medicationOrderNotes = ref<string>('');
const customEncounters = ref<ICustomEncounter[]>([]);
const panel = ref<number | undefined>();
const selectedItem = ref<ICustomEncounter>();
const searchKey = ref<string>('');
const isMyFavorite = ref(true);
const showDeleteDialog = ref(false);
const showConfirmDialog = ref(false);
const currentOrder = ref<IEncounterMedicationOrder>(null!);
const currentOrderItemId = ref<number>(null!);

const currentEncounter = computed(() => {
  return encounterStore.currentEncounter;
});

const searchItems = _.debounce(async () => {
  const query: IFilterQuery = {
    page: 1,
    name: searchKey.value,
    favored: isMyFavorite.value ? true : undefined,
  };

  const res = await customEncountersStore.searchCustomEncounters(
    CustomEncounterType.Medication,
    query,
  );
  customEncounters.value = res.results || [];
}, 600);

const searchUpdated = async (query: string) => {
  // vuetify bug, triggers update:search when toggling switch
  if (!query || query.length < 2 || ['true', 'false'].includes(query)) {
    return;
  }

  const currentItem = customEncounters.value.find(
    (item) => item.id === selectedItem.value?.id,
  );
  if (query === currentItem?.name) {
    return;
  }

  searchItems();
};

const clearInput = () => {
  searchKey.value = '';
  customEncounters.value = [];
  selectedItem.value = undefined;
};

const addMedicationOrder = () => {
  if (!currentEncounter.value.id || !selectedItem.value?.id) return;

  const payload: IMedicationOrderPayload = {
    practitioner: authStore.userInfo.practitioner_id!,
    encounter: currentEncounter.value.id,
    patient: patientStore.currentPatientId!,
    medication_order_items: [{ medication: selectedItem.value.id ,medication_name: selectedItem.value.name }],
  };

  loading.value = true;
  encounterStore
    .addMedicationOrder(facilityStore.currentFacilityId!, payload)
    .then(() => {
      emit('updated');
      clearInput();
    })
    .finally(() => {
      events.emit(ConfigurationEvents.ReloadCustomEncounters);
      loading.value = false;
    });
};

const openConfirmationDialog = (medicationOrder: IEncounterMedicationOrder) => {
  currentOrder.value = medicationOrder;

  showDeleteDialog.value = true;
};

const openConfirmDialog = (medicationOrder: IEncounterMedicationOrder, medicationOrderItemId: number) => {
  currentOrder.value = medicationOrder;
  currentOrderItemId.value = medicationOrderItemId;

  showConfirmDialog.value = true;
};

const deleteMedicationOrder = async () => {
  loading.value = true;
  encounterStore
    .deleteMedicationOrder(facilityStore.currentFacilityId!, currentOrder.value.id)
    .then(() => {
      emit('updated');
    })
    .finally(() => {
      events.emit(ConfigurationEvents.ReloadCustomEncounters);
      loading.value = false;
    });
};

const deleteMedicationOrderItem = async () => {
  loading.value = true;
  medicationOrderStore
    .deleteMedicationOrderItem(currentOrder.value.id, currentOrderItemId.value)
    .then(() => {
      emit('updated');
    })
    .finally(() => {
      events.emit(ConfigurationEvents.ReloadCustomEncounters);
      loading.value = false;
    });
};

const save = async (medicationOrderId: string, medicationOrderItem: IMedicationOrderItem, instructions?: string) => {
  loading.value = true;
  await medicationOrderStore.updateMedicationItemInstruction(
    medicationOrderId,
    medicationOrderItem.id,
    {
      instructions,
    });
  events.emit(ConfigurationEvents.ReloadCustomEncounters);
  loading.value = false;
};

const printMedicationOrder = (medicationOrder: IEncounterMedicationOrder) => {
  emit('print', medicationOrder);
};
</script>

<style scoped lang="scss">
.switch {
  height: 44px;
  display: flex;
  align-items: center;
}

.dosage-field-wrapper {
  width: 50%;
  gap: 15px;
}

.dosage-field.focused {
  border: 2px solid #5F63D7;
  border-radius: 50px;
}
</style>
