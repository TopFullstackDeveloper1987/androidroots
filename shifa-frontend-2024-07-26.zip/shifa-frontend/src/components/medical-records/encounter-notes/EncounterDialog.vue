<template>
  <form-dialog
    v-model="isShowDialog"
    max-width="650"
    @submit="submit"
    @opened="dialogOpened"
    :no-click-animation="true"
  >
    <template v-slot:header>
      <div class="text-primary">
        {{ $t('encounters.add_new_encounter') }}
      </div>
    </template>

    <v-row>
      <v-col cols="6">
        <select-field
          v-model="formData.practitioner"
          :items="practitioners"
          :rules="[required]"
          item-title="practitioner_name"
          item-value="id"
          :label="$t('common.practitioner')"
          attr="practitioner"
        />
      </v-col>
      <v-col cols="6">
        <select-field
          v-model="formData.encounter_status"
          :items="encounterStatuses"
          :rules="[required]"
          item-title="title"
          item-value="value"
          :label="$t('common.status')"
          attr="procedure_status"
        />
      </v-col>
      <v-col cols="6">
        <select-field
          v-model="formData.encounter_type"
          :items="encounterTypes"
          :rules="[required]"
          item-title="title"
          item-value="value"
          :label="$t('common.type')"
          attr="procedure_type"
        />
      </v-col>
      <v-col cols="6">
        <select-field
          v-model="formData.encounter_priority"
          :items="encounterPiorities"
          :rules="[required]"
          item-title="title"
          item-value="value"
          :label="$t('common.priority')"
          attr="procedure_type"
        />
      </v-col>
      <v-col cols="12">
        <switch-btn
          :label="$t('encounters.follow_up')"
          v-model="formData.follow_up_required"
        />
      </v-col>
      <v-col cols="12">
        <text-area
          v-model="formData.notes"
          :label="$t('patient.notes')"
          attr="notes"
          :rows="4"
        />
      </v-col>
    </v-row>
  </form-dialog>
</template>

<script setup lang="ts">
import {
  computed,
  WritableComputedRef,
  PropType,
  reactive,
} from 'vue';
import { required } from '@/utils/validations';
import {
  useAuthStore,
  usePatientStore,
  useEncounterStore,
  useFacilityStore,
} from '@/store';
import { useRouter } from 'vue-router';
import { encounterTypes, encounterStatuses, encounterPiorities } from '@/constants';
import {
  IPractitioner,
  IEncounterPayload,
} from '@/types';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  practitioners: {
    type: Array as PropType<IPractitioner[]>,
    default: () => [],
  },
  patientId: {
    type: String,
    default: undefined,
  },
  item: {
    type: Object as PropType<IEncounterPayload>,
    required: false,
  },
});

const authStore = useAuthStore();
const patientStore = usePatientStore();
const encounterStore = useEncounterStore();
const facilityStore = useFacilityStore();

const router = useRouter();

const emit = defineEmits(['update:modelValue', 'refresh', 'submit']);

let formData = reactive<IEncounterPayload>(<IEncounterPayload>{});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const dialogOpened = () => {
  if (props.item) {
    formData.practitioner = props.item.practitioner;
    formData.encounter_status = props.item.encounter_status;
    formData.encounter_type = props.item.encounter_type;
    formData.follow_up_required = props.item.follow_up_required;
    formData.notes = props.item.notes;
  } else {
    formData.follow_up_required = false;
    formData.encounter_status = 'new'!;
    formData.encounter_type = 'outpatient'!;
    formData.encounter_priority = 'low'!;
    if (patientStore.currentPatientId) {
      patientStore.getCurrentPatient();
    }
    if (authStore?.userInfo?.practitioner_id)
      formData.practitioner = authStore.userInfo.practitioner_id;
  }
};

const clearFormData = () => {
  formData = <IEncounterPayload>{};
};

const submit = async () => {
  const payload = {
    ...formData,
    patient: props.patientId || patientStore.currentPatientId!,
    facility: facilityStore.currentFacilityId!,
  };

  if (props.item) await encounterStore.updatePatientEncounter(props.item.id, payload);

  else await encounterStore.addEncounter(payload);

  emit('submit');

  isShowDialog.value = false;
  clearFormData();

  router.push(`/medical-records/${patientStore.currentPatientId}/encounter-notes`);
};
</script>

<style scoped></style>
