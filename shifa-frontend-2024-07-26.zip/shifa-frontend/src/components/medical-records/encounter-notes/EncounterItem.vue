<template>
  <expansion-panel :title="title" :icon="icon" v-model="panel">
    <template #content>
      <v-sheet class="px-3 py-5 bordered">
        <auto-complete
          :placeholder="placeholder"
          :items="customEncounters"
          v-model="selectedItem"
          :loading="loading"
          item-title="name"
          item-value="id"
          v-model:search="searchKey"
          @update:search="searchUpdated"
          @keyup.enter="createEncounterItem"
        >
          <template #append>
            <v-tooltip :text="$t('common.only_search_my_favorite')" location="top">
              <template v-slot:activator="{ props }">
                <switch-btn
                  v-bind="props"
                  :indeterminate="false"
                  v-model="isMyFavorite"
                  class="mr-2 switch"
                />
              </template>
            </v-tooltip>

            <v-tooltip :text="$t('common.add')" location="top">
              <template v-slot:activator="{ props }">
                <btn
                  v-bind="props"
                  icon="mdi-plus"
                  icon-only
                  :primary="false"
                  size="small"
                  variant="text"
                  color="primary"
                  @click="createEncounterItem"
                />
              </template>
            </v-tooltip>
          </template>
        </auto-complete>

        <div class="ml-5 mt-3">
          <template v-for="(item, index) in encounterItems" :key="index">
          <div
            class="d-flex justify-space-between align-center flex-wrap py-1"
          >
            <span class="text-subtitle-1"> • {{ getItemText(item) }} </span>
            <v-menu v-if="encounterType === CustomEncounterType.Complaint" v-model="menus[index]" persistent>
              <template v-slot:activator="{ props }">
              <div class="d-flex align-center onset-date-field-wrapper">
                <text-field :value="formatOnSetDate(item.onset_date || '')" v-bind="props" class="onset-date-menu" readonly :placeholder="$t('common.on_set_date')" />
                <btn variant="text" class="mx-2" :primary="false" icon-only icon="mdi-close" icon-size="15" size="20" @click="item.onset_date = ''; updateEncounterItem(item);" />
              </div>
              <v-slider
              v-model="item.severity"
              :step="1"
              :ticks="complaintSeverities"
              :max="4"
              :min="0"
              show-ticks="always"
              thumb-label="always"
              :tick-size="5"
              color="primary"
              thumb-color="primary"
              track-color="primary"
              track-fill-color="primary"
              class="severity-field mt-5"
              @click="updateEncounterItem(item)"
            >
              <template v-slot:thumb-label="{ modelValue }">
                <v-icon :icon="severityIcon(Math.min(Math.floor(modelValue)))" theme="dark" size="25"></v-icon>
              </template>
            </v-slider>
              </template>
              <v-list>
                <v-list-item>
                  <date-picker
                    v-model="item.onset_date"
                    show-original-date-picker
                    @onOk="updateEncounterItem(item); menus[index] = false;"
                  />
                </v-list-item>
                <v-list-item v-for="onsetDateItem in onsetDateItems" :key="onsetDateItem.value">
                  <btn variant="tonal" :primary="false" @click="item.onset_date = onsetDateItem.value; updateEncounterItem(item)">{{ onsetDateItem.title }}</btn>
                </v-list-item>
              </v-list>
            </v-menu>
            <v-tooltip :text="$t('common.delete')" location="top">
              <template v-slot:activator="{ props }">
                <btn
                  v-bind="props"
                  size="x-small"
                  icon-only
                  :primary="false"
                  variant="text"
                  icon="$delete"
                  :loading="loading"
                  @click="deleteEncounterItem(item)"
                />
              </template>
            </v-tooltip>
          </div>
          <template v-if="encounterType === CustomEncounterType.Complaint">
            <text-area v-model="item.hpi" :label="$t('encounters.history_of_present_illness')" />
            <div class="d-flex justify-end">
              <btn class="mt-4" @click="updateComplaintEncounter(item)" :loading="loading">{{ $t('common.save') }}</btn>
            </div>
            <v-divider class="my-5"></v-divider>
          </template>
          </template>
        </div>
      </v-sheet>
    </template>

    <template #actions>
      <slot name="actions"></slot>
    </template>
  </expansion-panel>
</template>

<script setup lang="ts">
import { ref, computed, WritableComputedRef, PropType, onMounted } from 'vue';
import { complaintSeverities } from '@/constants';
import _, { forEach } from 'lodash';

import { useEncounterStore, useCustomEncountersStore } from '@/store';
import {
  CustomEncounterType,
  ICustomEncounter,
  IEncounter,
  IEncounterItem,
  IFilterQuery,
} from '@/types';
import { useI18n } from 'vue-i18n';
import moment from 'moment';

const encounterStore = useEncounterStore();
const customEncountersStore = useCustomEncountersStore();

const props = defineProps({
  title: {
    type: String,
    default: '',
  },
  icon: {
    type: String,
    default: '',
  },
  placeholder: {
    type: String,
    default: '',
  },
  encounterType: {
    type: String as PropType<CustomEncounterType>,
    required: true,
  },
  encounterItems: {
    type: Array as PropType<IEncounterItem[]>,
    default: () => [],
  },
});

const emit = defineEmits(['updated', 'openCustomEncounterDialog']);

const loading = ref<boolean>(false);
const customEncounters = ref<ICustomEncounter[]>([]);
const panel = ref<number | undefined>();
const selectedItem = ref<number>();
const searchKey = ref<string>('');
const isMyFavorite = ref(true);
const menus = ref<boolean[]>([]);

const { t } = useI18n();

const onsetDateItems = ref([
  { title: t('common.yesterday'), value: moment().utc().subtract(1, 'days').format('YYYY-MM-DD') },
  { title: t('common.2_days_ago'), value: moment().utc().subtract(2, 'days').format('YYYY-MM-DD') },
  { title: t('common.3_days_ago'), value: moment().utc().subtract(3, 'days').format('YYYY-MM-DD') },
  { title: t('common.1_week_ago'), value: moment().utc().subtract(1, 'weeks').format('YYYY-MM-DD') },
  { title: t('common.2_weeks_ago'), value: moment().utc().subtract(2, 'weeks').format('YYYY-MM-DD') },
  { title: t('common.1_month_ago'), value: moment().utc().subtract(1, 'months').format('YYYY-MM-DD') },
  { title: t('common.2_months_ago'), value: moment().utc().subtract(2, 'months').format('YYYY-MM-DD') },
  { title: t('common.3_months_ago'), value: moment().utc().subtract(3, 'months').format('YYYY-MM-DD') },
  { title: t('common.1_year_ago'), value: moment().utc().subtract(1, 'years').format('YYYY-MM-DD') },
  { title: t('common.2_years_ago'), value: moment().utc().subtract(2, 'years').format('YYYY-MM-DD') },


]);

const currentEncounter: WritableComputedRef<IEncounter> = computed(() => {
  return encounterStore.currentEncounter;
});

const getItemText = (item: any) => {
  return item[props.encounterType];
};

const searchItems = _.debounce(async () => {
  const query: IFilterQuery = {
    page: 1,
    name: searchKey.value,
    favored: isMyFavorite.value ? true : undefined,
  };

  const res = await customEncountersStore.searchCustomEncounters(
    props.encounterType,
    query,
  );
  customEncounters.value = res.results || [];
}, 600);

const searchUpdated = async (query: string) => {
  // vuetify bug, triggers update:search when toggling switch
  if (!query || query.length < 2 || ['true', 'false'].includes(query)) {
    return;
  }

  const currentItem = customEncounters.value.find(
    (item) => item.id === selectedItem.value,
  );
  if (query === currentItem?.name) {
    return;
  }

  searchItems();
};

const severityIcon = (range: number) => {
  switch (range){
    case 0:
      return 'mdi-emoticon-confused';
    case 1:
      return 'mdi-emoticon-frown';
    case 2:
      return 'mdi-emoticon-cry';
    case 3:
      return 'mdi-emoticon-sick';
    case 4:
      return 'mdi-emoticon-dead';
  }
};

const updateComplaintEncounter = async (complaint: IEncounterItem) => {
  loading.value = true;
  await encounterStore.updateComplaintEncounter(complaint.encounter, complaint.id!, {
    onset_date: complaint.onset_date,
    severity: complaint.severity,
    hpi: complaint.hpi!,
  });
  emit('updated');
  loading.value = false;
};

const updateEncounterItem = _.debounce((item: IEncounterItem) => {
  const complaintPayload = {
    ...item,
    complaint: item.id?.toString(),
    severity: Math.min(Math.floor(item.severity!)),
    hpi: item.hpi,
    onset_date: !item.onset_date || item.onset_date === 'Invalid date' ? null! : moment(item.onset_date).format('YYYY-MM-DD'),
  };
  updateComplaintEncounter(complaintPayload);

}, 750);

const formatOnSetDate = (onset_date: string) => {
  return onset_date ? moment(onset_date).format('YYYY-MM-DD') : '';
};

const clearInput = () => {
  searchKey.value = '';
  customEncounters.value = [];
  selectedItem.value = undefined;
};

const createEncounterItem = () => {
  if (!currentEncounter.value.id || !selectedItem.value) return;

  loading.value = true;
  const payload: IEncounterItem = {
    encounter: currentEncounter.value.id,
    [props.encounterType]: selectedItem.value,
  };
  encounterStore
    .addEncounterItem(payload, props.encounterType)
    .then(() => {
      emit('updated');
      clearInput();
    })
    .finally(() => (loading.value = false));
};

const deleteEncounterItem = (encounterItem: IEncounterItem) => {
  loading.value = true;
  encounterStore
    .deleteEncounterItem(encounterItem, props.encounterType)
    .then(() => {
      emit('updated');
    })
    .finally(() => (loading.value = false));
};

onMounted(() => {
  forEach(props.encounterItems, (val, i) => {
    menus.value[i] = false;
  });

  document.body.addEventListener('click', () => {
    forEach(props.encounterItems, (val, i) => {
      menus.value[i] = false;
    });
  });
});
</script>

<style scoped lang="scss">
.switch {
  height: 44px;
  display: flex;
  align-items: center;
}

.onset-date-field-wrapper, .severity-field {
  width: 300px;
  max-width: 300px;
}

.severity-field {
  max-width: 400px;
}
</style>
