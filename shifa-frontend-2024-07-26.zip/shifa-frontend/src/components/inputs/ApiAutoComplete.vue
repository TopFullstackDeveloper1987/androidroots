<template>
  <auto-complete
    v-bind="$attrs"
    v-model:search="searchText"
    :items="items"
    :loading="loading"
    @update:search="searchUpdated"
  >
    <template v-slot:append-item="">
      <div v-intersect="endIntersect"></div>
    </template>
  </auto-complete>
</template>

<script setup lang="ts">
import _ from 'lodash';
import { ref, computed, PropType, onMounted } from 'vue';
import { useCommonStore } from '@/store';
import { IFilterQuery } from '@/types';

const props = defineProps({
  isFavored: {
    type: Boolean,
    default: false,
  },
  handler: {
    type: [Function],
    default: () => {},
  },
});

const next = ref<string>('');
const page = ref<number>(1);
const items = ref<any[]>([]);
const searchText = ref<string>('');
const loading = ref<boolean>(false);

onMounted(() => {
  searchItems();
});

const errors: any = computed(() => '');

const searchUpdated = async (query: string) => {
  page.value = 1;
  searchItems();
};

const searchItems = _.debounce(async (savePrevious = false) => {
  const query: IFilterQuery = {
    page: page.value,
    name: searchText.value ? searchText.value : undefined,
    favored: props.isFavored ? true : undefined,
  };
  loading.value = true;
  const res = await props.handler(query);
  if (savePrevious) items.value = [...items.value, ...res.results];
  else items.value = res.results;
  next.value = res.next;
  loading.value = false;
}, 600);

const endIntersect = (
  entries: boolean,
  observer: any[],
  isIntersecting: any,
) => {
  if (isIntersecting && next.value && !searchText.value) {
    page.value++;
    searchItems(true);
  }
};
</script>

<style lang="scss"></style>
