<template>
  <div>
    <vue-date-picker
      v-model="date"
      v-bind="$attrs"
      ref="datePickerRef"
      :range="range"
      :enable-time-picker="enableTimePicker"
      :timezone="timezone"
      :placeholder="placeholder"
      :required="required"
      :week-start="weekStart"
      :max-date="maxDate"
      :teleport="teleport"
      :input-class-name="inputClassName"
      calendar-cell-class-name="dp-custom-cell"
      class="bg-light"
      :class="{ 'original-date-picker': showOriginalDatePicker }"
    >
      <template #input-icon>
        <v-icon icon="$calendar" class="ml-2" />
      </template>

      <template #clear-icon="{ clear }">
        <v-icon icon="mdi-close" color="primary" class="mr-2" @click="clear" />
      </template>

      <template #arrow-left>
        <left-arrow />
      </template>

      <template #arrow-right>
        <right-arrow />
      </template>

      <template #action-buttons>
        <div class="action-button cancel mr-2" @click="onCancel">
          {{ $t('common.cancel') }}
        </div>

        <div class="action-button ok mr-2" @click="onOk">
          {{ $t('common.ok') }}
        </div>
      </template>

      <template
        v-for="(name, index) of slotNames"
        :key="index"
        #[name]="slotProps"
      >
        <slot :name="name" v-bind="slotProps || {}" />
      </template>
    </vue-date-picker>
    <text-field v-if="!showOriginalDatePicker" v-model="formattedDate" :rules="rules" read-only :disabled="disabled" :placeholder="placeholder" :class="props.class" @click="datePickerRef?.openMenu()">
      <template #append-inner>
        <v-icon v-if="!!date" size="25" @click.stop="date = ''">mdi-close</v-icon>
      </template>
      <template #prepend-inner>
        <v-icon color="primary">mdi-calendar-blank-outline</v-icon>
      </template>
    </text-field>
  </div>
</template>

<script setup lang="ts">
import VueDatePicker from '@vuepic/vue-datepicker';
import '@vuepic/vue-datepicker/dist/main.css';
import { useSlots, PropType, ref, computed, WritableComputedRef } from 'vue';
import { required as requiredFieldRule } from '@/utils';

import leftArrow from '@/assets/icons/left-arrow.svg?component';
import rightArrow from '@/assets/icons/right-arrow.svg?component';
import moment from 'moment';

const props = defineProps({
  modelValue: {
    default: null,
  },
  range: {
    type: Boolean,
    default: false,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  enableTimePicker: {
    type: Boolean,
    default: false,
  },
  returnWithFormat: {
    type: Boolean,
    default: false,
  },
  timezone: {
    type: String,
    default: 'UTC',
  },
  placeholder: {
    type: String,
    default: 'Select Date',
  },
  required: {
    type: Boolean,
    default: false,
  },
  showOriginalDatePicker: {
    type: Boolean,
    default: false,
  },
  weekStart: {
    type: [Number, String] as PropType<
      '0' | '1' | '2' | '3' | '4' | '5' | '6' | 0 | 1 | 2 | 3 | 4 | 5 | 6
    >,
    default: 0,
  },
  maxDate: {
    type: [Date, String],
    default: undefined,
  },
  teleport: {
    type: [Boolean, String],
    default: true,
  },
  class: {
    type: String,
    default: undefined,
  },
  rules: {
    type: Array,
    default: undefined,
  },
});

const emit = defineEmits(['onOk', 'update:modelValue']);

const slots = useSlots();
const slotNames = Object.keys(slots) as [];

const datePickerRef = ref();
const inputClassName = computed(
  () => `dp-custom-input ${props.range ? 'dp-custom-input-range' : ''}`,
);

const date: WritableComputedRef<any> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    if(props.returnWithFormat) {
      if(props.range && value) {
        emit('update:modelValue', moment.utc(value[0]).format('YYYY-MM-DD') + ' - ' + moment.utc(value[1]).format('YYYY-MM-DD'));
      }

      emit('update:modelValue', moment.utc(value).format('YYYY-MM-DD'));
    } else {
      emit('update:modelValue', value);
    }
  },
});

const formattedDate: WritableComputedRef<any> = computed({
  get() {
    if(!date.value)
      return null;

    if(props.range) {
      return moment.utc(date.value[0]).format('YYYY-MM-DD') + ' - ' + moment.utc(date.value[1]).format('YYYY-MM-DD');
    }

    return moment.utc(date.value).format('YYYY-MM-DD');
  },
  set(value) {
    console.log('set', value);
  },
});

const onCancel = () => {
  datePickerRef.value.closeMenu();
};

const onOk = () => {
  datePickerRef.value.selectDate();

  emit('onOk');
};
</script>

<style lang="scss">

.dp__main {
  font-family: 'Noto Sans', sans-serif;
  border-radius: 20px;
  height: 0;
  visibility: hidden;

  &.original-date-picker {
    height: unset !important;
    visibility: hidden;
  }

  .dp-custom-input {
    font-size: 16px;
    background-color: transparent;
    border: 1px solid transparent;
    min-height: 47px;

    &.dp-custom-input-range {
      min-width: 250px;
    }
  }
}

.dp__main,
.dp__menu {
  .dp--arrow-btn-nav {
    .dp__inner_nav {
      padding-top: 2px;
      width: 35px;
      height: 35px;
    }
  }

  .dp-custom-cell {
    border-radius: 50px;

    &.dp__today {
      border: 1px solid rgb(var(--v-theme-primary));
    }

    &.dp__active_date,
    &.dp__range_start,
    &.dp__range_end {
      background: rgb(var(--v-theme-primary));
    }
  }

  .action-button {
    cursor: pointer;

    padding: 4px 16px;
    border-radius: 20px;
    background-color: rgb(var(--v-theme-primary));
    color: white;

    &.cancel {
      background-color: white;
      color: rgb(var(--v-theme-primary));
      border: 1px solid rgb(var(--v-theme-primary));
    }
  }
}
</style>
