<template>
  <text-field
    class="base-phone-text-field"
    v-bind="$attrs"
    :flat="props.flat"
    :rounded="props.rounded"
    :density="props.density"
    :bgColor="props.bgColor"
    :variant="props.variant"
    :type="type"
    hide-details="auto"
    :error-messages="errors"
    :autocomplete="autocomplete"
  >
    <template #prepend>
      <select-field
        v-model="phoneExtension"
        :items="phoneExtensions"
        :label="$t('register_patient.country_code')"
      />
    </template>
  </text-field>
</template>

<script setup lang="ts">
import { computed, PropType, ref, watch, onMounted } from 'vue';
import { useCommonStore, useMetaDataStore } from '@/store';
import { ISelect } from '@/types';

import _ from 'lodash';

const commonStore = useCommonStore();
const metaDataStore = useMetaDataStore();

const emit = defineEmits(['update:phone-number-extension']);

const phoneExtension = ref<string>('+964');
const phoneExtensions = ref<ISelect<string>[]>([]);


watch(() => phoneExtension.value, (val) => {
  emit('update:phone-number-extension', val);
});

const props = defineProps({
  phoneNumber: {
    type: String,
    default: '',
  },
  phoneNumberExtension: {
    type: String,
    default: '+964',
  },
  rounded: {
    type: Boolean,
    default: true,
  },
  density: {
    type: String as PropType<
      null | 'default' | 'comfortable' | 'compact' | undefined
    >,
    default: 'compact',
  },
  bgColor: {
    type: String,
    default: 'light',
  },
  flat: {
    type: Boolean,
    default: true,
  },
  variant: {
    type: String as PropType<
      | 'filled'
      | 'outlined'
      | 'plain'
      | 'underlined'
      | 'solo'
      | 'solo-inverted'
      | 'solo-filled'
      | undefined
    >,
    default: 'solo',
  },
  type: {
    type: String,
    default: 'text',
  },
  autocomplete: {
    type: String,
    default: 'on',
  },
  attr: {
    type: String,
    default: '',
  },
  errorMessages: {
    type: [Array, String],
    default: '',
  },
});

const errors: any = computed(
  () =>
    props.errorMessages ||
    (commonStore.error?.data && commonStore.error.data[props.attr]) ||
    '',
);

onMounted(async () => {
  const extensions = await metaDataStore.getMetaDataCountryCode();
  _.forEach(extensions, val => {
    phoneExtensions.value.push({
      title: val.country_code,
      value: val.country_code,
    });
  });
});

</script>

<style lang="scss">
.base-phone-text-field {
  .v-text-field input {
    color: #9fa1b8;
  }

  .v-input__prepend {
    width: 130px;
  }
}
</style>
