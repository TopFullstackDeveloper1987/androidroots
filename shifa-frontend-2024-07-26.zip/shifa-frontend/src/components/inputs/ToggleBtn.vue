<template>
  <v-btn-toggle
    :color="color"
    v-bind="$attrs"
    class="text-secondary"
  >
  <btn v-for="(button, index) in buttons" :key="index">{{ button }}</btn>
  </v-btn-toggle>
</template>

<script setup lang="ts">
import { PropType } from 'vue';

const props = defineProps({
  color: {
    type: String,
    default: 'primary',
  },
  indeterminate: {
    type: Boolean,
    default: true,
  },
  buttons: {
    type: Array as PropType<String[]>,
    required: true,
  },
});
</script>
