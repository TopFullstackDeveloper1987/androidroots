<template>
  <v-menu>
    <template v-slot:activator="{ props }">
      <div v-bind="props" class="d-flex align-center user-pic-container cursor-pointer">
        <v-icon icon="mdi-account-circle" color="primary" size="35"/>
      </div>
    </template>
    <v-list>
      <v-list-item @click="logout">
        <v-list-item-title>{{ $t('layouts.logout') }}</v-list-item-title>
      </v-list-item>
    </v-list>
  </v-menu>
</template>

<script setup lang="ts">

import { useRouter } from 'vue-router';

const router = useRouter();

const logout = () => {
  // Clear user session and JWT token from local storage
  localStorage.removeItem('token');
  localStorage.removeItem('currentFacilityId');
  localStorage.removeItem('userInfo');
  localStorage.removeItem('currentPatientId');

  // Redirect to the login page
  router.push('/login');
};
</script>

<style scoped></style>
