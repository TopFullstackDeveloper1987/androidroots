<template>
  <v-btn fab icon>
    <v-badge content="2" color="error">
      <v-icon>mdi-bell-outline</v-icon>
    </v-badge>
  </v-btn>
</template>

<script setup lang="ts"></script>

<style scoped></style>
