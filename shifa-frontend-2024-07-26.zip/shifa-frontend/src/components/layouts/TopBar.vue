<template>
  <v-app-bar flat white height="78" id="shifa-top-bar" align-center>
    <v-app-bar-nav-icon class="ml-0 ml-md-2" @click="$emit('menuClicked')" />
    <v-app-bar-title class="ml-1 ml-md-2">
      <router-link to="/">
        <v-img width="112" height="43" :src="logo" />
      </router-link>
    </v-app-bar-title>

    <v-sheet position="relative" class="bg-transparent">
      <div v-if="!$vuetify.display.mdAndDown" class="search">
        <PatientSearch ref="PatientSearchRef" @create-encounter="createEncounter" @create-appointment="createAppointment" />
      </div>
      <v-card
        v-if="showSearch"
        class="search-mobile"
        v-click-outside="onClickOutside"
      >
        <PatientSearch ref="PatientSearchMobileRef" is-mobile @patient-selected="showSearch = false" @create-encounter="createEncounter" @create-appointment="createAppointment" />
      </v-card>
    </v-sheet>

    <v-sheet v-if="$vuetify.display.mdAndDown">
      <btn
        icon-only
        icon="mdi-magnify"
        @click="showSearch = !showSearch"
        :width="$vuetify.display.xs ? '32' : undefined"
        :height="$vuetify.display.xs ? '32' : undefined"
      >
      </btn>
    </v-sheet>

    <v-sheet class="ml-2 ml-md-4">
      <btn
        icon="mdi-plus"
        :icon-only="$vuetify.display.mdAndDown"
        :iconBefore="true"
        primary
        to="/register/patient"
        :width="$vuetify.display.xs ? '32' : undefined"
        :height="$vuetify.display.xs ? '32' : undefined"
      >
        {{
          $vuetify.display.mdAndDown
            ? ''
            : $t('register_patient.register_patient')
        }}
      </btn>
    </v-sheet>

    <v-sheet class="lang-switcher">
      <LanguageSwitcher />
    </v-sheet>

    <v-sheet
      v-if="!$vuetify.display.xs"
      class="mr-2"
    >
      <Notifications />
    </v-sheet>

    <v-sheet class="mr-2 mx-md-4">
      <UserMenu />
    </v-sheet>
    <encounter-dialog
      v-model="isEncounterDialog"
      :practitioners="practitionerSearchStore.practitioners"
      :patient-id="selectedPatient?.id"
      @submit="submit"
    />
    <new-appointment
      v-model="isShowNewAppointmentDialog"
      :practitioner-id="practitioner?.id"
      :patient-id="selectedPatient?.id"
      @submit="submit"
    />
  </v-app-bar>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue';
import logo from '@/assets/logo/logo-english.svg';
import PatientSearch from '@/components/common/PatientSearch.vue';
import LanguageSwitcher from '@/components/layouts/LanguageSwitcher.vue';
import Notifications from '@/components/layouts/Notifications.vue';
import UserMenu from '@/components/layouts/UserMenu.vue';
import EncounterDialog from '@/components/medical-records/encounter-notes/EncounterDialog.vue';
import NewAppointment from '@/components/appointments/NewAppointment.vue';

import { IPatient, IPractitioner } from '@/types';
import { usePractitionerSearchStore, useMedicalToolsStore, usePatientStore, useFacilityStore } from '@/store';

const showSearch = ref<boolean>(false);
const isEncounterDialog = ref<boolean>(false);
const isShowNewAppointmentDialog = ref<boolean>(false);
const practitioner = ref<IPractitioner>();
const selectedPatient = ref<IPatient>();
const PatientSearchRef = ref();
const PatientSearchMobileRef = ref();

const practitionerSearchStore = usePractitionerSearchStore();
const medicalToolsStore = useMedicalToolsStore();
const patientStore = usePatientStore();
const facilityStore = useFacilityStore();

const onClickOutside = () => {
  if(isShowNewAppointmentDialog.value || isEncounterDialog.value) {
    return;
  }
  showSearch.value = false;
};

const createEncounter = (patient: IPatient) => {
  selectedPatient.value = patient;
  isEncounterDialog.value = true;
};

const createAppointment = (patient: IPatient) => {
  selectedPatient.value = patient;
  isShowNewAppointmentDialog.value = true;
};

const submit = () => {
  patientStore.setCurrentPatient(selectedPatient.value!);
};

onMounted(async () => {
  practitioner.value = await medicalToolsStore.getPractitionerDetails();
  await practitionerSearchStore.searchPractitioners({
    fuuid: facilityStore.currentFacilityId!,
  });
});

</script>

<style lang="scss" scoped>
#shifa-top-bar {
  background: #fff;
  overflow: visible;
  border: 1px solid #dce2f1;
}

.v-app-bar-title:deep(.v-toolbar-title__placeholder) {
  width: fit-content;
}

.search {
  position: absolute;
  right: 0;
  top: -30px;
}

.search-mobile {
  position: absolute;
  top: 30px;
  left: -165px;
}

.lang-switcher {
  width: 184px;
  margin: 0 8px;
}

@media (max-width: 600px) {
  .lang-switcher {
    width: unset;
    margin: 0;
  }
}

</style>
