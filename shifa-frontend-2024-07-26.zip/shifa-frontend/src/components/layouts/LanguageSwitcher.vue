<template>
  <select-field
    :items="languages"
    item-title="title"
    item-value="value"
    v-model="locale"
    @change="changeLanguage"
    :menu-icon="$vuetify.display.xs ? '' : '$dropdown'"
    :bg-color="$vuetify.display.xs ? 'transparent' : undefined"
  >
    <template v-slot:selection="{ item }">
      <div class="d-flex align-center">
        <img
          :src="item.raw.icon"
          :width="$vuetify.display.xs ? 30 : 24"
          :height="$vuetify.display.xs ? 30 : 24"
          :alt="item.raw.icon"
        />
        <span v-if="!$vuetify.display.xs" class="ml-3 text-capitalize">
          {{ item.title }}
        </span>
      </div>
    </template>
  </select-field>
</template>

<script lang="ts" setup>
import { onBeforeMount, ref } from 'vue';
import { ILanguageItem } from '@/types';
import EnglishIcon from '@/assets/icons/usa-flag.svg';
import KurdishIcon from '@/assets/icons/kurdish-flag.svg';
import ArabicIcon from '@/assets/icons/arabic-flag.svg';
import { i18n } from '@/plugins';

const languages = ref<ILanguageItem[]>([
  { title: 'English', value: 'en', icon: EnglishIcon },
  { title: 'العربية', value: 'ar', icon: ArabicIcon },
  { title: 'سۆرانی', value: 'ckb', icon: KurdishIcon },
  { title: 'بادینی', value: 'ku', icon: KurdishIcon },
]);

const locale = ref<string>('en');

const changeLanguage = () => {
  localStorage.setItem('locale', locale.value);
  location.reload();
};

onBeforeMount(() => {
  if (['en', 'ar', 'ckb', 'ku'].includes(localStorage.getItem('locale')!)) {
    locale.value = localStorage.getItem('locale')!;
    i18n.global.locale.value = localStorage.getItem('locale')!;
  }
});

defineExpose({ languages });
</script>

<style lang="scss">
.base-text-field {
  .v-field__append-inner {
    i {
      font-size: 30px;
      color: #6064d8;
    }
  }
  .v-text-field input {
    color: #6064d8;
  }
}
</style>
