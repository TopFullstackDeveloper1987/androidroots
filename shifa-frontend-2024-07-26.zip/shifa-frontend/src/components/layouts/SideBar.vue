<template>
  <v-navigation-drawer width="268">
    <v-list
      nav
      density="compact"
      v-model:opened="opened"
      class="shifa-nav"
      :selected="selected"
    >
      <v-list-item
        v-if="showDashboard"
        prepend-icon="$dashboard"
        :title="$t('layouts.dashboard')"
        value="Dashboard"
        to="/dashboard"
        rounded="xl"
        elevation="0"
        variant="elevated"
        active-class="bg-primary active-nav dashboard"
      />

      <v-list-group
        v-for="{ pageId, name, icon, children } in computedSideBarItems"
        :key="pageId"
        :value="name"
        :prepend-icon="icon"
      >
        <template v-slot:activator="{ props }">
          <v-list-item
            class="font-weight-bold"
            v-bind="props"
            :title="$t(name)"
          />
        </template>

        <v-list-item
          v-for="child in children"
          :key="child.pageId"
          :value="child.pageId"
          :title="$t(child.name)"
          :to="child.path || '/'"
          :disabled="!child.path"
          rounded="xl"
          elevation="0"
          variant="elevated"
          exact
          active-class="bg-primary active-nav"
        ></v-list-item>
      </v-list-group>
    </v-list>
  </v-navigation-drawer>
</template>

<script lang="ts" setup>
import { ref, computed, onMounted } from 'vue';
import { useRoute } from 'vue-router';

import { sideBarItems, basicSideBarItems, onlyPrinterSideBarItems, onlyReportSideBarItems, onlyToolsSideBarItems, receptionistSideBarItems } from '@/constants';
import { usePatientStore, useAuthStore } from '@/store';
import { ISideBarItem, UserRole, UserSubscription } from '@/types';
import { LocalStorageService } from '@/services';

const route = useRoute();
const patientStore = usePatientStore();
const authStore = useAuthStore();

const currentUserRole =
    LocalStorageService.getInstance().getUserRole();

const opened = ref([]);
const selected = computed(() => [route.name]);
const items = ref<ISideBarItem[]>([]);
const showDashboard = computed(() => authStore.userInfo.subscription === UserSubscription.Basic || authStore.userInfo.subscription === UserSubscription.Silver || authStore.userInfo.subscription === UserSubscription.Gold);
const isReceptionist = computed(() => currentUserRole === UserRole.Receptionist);

const computedSideBarItems = computed(() => {
  return items.value.map((item) => {
    const children = item.children.map((child) => {
      if (!child.path.includes(':patientId')) {
        return child;
      }

      const path = patientStore.currentPatientId
        ? child.path.replace(':patientId', patientStore.currentPatientId!)
        : null;

      return {
        ...child,
        path,
      };
    });

    return {
      ...item,
      children,
    };
  });
});



onMounted(() => {
  if(isReceptionist.value) {
    items.value = receptionistSideBarItems;
    return;
  }

  switch(authStore.userInfo.subscription) {
    case UserSubscription.ToolPrescriptionPrinter:
      items.value = onlyPrinterSideBarItems;
      break;
    case UserSubscription.ToolReportGenerator:
      items.value = onlyReportSideBarItems;
      break;
    case UserSubscription.ToolKit:
      items.value = onlyToolsSideBarItems;
      break;
    case UserSubscription.Basic:
      items.value = basicSideBarItems;
      break;
    case UserSubscription.Silver:
      items.value = sideBarItems;
      break;
    case UserSubscription.Gold:
      items.value = sideBarItems;
      break;
    default:
      items.value = sideBarItems;
  }
});
</script>

<style lang="scss">
.shifa-nav {
  padding-left: 0;

  .active-nav {
    border-top-left-radius: 0 !important;
    border-bottom-left-radius: 0 !important;

    &.dashboard {
      .v-list-item__prepend > .v-icon {
        background-color: transparent;

        path {
          fill: white;
        }
      }
    }
  }

  .v-list-item--nav {
    .v-list-item-title {
      font-size: 14px;
      line-height: normal;
    }
  }

  .v-list-item__prepend > .v-icon {
    background-color: #f0f0fb;
    border-radius: 10px;
    width: 36px;
    height: 32px;

    & ~ .v-list-item__spacer {
      width: 20px;
    }
  }
}
</style>
