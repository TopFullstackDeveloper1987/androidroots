<template>
  <card-container
    :title="currentPatient ? null : $t('register_patient.register_patient')"
    :icon="currentPatient ? null : '$patient-injury'"
    :max-width="currentPatient ? null : 1077"
    class="justify-center card-container"
  >
    <VueCamera v-model="isShowDialog" />
    <div class="d-flex justify-center">
      <btn class="mt-3" primary icon="mdi-camera" @click="isShowDialog = true">{{ $t('camera.scan_national_id') }}</btn>
    </div>
    <v-form ref="formRef" v-model="isValidForm" @submit.prevent="submit">
      <v-container class="mandatory-form-fields-container">
        <v-row>
          <v-col cols="12" v-if="!currentPatient">
            <v-card-title class="px-0">{{
              $t('register_patient.personal_information')
            }}</v-card-title>
          </v-col>

          <v-col cols="12" class="py-2">
            <text-field
              v-model="formData.full_name"
              :rules="[required]"
              :label="$t('register_patient.full_name')"
              attr="full_name"
            />
          </v-col>

          <v-col cols="6" class="py-2">
            <v-radio-group v-model="formData.gender" inline hide-details>
              <v-radio v-for="(gender, idx) in gendersMock" :key="idx" :label="gender.title" :value="gender.value" color="primary"></v-radio>
            </v-radio-group>
          </v-col>

          <v-col cols="6" sm="3" md="3" class="py-2">
            <text-field
              v-model="formData.age"
              :rules="[required, onlyNumber]"
              :label="$t('common.age')"
            />
          </v-col>

          <v-col cols="6" sm="3" md="3" class="py-2">
            <select-field v-model="formData.years_or_months" :rules="[required]" :items="options" :placeholder="`${$t('register_patient.year')}/${$t('register_patient.month')}`" />
          </v-col>

          <v-col cols="6" class="py-2">
            <date-picker
              v-model="formData.dateOfBirth"
              :placeholder="$t('register_patient.date_of_birth')"
              attr="date_of_birth"
            />
          </v-col>
          <v-col cols="12" md="6" class="py-2">
            <phone-text-field
              v-model="formData.whatsapp"
              v-model:phone-number-extension="formData.whatsapp_country_code"
              :rules="[required, validPhoneNumber, onlyNumber]"
              :label="$t('register_patient.whatsapp')"
              placeholder="7xxxxxxxxx"
              attr="whatsapp"
            />
          </v-col>
          <v-col cols="12" md="6" class="py-2">
            <text-field
              v-model="formData.address"
              :label="$t('register_patient.address')"
              attr="address"
            />
          </v-col>
        </v-row>
        <expansion-panel v-model="panel" class="mt-7 mb-4">
          <template #title-content>{{ $t('register_patient.more_info') }}</template>
          <template #content>
            <div class="centered w-full">
              <v-container class="px-0 optional-form-fields-container">
                <v-row>
                  <v-col cols="12" md="6" class="py-2">
                    <text-field
                      v-model="formData.email"
                      :rules="[validOptionalEmail]"
                      :label="$t('register_patient.email')"
                      attr="email"
                    />
                  </v-col>
                  <v-col cols="12" md="6" class="py-2">
                    <select-field
                      v-model="formData.ethnicity"
                      :items="ethnicitiesMock"
                      :label="$t('register_patient.ethnicity')"
                      attr="ethnicity"
                    />
                  </v-col>
                  <v-col cols="12" md="6" class="py-2">
                    <select-field
                      v-model="formData.registrationMethod"
                      :items="registrationMethodsMock"
                      :label="$t('register_patient.registration_method')"
                      attr="registration_method"
                    />
                  </v-col>
                  <v-col cols="12" md="6" class="py-2">
                    <phone-text-field
                      v-model="formData.phone_1"
                      v-model:phone-number-extension="formData.phone_1_country_code"
                      :rules="[required, validPhoneNumber, onlyNumber]"
                      :label="$t('register_patient.phone_number')"
                      placeholder="7xxxxxxxxx"
                      attr="phone_1"
                    />
                  </v-col>
                  <v-col cols="12" md="6" class="py-2">
                    <phone-text-field
                      v-model="formData.viber"
                      v-model:phone-number-extension="formData.viber_country_code"
                      :rules="[validPhoneNumber, onlyNumber]"
                      :label="$t('register_patient.viber')"
                      placeholder="7xxxxxxxxx"
                      attr="viber"
                    />
                  </v-col>
                  <v-col cols="12" md="6" class="py-2">
                    <select-field
                      v-model="formData.city"
                      :items="cities"
                      item-title="name"
                      item-value="id"
                      :label="$t('register_patient.city')"
                      attr="city"
                    />
                  </v-col>

                  <v-col cols="12" md="6" class="py-2">
                    <select-field
                      v-model="formData.religion"
                      :items="religionsMock"
                      :label="$t('register_patient.religion')"
                      attr="religion"
                    />
                  </v-col>
                  <v-col cols="12" md="6" class="py-2">
                    <select-field
                      v-model="formData.language"
                      :items="languages"
                      :label="$t('register_patient.language')"
                      attr="preferred_language"
                    />
                  </v-col>
                  <v-col cols="12" md="6" class="py-2">
                    <select-field
                      v-model="formData.smokingStatus"
                      :items="smokingStatusesMock"
                      :label="$t('register_patient.smoking_status')"
                      attr="smoking_status"
                    />
                  </v-col>
                </v-row>
              </v-container>
            </div>
          </template>
        </expansion-panel>
        <template v-if="!currentPatient">
          <v-divider class="mt-7 mb-4"></v-divider>

          <v-row>
            <v-col cols="12">
              <v-card-title class="px-0">{{
                $t('register_patient.consent_agreement')
              }}</v-card-title>
            </v-col>

            <v-col cols="12">
              <v-card-text class="pa-0 text-disabled">{{
                $t('register_patient.consent_agreement')
              }}</v-card-text>
            </v-col>
          </v-row>

          <v-row class="mt-0">
            <v-col class="ps-0 py-2">
              <checkbox
                :label="$t('register_patient.accept_consent_agreement')"
                v-model="isAcceptAgreement"
              />
            </v-col>
          </v-row>
        </template>

        <v-divider class="my-4" />
        <v-row>
          <v-col class="text-right">
            <btn
              primary
              type="submit"
              :loading="commonStore.isLoading"
              :disabled="!currentPatient && !isAcceptAgreement"
            >
              {{
                currentPatient
                  ? $t('common.save')
                  : $t('register_patient.register_patient')
              }}
            </btn>
          </v-col>
        </v-row>
      </v-container>
    </v-form>
  </card-container>
</template>

<script lang="ts" setup>
import { PropType, reactive, ref, onMounted, watch } from 'vue';
import { useI18n } from 'vue-i18n';
import { useRouter } from 'vue-router';
import moment from 'moment-timezone';
import VueCamera from '@/components/common/VueCamera.vue';

const panel = ref<number[] | undefined>();
const options = ref<ISelect<string>[]>([
  {
    title: 'Years',
    value: 'years',
  },
  {
    title: 'Months',
    value: 'months',
  },
]);

import { required, validOptionalEmail, validPhoneNumber, onlyNumber } from '@/utils/validations';
import {
  languages,
  gendersMock,
  ethnicitiesMock,
  citiesMock,
  religionsMock,
  registrationMethodsMock,
  smokingStatusesMock,
} from '@/constants';
import {
  usePatientRegisterStore,
  useCommonStore,
  useFacilityStore,
  usePatientStore,
  useMetaDataStore,
} from '@/store';
import { IPatient, ISelect, IUpdatePatientPayload, ToastType,IMetaDataCity } from '@/types';

const commonStore = useCommonStore();
const patientRegisterStore = usePatientRegisterStore();
const patientStore = usePatientStore();
const facilityStore = useFacilityStore();
const metaDataStore = useMetaDataStore();

const router = useRouter();

const { t } = useI18n();

const props = defineProps({
  currentPatient: {
    type: Object as PropType<IPatient | null>,
    default: null,
  },
  onlyOptionalFields: {
    type: Boolean,
    default: false,
  },
});

const isValidForm = ref(false);
const formRef = ref(null);
const isShowDialog = ref(false);
const cities = ref<IMetaDataCity[]>([]);

const formData = reactive<{
  full_name?: string;
  email?: string;
  gender?: string;
  dateOfBirth?: Date;
  age?: string;
  years_or_months?: string;
  ethnicity?: string;
  phone_1?: string;
  phone_1_country_code?: string;
  viber?: string;
  viber_country_code?: string;
  whatsapp?: string;
  whatsapp_country_code?: string;
  address?: string;
  city?: number;
  religion?: string;
  language?: string;
  registrationMethod?: number;
  smokingStatus?: string;
}>({
  full_name: '',
  email: '',
  gender: 'M',
  dateOfBirth: null!,
  age: null!,
  years_or_months: 'years',
  ethnicity: '',
  phone_1: '',
  phone_1_country_code: '+964',
  viber: '',
  viber_country_code: '+964',
  whatsapp: '',
  whatsapp_country_code: '+964',
  address: '',
  city: null!,
  religion: '',
  language: 'CKB',
  registrationMethod: 3,
  smokingStatus: '',
});

const isAcceptAgreement = ref(false);

onMounted(async () => {
  updatePatientProfile();
  cities.value = await metaDataStore.getMetaData('city/IQ/');
});

watch(
  () => props.currentPatient,
  () => {
    updatePatientProfile();
  },
);

const updatePatientProfile = () => {
  if (props.currentPatient) {
    // update patient
    formData.full_name = props.currentPatient.full_name;
    formData.email = props.currentPatient.email;
    formData.gender = props.currentPatient.gender;
    formData.age = props.currentPatient.age;
    formData.years_or_months = props.currentPatient.years_or_months;
    formData.dateOfBirth = moment
      .utc(props.currentPatient.date_of_birth)
      .toDate();
    formData.ethnicity = props.currentPatient.ethnicity?.code;
    formData.phone_1 = props.currentPatient.phone_1;
    formData.viber = props.currentPatient.viber;
    formData.whatsapp = props.currentPatient.whatsapp;
    formData.phone_1_country_code = props.currentPatient.phone_1_country_code;
    formData.viber_country_code = props.currentPatient.viber_country_code;
    formData.whatsapp_country_code = props.currentPatient.whatsapp_country_code;
    formData.address = props.currentPatient.address;
    formData.city = props.currentPatient.city?.id;
    formData.religion = props.currentPatient.religion?.code;
    formData.language = props.currentPatient.preferred_language?.iso_code;
    formData.registrationMethod = props.currentPatient.registration_method;
    formData.smokingStatus = props.currentPatient.smoking_status?.code;
  }
};

const submit = async () => {
  await commonStore.clearErrorOnSubmit();

  if (!isValidForm.value) {
    return;
  }

  const payload: IUpdatePatientPayload = {
    email: formData.email!,
    full_name: formData.full_name!,
    date_of_birth: moment.utc(formData.dateOfBirth).format('YYYY-MM-DD'),
    phone_1: formData.phone_1!,
    viber: formData.viber!,
    whatsapp: formData.whatsapp!,
    age: formData.age!,
    years_or_months: formData.years_or_months!,
    phone_1_country_code: formData.phone_1_country_code!,
    viber_country_code: formData.viber_country_code!,
    whatsapp_country_code: formData.whatsapp_country_code!,
    gender: formData.gender!,
    registration_method: formData.registrationMethod!,
    registered_facility: facilityStore.currentFacilityId!,
    smoking_status: formData.smokingStatus!,
    address: formData.address!,
    ethnicity: formData.ethnicity!,
    religion: formData.religion!,
    preferred_language: formData.language!,
    city: formData.city!,
  };

  if (props.currentPatient) {
    await patientStore.updateCurrentPatient(payload);
    await patientStore.getCurrentPatient(true);

    commonStore.showToast(
      ToastType.Success,
      t('patient.update_patient_success'),
    );
  } else {
    const patient = await patientRegisterStore.registerPatient(payload);
    await patientStore.getCurrentPatient(true);

    commonStore.showToast(
      ToastType.Success,
      t('register_patient.register_patient_success'),
    );

    router.push(`/patients/${patient.id}/profile`);
  }
};
</script>
<style lang="scss" scoped>
.card-container {
  width: -webkit-fill-available;

  .mandatory-form-fields-container, .optional-form-fields-container {
    max-width: unset;
  }
}
</style>
