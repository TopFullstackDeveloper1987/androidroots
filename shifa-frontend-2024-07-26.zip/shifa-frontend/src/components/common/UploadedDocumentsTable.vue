<template>
  <data-table-server
    :items="patientDocuments"
    :headers="headers"
    :show-search-results-info="false"
    class="patient-documents-table"
  >
    <template v-slot:item="{ item }">
      <tr>
        <td class="d-flex align-center">
          <v-icon
            v-if="isImageFile(item.selectable.file_format)"
            icon="mdi-image"
            color="primary"
            @click="openDocumentPopup(item.selectable)"
          ></v-icon>
          <v-icon v-else icon="$attachment" @click="openDocumentPopup(item.selectable)"></v-icon>
          <span class="ml-2 file-name text-truncate text-decoration-underline text-primary cursor-pointer" @click="downloadFile(item.selectable)">{{
            item.selectable.file_name
          }}</span>
        </td>
        <td>
          {{
            moment.utc(item.selectable.upload_date).format('YYYY-MM-DD HH:mm')
          }}
        </td>
        <td>
          <v-btn
            icon
            color="light"
            size="small"
            :elevation="0"
          >
            <v-icon icon="mdi-square-edit-outline" color="primary"></v-icon>
          </v-btn>
          <v-btn
            icon
            color="light"
            size="small"
            :elevation="0"
            class="mx-1"
            @click="downloadFile(item.selectable)"
          >
            <v-icon icon="mdi-download" color="primary"></v-icon>
          </v-btn>
          <v-btn
            icon
            color="light"
            size="small"
            :elevation="0"
            @click="openDocumentPopup(item.selectable)"
          >
            <v-icon icon="mdi-open-in-new" color="primary"></v-icon>
          </v-btn>
        </td>
      </tr>
    </template>
  </data-table-server>
</template>
<script lang="ts" setup>
import { ref, onMounted, computed, ComputedRef } from 'vue';
import DataTableServer from '../common/DataTableServer.vue';
import { useI18n } from 'vue-i18n';
import moment from 'moment';
import { IPatientDocument } from '@/types';
import { usePatientDocumentsStore, usePatientStore } from '@/store';

const { t } = useI18n();

const { getPatientDocuments, downloadPatientDocument } =
  usePatientDocumentsStore();
const patientStore = usePatientStore();

const patientDocuments = ref<IPatientDocument[]>([]);

const currentPatientId: ComputedRef<string | null> = computed(() => {
  return patientStore.currentPatientId;
});

const headers = [
  {
    title: '#',
    key: 'file',
    sortable: false,
  },
  {
    title: t('patient.uploaded_at'),
    key: 'uploaded_at',
    sortable: false,
  },
  {
    title: t('patient.actions'),
    key: 'actions',
    sortable: false,
  },
];

const downloadFile = async (file: IPatientDocument) => {
  let patientDocument = await downloadPatientDocument(file.id);
  window.open(patientDocument.presigned_url, '_blank');
};

const openDocumentPopup = async (file: IPatientDocument) => {
  let patientDocument = await downloadPatientDocument(file.id);
  window.open(patientDocument.presigned_url, '_blank', 'width=600,height=400');
};

const isImageFile = (type: string) => {
  return ['jpg', 'jpeg', 'png', 'gif', 'svg'].includes(type);
};

const initialDocumentsLoad = async () => {
  if (patientStore.currentPatientId) {
    patientDocuments.value = await getPatientDocuments(currentPatientId.value!);
    patientDocuments.value = patientDocuments.value.reverse();
  }
};

onMounted(async () => {
  initialDocumentsLoad();
});

defineExpose({
  initialDocumentsLoad,
});
</script>
<style lang="scss" scoped>
.patient-documents-table:deep(.v-table__wrapper) {
  max-height: 400px;
}
.file-name {
  max-width: 225px;
}
</style>
