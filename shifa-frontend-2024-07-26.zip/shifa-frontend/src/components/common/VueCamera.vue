<template>
  <base-dialog v-model="isShowDialog" v-bind:="$attrs" :fullscreen="mobile">
    <template #content>
      <simple-vue-camera ref="camera">
        <div
          class="inner-camera pa-4 d-flex flex-column align-center justify-between"
        >
          <p class="info-text text-center">
            {{
              !frontIdCaptured
                ? $t('camera.capture_front_id')
                : $t('camera.capture_back_id')
            }}
          </p>
          <div class="id-box mt-2"></div>
          <btn
            class="mt-3"
            primary
            icon="mdi-camera"
            :loading="loading"
            icon-only
            @click="snapshot"
          />
        </div>
      </simple-vue-camera>
    </template>
  </base-dialog>
</template>

<script lang="ts" setup>
import { IDocumentScanPayload, ToastType } from '@/types';
import SimpleVueCamera from 'simple-vue-camera';
import { computed, ref, WritableComputedRef } from 'vue';
import { useCommonStore, usePatientDocumentsStore } from '@/store';
import { useI18n } from 'vue-i18n';
import { useDisplay } from 'vuetify';
const { mobile } = useDisplay();

const emit = defineEmits(['update:modelValue']);
const { t } = useI18n();

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const commonStore = useCommonStore();
const patientDocumentsStore = usePatientDocumentsStore();

const frontIdCaptured = ref(false);
const backIdCaptured = ref(false);

const loading = ref(false);

const front = ref<Blob | null>(null);
const back = ref<Blob | null>(null);

// Get a reference of the component
const camera = ref<InstanceType<typeof SimpleVueCamera>>();

// Use camera reference to call functions
const snapshot = async () => {
  front.value = await camera.value?.snapshot(
    { width: 1920, height: 1080 },
    'image/png',
    0.5,
  )!;

  if (!frontIdCaptured.value) {
    frontIdCaptured.value = true;

    camera.value?.pause();

    loading.value = true;

    front.value = await camera.value?.snapshot(
      { width: 1920, height: 1080 },
      'image/png',
      0.5,
    )!;

    commonStore.showToast(ToastType.Success, t('camera.front_id_captured'));

    loading.value = false;

    camera.value?.resume();
  } else {
    backIdCaptured.value = true;

    camera.value?.pause();

    loading.value = true;

    back.value = await camera.value?.snapshot()!;

    commonStore.showToast(ToastType.Success, t('camera.back_id_captured'));
    frontIdCaptured.value = false;
    backIdCaptured.value = false;

    let formData = new FormData();

    formData.append('front_image', front.value!, 'front.png');
    formData.append('back_image', back.value!, 'back.png');

    await patientDocumentsStore.scanDocument(formData);

    loading.value = false;

    isShowDialog.value = false;
  }
};
</script>
<style lang="scss" scoped>
.inner-camera {
  height: 100%;

  .info-text {
    color: #fff;
  }

  .id-box {
    height: 150px;
    width: 250px;
    border: 5px solid #5f63d7;
    border-radius: 4px;

    @media (max-width: 547px) {
      height: 100px;
      width: 100%;
    }
  }

  @media (max-width: 547px) {
    padding: 10px;
  }
}
</style>
