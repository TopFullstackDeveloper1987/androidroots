<template>
  <div>
    <div
      class="drop-zone"
      @dragenter="dragEnter"
      @dragleave="dragLeave"
      @drop="dragLeave"
    >
      <p class="file-drop-label" :class="{ 'text-disabled': !onDrag }">
        {{ $t('common.click_or_drop_your_files_here') }}
      </p>
      <v-file-input
        ref="fileInputRef"
        v-model="files"
        :multiple="multiple"
        variant="outlined"
        bg-color="light"
        hide-details
        color="primary"
        :label="$t('common.click_or_drop_your_files_here')"
        class="file-input"
      ></v-file-input>
    </div>
    <v-expansion-panels class="expansion-panels">
      <v-expansion-panel v-for="(file, index) in files" :key="index">
        <template #title>
          <btn
            v-if="!uploadLoading"
            icon="mdi-delete"
            icon-only
            :primary="false"
            size="small"
            variant="text"
            color="error"
            @click.stop="deleteFile(index)"
          />
          <v-img
            v-if="isImageFile(file?.type)"
            class="file-image"
            height="40"
            width="40"
            :src="getImageSrc(file)"
          ></v-img>
          <v-icon
            v-else
            class="file"
            color="primary"
            size="40"
            icon="mdi-file"
          />
          <p class="ml-3 text-body-1">{{ file?.name }}</p>
        </template>
        <template #text>
          <!-- <select-field
            :items="['Test 1', 'Test 2', 'Test 3']"
            chips
            multiple
            label="Tags"
          /> -->
          <text-area :label="$t('common.description')" class="mt-2" :rows="4" />
        </template>
      </v-expansion-panel>
    </v-expansion-panels>
  </div>
</template>
<script lang="ts" setup>
import { ref, WritableComputedRef, computed } from 'vue';
const emit = defineEmits(['update:modelValue']);

const fileInputRef = ref();
const onDrag = ref<Boolean>(false);

const props = defineProps({
  modelValue: {
    type: Array<File>,
    default: () => [],
  },
  multiple: {
    type: Boolean,
    default: false,
  },
  uploadLoading: {
    type: Boolean,
    default: false,
  },
});

const files: WritableComputedRef<File[]> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const getImageSrc = (file: File) => {
  return URL.createObjectURL(file);
};

const isImageFile = (type: string) => {
  return [
    'image/jpg',
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/svg',
  ].includes(type);
};

const deleteFile = (index: number) => {
  files.value.splice(index, 1);
};

const dragEnter = () => {
  onDrag.value = true;
};

const dragLeave = () => {
  onDrag.value = false;
};
</script>
<style lang="scss" scoped>
.drop-zone {
  position: relative;
  border: 1px dashed #5f63d7;
  border-radius: 10px;
  background-color: #f5f7fa;
  cursor: pointer;
  .file-drop-label {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 100px;
    text-align: center;
    color: #5f63d7;
  }

  .file-input {
    width: inherit;
    opacity: 0;
  }

  .file-input:deep(.v-input__control) {
    height: 225px;
  }

  .file-input:deep(.v-field__input) {
    display: none;
  }

  .file-input:deep(.v-input__prepend) {
    display: none;
  }

  .file-input:deep(.v-field__clearable) {
    display: none;
  }
}

.expansion-panels:deep(.v-expansion-panel-title) {
  padding-left: 0;
  padding-right: 0;
}

.expansion-panels:deep(.v-expansion-panel-text__wrapper) {
  padding-left: 0;
  padding-right: 0;
}

.files-list:deep(.v-list-item__prepend) {
  max-width: 40px;
}

.file-image {
  object-fit: unset;
  border: 0.25px solid #5f63d7;
  border-radius: 10px;
  max-width: 40px;
}
</style>
