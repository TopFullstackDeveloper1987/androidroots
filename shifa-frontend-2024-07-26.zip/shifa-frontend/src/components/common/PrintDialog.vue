<template>
  <base-dialog
    v-model="isShowDialog"
    show-footer
    v-bind:="$attrs"
    max-width="1200"
    :width="smAndDown ? 600 : width"
    :fullscreen="mobile"
  >
    <template #header>
      <btn primary @click="print"> {{ $t('common.print') }} </btn>
    </template>

    <template #content>
      <iframe
        id="print-contents-iframe"
        v-if="html"
        width="100%"
        height="100%"
        frameborder="0"
      >
      </iframe>
    </template>

    <template #footer>
      <div class="w-full text-right">
        <btn primary @click="print"> {{ $t('common.print') }} </btn>
      </div>
    </template>

    <v-divider class="my-4" />
  </base-dialog>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, WritableComputedRef, Ref } from 'vue';
import { useEncounterStore } from '@/store';
import { useDisplay } from 'vuetify';

const emit = defineEmits(['update:modelValue']);
const { mobile, smAndDown } = useDisplay();
const iframeRef: Ref<HTMLIFrameElement | null> = ref(null);

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  html: {
    type: String,
    default: '',
  },
  width: {
    type: Number || String,
    default: undefined,
  },
});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

onMounted(() => {
  loadHtmlToIframe();
  console.log('onMounted called');
});

const loadHtmlToIframe = () => {
  if (iframeRef.value && props.html) {
    const { contentDocument } = iframeRef.value;
    if (contentDocument) {
      contentDocument.open();
      contentDocument.write(props.html);
      contentDocument.close();
    }
  }
};

const print = async () => {
  const iframe = document.getElementById(
    'print-contents-iframe',
  ) as HTMLIFrameElement;
  if (!iframe) return;

  iframe.contentDocument!.open();
  iframe.contentDocument!.write(props.html);
  iframe.contentDocument!.close();
  iframe.contentWindow?.print();
};

const print_old = async () => {
  const modal = document.getElementById('print-contents');
  if (!modal) return;
  const cloned = modal.cloneNode(true);
  let section = document.getElementById('print');

  if (!section) {
    section = document.createElement('div');
    section.id = 'print';
    document.body.appendChild(section);
  }

  section.innerHTML = '';
  section.appendChild(cloned);
  window.print();
};
</script>

<style>
@media print {
  /* Hide everything outside of the printable content */
  * {
    display: none !important;
  }

  body > :not(#print-contents) {
    display: none;
  }

  #print-contents {
    display: block;
  }
}
</style>
