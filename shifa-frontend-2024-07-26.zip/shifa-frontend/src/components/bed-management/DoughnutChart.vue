<template>
  <Doughnut :data="statistics" :options="options" />
</template>

<script lang="ts" setup>
import { Chart as ChartJS, ArcElement, Tooltip, Legend, Title } from 'chart.js';
import { Doughnut } from 'vue-chartjs';
import { PropType, ref } from 'vue';
import { IDoughnutDataType } from '@/types';
ChartJS.register(ArcElement, Tooltip, Legend, Title);

const props = defineProps({
  statistics: {
    type: Object as PropType<IDoughnutDataType>,
    required: true,
  },
});

const options = ref({
  responsive: true,
  maintainAspectRatio: false,
  title: {
    display: true,
    text: 'Custom Chart Title',
  },
  // plugins: {

  // },
});
</script>
