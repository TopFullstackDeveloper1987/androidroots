<template>
  <v-card class="bed-card" outlined min-width="230">
    <v-card-title class="d-flex justify-space-between items-center">
      <span class="text-subtitle-1">{{ roomNumber }}</span>
      <!-- Menu Button with Options -->
      <v-menu :close-on-content-click="false" :nudge-right="40" transition="scale-transition" offset-y>
        <template v-slot:activator="{ props }">
          <v-btn v-bind="props" variant="text" rounded class="menu-btn">
            <v-icon>mdi-dots-vertical</v-icon>
          </v-btn>
        </template>
        <v-list>
          <v-list-item @click="$emit('update')">
            <v-list-item-title>{{ $t('common.edit') }}</v-list-item-title>
          </v-list-item>
          <v-list-item v-for="(item, index) in menuOptions" :key="index" @click="handleMenuClick(item)">
            <v-list-item-title>{{ item }}</v-list-item-title>
          </v-list-item>
          <v-list-item @click="$emit('remove')">
            <v-list-item-title>{{ $t('common.delete') }}</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </v-card-title>
    <v-divider></v-divider>
    <!-- Bed Icon -->
      <v-row justify="center" align="center" class="icon-row">
        <v-icon v-for="i in (roomType === BedType.Single ? 1 : 2)" :key="i" size="25" color="primary">mdi-bed-king</v-icon>
      </v-row>
      <v-divider></v-divider>
      <v-card-actions>
        <v-chip
          variant="outlined"
          size="small"
          :color="getStatusColor(roomStatus)"
        >
          {{ BED_STATUS_CHOICES[roomStatus] }}
        </v-chip>
      </v-card-actions>
  </v-card>
</template>

<script lang="ts" setup>
import { BedType } from '@/types';
import { BED_STATUS_CHOICES } from '@/constants';
import { ref } from 'vue';

const props = defineProps({
  roomNumber: {
    type: String,
    required: true,
  },
  roomType: {
    type: String,
    required: true,
  },
  roomStatus: {
    type: String,
    required: true,
  },
});

const emit = defineEmits(['update', 'remove']);

const menuOptions = ref(['Admit', 'Transfer', 'Discharge']);

const handleMenuClick = (option: any) => {
  // Handle menu option click here
  console.log('Clicked:', option);
};

const getStatusColor = (status: string) => {
  if (!status) return;
  if (status === 'occupied') return 'red';
  else if (status === 'available') return 'green';
  else if (status === 'needs_cleaning') return 'blue';
  else if (status === 'not_in_use') return 'orange';
  else return '';
};
</script>

<style scoped>
.bed-card {
  max-width: 300px; /* Adjust the width as needed */
  text-align: center;
  position: relative;
}

.icon-row {
   height: 100px;
}
</style>
