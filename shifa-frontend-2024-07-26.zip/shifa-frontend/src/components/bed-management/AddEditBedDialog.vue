<template>
  <form-dialog v-model="isShowDialog" @submit="save">
    <template v-slot:header>
      <div class="text-primary">
        {{
          isCreateAction ? $t('bed_management.add_bed') : $t('bed_management.edit_bed')
        }}
      </div>
    </template>
    <v-row>
      <v-col cols="12">
        <text-field
          v-model="formData.bed_number"
          :label="$t('bed_management.bed_number')"
          :rules="[required]"
          attr="bed_number"
        />
      </v-col>
      <v-col cols="12">
        <select-field
          v-model="formData.bed_status"
          :items="BedStatusMock"
          :rules="[required]"
          item-title="title"
          item-value="value"
          :label="$t('bed_management.bed_status')"
          attr="bed_status"
        />
      </v-col>
      <v-col cols="12">
        <select-field
          v-model="formData.bed_type"
          :items="BedTypesMock"
          :rules="[required]"
          item-title="title"
          item-value="value"
          :label="$t('bed_management.bed_type')"
          attr="bed_type"
        />
      </v-col>
      <v-col cols="12">
        <select-field
          v-model="formData.floor"
          :items="FloorsMock"
          :rules="[required]"
          item-title="title"
          item-value="value"
          :label="$t('bed_management.floor')"
          attr="floor"
        />
      </v-col>
    </v-row>
  </form-dialog>
</template>

<script setup lang="ts">
import {
  ref,
  computed,
  WritableComputedRef,
  PropType,
  watch,
} from 'vue';
import { required } from '@/utils/validations';
import {
  useCommonStore,
  useFacilityStore,
  useBedAvailabilityStore,
} from '@/store';
import { IBed, ToastType } from '@/types';
import { useI18n } from 'vue-i18n';
import { BedStatusMock, BedTypesMock, FloorsMock } from '@/constants';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  bed: {
    type: Object as PropType<IBed>,
    default: () => {},
  },
  isCreateAction: {
    type: Boolean,
    default: true,
  },
  floor: {
    type: Number,
    default: null,
  },
  ward: {
    type: Number,
    default: null,
  },
});

const commonStore = useCommonStore();
const facilityStore = useFacilityStore();
const bedAvailabilityStore = useBedAvailabilityStore();

const { t } = useI18n();

const emit = defineEmits(['update:modelValue', 'refresh']);

const formData = ref<IBed>(<IBed>{});

watch(
  () => props.modelValue,
  (newValue) => {
    if (newValue)
      if (!props.isCreateAction)
        formData.value = {
          ...props.bed,
        };
      else
        formData.value = {
          bed_number: '',
          bed_type: '',
          bed_status: '',
          facility: facilityStore.currentFacilityId!,
          floor: null!,
          ward: props.ward,
        };
  },
);

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const save = async () => {
  if (props.isCreateAction) {
    await bedAvailabilityStore.addBed(formData.value);
    commonStore.showToast(ToastType.Success, t('bed_management.bed_created'));
  } else {
    await bedAvailabilityStore.updateBed(formData.value);
    commonStore.showToast(ToastType.Success, t('bed_management.bed_updated'));
  }

  emit('refresh');
  isShowDialog.value = false;
};
</script>

<style scoped></style>
