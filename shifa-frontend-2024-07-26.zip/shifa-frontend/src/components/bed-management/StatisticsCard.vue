<template>
  <v-card class="card" height="260px">
    <div class="content">
      <svg-loader :icon="getWardIcon(ward.ward_name)" class="image" />
      <div class="info">
        <div class="title">{{ ward.ward_name }}</div>
        <div class="progress-bars">
          <div v-for="(bedStatus, index) in ward.bed_statuses" :key="index" class="progress-item">
            <v-progress-linear
              :model-value="bedStatus.percentage"
              height="5"
              class="progress-bar"
              :color="getBedStatusColor(bedStatus.bed_status)"
              rounded
            ></v-progress-linear>
            <div class="progress-info">{{ bedStatus.bed_status }}: {{ bedStatus.percentage }}%</div>
          </div>
        </div>
      </div>
    </div>
  </v-card>
</template>

<script lang="ts" setup>
import { IWards } from '@/types';
import { PropType } from 'vue';

const props = defineProps({
  ward: {
    type: Object as PropType<IWards>,
    required: true,
  },
});

const getBedStatusColor = (status: string) => {
  switch (status) {
    case 'available':
      return 'green';
    case 'occupied':
      return 'red';
    case 'not_in_use':
      return 'orange';
    case 'needs_cleaning':
      return 'blue';
  }
};

const getWardIcon = (ward: string) => {
  switch (ward) {
    case 'Emergency Department - ED':
      return 'temperature';
    case 'Intensive Care Unit - ICU':
      return 'heart-beat';
    default:
      return 'bmi';
  }
};
</script>

<style scoped>
.content {
  display: flex;
  align-items: start;
}

.title {
  font-size: 1.2rem;
  font-weight: bold;
  margin-bottom: 10px;
  padding: 10px;
  padding-left: 0;
}

.image {
  min-width: 75px;
  min-height: 75px;
  margin-top: 17.5px;
  margin-right: 20px;
  margin-left: 20px;
  border-radius: 10px; /* Make the image rounded */
}

.progress-bars {
  display: flex;
  flex-direction: column;
}

.progress-item {
  margin-bottom: 15px;
}

.progress-bar {
  width: 200px;
  left: unset !important;
  transform: unset !important;
}

.progress-info {
  font-size: 0.9rem;
}

.additional-info {
  display: flex;
  align-items: center;
}

.info-icon {
  margin-right: 5px;
}
</style>
