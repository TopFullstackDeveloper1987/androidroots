<template>
  <v-container fluid class="detail-view">
    <v-row no-gutters>
      <v-col class="detail-view-th">
        <div class="px-2">{{ $t('orders.medication_name') }}:</div>
      </v-col>

      <v-col class="detail-view-th">
        <div class="px-2">{{ $t('orders.code') }}:</div>
      </v-col>

      <v-col class="detail-view-th">
        <div class="px-2">{{ $t('common.warning') }}:</div>
      </v-col>
    </v-row>

    <v-row
      v-for="(medicationItem, index) of items"
      :key="medicationItem.id"
      no-gutters
    >
      <v-col
        class="detail-view-td"
        :class="{ 'last-child': index === medicationItems.length - 1 }"
      >
        <div class="px-2">
          {{ medicationItem.medication.name }}
        </div>
      </v-col>

      <v-col
        class="detail-view-td"
        :class="{ 'last-child': index === medicationItems.length - 1 }"
      >
        <div class="px-2">
          {{ medicationItem.medication.IQ_national_code }}
        </div>
      </v-col>

      <v-col
        class="detail-view-td"
        :class="{ 'last-child': index === medicationItems.length - 1 }"
      >
        <div class="d-flex align-items-center justify-space-between px-2">
          <div class="pr-2">
            <v-icon
              v-if="medicationItem.medication.has_warning"
              color="yellow"
              size="x-large"
            >
              mdi-alert
            </v-icon>
          </div>

          <div class="d-flex">
            <btn
              :primary="false"
              icon="mdi-square-edit-outline"
              icon-only
              icon-color="primary"
              variant="text"
              size="x-small"
              @click="onEdit(medicationItem.id)"
            >
              <tooltip>{{ $t('common.edit') }}</tooltip>
            </btn>

            <btn
              :primary="false"
              icon="$delete"
              icon-only
              icon-color="primary"
              variant="text"
              size="x-small"
              @click="onDelete(medicationItem.id)"
            >
              <tooltip>{{ $t('common.delete') }}</tooltip>
            </btn>
          </div>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup lang="ts">
import { PropType, computed } from 'vue';

import { IMedicationOrderItem } from '@/types';

const props = defineProps({
  items: {
    type: Array as PropType<IMedicationOrderItem[]>,
    default: () => [],
  },
});

const medicationItems = computed(() => {
  return props.items;
});

const onEdit = (testId: number) => {};

const onDelete = (testId: number) => {};
</script>
