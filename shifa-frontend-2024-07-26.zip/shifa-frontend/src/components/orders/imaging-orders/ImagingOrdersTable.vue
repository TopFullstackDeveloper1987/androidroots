<template>
  <div>
    <data-table-server
      v-model:page="page"
      v-model:expanded="expanded"
      :items-length="imagingOrderStore.searchResults?.count"
      :items="imagingOrderStore.searchResults?.results"
      :headers="headers"
      :search="search"
      no-gutters
      @update:options="loadItems"
    >
      <template v-slot:item="{ item }">
        <tr>
          <td>
            {{ item.raw.order_number }}
          </td>
          <td>
            {{
              moment.utc(item.raw.created_date).format('YYYY-MM-DD HH:mm:ss')
            }}
          </td>
          <td>
            {{ item.raw.modality }}
          </td>
          <td>
            {{ item.raw.practitioner_name }}
          </td>
          <td>
            {{ item.raw.patient_name }}
          </td>
          <td>
            <v-chip
              variant="outlined"
              size="small"
              :color="getStatusColor(item.raw.status?.code)"
            >
              {{ item.raw.status?.name }}
            </v-chip>
          </td>
          <td>
            <btn
              :primary="false"
              secondary
              icon="mdi-square-edit-outline"
              icon-only
              icon-color="primary"
              size="x-small"
              class="my-3 mr-3"
              @click="onEdit(item.raw.id)"
            >
              <tooltip>{{ $t('common.edit') }}</tooltip>
            </btn>
            <btn
              :primary="false"
              secondary
              icon="$print"
              icon-only
              icon-color="primary"
              size="x-small"
              class="my-3 mr-3"
              @click="printImagingOrder(item.raw.id)"
            >
              <tooltip>{{ $t('common.print') }}</tooltip>
            </btn>
            <btn
              :primary="false"
              secondary
              icon="mdi-download"
              icon-only
              icon-color="primary"
              size="x-small"
              class="my-3 mr-3"
              @click="downloadPdf(item.raw.id)"
            >
              <tooltip>{{ $t('common.download') }}</tooltip>
            </btn>
            <btn
              :primary="isExpanded(item.raw.id)"
              secondary
              class="my-3 mr-3"
              :icon="
                isExpanded(item.raw.id)
                  ? 'mdi-chevron-down'
                  : 'mdi-chevron-right'
              "
              icon-only
              size="x-small"
              :loading="state.loadingDetailsId === item.raw.id"
              :disabled="!item.raw.scan_count"
              @click="toggleDetails(item.raw.id)"
            >
              <tooltip>
                {{ $t('patient_list.see_quick_details') }}
              </tooltip>
            </btn>
          </td>
        </tr>
      </template>

      <template v-slot:expanded-row="{ columns, item }">
        <tr>
          <td :colspan="columns.length">
            <scan-type-item :scans="getLoadedImagingScans(item.raw.id)" />
          </td>
        </tr>
      </template>
    </data-table-server>
    <iframe
      id="print-contents-iframe"
      width="100%"
      height="0px"
      frameborder="0"
      style="display: none"
    >
    </iframe>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, watch, PropType } from 'vue';
import { useI18n } from 'vue-i18n';
import moment from 'moment-timezone';
import DataTableServer from '@/components/common/DataTableServer.vue';
import ScanTypeItem from './ScanTypeItem.vue';
import { useImagingOrderStore, useEncounterStore } from '@/store';
import { IImagingOrderQuery, IScan, ITableUpdateOptions } from '@/types';

const encounterStore = useEncounterStore();

const props = defineProps({
  modality: {
    type: String,
    default: '',
  },
  status: {
    type: String,
    default: '',
  },
  practitionerId: {
    type: String,
    default: '',
  },
  dates: {
    type: Array as PropType<Date[]>,
    default: () => [],
  },
});

const { t } = useI18n();

const imagingOrderStore = useImagingOrderStore();

const headers = [
  {
    title: t('orders.order_number'),
    key: 'id',
    sortable: false,
  },
  {
    title: t('orders.order_date'),
    key: 'created_date',
    sortable: false,
  },
  {
    title: t('orders.modality'),
    key: 'modality',
    sortable: false,
  },
  {
    title: t('orders.practitioner'),
    key: 'practitioner_name',
    sortable: false,
  },
  {
    title: t('orders.patient'),
    key: 'patient_name',
    sortable: false,
  },
  {
    title: t('orders.status'),
    key: 'status',
    sortable: false,
  },
  {
    title: t('orders.action'),
    key: 'scan_count',
    sortable: false,
  },
];

const page = ref(1);
const expanded = ref<string[]>([]);
const printableHtml = ref<string>('');

const search = ref('');

const imagingScans = ref<Record<string, IScan[]>>({});
const state = reactive<{
  loadingDetailsId: string | null;
}>({
  loadingDetailsId: null,
});

const getLoadedImagingScans = (orderId: string) => {
  return imagingScans.value[orderId];
};

const clearImagingScans = () => {
  imagingScans.value = {};
};

const triggerSearch = () => {
  page.value = 1;
  clearImagingScans();

  search.value = String(Date.now());
};

const printImagingOrder = (medicationOrderId: string) => {
  encounterStore.printImagingOrder(medicationOrderId).then((res) => {
    printableHtml.value = res;
    const iframe = document.getElementById(
      'print-contents-iframe',
    ) as HTMLIFrameElement;

    if (iframe) {
      iframe.style.display = 'block'; // Show the iframe for printing
      iframe.contentDocument!.open();
      iframe.contentDocument!.write(printableHtml.value);
      iframe.contentDocument!.close();

      iframe.onload = function () {
        iframe.contentWindow?.print();
        iframe.style.display = 'none'; // Hide the iframe again
      };
    }
  });
};

const downloadPdf = (medicationOrderId: string) => {
  encounterStore.downloadLabOrder(medicationOrderId).then((res) => {
    console.log('download', res);
  });
};

watch(
  () => [props.modality, props.dates, props.status, props.practitionerId],
  () => {
    triggerSearch();
  },
);

watch(page, () => {
  // clean up cache
  clearImagingScans();
});

const isExpanded = (orderId: string) => expanded.value.includes(orderId);

const loadItems = async ({ page }: ITableUpdateOptions) => {
  const query: IImagingOrderQuery = {
    page,
    modality: props.modality || undefined,
    status: props.status || undefined,
    practitioner_id: props.practitionerId || undefined,
  };

  if (props.dates?.length > 0) {
    query.from_date = props.dates[0]
      ? moment.utc(props.dates[0]).format('YYYY-MM-DD')
      : undefined;
    query.to_date = props.dates[1]
      ? moment.utc(props.dates[1]).format('YYYY-MM-DD')
      : undefined;
  }

  await imagingOrderStore.searchImagingOrders(query);
};

const getImagingScans = async (orderId: string) => {
  const existingImagingScans = getLoadedImagingScans(orderId);
  if (!existingImagingScans) {
    const scans = await imagingOrderStore.getImagingScans(orderId);
    imagingScans.value[orderId] = scans;
  }
};

const getStatusColor = (status: string) => {
  if (!status) return;
  if (status === 'new') return 'purple';
  else if (status === 'scheduled') return 'orange';
  else if (status === 'in-Progress') return 'blue';
  else if (status === 'completed') return 'green';
  else if (status === 'cancelled') return 'red';
  else return '';
};

const toggleDetails = async (orderId: string) => {
  if (isExpanded(orderId)) {
    const index = expanded.value.findIndex((id) => id === orderId);
    expanded.value.splice(index, 1);
  } else {
    state.loadingDetailsId = orderId;
    try {
      await getImagingScans(orderId);
      expanded.value.push(orderId);
    } finally {
      state.loadingDetailsId = null;
    }
  }
};

const onEdit = async (orderId: string) => {};
</script>
