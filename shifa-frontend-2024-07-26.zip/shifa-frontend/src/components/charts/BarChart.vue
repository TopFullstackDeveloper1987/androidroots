<template>
  <div class="position-relative fill-height">
    <bar :data="chartData" :options="mergedChartOptions" v-bind="$attrs" />
  </div>
</template>

<script setup lang="ts">
import { Bar } from 'vue-chartjs';
import {
  Colors,
  ChartData,
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
} from 'chart.js';
import { PropType, computed } from 'vue';

ChartJS.register(
  Colors,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
);

const props = defineProps({
  chartData: {
    type: Object as PropType<ChartData<'bar'>>,
    required: true,
  },
  chartOptions: {
    type: Object,
    default: () => {},
  },
});

const mergedChartOptions = computed(() => {
  return {
    responsive: true,
    maintainAspectRatio: false,
    ...props.chartOptions,
  };
});
</script>

<style scoped lang="scss"></style>
