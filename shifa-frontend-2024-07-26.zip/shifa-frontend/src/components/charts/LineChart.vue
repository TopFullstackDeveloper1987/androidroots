<template>
  <div class="position-relative fill-height">
    <Line :data="chartData" :options="mergedChartOptions" v-bind="$attrs" />
  </div>
</template>

<script setup lang="ts">
import { PropType, computed } from 'vue';
import {
  Colors,
  ChartData,
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'vue-chartjs';

ChartJS.register(
  Colors,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
);

const props = defineProps({
  chartData: {
    type: Object as PropType<ChartData<'line'>>,
    required: true,
  },
  chartOptions: {
    type: Object,
    default: () => {},
  },
});

const mergedChartOptions = computed(() => {
  return {
    responsive: true,
    maintainAspectRatio: false,
    ...props.chartOptions,
  };
});
</script>

<style scoped lang="scss"></style>
