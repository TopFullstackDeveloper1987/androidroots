<template>
  <div class="position-relative fill-height">
    <doughnut :data="chartData" :options="mergedChartOptions" v-bind="$attrs" />
  </div>
</template>

<script setup lang="ts">
import {
  Colors,
  ChartData,
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from 'chart.js';
import { Doughnut } from 'vue-chartjs';
import { PropType, computed } from 'vue';

ChartJS.register(Colors, ArcElement, Tooltip, Legend);

const props = defineProps({
  chartData: {
    type: Object as PropType<ChartData<'doughnut'>>,
    required: true,
  },
  chartOptions: {
    type: Object,
    default: () => {},
  },
});

const mergedChartOptions = computed(() => {
  return {
    responsive: true,
    maintainAspectRatio: false,
    ...props.chartOptions,
  };
});
</script>

<style scoped lang="scss"></style>
