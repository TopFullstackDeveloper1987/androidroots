<template>
  <div>
    <data-table-server
      v-model:page="page"
      v-model:expanded="expanded"
      :items="searchResults?.results"
      :headers="headers"
      :search="search"
      no-gutters
      :show-search-results-info="false"
      @update:options="loadItems"
    >
      <template v-slot:item="{ item }">
        <tr>
          <td>
            {{
              item.raw.appointment_date
                ? moment.utc(item.raw.appointment_date).format('YYYY-MM-DD')
                : '---'
            }}
          </td>
          <td>
            {{
              item.raw.appointment_date
                ? moment.utc(item.raw.appointment_date).format('HH:ss')
                : '---'
            }}
          </td>
          <td>
            {{ item.raw.practitioner.first_name }}
            {{ item.raw.practitioner.last_name }}
          </td>
          <td>{{ item.raw.appointment_purpose }}</td>
          <td>
            <v-chip
              variant="outlined"
              size="small"
              :color="getAppointmentStatusColor(item.raw)"
            >
              {{ getAppointmentStatus(item.raw) }}
            </v-chip>
          </td>
          <td>
            <btn
              :primary="false"
              secondary
              icon="mdi-square-edit-outline"
              icon-only
              icon-color="primary"
              size="x-small"
              class="my-3 mr-3"
              @click="onEdit(item.raw)"
            >
              <tooltip>{{ $t('common.edit') }}</tooltip>
            </btn>
          </td>
        </tr>
      </template>
    </data-table-server>
  </div>
</template>

<script setup lang="ts">
import {
  computed,
  ref,
  watch,
  PropType,
  onMounted,
  onBeforeUnmount,
} from 'vue';
import { useI18n } from 'vue-i18n';
import moment from 'moment-timezone';
import _ from 'lodash';

import DataTableServer from '@/components/common/DataTableServer.vue';
import {
  useFacilityAppointmentStore,
  useFacilityStore,
  usePatientStore,
} from '@/store';
import { AppointmentEvents, IAppointment, AppointmentStatus } from '@/types';
import { events } from '@/events';

const props = defineProps({
  type: {
    type: String,
    default: '',
  },
  status: {
    type: String,
    default: '',
  },
  practitionerId: {
    type: String,
    default: '',
  },
  sortBy: {
    type: String,
    default: '',
  },
  orderBy: {
    type: String,
    default: '',
  },
  dates: {
    type: Array as PropType<Date[]>,
    default: () => [],
  },
});

const { t } = useI18n();
const emit = defineEmits(['edit']);
const patientStore = usePatientStore();
const facilityStore = useFacilityStore();
const facilityAppointmentStore = useFacilityAppointmentStore();

const headers = [
  {
    title: t('common.date'),
    key: 'appointment_date',
    sortable: false,
  },
  {
    title: t('appointments.hour'),
    key: 'hour',
    sortable: false,
  },
  {
    title: t('appointments.doctor'),
    key: 'doctor',
    sortable: false,
  },
  {
    title: t('appointments.appointment_purpose'),
    key: 'appointment_purpose',
    sortable: false,
  },
  {
    title: t('appointments.status'),
    key: 'status',
    sortable: false,
  },
  {
    title: t('common.actions'),
    key: 'scan_count',
    sortable: false,
  },
];

const page = ref(1);
const expanded = ref<string[]>([]);

const search = ref('');

onMounted(async () => {
  bindEventHandlers();
});

onBeforeUnmount(() => {
  unbindEventHandlers();
});

const bindEventHandlers = () => {
  events.on(AppointmentEvents.ReloadAppointments, reloadItems);
};

const unbindEventHandlers = () => {
  events.off(AppointmentEvents.ReloadAppointments, reloadItems);
};

const reloadItems = async () => {
  await loadItems();
};

const searchResults = computed(() => {
  const results = _.cloneDeep(
    facilityAppointmentStore.facilityAppointments || [],
  );

  return {
    ...facilityAppointmentStore.facilityAppointments,
    results,
  };
});

const triggerSearch = () => {
  page.value = 1;
  search.value = String(Date.now());
};

watch(
  () => [props.type, props.dates, props.status, props.practitionerId],
  () => {
    triggerSearch();
  },
);

const getAppointmentStatus = (appointment: IAppointment) => {
  switch (appointment.appointment_status) {
    case AppointmentStatus.New:
      return t('appointments.new');
    case AppointmentStatus.Confirmed:
      return t('appointments.confirmed');
    case AppointmentStatus.Cancelled:
      return t('appointments.canceled');
    case AppointmentStatus.NoShow:
      return t('appointments.no_show');
  }
};

const getAppointmentStatusColor = (appointment: IAppointment) => {
  switch (appointment.appointment_status) {
    case AppointmentStatus.New:
      return 'primary';
    case AppointmentStatus.Confirmed:
      return 'green';
    case AppointmentStatus.Cancelled:
      return 'red';
    case AppointmentStatus.NoShow:
      return 'yellow';
  }
};

const loadItems = async () => {
  await facilityAppointmentStore.searchFacilityAppointments(
    facilityStore.currentFacilityId!,
    {
      practitioner_uuid: props.practitionerId || undefined,
      puuid: patientStore.currentPatientId!,
      sort_by: props.sortBy || 'appointment_date',
      order_by: props.orderBy || 'desc_to',
    },
  );
};

const onEdit = async (payload: IAppointment) => {
  emit('edit', payload);
};
</script>
