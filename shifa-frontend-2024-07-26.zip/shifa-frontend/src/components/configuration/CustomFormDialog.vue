<template>
  <form-dialog
    v-model="isShowDialog"
    @submit="submit"
    @opened="dialogOpened"
    width="600"
  >
    <template #header>
      {{
        customForm
          ? $t(`config.edit_custom_form`)
          : $t(`config.new_custom_form`)
      }}
    </template>

    <text-field
      v-model="formData.name"
      :label="$t('config.name')"
      :rules="[required]"
      attr="name"
      class="mb-4"
    />

    <select-field
      :items="formTypesChoices"
      v-model="formData.form_type"
      :label="$t('config.form_type')"
      class="mb-4"
    />

    <auto-complete
      :label="$t('config.speciality')"
      :items="specialities"
      v-model="formData.speciality"
      item-title="name"
      item-value="id"
      :rules="[required]"
      attr="speciality"
      class="mb-4"
    />

    <text-area
      v-model="schema"
      :label="$t('config.json_form_schema')"
      attr="form_json_schema"
      :rows="6"
      class="mb-4"
    />
  </form-dialog>
</template>

<script setup lang="ts">
import { WritableComputedRef, reactive, computed, ref, PropType } from 'vue';
import { useI18n } from 'vue-i18n';
import _ from 'lodash';

import { required } from '@/utils';
import { useMetaDataStore, useCustomFormsStore } from '@/store';
import {
  IIdName,
  ConfigurationEvents,
  CustomEncounterType,
  ICustomEncounter,
  ICreateCustomMedicationPayload,
  IUpdateCustomMedicationPayload,
  ICustomForm,
  ISpecialty,
  ICustomFormPayload,
} from '@/types';
import { formTypesChoices } from '@/constants';
import { events } from '@/events';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  specialities: {
    type: Object as PropType<ISpecialty[]>,
  },
  customForm: {
    type: Object as PropType<ICustomForm>,
    required: false,
  },
});

const customFormsStore = useCustomFormsStore();

const emit = defineEmits(['update:modelValue', 'updated']);

const loading = ref<boolean>(false);
let formData = reactive<ICustomFormPayload>(<ICustomFormPayload>{});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const schema: WritableComputedRef<any> = computed({
  get() {
    return JSON.stringify(formData.form_json_schema);
  },
  set(value: string) {
    formData.form_json_schema = JSON.parse(value);
  },
});

const dialogOpened = () => {
  if (props.customForm) {
    formData.name = props.customForm.name;
    formData.form_type = props.customForm.form_type!;
    formData.speciality = props.customForm.speciality?.id!;
    formData.form_json_schema = props.customForm.form_json_schema;
  } else {
    formData.name = '';
    formData.form_type = undefined;
    formData.speciality = undefined;
    formData.form_json_schema = [];
  }
};

const submit = async () => {
  loading.value = true;

  const payload = formData;

  if (props.customForm)
    await customFormsStore.updateCustomForm(payload, props.customForm.id);
  else await customFormsStore.createCustomForm(payload);

  loading.value = false;
  events.emit(ConfigurationEvents.ReloadConfig);
  isShowDialog.value = false;
};
</script>

<style lang="scss" scoped></style>
