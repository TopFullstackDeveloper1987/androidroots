<template>
  <data-table-server
    v-model:page="page"
    :items-length="productStore.searchResults?.count"
    :items="productStore.searchResults?.results"
    :headers="headers"
    :search="search"
    no-gutters
    @update:options="loadItems"
  >
    <template v-slot:item="{ item }">
      <tr>
        <td>
          <checkbox
            :model-value="item.raw.favored"
            :disabled="commonStore.isLoading"
            @update:modelValue="onUpdateFavorite(item.raw.id)"
          />
        </td>

        <td>
          {{ item.raw.name }}
        </td>
        <td>
          {{ item.raw.code }}
        </td>
        <td>
          {{ item.raw.brand }}
        </td>
        <td class="text-capitalize">
          {{ item.raw.description }}
        </td>
        <td>
          <btn
            :primary="false"
            secondary
            icon="mdi-square-edit-outline"
            icon-only
            icon-color="primary"
            size="x-small"
            class="my-3 mr-3"
            @click="onEdit(item.raw)"
          >
            <tooltip>{{ $t('common.edit') }}</tooltip>
          </btn>
        </td>
      </tr>
    </template>
  </data-table-server>
</template>

<script setup lang="ts">
import { ref, watch, onMounted, onBeforeUnmount } from 'vue';
import { useI18n } from 'vue-i18n';
import DataTableServer from '../common/DataTableServer.vue';
import { useCommonStore, useProductStore } from '@/store';
import {
  ITableUpdateOptions,
  ConfigurationEvents,
  IProduct,
  IFilterQuery,
} from '@/types';
import { events } from '@/events';

const props = defineProps({
  name: {
    type: String,
  },
  status: {
    type: String,
    default: 'all',
  },
  speciality: {
    type: Number,
  },
});

const { t } = useI18n();
const emit = defineEmits(['edit']);

const commonStore = useCommonStore();
const productStore = useProductStore();

const headers = [
  {
    title: t('config.favorite'),
    key: 'favored',
    sortable: false,
  },
  {
    title: t('config.name'),
    key: 'name',
    sortable: false,
  },
  {
    title: t('config.code'),
    key: 'code',
    sortable: false,
  },
  {
    title: t('config.brand'),
    key: 'brand',
    sortable: false,
  },
  {
    title: t('common.description'),
    key: 'description',
    sortable: false,
  },
  {
    title: t('common.actions'),
    key: 'actions',
    sortable: false,
  },
];

const page = ref(1);
const search = ref('');

onMounted(async () => {
  bindEventHandlers();
});

onBeforeUnmount(() => {
  unbindEventHandlers();
});

const bindEventHandlers = () => {
  events.on(ConfigurationEvents.ReloadConfig, reloadItems);
};

const unbindEventHandlers = () => {
  events.off(ConfigurationEvents.ReloadConfig, reloadItems);
};

const reloadItems = async () => {
  await loadItems({ page: 1 });
};

watch(
  () => [props.name, props.status, props.speciality],
  () => {
    reloadItems();
  },
);

const loadItems = async ({ page }: ITableUpdateOptions) => {
  let favored: boolean | undefined = undefined;

  if (props.status === 'favorite') {
    favored = true;
  } else if (props.status === 'other') {
    favored = false;
  }

  const query: IFilterQuery = {
    page,
    favored,
    name: props.name,
    speciality: props.speciality,
  };

  await productStore.searchProducts(query);
};

const onUpdateFavorite = async (id: string) => {
  await productStore.updateFavoriteProduct(Number(id));
  await reloadItems();
};

const onEdit = async (payload: IProduct) => {
  emit('edit', payload);
};
</script>
