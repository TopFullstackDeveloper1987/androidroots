<template>
  <div class="d-flex justify-space-between mb-3">
    <div class="d-flex flex-1-1">
      <select-field
        :items="favoriteStatuses"
        v-model="statusValue"
        :label="$t('config.favorite')"
        class="max-width-250 mr-4"
      />

      <search
        v-model="nameValue"
        :label="$t('config.name')"
        class="max-width-250 mr-4"
      />
    </div>

    <div>
      <btn icon="mdi-plus" :iconBefore="true" primary @click="$emit('new')">
        {{ newButtonTitle }}
      </btn>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, WritableComputedRef, onMounted } from 'vue';

import { favoriteStatuses } from '@/constants';

const emit = defineEmits(['update:status', 'update:name', 'new']);

const props = defineProps({
  status: {
    type: String,
    default: 'all',
  },
  name: {
    type: String,
  },
  newButtonTitle: {
    type: String,
  },
});

const statusValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.status;
  },
  set(value) {
    emit('update:status', value);
  },
});

const nameValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.name;
  },
  set(value) {
    emit('update:name', value);
  },
});

onMounted(() => {});
</script>
