<template>
  <form-dialog
    v-model="isShowDialog"
    class="dialog-form"
    :show-footer="false"
    v-bind:="$attrs"
    width="600"
    @submit="submit"
  >
    <template v-slot:header>
      <div class="text-primary">{{ $t(`config.add`) }}</div>
    </template>

    <select-field
      v-model="formData.configuration"
      :label="$t(`config.name`)"
      attr="configuration"
      class="my-3"
      item-title="name"
      item-value="name"
      :rules="[required]"
      :items="configList"
    />
    <text-field
      v-model="selectedConfig.name_display"
      :label="$t(`config.name_display`)"
      attr="name"
      class="mb-3"
      disabled
    />
    <text-field
      v-model="selectedConfig.group"
      :label="$t(`config.group`)"
      attr="name"
      class="mb-3"
      disabled
    />
    <text-field
      v-model="selectedConfig.sub_group"
      :label="$t(`config.sub_group`)"
      attr="name"
      class="mb-3"
      disabled
    />
    <v-divider />
    <select-field
      v-model="formData.entity"
      :label="$t(`config.entity`)"
      attr="name"
      class="my-3"
      :rules="[required]"
      :items="entityChoicesMock"
    />
    <text-field
      v-model="formData.entity_id"
      :label="$t(`config.entity_id`)"
      attr="name"
      class="mb-3"
      :rules="[required]"
    />
    <select-field
      v-model="formData.entity_id_type"
      :label="$t(`config.entity_type`)"
      attr="name"
      class="mb-3"
      :rules="[required]"
      :items="dataTypeChoicesMock"
    />
    <v-divider />
    <select-field
      v-model="formData.value_type"
      :label="$t(`config.value_type`)"
      attr="name"
      class="my-3"
      :rules="[required]"
      :items="dataTypeChoicesMock"
    />
    <text-field
      v-if="formData.configuration !== 'default_home'"
      v-model="formData.value"
      :label="$t(`config.value`)"
      attr="name"
      class="mb-3"
      :rules="[required]"
    />
    <select-field
      v-else
      v-model="formData.value"
      :label="$t(`config.value`)"
      attr="name"
      class="my-3"
      :rules="[required]"
      :items="pagesMock"
    />
  </form-dialog>
</template>

<script setup lang="ts">
import {
  ref,
  computed,
  reactive,
  WritableComputedRef,
  onMounted,
  ComputedRef,
} from 'vue';
import { IConfigList, IConfigPayload } from '@/types';
import { useDefaultSettingsStore } from '@/store';
import { entityChoicesMock, dataTypeChoicesMock, pagesMock } from '@/constants';
import { required } from '@/utils/validations';

const defaultSettingsStore = useDefaultSettingsStore();

const configList = ref<IConfigList[]>([]);

const emit = defineEmits(['update:modelValue', 'updated']);

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
});

let formData = reactive<IConfigPayload>({
  configuration: null,
  entity: null,
  entity_id: '',
  entity_id_type: null,
  value: '',
  value_type: null,
});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const selectedConfig: ComputedRef<any> = computed(() => {
  if (!formData.configuration) return <IConfigList>{};
  return configList.value.find(
    (config) => config.name == formData.configuration,
  );
});

onMounted(() => {
  loadConfigList();
});

const loadConfigList = async () => {
  configList.value = await defaultSettingsStore.getConfigList({});
};

const reset = () => {
  formData = {
    configuration: null,
    entity: null,
    entity_id: '',
    entity_id_type: null,
    value: '',
    value_type: null,
  };
};

const submit = async () => {
  await defaultSettingsStore.addConfig(formData);
  isShowDialog.value = false;
  emit('updated');
  reset();
};
</script>

<style scoped></style>
