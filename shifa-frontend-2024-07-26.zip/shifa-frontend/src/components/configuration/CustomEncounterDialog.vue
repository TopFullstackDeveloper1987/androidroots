<template>
  <form-dialog
    v-model="isShowDialog"
    @submit="submit"
    @opened="dialogOpened"
    width="600"
  >
    <template #header>
      {{
        encounter
          ? $t(`config.edit_${encounterType}`)
          : $t(`config.new_${encounterType}`)
      }}
    </template>

    <text-field
      v-model="formData.name"
      :label="_.capitalize(encounterType)"
      :rules="[required]"
      :attr="encounterType"
      class="mb-4"
    />

    <text-field
      v-if="isAdviceEncounter"
      v-model="formData.help_url"
      :label="$t('config.help_url')"
      :rules="[url]"
      attr="help_url"
      class="mb-4"
    />

    <auto-complete
      v-else-if="!isAdviceEncounter && !isComplaintEncounter && !isObservationEncounter"
      :label="$t(`config.${codeKey}`)"
      :items="metaDataItems"
      v-model="formData.code"
      :loading="loading"
      item-title="title"
      :item-value="codeKeyShort"
      :rules="[required]"
      v-model:search="searchKey"
      @update:search="searchUpdated"
    />
  </form-dialog>
</template>

<script setup lang="ts">
import {
  WritableComputedRef,
  reactive,
  computed,
  ref,
  PropType,
  onMounted,
} from 'vue';
import _ from 'lodash';

import { required, url } from '@/utils';
import { useMetaDataStore, useCustomEncountersStore } from '@/store';
import {
  CustomEncounterType,
  ICreateCustomEncounterPayload,
  IMetaDataCPTCode,
  IMetaDataICDCode,
  IMetaDataCodeQuery,
  ConfigurationEvents,
} from '@/types';
import { events } from '@/events';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  encounter: {
    type: Object as PropType<ICreateCustomEncounterPayload>,
    required: false,
  },
  encounterType: {
    type: String as PropType<CustomEncounterType>,
    required: true,
  },
});

const metaDataStore = useMetaDataStore();
const customEncountersStore = useCustomEncountersStore();

const emit = defineEmits(['update:modelValue', 'updated']);

const searchKey = ref<string>('');
const loading = ref<boolean>(false);
const metaDataItems = ref<
  (
    | (IMetaDataICDCode & { title: string })
    | (IMetaDataCPTCode & { title: string })
  )[]
    >([]);

const formData = reactive<{
  name?: string;
  code?: string;
  help_url?: string;
}>({});

const isProcedureEncounter = computed(() => {
  return CustomEncounterType.Procedure === props.encounterType;
});

const isAdviceEncounter = computed(() => {
  return CustomEncounterType.Advice === props.encounterType;
});

const isComplaintEncounter = computed(() => {
  return CustomEncounterType.Complaint === props.encounterType;
});

const isObservationEncounter = computed(() => {
  return CustomEncounterType.Observation === props.encounterType;
});

const codeKey = computed(() => {
  return isProcedureEncounter.value ? 'cpt_code' : 'icd_10_code';
});

const codeKeyShort = computed(() => {
  return isProcedureEncounter.value ? 'cpt_code' : 'icd_code';
});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const dialogOpened = () => {
  if (props.encounter) {
    formData.name = props.encounter?.name;
    formData.code = props.encounter?.[codeKey.value];
    formData.help_url = props.encounter.help_url;
  } else {
    formData.name = null!;
    formData.code = null!;
  }
};

const searchMetaDataItems = _.debounce(async () => {
  const chunks = searchKey.value.split(':').map((chunk) => chunk.trim());

  const params: IMetaDataCodeQuery = {
    type: props.encounterType,
    name: chunks.length > 1 ? chunks[1] : chunks[0],
    code: chunks.length > 1 ? chunks[0] : undefined,
  };

  if (isProcedureEncounter.value) {
    const res = await metaDataStore.getMetaDataCPTCodes(params);
    metaDataItems.value = (res || []).map((item) => ({
      ...item,
      title: `${item.cpt_code}: ${item.description}`,
    }));
  } else {
    const res = await metaDataStore.getMetaDataICDCodes(params);
    metaDataItems.value = (res || []).map((item) => ({
      ...item,
      title: `${item.icd_code}: ${item.short_description}`,
    }));
  }
}, 600);

const searchUpdated = async (query: string) => {
  if (!query || query.length < 2 || ['true', 'false'].includes(query)) {
    return;
  }

  const currentItem = metaDataItems.value.find(
    (item: any) => item[codeKeyShort.value] === formData.code,
  );
  if (query === currentItem?.title) {
    return;
  }

  searchMetaDataItems();
};

const submit = async () => {
  loading.value = true;

  const payload: ICreateCustomEncounterPayload = {
    name: formData.name!,
    [codeKey.value]: formData.code!,
    help_url: formData.help_url!,
  };

  if (props.encounter)
    await customEncountersStore.updateCustomEncounter(
      props.encounterType,
      payload,
      props.encounter.id!,
    );
  else
    await customEncountersStore.createCustomEncounter(
      props.encounterType,
      payload,
    );

  loading.value = false;
  events.emit(ConfigurationEvents.ReloadCustomEncounters);
  isShowDialog.value = false;
};

onMounted(() => {
  searchMetaDataItems();
});
</script>

<style lang="scss" scoped></style>
