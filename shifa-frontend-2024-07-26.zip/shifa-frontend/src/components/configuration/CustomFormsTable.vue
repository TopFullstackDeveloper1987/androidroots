<template>
  <data-table-server
    v-model:page="page"
    :items-length="customFormsStore.searchResults?.count"
    :items="customFormsStore.searchResults?.results"
    :headers="headers"
    :search="search"
    no-gutters
    @update:options="loadItems"
  >
    <template v-slot:item="{ item }">
      <tr>
        <td>
          <checkbox
            :model-value="item.raw.favored"
            :disabled="commonStore.isLoading"
            @update:modelValue="onUpdateFavorite(item.raw.id)"
          />
        </td>

        <td>
          {{ item.raw.name }}
        </td>
        <td class="text-capitalize">
          {{ item.raw.form_type }}
        </td>
        <td>
          {{ item.raw.speciality?.name }}
        </td>

        <td class="py-4">
          <textarea
            readonly
            :value="
              item.raw.form_json_schema
                ? JSON.stringify(item.raw.form_json_schema)
                : ''
            "
            cols="30"
            rows="4"
          />
        </td>
        <td>
          <btn
            :primary="false"
            secondary
            icon="mdi-square-edit-outline"
            icon-only
            icon-color="primary"
            size="x-small"
            class="my-3 mr-3"
            @click="onEdit(item.raw)"
          >
            <tooltip>{{ $t('common.edit') }}</tooltip>
          </btn>
        </td>
      </tr>
    </template>
  </data-table-server>
</template>

<script setup lang="ts">
import { ref, watch, onMounted, onBeforeUnmount } from 'vue';
import { useI18n } from 'vue-i18n';
import DataTableServer from '../common/DataTableServer.vue';
import { useCommonStore, useCustomFormsStore } from '@/store';
import {
  ICustomForm,
  IFilterQuery,
  ITableUpdateOptions,
  ConfigurationEvents,
} from '@/types';
import { events } from '@/events';

const props = defineProps({
  name: {
    type: String,
  },
  formType: {
    type: String,
  },
  speciality: {
    type: Number,
  },
});

const { t } = useI18n();
const emit = defineEmits(['edit']);

const commonStore = useCommonStore();
const customFormsStore = useCustomFormsStore();

const headers = [
  {
    title: t('config.favorite'),
    key: 'favored',
    sortable: false,
  },
  {
    title: t('config.name'),
    key: 'name',
    sortable: false,
  },
  {
    title: t('config.form_type'),
    key: 'form_type',
    sortable: false,
  },
  {
    title: t('config.speciality'),
    key: 'speciality',
    sortable: false,
  },
  {
    title: t('config.json_form_schema'),
    key: 'json_form_schema',
    sortable: false,
  },
  {
    title: t('common.actions'),
    key: 'actions',
    sortable: false,
  },
];

const page = ref(1);
const search = ref('');

onMounted(async () => {
  bindEventHandlers();
});

onBeforeUnmount(() => {
  unbindEventHandlers();
});

const bindEventHandlers = () => {
  events.on(ConfigurationEvents.ReloadConfig, reloadItems);
};

const unbindEventHandlers = () => {
  events.off(ConfigurationEvents.ReloadConfig, reloadItems);
};

const reloadItems = async () => {
  await loadItems({ page: 1 });
};

watch(
  () => [props.name, props.formType, props.speciality],
  () => {
    reloadItems();
  },
);

const loadItems = async ({ page }: ITableUpdateOptions) => {
  const query: IFilterQuery = {
    page,
    name: props.name,
    type: props.formType,
    speciality: props.speciality,
  };

  await customFormsStore.searchCustomForms(query);
};

const onUpdateFavorite = async (id: string) => {
  await customFormsStore.updateFavoriteCustomForm(Number(id));
  await reloadItems();
};

const onEdit = async (payload: ICustomForm) => {
  emit('edit', payload);
};
</script>
