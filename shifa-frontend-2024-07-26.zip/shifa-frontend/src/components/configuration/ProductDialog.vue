<template>
  <form-dialog
    v-model="isShowDialog"
    @submit="submit"
    @opened="dialogOpened"
    width="600"
  >
    <template #header>
      {{ item ? $t(`config.edit_product`) : $t(`config.new_product`) }}
    </template>

    <text-field
      v-model="formData.name"
      :label="$t('config.name')"
      :rules="[required]"
      attr="name"
      class="mb-4"
    />

    <text-field
      v-model="formData.code"
      :label="$t('config.code')"
      :rules="[required]"
      attr="code"
      class="mb-4"
    />

    <text-field
      v-model="formData.brand"
      :label="$t('common.brand')"
      :rules="[required]"
      attr="brand"
      class="mb-4"
    />

    <text-area
      v-model="formData.description"
      :label="$t('common.description')"
      :rules="[required]"
      attr="description"
      :rows="3"
      class="mb-4"
    />
  </form-dialog>
</template>

<script setup lang="ts">
import { WritableComputedRef, reactive, computed, ref, PropType } from 'vue';
import { required } from '@/utils';
import { useProductStore } from '@/store';
import { ConfigurationEvents, IProductPayload, IProduct } from '@/types';
import { events } from '@/events';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  item: {
    type: Object as PropType<IProduct>,
    required: false,
  },
});

const productStore = useProductStore();

const emit = defineEmits(['update:modelValue', 'updated']);

const loading = ref<boolean>(false);
let formData = reactive<IProductPayload>(<IProductPayload>{});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const dialogOpened = () => {
  if (props.item) {
    formData.name = props.item.name;
    formData.code = props.item.code;
    formData.brand = props.item.brand;
    formData.description = props.item.description;
  } else {
    formData.name = '';
    formData.code = '';
    formData.brand = '';
    formData.description = '';
  }
};

const submit = async () => {
  loading.value = true;

  const payload = formData;

  if (props.item) await productStore.updateProduct(payload, props.item.id);
  else await productStore.createProduct(payload);

  loading.value = false;
  events.emit(ConfigurationEvents.ReloadConfig);
  isShowDialog.value = false;
};
</script>

<style lang="scss" scoped></style>
