<template>
  <form-dialog
    v-model="isShowDialog"
    @submit="submit"
    @opened="dialogOpened"
    width="600"
  >
    <template #header>
      {{ item ? $t(`config.edit_service`) : $t(`config.new_service`) }}
    </template>

    <text-field
      v-model="formData.name"
      :label="$t('config.name')"
      :rules="[required]"
      attr="name"
      class="mb-4"
    />
    <select-field
      v-model="formData.currency"
      :items="currenciesMock"
      :label="$t('billing.currency')"
      :rules="[required]"
      attr="currency"
      class="mb-4"
    />

    <text-field
      v-model="formData.price"
      :rules="[requiredPositiveNumber]"
      :label="$t('billing.amount_paid')"
      attr="amount_paid"
      class="mb-4"
    />

    <text-area
      v-model="formData.description"
      :label="$t('common.description')"
      attr="notes"
    />
  </form-dialog>
</template>

<script setup lang="ts">
import { WritableComputedRef, reactive, computed, ref, PropType } from 'vue';
import { required, requiredPositiveNumber } from '@/utils';
import { useServiceStore } from '@/store';
import { ConfigurationEvents, IServicePayload, IService } from '@/types';
import { currenciesMock } from '@/constants';
import { events } from '@/events';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  item: {
    type: Object as PropType<IService>,
    required: false,
  },
});

const serviceStore = useServiceStore();

const emit = defineEmits(['update:modelValue', 'updated']);

const loading = ref<boolean>(false);
let formData = reactive<IServicePayload>(<IServicePayload>{});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const dialogOpened = () => {
  if (props.item) {
    formData.name = props.item.name;
    formData.price = props.item.price;
    formData.currency = props.item.currency;
    formData.description = props.item.description;
  } else {
    formData.name = '';
    formData.price = null!;
    formData.currency = '';
    formData.description = '';
  }
};

const submit = async () => {
  loading.value = true;

  const payload = formData;

  if (props.item) await serviceStore.updateService(payload, props.item.id);
  else await serviceStore.createService(payload);

  loading.value = false;
  events.emit(ConfigurationEvents.ReloadConfig);
  isShowDialog.value = false;
};
</script>

<style lang="scss" scoped></style>
