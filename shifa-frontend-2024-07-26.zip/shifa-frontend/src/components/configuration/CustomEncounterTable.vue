<!-- Complaints, Observations, Diagnosis -->
<template>
  <div>
    <data-table-server
      v-model:page="page"
      :items-length="searchResults?.count"
      :items="searchResults?.results"
      :headers="isMedicationEncounter ? medicationHeaders : headers"
      :search="search"
      no-gutters
      @update:options="loadItems"
    >
      <template v-slot:item="{ item }">
        <tr>
          <td>
            <checkbox
              :model-value="item.raw.favored"
              :disabled="commonStore.isLoading"
              @update:modelValue="onUpdateFavorite(item.raw.id)"
            />
          </td>
          <td v-if="isMedicationEncounter">
            {{ item.raw.IQ_national_code }}
          </td>
          <td>
            {{ item.raw.name }}
          </td>
          <td v-if="isProcedureEncounter">
            {{ item.raw.category }}
          </td>
          <td v-if="isAdviceEncounter">
            <a :href="item.raw.help_url" target="_blank" rel="help_url">
              {{ item.raw.help_url }}
            </a>
          </td>
          <td v-if="isMedicationEncounter">
            {{ item.raw.drug_category_name }}
          </td>
          <td v-if="isMedicationEncounter">
            {{ item.raw.drug_sub_category_name }}
          </td>
          <td v-if="isMedicationEncounter">
            <v-icon v-if="item.raw.has_warning" color="yellow" size="x-large">
              mdi-alert
            </v-icon>
          </td>
          <td v-if="isMedicationEncounter">
            <btn
              v-if="item.raw.has_notes && !details[item.raw.id]"
              :primary="false"
              secondary
              icon="mdi-message-outline"
              icon-only
              icon-color="primary"
              size="x-small"
              @click="getNotes(item.raw.id)"
            >
            </btn>
            <btn
              v-else-if="item.raw.has_notes && details[item.raw.id]"
              :primary="false"
              secondary
              icon="mdi-message-outline"
              icon-only
              icon-color="primary"
              size="x-small"
            >
              <tooltip>
                {{ details[item.raw.id].description }}
              </tooltip>
            </btn>
          </td>
          <td v-if="!isMedicationEncounter && !isAdviceEncounter && !isComplaintEncounter && !isObservationEncounter">
            {{ item.columns[codeKey] }}
          </td>
          <td>
            <btn
              :primary="false"
              secondary
              icon="mdi-square-edit-outline"
              icon-only
              icon-color="primary"
              size="x-small"
              class="my-3 mr-3"
              @click="onEdit(item.raw)"
            >
              <tooltip>{{ $t('common.edit') }}</tooltip>
            </btn>
            <!-- <btn
              :primary="false"
              secondary
              icon="$delete"
              icon-only
              icon-color="primary"
              size="x-small"
              class="my-3 mr-3"
              @click="onDelete(item.columns.id)"
            >
              <tooltip>{{ $t('common.delete') }}</tooltip>
            </btn> -->
          </td>
        </tr>
      </template>
    </data-table-server>
    <medication-notes-dialog v-model="isShowDialog" :notes="details?.notes" />
  </div>
</template>

<script setup lang="ts">
import {
  computed,
  ref,
  watch,
  PropType,
  onMounted,
  onBeforeUnmount,
} from 'vue';
import _ from 'lodash';
import { useI18n } from 'vue-i18n';
import DataTableServer from '../common/DataTableServer.vue';
import MedicationNotesDialog from './MedicationNotesDialog.vue';
import {
  useCommonStore,
  useMetaDataStore,
  useCustomEncountersStore,
} from '@/store';
import {
  ICustomEncounter,
  ITableUpdateOptions,
  CustomEncounterType,
  ConfigurationEvents,
  IFilterQuery,
} from '@/types';
import { events } from '@/events';

const props = defineProps({
  encounterType: {
    type: String as PropType<CustomEncounterType>,
    required: true,
  },
  status: {
    type: String,
    default: 'all',
  },
  name: {
    type: String,
  },
  speciality: {
    type: Number,
  },
  category: {
    type: String,
  },
  subCategory: {
    type: String,
  },
});

const { t } = useI18n();
const emit = defineEmits(['edit']);

const commonStore = useCommonStore();
const metaDataStore = useMetaDataStore();
const customEncountersStore = useCustomEncountersStore();

const isMedicationEncounter = computed(() => {
  return CustomEncounterType.Medication === props.encounterType;
});

const isProcedureEncounter = computed(() => {
  return CustomEncounterType.Procedure === props.encounterType;
});

const isAdviceEncounter = computed(() => {
  return CustomEncounterType.Advice === props.encounterType;
});

const isComplaintEncounter = computed(() => {
  return CustomEncounterType.Complaint === props.encounterType;
});

const isObservationEncounter = computed(() => {
  return CustomEncounterType.Observation === props.encounterType;
});

const codeKey = computed(() => {
  return props.encounterType === CustomEncounterType.Procedure
    ? 'cpt_code'
    : 'icd_10_code';
});

const headers = [
  {
    title: t('config.favorite'),
    key: 'favored',
    sortable: false,
  },
  {
    title: t('config.name'),
    key: 'name',
    sortable: false,
  },
  {
    title: t(`config.${codeKey.value}`),
    key: codeKey.value,
    sortable: false,
  },
  {
    title: t('common.actions'),
    key: 'id',
    sortable: false,
  },
];

if (isProcedureEncounter.value) {
  headers.splice(2, 0, {
    title: t('config.category'),
    key: 'category',
    sortable: false,
  });
}

if (isAdviceEncounter.value) {
  headers.splice(2, 1, {
    title: t('config.help_url'),
    key: 'help_url',
    sortable: false,
  });
}

if (isComplaintEncounter.value || isObservationEncounter.value) {
  headers.splice(2, 1);
}

const medicationHeaders = [
  {
    title: t('config.favorite'),
    key: 'favored',
    sortable: false,
  },
  {
    title: t('config.code'),
    key: 'code',
    sortable: false,
  },
  {
    title: t('config.name'),
    key: 'name',
    sortable: false,
  },
  {
    title: t('config.category'),
    key: 'category',
    sortable: false,
  },
  {
    title: t('config.sub_category'),
    key: 'sub_category',
    sortable: false,
  },
  {
    title: t('config.warning'),
    key: 'warning',
    sortable: false,
  },
  {
    title: t('common.notes'),
    key: 'notes',
    sortable: false,
  },
  {
    title: t('common.actions'),
    key: 'id',
    sortable: false,
  },
];

const page = ref(1);
const search = ref('');
const details = ref<any>({});
const isShowDialog = ref<boolean>(false);

const searchResults = computed(() => {
  const results = _.cloneDeep(
    customEncountersStore.searchResults?.results || [],
  )
    .sort((a, b) => a.id - b.id)
    .map((result) => ({
      ...result,
      id: String(result.id),
    }));

  return {
    ...customEncountersStore.searchResults,
    results,
  };
});

const getNotes = async (id: number) => {
  const res = await metaDataStore.getMetaDataDetails(props.encounterType!, id);
  details.value = res;
  isShowDialog.value = true;
};

onMounted(async () => {
  bindEventHandlers();
});

onBeforeUnmount(() => {
  unbindEventHandlers();
});

const bindEventHandlers = () => {
  events.on(ConfigurationEvents.ReloadCustomEncounters, reloadItems);
};

const unbindEventHandlers = () => {
  events.off(ConfigurationEvents.ReloadCustomEncounters, reloadItems);
};

const reloadItems = async () => {
  await loadItems({ page: 1 });
};

const triggerSearch = () => {
  page.value = 1;

  search.value = String(Date.now());
};

watch(
  () => [
    props.status,
    props.name,
    props.speciality,
    props.category,
    props.subCategory,
  ],
  () => {
    triggerSearch();
  },
);

const loadItems = async ({ page }: ITableUpdateOptions) => {
  let favored: boolean | undefined = undefined;

  if (props.status === 'favorite') {
    favored = true;
  } else if (props.status === 'other') {
    favored = false;
  }

  const query: IFilterQuery = {
    page,
    name: props.name,
    drug_category: props.category,
    drug_sub_category: props.subCategory,
    favored,
    speciality: props.speciality,
  };

  await customEncountersStore.searchCustomEncounters(
    props.encounterType!,
    query,
  );
};

const onUpdateFavorite = async (id: string) => {
  await customEncountersStore.updateFavoriteCustomEncounter(
    props.encounterType,
    Number(id),
  );
  await reloadItems();
};

const onEdit = async (payload: ICustomEncounter) => {
  emit('edit', payload);
};
</script>
