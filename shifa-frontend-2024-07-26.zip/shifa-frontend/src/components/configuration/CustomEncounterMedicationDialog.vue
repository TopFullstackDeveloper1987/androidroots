<template>
  <form-dialog
    v-model="isShowDialog"
    @submit="submit"
    @opened="dialogOpened"
    width="600"
  >
    <template #header>
      {{
        encounter
          ? $t(`config.edit_${encounterType}`)
          : $t(`config.new_${encounterType}`)
      }}
    </template>

    <auto-complete
      :label="$t('config.category')"
      :items="categories"
      v-model="formData.drug_category"
      item-title="name"
      item-value="id"
      :rules="[required]"
      attr="drug_category"
      @update:modelValue="loadSubCategories"
      class="mb-4"
    />

    <auto-complete
      :label="$t('config.sub_category')"
      :items="subCategories"
      v-model="formData.drug_sub_category"
      item-title="name"
      item-value="id"
      :rules="[required]"
      attr="drug_sub_category"
      :disabled="!formData.drug_category"
      class="mb-4"
    />

    <text-field
      v-model="formData.IQ_national_code"
      :label="$t('config.code')"
      :rules="[required]"
      attr="IQ_national_code"
      class="mb-4"
    />

    <text-field
      v-model="formData.name"
      :label="$t('config.medication_name')"
      :rules="[required]"
      attr="medication_name"
      class="mb-4"
    />

    <text-area
      v-if="!encounter"
      v-model="formData.notes"
      :label="$t('config.notes')"
      attr="description"
      :rows="3"
      class="mb-4"
    />

    <checkbox
      :label="$t('config.medication_warning')"
      v-model="formData.has_warning"
    />
  </form-dialog>
</template>

<script setup lang="ts">
import { WritableComputedRef, reactive, computed, ref, PropType } from 'vue';
import { useI18n } from 'vue-i18n';
import _ from 'lodash';

import { required } from '@/utils';
import { useCustomEncountersStore, useMetaDataStore } from '@/store';
import {
  IIdName,
  ConfigurationEvents,
  CustomEncounterType,
  ICustomEncounter,
  ICreateCustomMedicationPayload,
  IUpdateCustomMedicationPayload,
} from '@/types';
import { events } from '@/events';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  categories: {
    type: Array,
    default: () => [],
  },
  encounter: {
    type: Object as PropType<ICustomEncounter>,
    required: false,
  },
  encounterType: {
    type: String as PropType<CustomEncounterType>,
    required: true,
  },
});

const metaDataStore = useMetaDataStore();
const customEncountersStore = useCustomEncountersStore();

const emit = defineEmits(['update:modelValue', 'updated']);

const loading = ref<boolean>(false);
const subCategories = ref<IIdName[]>([]);
const formData = reactive<
  ICreateCustomMedicationPayload | IUpdateCustomMedicationPayload
>(<ICreateCustomMedicationPayload | IUpdateCustomMedicationPayload>{});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const dialogOpened = () => {
  if (props.encounter) {
    formData.name = props.encounter.name;
    formData.drug_category = props.encounter.drug_category!;
    formData.drug_sub_category = props.encounter.drug_sub_category!;
    formData.has_warning = props.encounter.has_warning;
    formData.IQ_national_code = props.encounter.IQ_national_code;
    formData.IQ_national_code = props.encounter.IQ_national_code;
  } else {
    formData.name = '';
    formData.drug_category = '';
    formData.drug_sub_category = '';
    formData.has_warning = false;
    formData.notes = '';
    formData.IQ_national_code = '';
  }
};

const loadSubCategories = async () => {
  formData.drug_sub_category = '';
  if (!formData.drug_category) return;

  const res = await metaDataStore.getMetaData(
    `drug-category/${formData.drug_category}/drug-sub-category`,
  );
  subCategories.value = res as any;
};

const submit = async () => {
  loading.value = true;

  const payload = formData;

  if (props.encounter) {
    await customEncountersStore.updateCustomEncounter(
      props.encounterType,
      payload,
      props.encounter.id!,
    );
  } else {
    await customEncountersStore.createCustomEncounter(
      props.encounterType,
      payload,
    );
  }

  loading.value = false;
  events.emit(ConfigurationEvents.ReloadCustomEncounters);
  isShowDialog.value = false;
};
</script>

<style lang="scss" scoped></style>
