<!-- Complaints, Observations, Diagnosis -->
<template>
  <div class="d-flex justify-space-between mb-3">
    <div class="d-flex flex-1-1">
      <select-field
        :items="favoriteStatuses"
        v-model="statusValue"
        :label="$t('config.favorite')"
        class="max-width-250 mr-4"
      />

      <search
        v-model="nameValue"
        :label="$t('config.name')"
        class="max-width-250 mr-4"
      />

      <auto-complete
        v-if="!isMedication"
        :items="specialities"
        v-model="specialityValue"
        item-title="name"
        item-value="id"
        clearable
        :label="$t('config.speciality')"
        class="max-width-250 mr-4"
      />

      <auto-complete
        v-if="isMedication"
        :items="categories"
        v-model="categoryValue"
        item-title="name"
        item-value="id"
        clearable
        :label="$t('config.category')"
        class="max-width-250 mr-4"
      />

      <auto-complete
        v-if="isMedication"
        :items="subCategories"
        v-model="subCategoryValue"
        item-title="name"
        item-value="id"
        clearable
        :label="$t('config.sub_category')"
        class="max-width-250 mr-4"
        :disabled="!categoryValue"
      />
    </div>

    <div>
      <btn icon="mdi-plus" :iconBefore="true" primary @click="$emit('new')">
        {{ newButtonTitle }}
      </btn>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, WritableComputedRef, onMounted } from 'vue';

import { IIdName, ISpecialty } from '@/types';
import { useMetaDataStore } from '@/store';
import { favoriteStatuses } from '@/constants';

const emit = defineEmits([
  'update:status',
  'update:name',
  'update:category',
  'update:subCategory',
  'update:speciality',
  'new',
]);

const props = defineProps({
  status: {
    type: String,
    default: 'all',
  },
  name: {
    type: String,
  },
  category: {
    type: String,
  },
  subCategory: {
    type: String,
  },
  speciality: {
    type: Number,
  },
  newButtonTitle: {
    type: String,
  },
  isMedication: {
    type: Boolean,
    default: false,
  },
  isDiagnosis: {
    type: Boolean,
    default: false,
  },
  categories: {
    type: Array,
    default: () => [],
  },
});

const metaDataStore = useMetaDataStore();

const subCategories = ref<IIdName[]>([]);
const specialities = ref<ISpecialty[]>([]);

const statusValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.status;
  },
  set(value) {
    emit('update:status', value);
  },
});

const nameValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.name;
  },
  set(value) {
    emit('update:name', value);
  },
});

const categoryValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.category;
  },
  set(value) {
    emit('update:category', value);
    loadSubCategories(value);
  },
});

const subCategoryValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.subCategory;
  },
  set(value) {
    emit('update:subCategory', value);
  },
});

const specialityValue: WritableComputedRef<number | undefined> = computed({
  get() {
    return props.speciality;
  },
  set(value) {
    emit('update:speciality', value);
  },
});

const loadSubCategories = async (value: string | undefined) => {
  if (!value) {
    subCategoryValue.value = undefined;
    return;
  }
  const res = await metaDataStore.getMetaData(
    `drug-category/${value}/drug-sub-category`,
  );
  subCategories.value = res as any;
};

const loadSpecialities = async () => {
  const res = await metaDataStore.getMetaData('speciality');
  specialities.value = res as any;
};

onMounted(() => {
  loadSpecialities();
});
</script>
