<template>
  <base-dialog
    v-model="isShowDialog"
    class="dialog-form"
    :show-footer="false"
    v-bind:="$attrs"
  >
    <template #header>
      {{ $t('config.notes') }}
    </template>

    <template #content>
      {{ notes }}
    </template>
  </base-dialog>
</template>

<script setup lang="ts">
import { WritableComputedRef, computed } from 'vue';

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  notes: {
    type: String,
    default: '',
  },
});

const emit = defineEmits(['update:modelValue']);

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});
</script>
