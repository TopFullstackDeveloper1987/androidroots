<!-- Complaints, Observations, Diagnosis -->
<template>
  <div class="d-flex justify-space-between mb-3">
    <div class="d-flex flex-1-1">
      <search
        v-model="nameValue"
        :label="$t('config.name')"
        class="max-width-250 mr-4"
      />

      <select-field
        clearable
        :items="formTypesChoices"
        v-model="formTypeValue"
        :label="$t('config.form_type')"
        class="max-width-250 mr-4"
      />

      <auto-complete
        :items="specialities"
        v-model="specialityValue"
        item-title="name"
        item-value="id"
        clearable
        :label="$t('config.speciality')"
        class="max-width-250 mr-4"
      />
    </div>

    <div>
      <btn icon="mdi-plus" :iconBefore="true" primary @click="$emit('new')">
        {{ newButtonTitle }}
      </btn>
    </div>
  </div>
</template>

<script setup lang="ts">
import { PropType, computed, WritableComputedRef } from 'vue';

import { ISpecialty } from '@/types';
import { formTypesChoices } from '@/constants';

const emit = defineEmits([
  'new',
  'update:name',
  'update:formType',
  'update:speciality',
]);

const props = defineProps({
  specialities: {
    type: Object as PropType<ISpecialty[]>,
  },
  formType: {
    type: String,
  },
  name: {
    type: String,
  },
  speciality: {
    type: Number,
  },
  newButtonTitle: {
    type: String,
  },
});

const nameValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.name;
  },
  set(value) {
    emit('update:name', value);
  },
});

const formTypeValue: WritableComputedRef<string | undefined> = computed({
  get() {
    return props.formType;
  },
  set(value) {
    emit('update:formType', value);
  },
});

const specialityValue: WritableComputedRef<number | undefined> = computed({
  get() {
    return props.speciality;
  },
  set(value) {
    emit('update:speciality', value);
  },
});
</script>
