<template>
  <form-dialog v-model="isShowDialog" @submit="submit" @opened="dialogOpened">
    <template #header>
      {{ $t('billing.make_payment') }}
    </template>

    <v-row>
      <v-col cols="12">
        <select-field
          v-model="formData.payment_method"
          :items="paymentMethodsMock"
          :label="$t('billing.payment_method')"
          :rules="[required]"
          attr="payment_method"
        />
      </v-col>

      <v-col cols="12">
        <select-field
          v-model="formData.currency"
          :items="currenciesMock"
          :label="$t('billing.currency')"
          :rules="[required]"
          attr="currency"
        />
      </v-col>

      <v-col cols="12">
        <text-field
          v-model="formData.amount_paid"
          :rules="[requiredPositiveNumber]"
          :label="$t('billing.amount_paid')"
          attr="amount_paid"
        />
      </v-col>

      <v-col cols="12">
        <text-area
          v-model="formData.notes"
          :label="$t('appointments.notes')"
          attr="notes"
        />
      </v-col>
    </v-row>
  </form-dialog>
</template>

<script setup lang="ts">
import { WritableComputedRef, reactive, computed, PropType } from 'vue';
import { useI18n } from 'vue-i18n';

import { required, requiredPositiveNumber } from '@/utils';
import { useCommonStore, useFacilityStore, useInvoiceStore } from '@/store';
import { paymentMethodsMock, currenciesMock } from '@/constants';
import { IInvoice, InvoiceEvents, ToastType } from '@/types';
import { events } from '@/events';

const commonStore = useCommonStore();
const facilityStore = useFacilityStore();
const invoiceStore = useInvoiceStore();

const { t } = useI18n();

const emit = defineEmits(['update:modelValue']);

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  invoice: {
    type: Object as PropType<IInvoice>,
    required: true,
  },
});

const isShowDialog: WritableComputedRef<boolean> = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit('update:modelValue', value);
  },
});

const formData = reactive<{
  payment_method: string;
  currency?: string;
  amount_paid?: string;
  notes?: string;
}>({
  payment_method: 'cash',
});

const dialogOpened = () => {
  formData.payment_method = 'cash';
  formData.currency = props.invoice.currency.code;
  formData.amount_paid = props.invoice.total_amount;
  formData.notes = undefined;
};

const submit = async () => {
  await invoiceStore.payInvoice(facilityStore.currentFacilityId!, {
    invoice: props.invoice.id,
    payment_method: formData.payment_method,
    currency: formData.currency!,
    amount_paid: formData.amount_paid!,
    notes: formData.notes,
  });

  events.emit(InvoiceEvents.ReloadInvoices);

  commonStore.showToast(
    ToastType.Success,
    t('billing.successfully_paid_invoice'),
  );

  isShowDialog.value = false;
};
</script>

<style lang="scss" scoped></style>
