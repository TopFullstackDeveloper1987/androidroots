export async function loadFonts() {
  const webFontLoader = await import(
    /* webpackChunkName: "webfontloader" */ 'webfontloader'
  );

  webFontLoader.load({
    google: {
      families: ['Noto+Sans:400,700', 'Noto+Kufi+Arabic:400,700'],
    },
  });
}
