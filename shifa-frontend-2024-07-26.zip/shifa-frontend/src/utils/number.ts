export const extractNumber = (str: string) => {
  if (!str) {
    return 0;
  }

  const match = str.match(/\d+/);
  return Number(match && match[0]);
};
