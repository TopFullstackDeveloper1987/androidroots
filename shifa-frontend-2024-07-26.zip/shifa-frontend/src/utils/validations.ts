import { useGlobalI18n } from '@/plugins';

const { t } = useGlobalI18n();

const arabicNumerals = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
const englishNumerals = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

export const required = (value: any) => {
  if (value === undefined || value === null || value === '') {
    return `${t('validation.required_field')}`;
  }

  return true;
};

export const validOptionalEmail = (value: string) => {
  if (!value) return true;

  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return true;

  return `${t('validation.valid_email')}`;
};

export const validRequiredEmail = (value: string) => {
  if (!value) {
    return `${t('validation.required_field')}`;
  }

  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return true;

  return `${t('validation.valid_email')}`;
};

export const onlyNumber = (value: string) => {

  if(!isNaN(Number(value))) {
    return true;
  }

  const arrayOfChars = value?.split('');

  let ageString = '';

  arrayOfChars?.forEach(char => {
    if(arabicNumerals.includes(char)) {

      ageString += englishNumerals[arabicNumerals.indexOf(char)];
    } else {
      ageString += char;
    }

  });

  if (isNaN(Number(ageString))) {
    return `${t('validation.only_number')}`;
  }

  return true;
};

export const requiredPositiveNumber = (value: string | number) => {
  if (!Number(value)) {
    return `${t('validation.required_field')}`;
  }

  return true;
};

export const lessThanOrEqual =
  (upperValue: number, message?: string) => (value: string | number) => {
    if (!value) {
      return true;
    }

    if (Number(value) > upperValue) {
      if (message) {
        return message;
      }

      return `${t('validation.less_than_or_equal')} ${upperValue}`;
    }

    return true;
  };

export const validPhoneNumber = (value: string) => {
  if (!value) return true;

  if (!(value.startsWith('7') || value.startsWith('٧'))) {
    return `${t('validation.valid_phone_number')}`;
  }

  if (value.length !== 10) {
    return `${t('validation.valid_phone_number')}`;
  }

  return true;
};

export const url = (value: any) => {
  if (!value) return true;

  if (
    /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([-.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/.test(
      value,
    )
  )
    return true;

  return `${t('validation.invalid_url')}`;
};
