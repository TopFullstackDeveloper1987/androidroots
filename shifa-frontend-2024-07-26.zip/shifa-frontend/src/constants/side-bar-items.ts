import { ISideBarItem } from '@/types';
import { PageId } from './page-id';

export const sideBarItems: ISideBarItem[] = [
  {
    pageId: PageId.Patients,
    name: 'layouts.patients',
    icon: '$patient-injury',
    children: [
      {
        pageId: PageId.PatientList,
        name: 'layouts.patient_list',
        path: '/patients/list',
      },
      {
        pageId: PageId.PatientProfile,
        name: 'layouts.patient_profile',
        path: '/patients/:patientId/profile',
      },
      {
        pageId: PageId.PatientCondition,
        name: 'layouts.patient_condition',
        path: '/patients/:patientId/condition',
      },
      {
        pageId: PageId.PatientMeasures,
        name: 'layouts.patient_measures',
        path: '/patients/:patientId/measures',
      },
    ],
  },
  {
    pageId: PageId.MedicalRecords,
    name: 'layouts.medical_records',
    icon: '$medical-records',
    children: [
      {
        pageId: PageId.EncounterNotes,
        name: 'layouts.encounter_notes',
        path: '/medical-records/:patientId/encounter-notes',
      },
      {
        pageId: PageId.TestResults,
        name: 'layouts.test_results',
        path: '/medical-records/:patientId/test-results',
      },
      {
        pageId: PageId.Medications,
        name: 'layouts.medications',
        path: '/medical-records/:patientId/medications',
      },
      {
        pageId: PageId.PatientProcedures,
        name: 'layouts.procedures',
        path: '/medical-records/:patientId/procedures',
      },
    ],
  },
  {
    pageId: PageId.Orders,
    name: 'layouts.orders',
    icon: '$orders',
    children: [
      {
        pageId: PageId.MedicationOrders,
        name: 'layouts.medication_orders',
        path: '/orders/medication-orders',
      },
      {
        pageId: PageId.LabOrders,
        name: 'layouts.lab_orders',
        path: '/orders/lab-orders',
      },
      {
        pageId: PageId.ImagingOrders,
        name: 'layouts.imaging_orders',
        path: '/orders/imaging-orders',
      },
    ],
  },
  {
    pageId: PageId.Billing,
    name: 'layouts.billing',
    icon: '$medical-notes',
    children: [
      {
        pageId: PageId.Invoices,
        name: 'layouts.invoices',
        path: '/billing/invoices',
      },
      {
        pageId: PageId.Payments,
        name: 'layouts.payments',
        path: '/billing/payments',
      },
    ],
  },
  {
    pageId: PageId.BedManagement,
    name: 'layouts.bed_management',
    icon: '$medical-notes',
    children: [
      {
        pageId: PageId.AdminDashboard,
        name: 'layouts.admin_dashboard',
        path: '/bed-management/admin-dashboard',
      },
      {
        pageId: PageId.BedAvailability,
        name: 'layouts.bed_availability',
        path: '/bed-management/bed-availability',
      },
    ],
  },
  {
    pageId: PageId.Reports,
    name: 'layouts.reports',
    icon: '$reports',
    children: [
      {
        pageId: PageId.Analytics,
        name: 'layouts.analytics',
        path: '/reports/analytics',
      },
    ],
  },
  {
    pageId: PageId.Tools,
    name: 'layouts.tools',
    icon: '$tools',
    children: [
      {
        pageId: PageId.PrescriptionPrinter,
        name: 'layouts.print_prescription',
        path: '/tools/print-prescription',
      },
      {
        pageId: PageId.AiReportGenerator,
        name: 'layouts.medical_report',
        path: '/tools/ai-report-generator',
      },
    ],
  },
  {
    pageId: PageId.Configuration,
    name: 'layouts.configuration',
    icon: '$info',
    children: [
      {
        pageId: PageId.DefaultSettings,
        name: 'layouts.default_settings',
        path: '/configuration/default-settings',
      },
      {
        pageId: PageId.EncounterNotesConfig,
        name: 'layouts.encounter_notes',
        path: '/configuration/encounter-notes',
      },
      {
        pageId: PageId.Procedures,
        name: 'layouts.procedures',
        path: '/configuration/procedures',
      },
      {
        pageId: PageId.Complaints,
        name: 'layouts.complaints',
        path: '/configuration/complaints',
      },
      {
        pageId: PageId.Observations,
        name: 'layouts.observations',
        path: '/configuration/observations',
      },
      {
        pageId: PageId.Diagnosis,
        name: 'layouts.diagnosis',
        path: '/configuration/diagnosis',
      },
      {
        pageId: PageId.Medication,
        name: 'layouts.medication',
        path: '/configuration/medication',
      },
      {
        pageId: PageId.Advice,
        name: 'layouts.advice',
        path: '/configuration/advice',
      },
      {
        pageId: PageId.CustomForms,
        name: 'layouts.custom_forms',
        path: '/configuration/custom-forms',
      },
      {
        pageId: PageId.Products,
        name: 'layouts.products',
        path: '/configuration/products',
      },
      {
        pageId: PageId.Services,
        name: 'layouts.services',
        path: '/configuration/services',
      },
    ],
  },
];


export const basicSideBarItems: ISideBarItem[] = [
  {
    pageId: PageId.Patients,
    name: 'layouts.patients',
    icon: '$patient-injury',
    children: [
      {
        pageId: PageId.PatientList,
        name: 'layouts.patient_list',
        path: '/patients/list',
      },
      {
        pageId: PageId.PatientProfile,
        name: 'layouts.patient_profile',
        path: '/patients/:patientId/profile',
      },
      {
        pageId: PageId.PatientCondition,
        name: 'layouts.patient_condition',
        path: '/patients/:patientId/condition',
      },
      {
        pageId: PageId.PatientMeasures,
        name: 'layouts.patient_measures',
        path: '/patients/:patientId/measures',
      },
    ],
  },
  {
    pageId: PageId.MedicalRecords,
    name: 'layouts.medical_records',
    icon: '$medical-records',
    children: [
      {
        pageId: PageId.EncounterNotes,
        name: 'layouts.encounter_notes',
        path: '/medical-records/:patientId/encounter-notes',
      },
      {
        pageId: PageId.TestResults,
        name: 'layouts.test_results',
        path: '/medical-records/:patientId/test-results',
      },
      {
        pageId: PageId.Medications,
        name: 'layouts.medications',
        path: '/medical-records/:patientId/medications',
      },
      {
        pageId: PageId.PatientProcedures,
        name: 'layouts.procedures',
        path: '/medical-records/:patientId/procedures',
      },
    ],
  },
  {
    pageId: PageId.Orders,
    name: 'layouts.orders',
    icon: '$orders',
    children: [
      {
        pageId: PageId.MedicationOrders,
        name: 'layouts.medication_orders',
        path: '/orders/medication-orders',
      },
      {
        pageId: PageId.LabOrders,
        name: 'layouts.lab_orders',
        path: '/orders/lab-orders',
      },
      {
        pageId: PageId.ImagingOrders,
        name: 'layouts.imaging_orders',
        path: '/orders/imaging-orders',
      },
    ],
  },
  {
    pageId: PageId.Billing,
    name: 'layouts.billing',
    icon: '$medical-notes',
    children: [
      {
        pageId: PageId.Invoices,
        name: 'layouts.invoices',
        path: '/billing/invoices',
      },
      {
        pageId: PageId.Payments,
        name: 'layouts.payments',
        path: '/billing/payments',
      },
    ],
  },
  {
    pageId: PageId.BedManagement,
    name: 'layouts.bed_management',
    icon: '$medical-notes',
    children: [
      {
        pageId: PageId.AdminDashboard,
        name: 'layouts.admin_dashboard',
        path: '/bed-management/admin-dashboard',
      },
      {
        pageId: PageId.BedAvailability,
        name: 'layouts.bed_availability',
        path: '/bed-management/bed-availability',
      },
    ],
  },
  {
    pageId: PageId.Reports,
    name: 'layouts.reports',
    icon: '$reports',
    children: [
      {
        pageId: PageId.Analytics,
        name: 'layouts.analytics',
        path: '/reports/analytics',
      },
    ],
  },
  {
    pageId: PageId.Tools,
    name: 'layouts.tools',
    icon: '$tools',
    children: [
      {
        pageId: PageId.PrescriptionPrinter,
        name: 'layouts.print_prescription',
        path: '/tools/print-prescription',
      },
      {
        pageId: PageId.AiReportGenerator,
        name: 'layouts.medical_report',
        path: '/tools/ai-report-generator',
      },
    ],
  },
  {
    pageId: PageId.Configuration,
    name: 'layouts.configuration',
    icon: '$info',
    children: [
      {
        pageId: PageId.DefaultSettings,
        name: 'layouts.default_settings',
        path: '/configuration/default-settings',
      },
      {
        pageId: PageId.EncounterNotesConfig,
        name: 'layouts.encounter_notes',
        path: '/configuration/encounter-notes',
      },
      {
        pageId: PageId.Procedures,
        name: 'layouts.procedures',
        path: '/configuration/procedures',
      },
      {
        pageId: PageId.Complaints,
        name: 'layouts.complaints',
        path: '/configuration/complaints',
      },
      {
        pageId: PageId.Observations,
        name: 'layouts.observations',
        path: '/configuration/observations',
      },
      {
        pageId: PageId.Diagnosis,
        name: 'layouts.diagnosis',
        path: '/configuration/diagnosis',
      },
      {
        pageId: PageId.Medication,
        name: 'layouts.medication',
        path: '/configuration/medication',
      },
      {
        pageId: PageId.Advice,
        name: 'layouts.advice',
        path: '/configuration/advice',
      },
      {
        pageId: PageId.CustomForms,
        name: 'layouts.custom_forms',
        path: '/configuration/custom-forms',
      },
      {
        pageId: PageId.Products,
        name: 'layouts.products',
        path: '/configuration/products',
      },
      {
        pageId: PageId.Services,
        name: 'layouts.services',
        path: '/configuration/services',
      },
    ],
  },
];

export const receptionistSideBarItems: ISideBarItem[] = [
  {
    pageId: PageId.Patients,
    name: 'layouts.patients',
    icon: '$patient-injury',
    children: [
      {
        pageId: PageId.PatientList,
        name: 'layouts.patient_list',
        path: '/patients/list',
      },
      {
        pageId: PageId.PatientProfile,
        name: 'layouts.patient_profile',
        path: '/patients/:patientId/profile',
      },
    ],
  },
  {
    pageId: PageId.BedManagement,
    name: 'layouts.bed_management',
    icon: '$medical-notes',
    children: [
      {
        pageId: PageId.AdminDashboard,
        name: 'layouts.admin_dashboard',
        path: '/bed-management/admin-dashboard',
      },
      {
        pageId: PageId.BedAvailability,
        name: 'layouts.bed_availability',
        path: '/bed-management/bed-availability',
      },
    ],
  },
];

export const onlyToolsSideBarItems: ISideBarItem[] = [
  {
    pageId: PageId.Tools,
    name: 'layouts.tools',
    icon: '$tools',
    children: [
      {
        pageId: PageId.PrescriptionPrinter,
        name: 'layouts.print_prescription',
        path: '/tools/print-prescription',
      },
      {
        pageId: PageId.AiReportGenerator,
        name: 'layouts.medical_report',
        path: '/tools/ai-report-generator',
      },
    ],
  },
  {
    pageId: PageId.BedManagement,
    name: 'layouts.bed_management',
    icon: '$medical-notes',
    children: [
      {
        pageId: PageId.AdminDashboard,
        name: 'layouts.admin_dashboard',
        path: '/bed-management/admin-dashboard',
      },
      {
        pageId: PageId.BedAvailability,
        name: 'layouts.bed_availability',
        path: '/bed-management/bed-availability',
      },
    ],
  },
];

export const onlyPrinterSideBarItems: ISideBarItem[] = [
  {
    pageId: PageId.Tools,
    name: 'layouts.tools',
    icon: '$tools',
    children: [
      {
        pageId: PageId.PrescriptionPrinter,
        name: 'layouts.print_prescription',
        path: '/tools/print-prescription',
      },
    ],
  },
  {
    pageId: PageId.BedManagement,
    name: 'layouts.bed_management',
    icon: '$medical-notes',
    children: [
      {
        pageId: PageId.AdminDashboard,
        name: 'layouts.admin_dashboard',
        path: '/bed-management/admin-dashboard',
      },
      {
        pageId: PageId.BedAvailability,
        name: 'layouts.bed_availability',
        path: '/bed-management/bed-availability',
      },
    ],
  },
];

export const onlyReportSideBarItems: ISideBarItem[] = [
  {
    pageId: PageId.Tools,
    name: 'layouts.tools',
    icon: '$tools',
    children: [
      {
        pageId: PageId.AiReportGenerator,
        name: 'layouts.medical_report',
        path: '/tools/ai-report-generator',
      },
    ],
  },
  {
    pageId: PageId.BedManagement,
    name: 'layouts.bed_management',
    icon: '$medical-notes',
    children: [
      {
        pageId: PageId.AdminDashboard,
        name: 'layouts.admin_dashboard',
        path: '/bed-management/admin-dashboard',
      },
      {
        pageId: PageId.BedAvailability,
        name: 'layouts.bed_availability',
        path: '/bed-management/bed-availability',
      },
    ],
  },
];
