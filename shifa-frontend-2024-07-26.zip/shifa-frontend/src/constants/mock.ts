import { useGlobalI18n } from '@/plugins';
import { ISelect } from '@/types';

const { t } = useGlobalI18n();

// TODO: we will replace these with metadata API later so don't need to put them in i18n
export const hospitalsMock = ['Hospital 1', 'Hospital 2', 'Hospital 3'];

export const titlesMock: ISelect<string>[] = [
  {
    title: 'Doctor',
    value: 'Dr',
  },
  {
    title: 'Professor',
    value: 'Prof',
  },
  {
    title: 'Mr',
    value: 'Mr',
  },
  {
    title: 'Mrs',
    value: 'Mrs',
  },
  {
    title: 'Miss',
    value: 'Miss',
  },
];

export const gendersMock: ISelect<string>[] = [
  {
    title: 'Male',
    value: 'M',
  },
  {
    title: 'Female',
    value: 'F',
  },
];

export const ethnicitiesMock: ISelect<string>[] = [
  {
    title: 'Arab',
    value: 'AR',
  },
  {
    title: 'Kurd',
    value: 'KU',
  },
  {
    title: 'Turk',
    value: 'TU',
  },
  {
    title: 'Assyrians',
    value: 'AS',
  },
  {
    title: 'Chaldeans',
    value: 'CH',
  },
  {
    title: 'African',
    value: 'AF',
  },
  {
    title: 'European',
    value: 'EU',
  },
  {
    title: 'Asian',
    value: 'AS',
  },
  {
    title: 'American',
    value: 'NA',
  },
  {
    title: 'Other',
    value: 'OT',
  },
];

export const citiesMock: ISelect<number>[] = [
  {
    title: 'Erbil',
    value: 1,
  },
  {
    title: 'Duhok',
    value: 2,
  },
  {
    title: 'Sulaimaniya',
    value: 3,
  },
];

export const religionsMock: ISelect<string>[] = [
  {
    title: 'Christianity',
    value: 'CH',
  },
  {
    title: 'Islam',
    value: 'IS',
  },
  {
    title: 'Yazidism',
    value: 'YA',
  },
  {
    title: 'Judaism',
    value: 'JU',
  },
  {
    title: 'Mandaeism',
    value: 'MA',
  },
  {
    title: 'Zoroastrianism',
    value: 'ZO',
  },
  {
    title: 'Buddhism',
    value: 'BU',
  },
  {
    title: 'Hinduism',
    value: 'HI',
  },
  {
    title: 'Other',
    value: 'OT',
  },
];

export const registrationMethodsMock: ISelect<number>[] = [
  {
    title: 'Mobile APP',
    value: 1,
  },
  {
    title: 'Website',
    value: 2,
  },
  {
    title: 'Offline - Practice',
    value: 3,
  },
];

export const smokingStatusesMock: ISelect<string>[] = [
  {
    title: 'Non Smoker',
    value: 'non_smoker',
  },
  {
    title: 'Former Smoker',
    value: 'former_smoker',
  },
  {
    title: 'Light Smoker',
    value: 'light_smoker',
  },
  {
    title: 'Moderate Smoker',
    value: 'moderate_smoker',
  },
  {
    title: 'Heavy Smoker',
    value: 'heavy_smoker',
  },
  {
    title: 'Very Heavy Smoker',
    value: 'very_heavy_smoker',
  },
  {
    title: 'Shisha Smoker',
    value: 'shisha_smoker',
  },
];

export const contactMethodsMock: ISelect<number>[] = [
  {
    title: 'Phone',
    value: 1,
  },
  {
    title: 'Online - Website',
    value: 2,
  },
  {
    title: 'Online - Mobile App',
    value: 3,
  },
  {
    title: 'Offline - Visit to Facility',
    value: 4,
  },
];

export const BedTypesMock: ISelect<string>[] = [
  {
    title: t('bed_management.single'),
    value: 'single',
  },
  {
    title: t('bed_management.double'),
    value: 'double',
  },
];

export const BedStatusMock: ISelect<string>[] = [
  {
    title: t('bed_management.available'),
    value: 'available',
  },
  {
    title: t('bed_management.occupied'),
    value: 'occupied',
  },
  {
    title: t('bed_management.needs_cleaning'),
    value: 'needs_cleaning',
  },
  {
    title: t('bed_management.not_in_use'),
    value: 'not_in_use',
  },
];

export const FloorsMock: ISelect<number>[] = [
  {
    title: t('bed_management.ground_floor'),
    value: 0,
  },
  {
    title: t('bed_management.first_floor'),
    value: 1,
  },
  {
    title: t('bed_management.second_floor'),
    value: 2,
  },
  {
    title: t('bed_management.third_floor'),
    value: 3,
  },
  {
    title: t('bed_management.fourth_floor'),
    value: 4,
  },
  {
    title: t('bed_management.fifth_floor'),
    value: 5,
  },
  {
    title: t('bed_management.sixth_floor'),
    value: 6,
  },
  {
    title: t('bed_management.seventh_floor'),
    value: 7,
  },
  {
    title: t('bed_management.eighth_floor'),
    value: 9,
  },
  {
    title: t('bed_management.nineth_floor'),
    value: 9,
  },
  {
    title: t('bed_management.tenth_floor'),
    value: 10,
  },
];

export const appointmentPurposeChoicesMock: ISelect<string>[] = [
  {
    title: 'Regular Checkup',
    value: 'checkup',
  },
  {
    title: 'Follow-up Appointment',
    value: 'follow_up',
  },
  {
    title: 'Consultation',
    value: 'consultation',
  },
  {
    title: 'Vaccination',
    value: 'vaccination',
  },
  {
    title: 'Medical Procedure',
    value: 'procedure',
  },
  {
    title: 'Other',
    value: 'other',
  },
];

export const appointmentStatusesMock: ISelect<number>[] = [
  {
    title: 'New - Planned',
    value: 1,
  },
  {
    title: 'Confirmed - Checked In',
    value: 2,
  },
  {
    title: 'Cancelled',
    value: 3,
  },
  {
    title: 'NoShow',
    value: 4,
  },
];

export const imagingOrderStatusesMock: ISelect<string>[] = [
  {
    title: 'New',
    value: 'new',
  },
  {
    title: 'Scheduled',
    value: 'scheduled',
  },
  {
    title: 'In Progress',
    value: 'in-Progress',
  },
  {
    title: 'Completed',
    value: 'completed',
  },
  {
    title: 'Cancelled',
    value: 'cancelled',
  },
];

export const invoiceStatusesMock: ISelect<string>[] = [
  {
    title: 'Pending',
    value: 'pending',
  },
  {
    title: 'Paid',
    value: 'paid',
  },
  {
    title: 'Cancelled',
    value: 'cancelled',
  },
  {
    title: 'Refunded',
    value: 'refunded',
  },
  {
    title: 'Partial',
    value: 'partial',
  },
  {
    title: 'Overpaid',
    value: 'overpaid',
  },
];

export const paymentMethodsMock: ISelect<string>[] = [
  {
    title: 'Cash',
    value: 'cash',
  },
  {
    title: 'Card',
    value: 'card',
  },
];

export const currenciesMock: ISelect<string>[] = [
  {
    title: 'USD',
    value: 'usd',
  },
  {
    title: 'EUR',
    value: 'eur',
  },
  {
    title: 'Iraqi Dinar',
    value: 'iqd',
  },
];

export const entityChoicesMock: ISelect<string>[] = [
  {
    title: 'Facility',
    value: 'facility',
  },
  {
    title: 'Patient',
    value: 'patient',
  },
  {
    title: 'Practitioner',
    value: 'practitioner',
  },
  {
    title: 'Encounter',
    value: 'encounter',
  },
  {
    title: 'User',
    value: 'user',
  },
  {
    title: 'Other',
    value: 'other',
  },
];

export const dataTypeChoicesMock: ISelect<string>[] = [
  {
    title: 'Integer',
    value: 'int',
  },
  {
    title: 'String',
    value: 'string',
  },
  {
    title: 'Date',
    value: 'date',
  },
  {
    title: 'UUID',
    value: 'uuid',
  },
  {
    title: 'Boolean',
    value: 'boolean',
  },
  {
    title: 'Float',
    value: 'float',
  },
  {
    title: 'Object',
    value: 'object',
  },
];

export const pagesMock: ISelect<string>[] = [

  // Dashboard
  {
    title: t('layouts.dashboard'),
    value: '/dashboard',
  },

  // Billing
  {
    title: t('layouts.invoices'),
    value: '/billing/invoices',
  },
  {
    title: t('layouts.payments'),
    value: '/billing/payments',
  },

  // Tools
  {
    title: t('layouts.print_prescription'),
    value: '/tools/print-prescription',
  },
  {
    title: t('layouts.medical_report'),
    value: '/tools/ai-report-generator',
  },

  // Configuration
  {
    title: t('layouts.default_settings'),
    value: '/configuration/default-settings',
  },
  {
    title: t('layouts.encounter_notes'),
    value: '/configuration/encounter-notes',
  },
  {
    title: t('layouts.procedures'),
    value: '/configuration/procedures',
  },
  {
    title: t('layouts.complaints'),
    value: '/configuration/complaints',
  },
  {
    title: t('layouts.observations'),
    value: '/configuration/observations',
  },
  {
    title: t('layouts.diagnosis'),
    value: '/configuration/diagnosis',
  },
  {
    title: t('layouts.medication'),
    value: '/configuration/medication',
  },
  {
    title: t('layouts.advice'),
    value: '/configuration/advice',
  },
  {
    title: t('layouts.custom_forms'),
    value: '/configuration/custom-forms',
  },
  {
    title: t('layouts.products'),
    value: '/configuration/products',
  },
  {
    title: t('layouts.services'),
    value: '/configuration/services',
  },
];

export const childrenGenderMock: ISelect<string>[] = [
  {
    title: 'Boys',
    value: 'boys',
  },
  {
    title: 'Girls',
    value: 'girls',
  },
];

export const childrenGrowthMetricMock: ISelect<string>[] = [
  {
    title: 'Height for age',
    value: 'height',
  },
  {
    title: 'Weight for age',
    value: 'weight',
  },
  {
    title: 'Head Circumference for Age (Birth to 13 weeks)',
    value: 'head_circumference_b_to_13_w',
  },
  {
    title: 'Head Circumference for Age (Birth to 2 years)',
    value: 'head_circumference_b_to_2_years',
  },
  {
    title: 'Head Circumference for Age (Birth to 5 years)',
    value: 'head_circumference_b_to_5_years',
  },
];

export const favoriteStatuses: ISelect<string>[] = [
  {
    title: t('common.all'),
    value: 'all',
  },
  {
    title: t('common.my_favorite'),
    value: 'favorite',
  },
  {
    title: t('common.other'),
    value: 'other',
  },
];

export const procedureStatuses: ISelect<string>[] = [
  {
    title: t('enums.pending'),
    value: 'pending',
  },
  {
    title: t('enums.canceled'),
    value: 'canceled',
  },
  {
    title: t('enums.in_progress'),
    value: 'in-progress',
  },
  {
    title: t('enums.postponed'),
    value: 'postponed',
  },
  {
    title: t('enums.completed'),
    value: 'completed',
  },
];

export const procedureTypes: ISelect<string>[] = [
  {
    title: t('enums.intervention'),
    value: 'intervention',
  },
  {
    title: t('enums.cosmetic'),
    value: 'cosmetic',
  },
  {
    title: t('enums.other'),
    value: 'other',
  },
];

export const encounterTypes: ISelect<string>[] = [
  {
    title: t('enums.inpatient'),
    value: 'inpatient',
  },
  {
    title: t('enums.outpatient'),
    value: 'outpatient',
  },
  {
    title: t('enums.emergency'),
    value: 'emergency',
  },
  {
    title: t('enums.virtual'),
    value: 'virtual',
  },
];

export const encounterStatuses: ISelect<string>[] = [
  {
    title: t('enums.new'),
    value: 'new',
  },
  {
    title: t('enums.in_progress'),
    value: 'in-progress',
  },
  {
    title: t('enums.on_hold'),
    value: 'on-hold',
  },
  {
    title: t('enums.completed'),
    value: 'completed',
  },
];

export const encounterPiorities: ISelect<string>[] = [
  {
    title: t('enums.low'),
    value: 'low',
  },
  {
    title: t('enums.medium'),
    value: 'medium',
  },
  {
    title: t('enums.high'),
    value: 'high',
  },
];

export const reportTemplateMock: ISelect<string>[] = [
  {
    title: 'General checkup',
    value: 'general-checkup',
  },
  {
    title: 'Cardiology Consultation',
    value: 'cardiology-consultation',
  },
];

export const phoneExtensionsMock: ISelect<string>[] = [
  {
    title: '+964',
    value: '+964',
  },
];

export const formTypesChoices: ISelect<string>[] = [
  {
    title: t('common.patient'),
    value: 'patient',
  },
  {
    title: t('common.encounter'),
    value: 'encounter',
  },
];

export const relationsMock: ISelect<string>[] = [
  {
    title: t('patient_record.parent'),
    value: 'parent',
  },
  {
    title: t('patient_record.grandparent'),
    value: 'grandparent',
  },
  {
    title: t('patient_record.sibling'),
    value: 'sibling',
  },
  {
    title: t('patient_record.uncle'),
    value: 'uncle',
  },
  {
    title: t('patient_record.aunt'),
    value: 'aunt',
  },
  {
    title: t('patient_record.cousin'),
    value: 'cousin',
  },
  {
    title: t('common.other'),
    value: 'other',
  },
];

export const BED_STATUS_CHOICES: any = {
  available: t('bed_management.available'),
  occupied: t('bed_management.occupied'),
  needs_cleaning: t('bed_management.needs_cleaning'),
  not_in_use: t('bed_management.not_in_use'),
};
