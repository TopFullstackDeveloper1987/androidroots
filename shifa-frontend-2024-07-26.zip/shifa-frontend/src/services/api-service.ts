// types
import {
  ILoginPayload,
  IToken,
  IUserInfo,
  IUpdatePatientPayload,
  IPatient,
  ICondition,
  IBulkUpdatePatientConditionPayload,
  IPatientCondition,
  IPatientDocument,
  IPaginatedResponse,
  IFacility,
  IPatientRecord,
  IAllergy,
  IPatientAllergy,
  IPatientAlert,
  IAlert,
  IPatientMeasurePivot,
  IMeasure,
  ISearchFacilityQuery,
  ISearchPractitionerQuery,
  IPractitioner,
  IRegisterPatientAppointmentPayload,
  IAppointment,
  AppointmentAction,
  IEncounter,
  IEncounterItem,
  IEncounterPayload,
  ISearchPatientQuery,
  IEncounterFollowup,
  ISearchFacilityAppointmentsQuery,
  IImagingOrderQuery,
  IImagingOrder,
  ILabOrderQuery,
  ILabOrder,
  IScan,
  IImagingOrderPayload,
  ILabOrderPayload,
  IEncounterImagingOrder,
  IEncounterLabOrder,
  IMedicationOrderPayload,
  ILabOrderTest,
  IMeasureValue,
  IMedicationOrderQuery,
  IMedicationOrder,
  IInvoiceQuery,
  IInvoice,
  IInvoiceItem,
  ILabTestProfileItem,
  IConfigQuery,
  IConfig,
  IConfiguration,
  IFacilityProduct,
  ICreateInvoicePayload,
  IPayInvoicePayload,
  IPayAppointmentFeePayload,
  IPaymentQuery,
  IPayment,
  IMetaDataCodeQuery,
  IMetaDataICDCode,
  IMetaDataCountryCode,
  IMetaDataCPTCode,
  IMedicationOrderItem,
  IConfigPayload,
  IConfigListQuery,
  IConfigList,
  IConfigByNames,
  IDefaultAppointmentFeeValue,
  IPatientMedicalSummary,
  ICustomEncounter,
  IFilterQuery,
  CustomEncounterType,
  ICreateCustomEncounterPayload,
  IProcedureQuery,
  IProcedure,
  IProcedurePayload,
  IProcedureItemQuery,
  IProcedureItem,
  IProcedureDetails,
  ICreateCustomMedicationPayload,
  ICustomForm,
  IEncounterCustomForm,
  ICustomFormPayload,
  IProduct,
  IConfigPaginationQuery,
  IService,
  IProductPayload,
  IServicePayload,
  IPrescriptionPrintPayload,
  IMedicalReport,
  IMedicalReportPayload,
  IMedicalReportPrintPayload,
  ITemplateDesignPayload,
  IConfigurationsResponse,
  IMedicationOrderItemUpdatePayload,
  IEncounterUpdatePayloadItem,
  IPatientSurgicalHistory,
  IPatientFamilyHistory,
  IBedQuery,
  IWard,
  IBed,
  IBedAnalytics,
  ITotalChartDataResponse,
} from '@/types';

// services
import { AxiosService } from './axios-service';

export class ApiService {
  private static instance: ApiService;

  constructor(private readonly axiosService: AxiosService) {}

  static getInstance() {
    if (!ApiService.instance) {
      ApiService.instance = new ApiService(AxiosService.getInstance());
    }

    return ApiService.instance;
  }

  async login(payload: ILoginPayload) {
    // Currently the api is not working without the trailing slash at the end of the endpoint
    return this.axiosService.post<IToken>('auth/login/', payload);
  }

  async getUserInfo(fuuid: string) {
    return this.axiosService.get<IUserInfo>(`auth/${fuuid}/me/`);
  }

  async registerPatient(payload: IUpdatePatientPayload, fuuid: string) {
    return this.axiosService.post<IPatient>('patient/register/', payload, { params: { fuuid } });
  }

  async getConditionMetadata(category?: string) {
    return this.axiosService.get<ICondition[]>('metadata/condition/', {
      params: { category },
    });
  }

  async searchPatient(params: ISearchPatientQuery) {
    return this.axiosService.get<IPaginatedResponse<IPatient>>(
      'patient/search/',
      {
        params,
      },
    );
  }

  async getPatientConditions(patientId: string) {
    return this.axiosService.get<IPatientCondition[]>(
      `patient/${patientId}/patient-condition/`,
    );
  }

  async bulkUpdatePatientConditions(
    patientId: string,
    payload: IBulkUpdatePatientConditionPayload,
  ) {
    return this.axiosService.post<IPatientCondition[]>(
      `patient/${patientId}/patient-condition/`,
      payload,
    );
  }

  async getMedicalRecord(patientId: string) {
    return this.axiosService.get<IPatientRecord>(`medical-record/${patientId}`);
  }

  async getAllergies() {
    return this.axiosService.get<IAllergy[]>('metadata/allergy/');
  }

  async getAlerts() {
    return this.axiosService.get<IAlert[]>('metadata/flag/');
  }

  async addPatientAlert(payload: IPatientAlert) {
    return this.axiosService.post<IPatientAlert>(
      `patient/${payload.patient}/patient-flag/`,
      payload,
    );
  }

  async updatePatientAlert(payload: IPatientAlert) {
    return this.axiosService.patch<IPatientAlert>(
      `patient/${payload.patient}/patient-flag/${payload.id}/`,
      payload,
    );
  }

  async deletePatientAlert(payload: IPatientAlert) {
    return this.axiosService.delete<IPatientAlert>(
      `patient/${payload.patient}/patient-flag/${payload.id}/`,
    );
  }
  async getSurgeries() {
    return this.axiosService.get<IPatientSurgicalHistory[]>('metadata/surgery/');
  }
  async addPastSurgicalHistory(payload: IPatientSurgicalHistory) {
    return this.axiosService.post<IPatientSurgicalHistory>(
      `patient/${payload.patient}/patient-surgical-history/`,
      payload,
    );
  }
  async updatePastSurgeryHistory(payload: IPatientSurgicalHistory) {
    return this.axiosService.patch<IPatientSurgicalHistory>(
      `patient/${payload.patient}/patient-surgical-history/${payload.id}/`,
      payload,
    );
  }
  async deletePastSurgeryHistory(payload: IPatientSurgicalHistory) {
    return this.axiosService.delete<IPatientSurgicalHistory>(
      `patient/${payload.patient}/patient-surgical-history/${payload.id}/`,
    );
  }
  async addPatientFamilyHistory(payload: IPatientFamilyHistory) {
    return this.axiosService.post<IPatientFamilyHistory>(
      `patient/${payload.patient}/patient-family-history/`,
      payload,
    );
  }
  async updatePatientFamilyHistory(payload: IPatientFamilyHistory) {
    return this.axiosService.patch<IPatientFamilyHistory>(
      `patient/${payload.patient}/patient-family-history/${payload.id}/`,
      payload,
    );
  }
  async deleteFamilyHistory(payload: IPatientFamilyHistory) {
    return this.axiosService.delete<IPatientFamilyHistory>(
      `patient/${payload.patient}/patient-family-history/${payload.id}/`,
    );
  }
  async addPatientAllergy(payload: IPatientAllergy) {
    return this.axiosService.post<IPatientAllergy>(
      `patient/${payload.patient}/patient-allergy/`,
      payload,
    );
  }

  async updatePatientAllergy(payload: IPatientAllergy) {
    return this.axiosService.patch<IPatientAllergy>(
      `patient/${payload.patient}/patient-allergy/${payload.id}/`,
      payload,
    );
  }

  async deletePatientAllergy(payload: IPatientAllergy) {
    return this.axiosService.delete<IPatientAllergy>(
      `patient/${payload.patient}/patient-allergy/${payload.id}/`,
    );
  }

  async getMeasures(measure_type: string) {
    return this.axiosService.get<IMeasure[]>(
      `metadata/measure/?type=${measure_type}`,
    );
  }

  async getPatientMeasures(patientId: string, measure_type: string) {
    return this.axiosService.get<IPatientMeasurePivot>(
      `patient/${patientId}/patient-measure-pivot/?type=${measure_type}`,
    );
  }

  async addPatientMeasure(payload: IMeasureValue) {
    return this.axiosService.post(
      `patient/${payload.patient}/patient-measure/`,
      payload,
    );
  }

  async getPatientDocuments(patientId: string) {
    return this.axiosService.get<IPatientDocument[]>(
      `patient/${patientId}/patient-document/`,
    );
  }

  async uploadPatientDocuments(payload: FormData, patientId: string) {
    return this.axiosService.post(`document/upload/${patientId}/`, payload, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  }

  async downloadPatientDocument(fileId: string) {
    return this.axiosService.get<IPatientDocument>(
      `document/download/${fileId}/`,
    );
  }

  async scanDocument(payload: FormData) {
    return this.axiosService.post(
      'document/scan/',
      payload,
    );
  }

  async getPatientReportByGender(
    fuuid: string,
    group_by: string,
    from_date: string,
    to_date: string,
  ) {
    return this.axiosService.get<ITotalChartDataResponse>(
      `/reporting/${fuuid}/patient-profile-metric/`,
      { params: { group_by, from_date, to_date } },
    );
  }

  async getPatientMedicalSummaries(patientId: string) {
    return this.axiosService.get<IPatientMedicalSummary[]>(
      `patient/${patientId}/encounter-summary/`,
    );
  }

  async getEncountersReport(
    fuuid: string,
    group_by: string,
    from_date: string,
    to_date: string,
  ) {
    return this.axiosService.get<ITotalChartDataResponse>(
      `/reporting/${fuuid}/encounter-status-over-time/`,
      { params: { group_by, from_date, to_date } },
    );
  }

  async getTopComplaintData(
    fuuid: string,
    group_by: string,
    from_date: string,
    to_date: string,
  ) {
    return this.axiosService.get<ITotalChartDataResponse>(
      `/reporting/${fuuid}/top-encounter-complaint/`,
      { params: { group_by, from_date, to_date } },
    );
  }

  async getTopDiagnosisData(
    fuuid: string,
    group_by: string,
    from_date: string,
    to_date: string,
  ) {
    return this.axiosService.get<ITotalChartDataResponse>(
      `/reporting/${fuuid}/top-encounter-diagnosis/`,
      { params: { group_by, from_date, to_date } },
    );
  }

  async getPatientEncounterSummaries(patientId: string) {
    return this.axiosService.get<IEncounter[]>(
      `patient/${patientId}/encounter-summary/`,
    );
  }

  async searchFacilities(query: ISearchFacilityQuery = {}) {
    return this.axiosService.get<IPaginatedResponse<IFacility>>(
      'facility/search/',
      {
        params: query,
      },
    );
  }

  async searchFacilityAppointments(
    facilityId: string,
    query: ISearchFacilityAppointmentsQuery = {},
  ) {
    return this.axiosService.get<IAppointment[]>(
      `facility/${facilityId}/appointment/`,
      {
        params: query,
      },
    );
  }

  async searchPractitioners(params: ISearchPractitionerQuery = {}) {
    return this.axiosService.get<IPaginatedResponse<IPractitioner>>(
      'team/search/',
      {
        params,
      },
    );
  }

  async registerPatientAppointment(
    payload: IRegisterPatientAppointmentPayload,
    fuuid: string,
  ) {
    return this.axiosService.post<IAppointment>(
      `patient/${payload.patient}/appointment/`,
      payload,
      { params: { fuuid } },
    );
  }
  async getAppointmentsReport(
    fuuid: string,
    group_by: string,
    from_date: string,
    to_date: string,
  ) {
    return this.axiosService.get<ITotalChartDataResponse>(
      `/reporting/${fuuid}/appointment-status-over-time/`,
      { params: { group_by, from_date, to_date } },
    );
  }
  async updateAppointmentAction(
    appointmentId: string,
    action: AppointmentAction,
  ) {
    return this.axiosService.post(`appointment/${appointmentId}/${action}/`);
  }

  async updatePatientAppointment(
    patientId: string,
    appointmentId: string,
    payload: Partial<IAppointment>,
    fuuid: string,
  ) {
    return this.axiosService.patch(
      `patient/${patientId}/appointment/${appointmentId}/`,
      payload,
      { params: { fuuid } },
    );
  }

  async getPatientEncounters(patientId: string) {
    return this.axiosService.get<IEncounter[]>(
      `encounter/${patientId}/encounter/`,
    );
  }

  async getPatientEncounter(encounterId: string) {
    return this.axiosService.get<IEncounter>(`/encounter/${encounterId}`);
  }

  async addPatientEncounter(payload: IEncounter) {
    return this.axiosService.post(
      `encounter/${payload.patient}/encounter/`,
      payload,
    );
  }

  async updatePatientEncounter(encounterId: string, payload: IEncounter) {
    return this.axiosService.patch(`encounter/${encounterId}/`, payload);
  }

  async updateComplaintEncounter(encounterId: string, complaintId: number, payload: IEncounterUpdatePayloadItem) {
    return this.axiosService.patch(`encounter/${encounterId}/complaint/${complaintId}/`, payload);
  }

  async getEncounterItems(encounterId: string, key: string) {
    return this.axiosService.get(`encounter/${encounterId}/${key}/`);
  }

  async addEncounterItem(
    payload: IEncounterItem | IEncounterFollowup,
    key: string,
  ) {
    return this.axiosService.post(
      `encounter/${payload.encounter}/${key}/`,
      payload,
    );
  }

  async addEncounter(
    payload: IEncounterPayload,
  ) {
    return this.axiosService.post(
      `encounter/${payload.patient}/encounter/`,
      payload,
    );
  }

  async deleteEncounterItem(
    payload: IEncounterItem | IEncounterFollowup,
    key: string,
  ) {
    return this.axiosService.delete(
      `encounter/${payload.encounter}/${key}/${payload.id}`,
    );
  }

  async getMetaData<T, R>(key: string, params?: T) {
    return this.axiosService.get<R[]>(`metadata/${key}`, {
      params,
    });
  }

  async getMetaDataDetails<T, R>(key: string, id: number) {
    return this.axiosService.get<R[]>(`metadata/${key}/${id}`);
  }

  async getlabTestProfileItems(profileId: number) {
    return this.axiosService.get<ILabTestProfileItem[]>(
      `metadata/lab_test_profile_item?profile_id=${profileId}`,
    );
  }

  async addImagingOrder(payload: IImagingOrderPayload) {
    return this.axiosService.post(
      `imaging/${payload.facility}/order/`,
      payload,
    );
  }

  async deleteImagingOrder(payload: IEncounterImagingOrder) {
    return this.axiosService.delete(
      `imaging/${payload.facility}/order/${payload.id}`,
    );
  }

  async printImagingOrder(imagingOrderId: string) {
    return this.axiosService.get<string>(
      `document/imaging-order/${imagingOrderId}/html/`,
    );
  }

  async downloadImagingOrder(imagingOrderId: string) {
    return this.axiosService.get<string>(
      `document/imaging-order/${imagingOrderId}/pdf/`,
    );
  }

  async addLabOrder(payload: ILabOrderPayload) {
    return this.axiosService.post(`lab/${payload.facility}/order/`, payload);
  }

  async deleteLabOrder(payload: IEncounterLabOrder) {
    return this.axiosService.delete(
      `lab/${payload.facility}/order/${payload.id}`,
    );
  }

  async getPatient(patientId: string, fuuid: string) {
    return this.axiosService.get<IPatient>(`patient/${patientId}/`, { params: { fuuid } });
  }

  async updatePatient(patientId: string, payload: IUpdatePatientPayload, fuuid: string) {
    return this.axiosService.patch<IPatient>(`patient/${patientId}/`, payload, { params: { fuuid } });
  }

  async searchImagingOrders(facilityId: string, params: IImagingOrderQuery) {
    return this.axiosService.get<IPaginatedResponse<IImagingOrder>>(
      `imaging/${facilityId}/order/`,
      {
        params,
      },
    );
  }

  async getImagingScans(facilityId: string, imagingOrderId: string) {
    return this.axiosService.get<IScan[]>(
      `imaging/${facilityId}/order/${imagingOrderId}/imaging-scan/`,
    );
  }

  async addMedicationOrder(
    facilityId: string,
    payload: IMedicationOrderPayload,
  ) {
    return this.axiosService.post(`medication/${facilityId}/order/`, payload);
  }

  async deleteMedicationOrder(facilityId: string, medicationOrderId: string) {
    return this.axiosService.delete(
      `medication/${facilityId}/order/${medicationOrderId}`,
    );
  }

  async printMedicationOrder(medicationOrderId: string) {
    return this.axiosService.get<string>(
      `document/medication-order/${medicationOrderId}/html/`,
    );
  }

  async downloadMedicationOrder(medicationOrderId: string) {
    return this.axiosService.get<string>(
      `document/medication-order/${medicationOrderId}/pdf/`,
    );
  }

  async searchLabOrders(facilityId: string, params: ILabOrderQuery) {
    return this.axiosService.get<IPaginatedResponse<ILabOrder>>(
      `lab/${facilityId}/order/`,
      {
        params,
      },
    );
  }

  async getLabTests(facilityId: string, labOrderId: string) {
    return this.axiosService.get<ILabOrderTest[]>(
      `lab/${facilityId}/order/${labOrderId}/lab-test/`,
    );
  }

  async printLabOrder(labOrderId: string) {
    return this.axiosService.get<string>(
      `document/lab-order/${labOrderId}/html/`,
    );
  }

  async downloadLabOrder(labOrderId: string) {
    return this.axiosService.get<string>(
      `document/lab-order/${labOrderId}/pdf/`,
    );
  }

  async searchMedicationOrders(
    facilityId: string,
    params: IMedicationOrderQuery,
  ) {
    return this.axiosService.get<IPaginatedResponse<IMedicationOrder>>(
      `medication/${facilityId}/order/`,
      {
        params,
      },
    );
  }

  async getMedicationItems(facilityId: string, medicationOrderId: string) {
    return this.axiosService.get<IMedicationOrderItem[]>(
      `medication/${facilityId}/order/${medicationOrderId}/medication/`,
    );
  }

  async deleteMedicationOrderItem(facilityId: string, medicationOrderId: string, medicationOrderItemId: number) {
    return this.axiosService.delete<IMedicationOrderItem[]>(
      `medication/${facilityId}/order/${medicationOrderId}/medication/${medicationOrderItemId}/`,
    );
  }

  async updateMedicationItemInstruction(facilityId: string, medicationOrderId: string, medicationOrderItemId: number, payload: IMedicationOrderItemUpdatePayload) {
    return this.axiosService.patch<IMedicationOrderItemUpdatePayload>(
      `medication/${facilityId}/order/${medicationOrderId}/medication/${medicationOrderItemId}/`,
      payload,
    );
  }

  async searchInvoices(facilityId: string, params: IInvoiceQuery) {
    return this.axiosService.get<IPaginatedResponse<IInvoice>>(
      `billing/${facilityId}/invoice/`,
      { params },
    );
  }

  async getConfigs(facilityId: string, params: IConfigQuery) {
    return this.axiosService.get<IPaginatedResponse<IConfig>>(
      `config/${facilityId}/`,
      {
        params,
      },
    );
  }

  async getDefaultTemplateDesign(facilityId: string, pruuid: string) {
    return this.axiosService.get<IConfig[]>(
      `config/${facilityId}/entity-config/?entity=practitioner&entity_id=${pruuid}&name=default_template_design`,
    );
  }

  async setDefaultTemplateDesign(facilityId: string, payload: ITemplateDesignPayload) {
    return this.axiosService.post<IConfig>(
      `config/${facilityId}/entity-config/`,
      payload,
    );
  }

  async getInvoiceItems(facilityId: string, invoiceId: string) {
    return this.axiosService.get<IInvoiceItem[]>(
      `billing/${facilityId}/invoice/${invoiceId}/item/`,
    );
  }

  async getFacilityProducts(facilityId: string) {
    return this.axiosService.get<IFacilityProduct[]>(
      `billing/${facilityId}/product/`,
    );
  }

  async createInvoice(facilityId: string, payload: ICreateInvoicePayload) {
    return this.axiosService.post(`billing/${facilityId}/invoice/`, payload);
  }

  async payInvoice(facilityId: string, payload: IPayInvoicePayload) {
    return this.axiosService.post(`billing/${facilityId}/payment/`, payload);
  }

  async payAppointmentFee(
    facilityId: string,
    payload: IPayAppointmentFeePayload,
  ) {
    return this.axiosService.post(`billing/${facilityId}/payment/`, payload);
  }

  async printInvoice(invoiceId: number) {
    return this.axiosService.get<string>(`document/invoice/${invoiceId}/html/`);
  }

  async downloadInvoice(invoiceId: number) {
    return this.axiosService.get<string>(`document/invoice/${invoiceId}/pdf/`);
  }

  async searchPayments(facilityId: string, params: IPaymentQuery) {
    return this.axiosService.get<IPaginatedResponse<IPayment>>(
      `billing/${facilityId}/payment/`,
      { params },
    );
  }

  async getMetaDataICDCodes(params: IMetaDataCodeQuery) {
    return this.axiosService.get<IMetaDataICDCode[]>('metadata/icd-code/', {
      params,
    });
  }

  async getMetaDataCountryCode() {
    return this.axiosService.get<IMetaDataCountryCode[]>('metadata/country/');
  }

  async getMetaDataCPTCodes(params: IMetaDataCodeQuery) {
    return this.axiosService.get<IMetaDataCPTCode[]>('metadata/cpt-code/', {
      params,
    });
  }

  async getEncounterDocumentPdf(type: string, id: string) {
    return this.axiosService.post<any>(
      `document/${type}/encounter/${id}/pdf/`,
      {},
    );
  }

  async getEncounterDocumentHtml(type: string, id: string) {
    return this.axiosService.post<any>(
      `document/${type}/encounter/${id}/html/`,
      {},
    );
  }

  async getConfigList(facilityId: string, params?: IConfigListQuery) {
    return this.axiosService.get<IConfigList[]>(`config/${facilityId}`, {
      params,
    });
  }

  async getConfig(facilityId: string, params?: IConfigQuery) {
    return this.axiosService.get<IConfig[]>(
      `config/${facilityId}/entity-config/`,
      {
        params,
      },
    );
  }

  async getVitalPanelConfig(facilityId: string, params?: IConfigQuery) {
    return this.axiosService.get<IConfigurationsResponse[]>(
      `config/${facilityId}/entity-config/`,
      {
        params,
      },
    );
  }

  async addConfig(facilityId: string, payload: IConfigPayload) {
    return this.axiosService.post<IConfig>(
      `config/${facilityId}/entity-config/`,
      payload,
    );
  }

  async deleteConfig(facilityId: string, configId: string) {
    return this.axiosService.delete(
      `config/${facilityId}/entity-config/${configId}`,
    );
  }

  async getDefaultAppointmentFeeValues(practitionerId: string, group: string) {
    return this.axiosService.get<IDefaultAppointmentFeeValue[]>(
      `team/${practitionerId}/config/default-setting/?group=${group}`,
    );
  }

  async searchCustomEncounters(
    practitionerId: string,
    encounterType: CustomEncounterType,
    params: IFilterQuery,
  ) {
    return this.axiosService.get<IPaginatedResponse<ICustomEncounter>>(
      `team/${practitionerId}/${encounterType}/`,
      {
        params,
      },
    );
  }

  async createCustomEncounter(
    encounterType: CustomEncounterType,
    payload: ICreateCustomEncounterPayload | ICreateCustomMedicationPayload,
  ) {
    return this.axiosService.post<ICustomEncounter>(
      `metadata/${encounterType}/`,
      payload,
    );
  }

  async updateCustomEncounter(
    encounterType: CustomEncounterType,
    payload: ICreateCustomEncounterPayload | ICreateCustomMedicationPayload,
    customEncounterId: number,
  ) {
    return this.axiosService.patch<ICustomEncounter>(
      `metadata/${encounterType}/${customEncounterId}/`,
      payload,
    );
  }

  async deleteCustomEncounter(
    practitionerId: string,
    encounterType: CustomEncounterType,
    customEncounterTypeId: number,
  ) {
    return this.axiosService.delete<ICustomEncounter>(
      `team/${practitionerId}/${encounterType}/${customEncounterTypeId}/`,
    );
  }

  async updateFavoriteCustomEncounter(
    practitionerId: string,
    encounterType: CustomEncounterType,
    customEncounterTypeId: number,
  ) {
    return this.axiosService.patch<ICustomEncounter>(
      `team/${practitionerId}/${encounterType}-favorite/${customEncounterTypeId}/`,
      {
        practitioner: practitionerId,
        [encounterType]: customEncounterTypeId,
      },
    );
  }

  async getConfigByNames(
    facilityId: string,
    group: string,
    subGroup: string,
    pruuid: string,
  ) {
    return this.axiosService.get<IConfigByNames[]>(
      `config/${facilityId}/entity-config/${group}/${subGroup}`,
      { params: { pruuid: pruuid } },
    );
  }

  async getEncounterConfigs(group: string, subGroup: string, pruuid: string) {
    return this.axiosService.get<IConfiguration[]>(
      `team/${pruuid}/config/encounter-notes/`,
      { params: { group, sub_group: subGroup } },
    );
  }

  async updateConfig(
    practitionerId: string,
    fuuid: string,
    configName: string,
  ) {
    return this.axiosService.patch<ICustomEncounter>(
      `team/${practitionerId}/config/encounter-notes/${configName}/?fuuid=${fuuid}`,
    );
  }

  async getProcedures(facilityId: string, params: IProcedureQuery) {
    return this.axiosService.get<IPaginatedResponse<IProcedure>>(
      `procedure/${facilityId}/order/`,
      {
        params,
      },
    );
  }

  async getProcedureDetails(facilityId: string, order_id: string) {
    return this.axiosService.get<IProcedureDetails>(
      `procedure/${facilityId}/order/${order_id}`,
    );
  }

  async addProcedure(facilityId: string, payload: IProcedurePayload) {
    return this.axiosService.post(`procedure/${facilityId}/order/`, payload);
  }

  async updateProcedure(
    facilityId: string,
    id: string,
    payload: IProcedurePayload,
  ) {
    return this.axiosService.patch(
      `procedure/${facilityId}/order/${id}/`,
      payload,
    );
  }

  async getProcedureItems(practitionerId: string, params: IProcedureItemQuery) {
    return this.axiosService.get<IPaginatedResponse<IProcedureItem>>(
      `team/${practitionerId}/procedure/`,
      {
        params,
      },
    );
  }

  async searchCustomForms(practitionerId: string, params: IFilterQuery) {
    return this.axiosService.get<IPaginatedResponse<ICustomForm>>(
      `team/${practitionerId}/form/`,
      { params },
    );
  }

  async createCustomForm(payload: ICustomFormPayload) {
    return this.axiosService.post<ICustomForm>('metadata/form/', payload);
  }

  async updateCustomForm(payload: ICustomFormPayload, customFormId: number) {
    return this.axiosService.patch<ICustomForm>(
      `metadata/form/${customFormId}/`,
      payload,
    );
  }

  async updateFavoriteCustomForm(practitionerId: string, customFormId: number) {
    return this.axiosService.patch<ICustomEncounter>(
      `team/${practitionerId}/form-favorite/${customFormId}/`,
      {
        practitioner: practitionerId,
      },
    );
  }

  async getCustomForm(encounterId: string, formId: number) {
    return this.axiosService.get<IEncounterCustomForm>(
      `encounter/${encounterId}/form/${formId}`,
    );
  }

  async saveCustomForm(encounterId: string, formId: number, payload: any) {
    return this.axiosService.patch<IEncounterCustomForm>(
      `encounter/${encounterId}/form/${formId}/`,
      payload,
    );
  }

  async searchProducts(
    practitionerId: string,
    params?: IConfigPaginationQuery,
  ) {
    return this.axiosService.get<IPaginatedResponse<IProduct>>(
      `team/${practitionerId}/product/`,
      { params },
    );
  }

  async createProduct(payload: IProductPayload) {
    return this.axiosService.post<ICustomForm>('metadata/product/', payload);
  }

  async updateProduct(payload: IProductPayload, id: number) {
    return this.axiosService.patch<IProduct>(
      `metadata/product/${id}/`,
      payload,
    );
  }

  async updateFavoriteProduct(practitionerId: string, id: number) {
    return this.axiosService.patch<IProduct>(
      `team/${practitionerId}/product-favorite/${id}/`,
      {
        practitioner: practitionerId,
      },
    );
  }

  async searchServices(
    practitionerId: string,
    params?: IConfigPaginationQuery,
  ) {
    return this.axiosService.get<IPaginatedResponse<IService>>(
      `team/${practitionerId}/service/`,
      { params },
    );
  }

  async createService(payload: IServicePayload) {
    return this.axiosService.post<IService>('metadata/service/', payload);
  }

  async updateService(payload: IServicePayload, id: number) {
    return this.axiosService.patch<IService>(
      `metadata/service/${id}/`,
      payload,
    );
  }

  async updateFavoriteService(practitionerId: string, id: number) {
    return this.axiosService.patch<IService>(
      `team/${practitionerId}/service-favorite/${id}/`,
      {
        practitioner: practitionerId,
      },
    );
  }

  async getPractitionerDetails(
    practitionerId: string,
  ) {
    return this.axiosService.get<IPractitioner>(
      `team/${practitionerId}/`,
    );
  }

  async printPrescription(
    practitionerId: string,
    payload: IPrescriptionPrintPayload,
    design: number,
  ) {
    return this.axiosService.post<IPrescriptionPrintPayload>(
      `/tools/prescription-printer/practitioner/${practitionerId}/html/?design=${design}`,
      payload,
    );
  }

  async generateMedicalReport(
    practitionerId: string,
    payload: IMedicalReportPayload,
  ) {
    return this.axiosService.post<IMedicalReport>(
      `/tools/medical-report/practitioner/${practitionerId}/text/`,
      payload,
    );
  }

  async printMedicalReport(
    practitionerId: string,
    payload: IMedicalReportPrintPayload,
  ) {
    return this.axiosService.post<IMedicalReport>(
      `/tools/medical-report/practitioner/${practitionerId}/html/`,
      payload,
    );
  }
  async getBeds(
    fuuid: string,
    params?: IBedQuery,
  ) {
    return this.axiosService.get<IWard[]>(
      `/facility/${fuuid}/bed/`,
      {
        params,
      },
    );
  }

  async getBedStatusByWard(
    fuuid: string,
  ) {
    return this.axiosService.get<IBedAnalytics>(
      `/reporting/${fuuid}/bed-status-by-ward/`,
    );
  }

  async addBed(
    fuuid: string,
    payload: IBed,
  ) {
    return this.axiosService.post<IBed>(
      `/facility/${fuuid}/bed/`,
      payload,
    );
  }

  async updateBed(
    fuuid: string,
    payload: IBed,
  ) {
    return this.axiosService.patch<IBed>(
      `/facility/${fuuid}/bed/${payload.id}/`,
      payload,
    );
  }

  async removeBed(
    fuuid: string,
    id: number,
  ) {
    return this.axiosService.delete<IBed>(
      `/facility/${fuuid}/bed/${id}/`,
    );
  }
}
