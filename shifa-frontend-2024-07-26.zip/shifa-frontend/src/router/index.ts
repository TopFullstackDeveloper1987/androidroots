// composables
import { createRouter, createWebHistory } from 'vue-router';

// layouts
const MainLayout = import('@/layouts/Main.vue');
const PatientLayout = import('@/layouts/Patient.vue');

// views
const Dashboard = import('@/views/Dashboard.vue');
const PatientList = import('@/views/patients/PatientList.vue');
const PatientProfile = import('@/views/patients/PatientProfile.vue');
const PatientCondition = import('@/views/patients/PatientCondition.vue');
const PatientMeasures = import('@/views/patients/PatientMeasures.vue');

const EncounterNotes = import('@/views/medical-records/EncounterNotes.vue');
const EncounterNotesConfig = import('@/views/configuration/EncounterNotes.vue');
const TestResults = import('@/views/medical-records/TestResults.vue');
const Medications = import('@/views/medical-records/Medications.vue');
const Procedures = import('@/views/medical-records/Procedures.vue');

const MedicationOrders = import('@/views/orders/MedicationOrders.vue');
const LabOrders = import('@/views/orders/LabOrders.vue');
const ImagingOrders = import('@/views/orders/ImagingOrders.vue');

const ReferralRequests = import('@/views/referrals/ReferralRequests.vue');

const Analytics = import('@/views/reports/Analytics.vue');

const PrescriptionPrinter = import('@/views/tools/PrescriptionPrinter.vue');
const AiReportGenerator = import('@/views/tools/AiReportGenerator.vue');

const Invoices = import('@/views/billing/Invoices.vue');
const Payments = import('@/views/billing/Payments.vue');

const AdminDashboard = import('@/views/bed-management/AdminDashboard.vue');
const BedAvailability = import('@/views/bed-management/BedAvailability.vue');

const Login = import('@/views/Login.vue');
const RegisterPatient = import('@/views/RegisterPatient.vue');

const DefaultSettings = import('@/views/configuration/DefaultSettings.vue');
const ConfigProcedures = import('@/views/configuration/Procedures.vue');
const ConfigComplaints = import('@/views/configuration/Complaints.vue');
const ConfigObservations = import('@/views/configuration/Observations.vue');
const ConfigDiagnosis = import('@/views/configuration/Diagnosis.vue');
const ConfigMedication = import('@/views/configuration/Medication.vue');
const ConfigAdvice = import('@/views/configuration/Advice.vue');
const CustomForms = import('@/views/configuration/CustomForms.vue');
const Products = import('@/views/configuration/Products.vue');
const Services = import('@/views/configuration/Services.vue');

// services
import { LocalStorageService } from '@/services';
import { UserRole, UserSubscription } from '@/types';

let routes = [
  // Dashboard
  {
    path: '/',
    component: () => MainLayout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => Dashboard,
      },
      // Patients
      {
        path: 'patients',
        redirect: '/patients/list',
        children: [
          {
            path: 'list',
            name: 'Patient List',
            component: () => PatientList,
          },
        ],
      },
      // Orders
      {
        path: 'orders',
        redirect: '/orders/medication-orders',
        children: [
          {
            path: 'medication-orders',
            name: 'Medication Orders',
            component: () => MedicationOrders,
          },
          {
            path: 'lab-orders',
            name: 'Lab Orders',
            component: () => LabOrders,
          },
          {
            path: 'imaging-orders',
            name: 'Imaging Orders',
            component: () => ImagingOrders,
          },
        ],
      },
      // Reports
      {
        path: 'reports',
        redirect: '/reports/analytics',
        children: [
          {
            path: 'analytics',
            name: 'Analytics',
            component: () => Analytics,
          },
        ],
      },
      // Tools
      {
        path: 'tools',
        redirect: '/tools/print-prescription',
        children: [
          {
            path: 'print-prescription',
            name: 'PrescriptionPrinter',
            component: () => PrescriptionPrinter,
          },
          {
            path: 'ai-report-generator',
            name: 'AiReportGenerator',
            component: () => AiReportGenerator,
          },
        ],
      },
      // Billing
      {
        path: 'billing',
        redirect: '/billing/invoices',
        children: [
          {
            path: 'invoices',
            name: 'Invoices',
            component: () => Invoices,
          },
          {
            path: 'payments',
            name: 'Payments',
            component: () => Payments,
          },
        ],
      },
      // Bed Management
      {
        path: 'bed-management',
        redirect: '/bed-management/admin-dashboard',
        children: [
          {
            path: 'admin-dashboard',
            name: 'Admin Dashboard',
            component: () => AdminDashboard,
          },
          {
            path: 'bed-availability',
            name: 'Bed Availability',
            component: () => BedAvailability,
          },
        ],
      },
      // Register Patient
      {
        path: '/register',
        redirect: '/register/patient',
        children: [
          {
            path: 'patient',
            name: 'Register Patient',
            component: () => RegisterPatient,
          },
        ],
      },
      // Configuration
      {
        path: '/configuration',
        children: [
          {
            path: 'default-settings',
            name: 'Configuration',
            component: () => DefaultSettings,
          },
          {
            path: 'encounter-notes',
            name: 'EncounterNotes',
            component: () => EncounterNotesConfig,
          },
          {
            path: 'procedures',
            name: 'ConfigProcedures',
            component: () => ConfigProcedures,
          },
          {
            path: 'complaints',
            name: 'ConfigComplaints',
            component: () => ConfigComplaints,
          },
          {
            path: 'observations',
            name: 'ConfigObservations',
            component: () => ConfigObservations,
          },
          {
            path: 'diagnosis',
            name: 'ConfigDiagnosis',
            component: () => ConfigDiagnosis,
          },
          {
            path: 'medication',
            name: 'ConfigMedication',
            component: () => ConfigMedication,
          },
          {
            path: 'advice',
            name: 'ConfigAdvice',
            component: () => ConfigAdvice,
          },
          {
            path: 'custom-forms',
            name: 'CustomForms',
            component: () => CustomForms,
          },
          {
            path: 'products',
            name: 'Products',
            component: () => Products,
          },
          {
            path: 'services',
            name: 'Services',
            component: () => Services,
          },
        ],
      },
    ],
  },
  // Patient Profile Layout
  {
    path: '/',
    component: () => PatientLayout,
    children: [
      // Patient
      {
        path: '/patients/:patientId/profile',
        name: 'Patient Profile',
        component: () => PatientProfile,
      },
      {
        path: '/patients/:patientId/condition',
        name: 'Patient Condition',
        component: () => PatientCondition,
      },
      {
        path: '/patients/:patientId/measures',
        name: 'Patient Measures',
        component: () => PatientMeasures,
      },
      // Medical Records
      {
        path: 'medical-records',
        children: [
          {
            path: ':patientId/encounter-notes',
            name: 'Encounter Notes',
            component: () => EncounterNotes,
          },
          {
            path: ':patientId/procedures',
            name: 'PatientProcedures',
            component: () => Procedures,
          },
          {
            path: ':patientId/test-results',
            name: 'Test Results',
            component: () => TestResults,
          },
          {
            path: ':patientId/medications',
            name: 'Medications',
            component: () => Medications,
          },
        ],
      },
    ],
  },
  // Auth
  {
    path: '/login',
    name: 'Login',
    component: () => Login,
  },
  // Not found
  {
    path: '/:pathMatch(.*)*',
    redirect: '/',
  },
];

const basicRoutes = [
  // Dashboard
  {
    path: '/',
    component: () => MainLayout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => Dashboard,
      },
      // Patients
      {
        path: 'patients',
        redirect: '/patients/list',
        children: [
          {
            path: 'list',
            name: 'Patient List',
            component: () => PatientList,
          },
        ],
      },
      // Orders
      {
        path: 'orders',
        redirect: '/orders/medication-orders',
        children: [
          {
            path: 'medication-orders',
            name: 'Medication Orders',
            component: () => MedicationOrders,
          },
          {
            path: 'lab-orders',
            name: 'Lab Orders',
            component: () => LabOrders,
          },
          {
            path: 'imaging-orders',
            name: 'Imaging Orders',
            component: () => ImagingOrders,
          },
        ],
      },
      // Tools
      {
        path: 'tools',
        redirect: '/tools/print-prescription',
        children: [
          {
            path: 'print-prescription',
            name: 'PrescriptionPrinter',
            component: () => PrescriptionPrinter,
          },
          {
            path: 'ai-report-generator',
            name: 'AiReportGenerator',
            component: () => AiReportGenerator,
          },
        ],
      },
      // Billing
      {
        path: 'billing',
        redirect: '/billing/invoices',
        children: [
          {
            path: 'invoices',
            name: 'Invoices',
            component: () => Invoices,
          },
          {
            path: 'payments',
            name: 'Payments',
            component: () => Payments,
          },
        ],
      },
      // Bed Management
      {
        path: 'bed-management',
        redirect: '/bed-management/admin-dashboard',
        children: [
          {
            path: 'admin-dashboard',
            name: 'Admin Dashboard',
            component: () => AdminDashboard,
          },
          {
            path: 'bed-availability',
            name: 'Bed Availability',
            component: () => BedAvailability,
          },
        ],
      },
      // Reports
      {
        path: 'reports',
        redirect: '/reports/analytics',
        children: [
          {
            path: 'analytics',
            name: 'Analytics',
            component: () => Analytics,
          },
        ],
      },
      // Register Patient
      {
        path: '/register',
        redirect: '/register/patient',
        children: [
          {
            path: 'patient',
            name: 'Register Patient',
            component: () => RegisterPatient,
          },
        ],
      },
      // Configuration
      {
        path: '/configuration',
        children: [
          {
            path: 'default-settings',
            name: 'Configuration',
            component: () => DefaultSettings,
          },
          {
            path: 'encounter-notes',
            name: 'EncounterNotes',
            component: () => EncounterNotesConfig,
          },
          {
            path: 'procedures',
            name: 'ConfigProcedures',
            component: () => ConfigProcedures,
          },
          {
            path: 'complaints',
            name: 'ConfigComplaints',
            component: () => ConfigComplaints,
          },
          {
            path: 'observations',
            name: 'ConfigObservations',
            component: () => ConfigObservations,
          },
          {
            path: 'diagnosis',
            name: 'ConfigDiagnosis',
            component: () => ConfigDiagnosis,
          },
          {
            path: 'medication',
            name: 'ConfigMedication',
            component: () => ConfigMedication,
          },
          {
            path: 'advice',
            name: 'ConfigAdvice',
            component: () => ConfigAdvice,
          },
          {
            path: 'custom-forms',
            name: 'CustomForms',
            component: () => CustomForms,
          },
          {
            path: 'products',
            name: 'Products',
            component: () => Products,
          },
          {
            path: 'services',
            name: 'Services',
            component: () => Services,
          },
        ],
      },
    ],
  },
  // Patient Profile Layout
  {
    path: '/',
    component: () => PatientLayout,
    children: [
      // Patient
      {
        path: '/patients/:patientId/profile',
        name: 'Patient Profile',
        component: () => PatientProfile,
      },
      {
        path: '/patients/:patientId/condition',
        name: 'Patient Condition',
        component: () => PatientCondition,
      },
      {
        path: '/patients/:patientId/measures',
        name: 'Patient Measures',
        component: () => PatientMeasures,
      },
      // Medical Records
      {
        path: 'medical-records',
        children: [
          {
            path: ':patientId/encounter-notes',
            name: 'Encounter Notes',
            component: () => EncounterNotes,
          },
          {
            path: ':patientId/procedures',
            name: 'PatientProcedures',
            component: () => Procedures,
          },
          {
            path: ':patientId/test-results',
            name: 'Test Results',
            component: () => TestResults,
          },
          {
            path: ':patientId/medications',
            name: 'Medications',
            component: () => Medications,
          },
        ],
      },
    ],
  },
  // Auth
  {
    path: '/login',
    name: 'Login',
    component: () => Login,
  },
  // Not found
  {
    path: '/:pathMatch(.*)*',
    redirect: '/',
  },
];

const receptionistRoutes = [
  // Dashboard
  {
    path: '/',
    component: () => MainLayout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => Dashboard,
      },
      // Patients
      {
        path: 'patients',
        redirect: '/patients/list',
        children: [
          {
            path: 'list',
            name: 'Patient List',
            component: () => PatientList,
          },
        ],
      },
      // Register Patient
      {
        path: '/register',
        redirect: '/register/patient',
        children: [
          {
            path: 'patient',
            name: 'Register Patient',
            component: () => RegisterPatient,
          },
        ],
      },
      // Bed Management
      {
        path: 'bed-management',
        redirect: '/bed-management/admin-dashboard',
        children: [
          {
            path: 'admin-dashboard',
            name: 'Admin Dashboard',
            component: () => AdminDashboard,
          },
          {
            path: 'bed-availability',
            name: 'Bed Availability',
            component: () => BedAvailability,
          },
        ],
      },
    ],
  },
  {
    path: '/',
    component: () => PatientLayout,
    children: [
      // Patient
      {
        path: '/patients/:patientId/profile',
        name: 'Patient Profile',
        component: () => PatientProfile,
      },
    ],
  },
  // Auth
  {
    path: '/login',
    name: 'Login',
    component: () => Login,
  },
  // Not found
  {
    path: '/:pathMatch(.*)*',
    redirect: '/dashboard',
  },
];

const onlyPrinterToolRoutes = [
  // Dashboard
  {
    path: '/',
    component: () => MainLayout,
    redirect: '/print-prescription',
    children: [
      // Tools
      {
        path: 'tools',
        redirect: '/tools/print-prescription',
        children: [
          {
            path: 'print-prescription',
            name: 'PrescriptionPrinter',
            component: () => PrescriptionPrinter,
          },
        ],
      },
      // Bed Management
      {
        path: 'bed-management',
        redirect: '/bed-management/admin-dashboard',
        children: [
          {
            path: 'admin-dashboard',
            name: 'Admin Dashboard',
            component: () => AdminDashboard,
          },
          {
            path: 'bed-availability',
            name: 'Bed Availability',
            component: () => BedAvailability,
          },
        ],
      },
    ],
  },
  // Auth
  {
    path: '/login',
    name: 'Login',
    component: () => Login,
  },
  // Not found
  {
    path: '/:pathMatch(.*)*',
    redirect: '/tools/print-prescription',
  },
];

const onlyReportToolRoutes = [
  // Dashboard
  {
    path: '/',
    component: () => MainLayout,
    redirect: '/ai-report-generator',
    children: [
      // Tools
      {
        path: 'tools',
        redirect: '/tools/ai-report-generator',
        children: [
          {
            path: 'ai-report-generator',
            name: 'AiReportGenerator',
            component: () => AiReportGenerator,
          },
        ],
      },
      // Bed Management
      {
        path: 'bed-management',
        redirect: '/bed-management/admin-dashboard',
        children: [
          {
            path: 'admin-dashboard',
            name: 'Admin Dashboard',
            component: () => AdminDashboard,
          },
          {
            path: 'bed-availability',
            name: 'Bed Availability',
            component: () => BedAvailability,
          },
        ],
      },
    ],
  },
  // Auth
  {
    path: '/login',
    name: 'Login',
    component: () => Login,
  },
  // Not found
  {
    path: '/:pathMatch(.*)*',
    redirect: '/tools/ai-report-generator',
  },
];

const onlyToolKitRoutes = [
  // Dashboard
  {
    path: '/',
    component: () => MainLayout,
    redirect: '/print-prescription',
    children: [
      // Tools
      {
        path: 'tools',
        redirect: '/tools/print-prescription',
        children: [
          {
            path: 'print-prescription',
            name: 'PrescriptionPrinter',
            component: () => PrescriptionPrinter,
          },
          {
            path: 'ai-report-generator',
            name: 'AiReportGenerator',
            component: () => AiReportGenerator,
          },
        ],
      },
      // Bed Management
      {
        path: 'bed-management',
        redirect: '/bed-management/admin-dashboard',
        children: [
          {
            path: 'admin-dashboard',
            name: 'Admin Dashboard',
            component: () => AdminDashboard,
          },
          {
            path: 'bed-availability',
            name: 'Bed Availability',
            component: () => BedAvailability,
          },
        ],
      },
    ],
  },
  // Auth
  {
    path: '/login',
    name: 'Login',
    component: () => Login,
  },
  // Not found
  {
    path: '/:pathMatch(.*)*',
    redirect: '/tools/print-prescription',
  },
];


const currentUserSubscription =
LocalStorageService.getInstance().getUserSubscription();

switch(currentUserSubscription) {
  case UserSubscription.ToolPrescriptionPrinter:
    routes = onlyPrinterToolRoutes;
    break;
  case UserSubscription.ToolReportGenerator:
    routes = onlyReportToolRoutes;
    break;
  case UserSubscription.ToolKit:
    routes = onlyToolKitRoutes;
    break;
  case UserSubscription.Basic:
    routes = basicRoutes;
    break;
}

const currentUserRole =
LocalStorageService.getInstance().getUserRole();

if(currentUserRole === UserRole.Receptionist) {
  routes = receptionistRoutes;
}

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

router.beforeEach((to, from, next) => {
  const isLogin = to.path.startsWith('/login');
  if (isLogin) {
    next();
    return;
  }

  const token = LocalStorageService.getInstance().getToken();
  const currentFacilityId =
    LocalStorageService.getInstance().getCurrentFacilityId();

  if (!token || !currentFacilityId) {
    next('/login');

    return;
  }

  next();
});

export default router;
