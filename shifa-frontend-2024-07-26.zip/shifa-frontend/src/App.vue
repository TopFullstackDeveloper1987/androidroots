<template>
  <div>
    <router-view />
    <Toast
      v-model="commonStore.toastData.show"
      :type="commonStore.toastData.type"
      :message="commonStore.toastData.message"
    />
  </div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue';
import Toast from '@/components/common/Toast.vue';
import { useRouter } from 'vue-router';
import { LocalStorageService } from '@/services';
import { useAuthStore, useCommonStore, useDefaultSettingsStore } from '@/store';
import { IConfigurationsResponse } from '@/types';
import forEach from 'lodash/forEach';

const authStore = useAuthStore();
const commonStore = useCommonStore();
const defaultSettingsStore = useDefaultSettingsStore();
const router = useRouter();

const configurations = ref<IConfigurationsResponse[]>();

onMounted(async () => {
  const token = LocalStorageService.getInstance().getToken();
  if (token) {
    authStore.getUserInfo();

    configurations.value = await defaultSettingsStore.getVitalPanelConfig({
      name: 'default_home',
      entity: 'practitioner',
      entity_id: authStore.userInfo.id,
      output_format: 'list',
    });

    if(!router.options.history.state.back) {
      forEach(configurations.value, config => {
        if(config.configuration === 'default_home') {
          router.push(config.value);
        }
      });
    }
  }
});
</script>
