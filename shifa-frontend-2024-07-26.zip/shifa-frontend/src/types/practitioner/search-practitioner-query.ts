export interface ISearchPractitionerQuery {
  fuuid?: string;
  first_name?: string;
  last_name?: string;
}
