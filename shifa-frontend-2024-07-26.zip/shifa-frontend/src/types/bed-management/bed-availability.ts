export enum BedType {
  Single = 'single',
  Double = 'double',
}

export enum BedStatus {
  Available = 'available',
  Occupied = 'occupied',
  NeedsCleaning = 'needs cleaning',
  NotInUse = 'not in use',
}

export interface IBedQuery {
  floor?: number,
  status?: string,
  type?: string,
}

export interface IBed {
  id?: number,
  ward_name?: string,
  floor_name?: string,
  created_date?: string,
  is_active?: boolean,
  soft_delete?: boolean,
  deleted_date?: string,
  bed_number: string,
  floor: number,
  bed_status: string,
  bed_type: string,
  ward: number,
  facility: string,
}

export interface IWard {
  id: number,
  name: string,
  name_arabic: string,
  name_kurdish: string,
  beds: IBed[],
}

export interface IBedStatus {
  bed_status: string,
  bed_count: number,
  percentage: number,
}

export interface IWards {
  ward_id: number,
  ward_name: string,
  bed_statuses: IBedStatus[],
}

export interface IBedAnalytics {
  wards: IWards[],
  summary: IBedStatus[],
}

export interface IDataset {
  backgroundColor: string[],
  data: number[],
}

export interface IDoughnutDataType {
  labels: string[],
  datasets: IDataset[],
}
