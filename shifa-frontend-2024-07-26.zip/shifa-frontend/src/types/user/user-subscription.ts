export enum UserSubscription {
  ToolPrescriptionPrinter = 'tool-prescription-printer',
  ToolReportGenerator = 'tool-report-generator',
  ToolKit = 'toolkit',
  Basic = 'basic',
  Silver = 'silver',
  Gold = 'gold'
}
