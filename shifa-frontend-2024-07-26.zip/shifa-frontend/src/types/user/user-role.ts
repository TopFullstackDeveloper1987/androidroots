export enum UserRole {
  Receptionist = 'receptionist',
  Practitioner = 'practitioner',
  Nurse = 'nurse'
}
