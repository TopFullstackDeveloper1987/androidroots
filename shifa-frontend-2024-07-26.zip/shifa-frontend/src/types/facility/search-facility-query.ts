export interface ISearchFacilityQuery {
  city?: string;
  name?: string;
}
