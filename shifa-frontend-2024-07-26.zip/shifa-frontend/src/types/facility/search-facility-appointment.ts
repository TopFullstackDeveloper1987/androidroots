export interface ISearchFacilityAppointmentsQuery {
  date?: string;
  practitioner_uuid?: string;
  puuid?: string;
  sort_by?: string,
  order_by?: string,
}
