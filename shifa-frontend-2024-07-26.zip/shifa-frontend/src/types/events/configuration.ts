export enum ConfigurationEvents {
  ReloadConfig = 'reload-config',
  ReloadCustomEncounters = 'reload-custom-encounters',
  ReloadComplaints = 'reload-complaints',
  ReloadObservations = 'reload-observations',
  ReloadDiagnosis = 'reload-diagnosis',
  ReloadMedications = 'reload-medications',
  ReloadMedicalRecords = 'reload-medical-records',
}
