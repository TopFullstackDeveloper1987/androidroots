export enum InvoiceEvents {
  ReloadInvoices = 'reload-invoices',
}
