export enum ProcedureEvents {
  ReloadProcedures = 'reload-procedures',
}
