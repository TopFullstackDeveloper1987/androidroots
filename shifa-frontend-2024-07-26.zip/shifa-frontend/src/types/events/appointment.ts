export enum AppointmentEvents {
  ReloadAppointments = 'reload-appointments',
  ShowAppointmentUpdateDialog = 'show-appointment-update-dialog',
}
