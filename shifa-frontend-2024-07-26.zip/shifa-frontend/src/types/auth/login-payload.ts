export interface ILoginPayload {
  facility_id: string;
  username: string;
  password: string;
}
