import { ICodeName, IScan, ILabOrderTest, IMedicationOrderItem } from '@/types';

export interface IEncounter {
  id: string;
  encounter_date: string;
  encounter_priority: ICodeName;
  encounter_status: ICodeName;
  encounter_type: ICodeName;
  facility: string;
  follow_up_required: boolean;
  created_by_user?: string;
  created_date?: string;
  deleted_by_user?: string | null;
  deleted_date?: string | null;
  soft_delete?: boolean;
  is_active?: boolean;
  notes: string;
  patient: string;
  practitioner: string;
  encounter_advice: IEncounterItem[];
  encounter_complaints: IEncounterItem[];
  encounter_diagnosis: IEncounterItem[];
  encounter_procedures: IEncounterItem[];
  encounter_observations: IEncounterItem[];
  encounter_followup: IEncounterFollowup[];
  imaging_orders: IEncounterImagingOrder[];
  lab_orders: IEncounterLabOrder[];
  medication_orders: IEncounterMedicationOrder[];
  medical_orders: IEncounterMedicationOrder[];
}

export interface IEncounterPayload {
  id: string;
  encounter_date: string;
  encounter_priority: String;
  encounter_status: String;
  encounter_type: String;
  facility: string;
  follow_up_required: boolean;
  created_by_user?: string;
  created_date?: string;
  deleted_by_user?: string | null;
  deleted_date?: string | null;
  soft_delete?: boolean;
  is_active?: boolean;
  notes: string;
  patient: string;
  practitioner: string;
  encounter_advice: IEncounterItem[];
  encounter_complaints: IEncounterItem[];
  encounter_diagnosis: IEncounterItem[];
  encounter_procedures: IEncounterItem[];
  encounter_observations: IEncounterItem[];
  encounter_followup: IEncounterFollowup[];
  imaging_orders: IEncounterImagingOrder[];
  lab_orders: IEncounterLabOrder[];
  medication_orders: IEncounterMedicationOrder[];
}

export interface IEncounterItem {
  encounter: string;
  id?: number;
  created_date?: string;
  is_active?: boolean;
  soft_delete?: boolean;
  deleted_date?: string;
  created_by_user?: string;
  deleted_by_user?: string;
  advice?: string;
  complaint?: string;
  diagnosis?: string;
  lab_order?: string;
  medication?: string;
  observation?: string;
  procedure?: string;
  priority?: string;
  severity?: number;
  hpi?: string;
  onset_date?: string;
  menu?: boolean;
}

export interface IEncounterUpdatePayloadItem {
  severity?: number;
  onset_date?: string;
  hpi?: string;
}

export interface IEncounterImagingOrder {
  created_by_user: string;
  created_date: string;
  deleted_by_user: string | null;
  deleted_date: string | null;
  encounter: string;
  facility: string;
  id: string;
  is_active: boolean;
  notes: string;
  order_number: string;
  patient: string;
  practitioner: string;
  priority: string;
  scans: IScan[];
  soft_delete: boolean;
  status: string;
}

export interface IEncounterLabOrder {
  created_by_user: string;
  created_date: string;
  deleted_by_user: string | null;
  deleted_date: string | null;
  encounter: string;
  facility: string;
  id: string;
  is_active: boolean;
  lab_order_items: ILabOrderTest[];
  lab_test_profile: number;
  notes: string;
  order_number: string;
  patient: string;
  practitioner: string;
  priority: string;
  soft_delete: boolean;
  status: string;
}

export interface IEncounterMedicationOrder {
  created_by_user: string;
  created_date: string;
  deleted_by_user: string | null;
  deleted_date: string | null;
  encounter: string;
  facility: string;
  id: string;
  is_active: boolean;
  medication_order_items: IMedicationOrderItem[];
  notes: string;
  order_number: string;
  patient: string;
  practitioner: string;
  status: string;
}

export interface IEncounterFollowup {
  id?: string;
  encounter: string;
  followup_note: string;
  followup_date: string;
}

export interface IEncounterCustomForm {
  encounter: string;
  form_json_data: any;
  form_json_schema: any[];
  id: number;
}
