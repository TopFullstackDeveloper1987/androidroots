import { ICodeName, IPaginationQuery, IProduct } from '@/types';

interface IOrderItem {
  product: number | null;
}

export interface IProcedureItemQuery {
  favored?: boolean;
  name?: string;
  page?: number;
}

export interface IProcedureItem extends IPaginationQuery {
  id: number;
  name: string;
  description: string;
  cpt_code: string;
  favored: boolean;
}

export interface IProcedurePayload {
  patient: string | null;
  practitioner: string | null;
  procedure_date: string | null;
  procedure_status: string | null;
  procedure_type: string | null;
  notes: string;
  procedure: number | null;
  order_items: IOrderItem[];
}

export interface IProcedureQuery extends IPaginationQuery {
  encounter_id?: string;
  from_date?: string;
  order_status?: string;
  order_type?: string;
  patient_id?: string;
  practitioner_id?: string;
  procedure_id?: string;
  procedure_order_id?: string;
  to_date?: string;
}

export interface IProcedure {
  created_date: string;
  encounter: string | null;
  facility: string;
  id: string;
  item_count: number;
  notes: string;
  order_number: string;
  order_items: IProcedureOrderItem[];
  patient: string;
  patient_name: string;
  practitioner: string;
  practitioner_name: string;
  priority: string;
  procedure: number;
  procedure_date: string;
  procedure_name: string;
  procedure_status: ICodeName;
  procedure_type: ICodeName;
}

export interface IProcedureDetails {
  created_by_user: string;
  created_date: string;
  deleted_by_user: string | null;
  deleted_date: string | null;
  encounter: string | null;
  facility: string;
  id: string;
  is_active: boolean;
  notes: string;
  order_items: IProcedureOrderItem[];
  order_number: string;
  outcome_result: string | null;
  patient: string;
  practitioner: string;
  procedure_date: string;
  procedure_status: string;
  procedure_type: string;
  soft_delete: boolean;
}

export interface IProcedureOrderItem {
  brand: string | null;
  id: number;
  code: string;
  name: string;
  procedure_order: string;
  product: IProduct;
}
