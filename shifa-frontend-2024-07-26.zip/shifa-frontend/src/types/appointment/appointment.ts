import { ContactMethod } from '../common';
import { IFacility } from '../facility';
import { IPatient } from '../patient';
import { IPractitioner } from '../practitioner';
import { AppointmentStatus } from './appointment-status';
import { QueueStatus } from './queue-status';

export interface IAppointment {
  id: string;
  created_date: string;
  is_active: boolean;
  soft_delete: boolean;
  deleted_date: string;
  contact_method: ContactMethod;
  currency: string;

  amount_paid: string;
  appointment_status: AppointmentStatus;
  queue_status: QueueStatus;
  appointment_date: string;
  duration_mins: number;
  appointment_number: number;
  appointment_purpose: string;
  notes: string;
  created_by_user: string;
  deleted_by_user: string;
  patient: IPatient;
  practitioner: IPractitioner;
  facility: IFacility;
}

export interface IPayAppointmentFeePayload {
  appointment: string;
  payment_method: string;
  currency: string;
  amount_paid: string;
  notes?: string;
}

export interface IAppointmentData {
  label?: string,
  data: number[],
  backgroundColor?: string,
  borderColor?: string,
  borderWidth?: number,
}

export interface ITotalChartData {
  labels: string[],
  datasets: IAppointmentData[],
}

export interface ITotalChartDataResponse {
  totalAppointments: ITotalChartData,
  totalAppointmentsByStatus: ITotalChartData,
  totalEncounters: ITotalChartData,
  totalEncountersByStatus: ITotalChartData,
  topEncounterComplaints: ITotalChartData,
  topEncounterDiagnosis: ITotalChartData,
  ageRange: ITotalChartData,
  cityBreakdown: ITotalChartData,
  genderBreakdown: ITotalChartData,
  registrationMethod: ITotalChartData,
  smokingBreakdown: ITotalChartData,

}

export interface IAppointmentSummary {
  label: string,
  data: number,
}
