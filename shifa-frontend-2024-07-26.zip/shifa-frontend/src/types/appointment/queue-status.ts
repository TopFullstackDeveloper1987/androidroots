export enum QueueStatus {
  New = 1,
  InProgress = 2,
  Done = 3,
}
