export enum AppointmentAction {
  Cancel = 'cancel',
  Confirm = 'confirm',
  Checkin = 'checkin',
  Checkout = 'checkout',
}
