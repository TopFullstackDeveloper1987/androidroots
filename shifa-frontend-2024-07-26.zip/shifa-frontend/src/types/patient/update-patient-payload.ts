export interface IUpdatePatientPayload {
  full_name: string;
  email: string;
  date_of_birth: string;
  years_or_months: string;
  age: string;
  phone_1: string;
  phone_1_country_code: string;
  viber: string;
  viber_country_code: string;
  whatsapp: string;
  whatsapp_country_code: string;
  gender: string;
  registration_method: number;
  registered_facility: string;
  smoking_status: string;
  address: string;
  ethnicity: string;
  religion: string;
  preferred_language: string;
  city: number;
}
