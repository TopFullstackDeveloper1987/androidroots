export interface IPatientDocument {
  id: string;
  file?: string;
  file_format?: string;
  file_name?: string;
  patient?: string;
  presigned_url?: string;
  description?: string;
  document_subtype?: string;
}

export interface IDocumentScanPayload {
  front_image: Blob;
  back_image: Blob;
}
