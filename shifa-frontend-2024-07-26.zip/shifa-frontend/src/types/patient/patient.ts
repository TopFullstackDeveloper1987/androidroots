import { ICity, ICodeName, IEthnicity, ILanguage, IReligion } from '../common';

export interface IPatient {
  id: string;
  address: string;
  city: ICity;
  date_of_birth: string;
  years_or_months: string;
  age: string;
  ethnicity: IEthnicity;
  full_name: string;
  first_name: string;
  last_name: string;
  patient_name?: string;
  gender: string;
  health_id: string | null;
  phone_1: string;
  phone_1_country_code: string;
  viber?: string;
  viber_country_code?: string;
  whatsapp?: string;
  whatsapp_country_code?: string;
  preferred_language: ILanguage;
  registration_method: number;
  religion: IReligion;
  smoking_status: ICodeName;
  email: string;
  picture?: string;
}
