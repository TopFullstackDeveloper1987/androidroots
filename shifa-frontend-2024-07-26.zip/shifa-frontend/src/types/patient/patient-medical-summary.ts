export interface IPatientMedicalSummary {
  encounter_status: string;
  encounter_date: Date;
  patient: string;
  facility: string;
  practitioner: string;
  encounter_complaints: string;
  encounter_observations: string;
  encounter_diagnosis: string;
  medical_orders: string;
}
