import { ICodeName, IPaginationQuery } from '@/types';

export interface ILabOrderQuery extends IPaginationQuery {
  encounter_id?: string;
  lab_order_id?: string;
  test_profile_id?: string;
  order_date?: string;
  from_date?: string;
  to_date?: string;
  order_status?: string;
  status?: string;
  patient_id?: string;
  practitioner_id?: string;
}

export interface ILabOrder {
  created_date: string;
  encounter: string;
  id: string;
  notes: string;
  order_number: string;
  patient: string;
  patient_name: string;
  practitioner: string;
  practitioner_name: string;
  priority: ICodeName;
  status: ICodeName;
  test_count: number;
  test_profile_id: number;
  test_profile_short_name: string;
}

export interface ILabOrderTest {
  id: number;
  lab_order: string;
  lab_test: ILabTest;
  notes: null | string;
  status: string;
  test_date: null | string;
  test_result: null | string;
}

export interface ILabTest {
  description: string;
  id: number;
  is_active: boolean;
  is_fasting_required: boolean;
  name: string;
  name_arabic: string;
  name_kurdish: string;
  name_short: string;
  patient_instructions: string;
  range: string;
  specimen_type: string;
  unit: string;
}

export interface ILabOrderPayload {
  encounter: string;
  patient: string;
  facility: string;
  notes: null | string;
  practitioner: string;
  lab_test_profile: number;
  lab_order_items: ILabOrderItemPayload[];
}

export interface ILabOrderItemPayload {
  lab_test: number;
}

export interface ILabTestProfileItem {
  id: number;
  lab_test: ILabTest;
  order_by: number;
  profile_id: number;
  profile_name: string;
  profile_name_short: string;
}
