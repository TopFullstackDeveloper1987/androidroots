import { ICodeName, IPaginationQuery } from '@/types';

export interface IMedicationOrderQuery extends IPaginationQuery {
  encounter_id?: string;
  medication_order_id?: string;
  medication?: string;
  from_date?: string;
  to_date?: string;
  status?: string;
  patient_id?: string;
  practitioner_id?: string;
}

export interface IMedicationOrder {
  created_date: string;
  encounter: string;
  id: string;
  item_count: number;
  notes: string;
  order_number: string;
  patient: string;
  patient_name: string;
  practitioner: string;
  practitioner_name: string;
  status: ICodeName;
}

export interface IMedicationOrderItem {
  id: number;
  medication: IMedication;
  medication_name?: string;
  status: string;
  notes?: string;
  is_dosage_field_focused?: boolean,
  instructions?: string;
}

export interface IMedicationOrderItemUpdatePayload {
  instructions?: string;
}

export interface IMedication {
  IQ_national_code: string;
  description: string;
  drug_category: string;
  drug_category_name?: string;
  drug_sub_category: string;
  drug_sub_category_name?: string;
  has_warning: boolean;
  id: number;
  name: string;
}

export interface IMedicationOrderPayload {
  encounter: string;
  practitioner: string;
  patient: string;
  medication_order_items: IMedicationOrderItemPayload[];
}

export interface IMedicationOrderItemPayload {
  medication: number;
  medication_name: string;
}
