import { ICodeName, IPaginationQuery } from '@/types';

export interface IImagingOrderQuery extends IPaginationQuery {
  encounter_id?: string;
  imaging_order_id?: string;
  modality?: string;
  order_date?: string;
  status?: string;
  patient_id?: string;
  practitioner_id?: string;
  from_date?: string;
  to_date?: string;
}

export interface IImagingOrder {
  created_date: string;
  encounter: string;
  id: string;
  modality: string;
  notes: string;
  order_number: string;
  patient: string;
  patient_name: string;
  practitioner: string;
  practitioner_name: string;
  priority: ICodeName;
  scan_count: number;
  status: ICodeName;
}

export interface IImagingOrderPayload {
  encounter: string;
  patient: string;
  facility: string;
  practitioner: string;
  scans: IScanPayload[];
}

export interface IScanPayload {
  scan_type: number;
  notes: string | null;
}

export interface IScan {
  id: number;
  scan_type: IScanType;
  notes: string | null;
  scan_date: string | null;
  status: string;
}

export interface IScanType {
  body_part: string;
  cpt_code: string | null;
  icd_10_code: string | null;
  id: number;
  is_active: string;
  modality: string;
  name: string;
  scan_category: string;
}
