export interface ICondition {
  id: number;
  name: string;
  code: string;
  category: string;
  description?: string;
  order_by: number;
  is_active: boolean;
}

export interface IAllergy {
  id: number;
  name: string;
  code: string;
  category: string;
  description?: string;
  is_active: boolean;
}

export interface IAlert {
  id?: number;
  name: string;
  code?: string;
  icon?: string;
  is_active?: boolean;
}

export interface IMeasure {
  id?: number;
  name: string;
  measure_type?: string;
  unit?: string;
  description?: string;
  is_active?: boolean;
  value?: string | number;
  date?: Date;
}

export interface IMetaDataAdviceQuery {
  facility?: string;
  name?: string;
  practitioner?: string;
}

export interface IMetaDataCodeQuery {
  code?: string;
  name: string;
  practitioner?: string;
  type?: string;
}

export interface IMetaDataMedicationOrderQuery {
  medication?: string;
}

export interface IMetaDataICDCode {
  icd_code: string;
  category_code: string;
  diagnosis_code: string;
  short_description: string;
  long_description: string;
  category_title: string;
  is_active: boolean;
}

export interface IMetaDataCity {
  id: number,
  country: string,
  name: string,
  name_arabic: string,
  name_kurdish: string,
}

export interface IMetaDataCountryCode {
  iso_code: string,
  country_code: string,
  name: string,
  name_arabic: string,
  name_kurdish: string,
  name_turkish: string;
  name_persian: string;
  is_active: true;
}

export interface IMetaDataCPTCode {
  cpt_code: string;
  category_code: string;
  diagnosis_code: string;
  description: string;
  long_description: string;
  category_title: string;
  is_active: boolean;
}

export interface IMetaDataChildGrowthPercentile {
  id: number;
  year: number;
  month: number;
  week: number;
  gender: string;
  metric: string;
  percentile_95th: string;
  percentile_75th: string;
  percentile_50th: string;
  percentile_25th: string;
  percentile_5th: string;
}

export interface IMetaDataChildGrowthPercentileQuery {
  gender: string;
  metric: string;
}

export interface IMetaDataTemplateDesigns {
  id: number;
  name: string;
}
