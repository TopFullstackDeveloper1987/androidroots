import { IPatientDetails, IPrescriptionItem } from './prescription';

export interface IMedicalReport {
  report_text: string,
}

export interface IComplaintItem {
  name: string;
  dosage: string;
}

export interface IDiagnosisItem {
  name: string;
  dosage: string;
}

export interface IMedicalReportPayload {
  patient_details: IPatientDetails,
  medications?: IPrescriptionItem[],
  complaints?: IComplaintItem[],
  diagnosis?: IDiagnosisItem[],
  additional_notes?: String,
}

export interface IMedicalReportPrintPayload {
  patient_details: IPatientDetails,
  report_data: string,
}
