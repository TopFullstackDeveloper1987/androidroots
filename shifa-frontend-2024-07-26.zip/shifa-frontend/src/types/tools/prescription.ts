export interface IPrescriptionItem {
  name: string;
  dosage: string;
}

export interface IPatientDetails {
  name: string,
  age: number,
  gender: string,
}

export interface IPrescriptionPrintPayload {
  patient_details: IPatientDetails,
  medications: IPrescriptionItem[],
}

export interface ITemplateDesignPayload {
  configuration: string,
  facility: string,
  entity: string,
  entity_id: string,
  entity_id_type: string,
  value: string | number,
  value_type: string,

}
