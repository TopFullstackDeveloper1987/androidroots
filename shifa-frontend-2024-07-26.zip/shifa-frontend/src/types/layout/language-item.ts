import { ISelect } from './select';

export interface ILanguageItem extends ISelect<string> {
  icon: string;
}
