export enum DialogType {
  Danger = 'danger',
  Warning = 'warning',
  Info = 'primary',
}
