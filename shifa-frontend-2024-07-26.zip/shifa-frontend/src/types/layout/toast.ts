export enum ToastType {
  Error = 'error',
  Warning = 'warning',
  Info = 'Info',
  Success = 'success',
}
