import { PageId } from '@/constants';

export interface ISideBarItemChild {
  pageId: PageId;
  name: string;
  path: string;
}
