export interface ISelect<T> {
  title: string;
  value: T;
}
