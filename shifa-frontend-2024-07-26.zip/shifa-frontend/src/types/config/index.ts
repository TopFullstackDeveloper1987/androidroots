import { ISpecialty } from '../common';

export interface IConfigList {
  group: string;
  is_active: boolean;
  name: string;
  name_display: string;
  sub_group: string;
}

export interface IConfig {
  group: string;
  sub_groups: IConfigSubGroup[];
}

export interface IConfigMeta {
  title: string;
  value: boolean;
  icon?: string;
}

export interface IConfigSubGroup {
  sub_group: string;
  items: IConfigItem[];
}

export interface IConfigItem {
  created_by_user: string;
  created_date: string;
  deleted_by_user: any;
  deleted_date: any;
  entity: string;
  entity_id: string;
  entity_id_type: string;
  facility: string;
  group: string;
  id: number;
  is_active: boolean;
  name: string;
  name_display: string;
  soft_delete: boolean;
  sub_group: string;
  value: string;
  value_type: string;
}

export interface IConfigListQuery {
  group?: string;
  sub_group?: string;
  name?: string;
  output_format?: string;
  entity?: string;
  entity_id?: string;
}

export interface IConfigQuery {
  entity?: string;
  entity_id?: string;
  name?: string;
  output_format?: string;
}

export interface IConfigPayload {
  configuration: string | null;
  entity: string | null;
  entity_id: string;
  entity_id_type: string | null;
  value: string;
  value_type: string | null;
}

export interface IConfigurationsResponse {
  configuration: string | null;
  entity: string | null;
  entity_id: string;
  entity_id_type: string | null;
  value: string;
  value_type: string | null;
}

export interface IConfiguration {
  name: string;
  name_display: string;
  icon?: string;
  group: string;
  sub_group: string;
  is_active: boolean;
  is_selected: boolean;
}

export interface IConfigByNames {
  id: number;
  configuration: IConfiguration;
  facility: string;
  entity: string;
  entity_id: string;
  entity_id_type: string;
  value: boolean | string;
  value_type: string;
}

export interface IDefaultAppointmentFeeValue {
  id: number;
  configuration: IConfiguration;
  facility: string;
  entity: string;
  entity_id: string;
  entity_id_type: string;
  value: string;
  value_type: string;
}

export enum CustomEncounterType {
  Complaint = 'complaint',
  Observation = 'observation',
  Diagnosis = 'diagnosis',
  Medication = 'medication',
  Procedure = 'procedure',
  Advice = 'advice',
}

export interface IDrugCategory {
  id: string;
  name: string;
}

export interface IDrugSubCategory {
  id: string;
  name: string;
}

export interface ICustomEncounter {
  id: number;
  name: string;
  favored: boolean;
  cpt_code?: string;
  icd_10_code?: string;
  short_description?: string;
  IQ_national_code?: string;
  category?: string;
  drug_category?: string;
  drug_category_name?: string;
  drug_sub_category?: string;
  drug_sub_category_name?: string;
  notes?: string;
  has_warning?: boolean;
  has_notes?: boolean;
}

export interface ICreateCustomEncounterPayload {
  id?: number;
  name: string;
  icd_10_code?: string;
  cpt_code?: string;
  help_url?: string;
}

export interface ICreateCustomMedicationPayload {
  name: string;
  drug_category: string;
  drug_sub_category: string;
  has_warning: boolean | undefined;
  notes: string;
  IQ_national_code: string | undefined;
}

export interface IUpdateCustomMedicationPayload {
  name: string;
  drug_category: string;
  drug_sub_category: string;
  has_warning: boolean | undefined;
  notes: string;
  IQ_national_code: string | undefined;
}

export interface ICustomForm {
  favored: boolean;
  form_json_schema: any[];
  form_type?: string;
  id: number;
  name: string;
  speciality?: ISpecialty;
}

export interface ICustomFormPayload {
  name: string;
  form_type?: string;
  speciality?: number;
  form_json_schema: any[];
}

export interface IProduct {
  brand: string;
  code: string;
  description: string;
  favored: boolean;
  id: number;
  name: string;
  name_arabic: string | null;
  name_kurdish: string | null;
}

export interface IProductPayload {
  name: string;
  code: string;
  brand: string;
  description: string;
}

export interface IService {
  id: number;
  name: string;
  currency: string;
  price: number;
  description: string;
}

export interface IServicePayload {
  name: string;
  currency: string;
  price: number;
  description: string;
}
