<template>
  <div class="container">
    <div class="d-flex justify-space-between pb-3 tab-filters-wrapper">
      <div class="my-1">
        <toggle-btn v-model="tab" :buttons="ToggleBtns" />
      </div>
      <div class="d-flex justify-end my-1 filters">
        <toggle-btn v-model="groupBy" :buttons="groupByBtns" />
        <date-range-picker v-model="dateRange" class="pl-2" />
      </div>
    </div>


    <card-container v-if="tab === 1 && !loading" :title="authStore.userInfo.practitioner_name" class="w-100">
      <analytics-summary :summary-data="totalDataSummary" />
      <analytics-charts
        :loading="loading"
        :total-bar-chart="totalData"
        :total-doughnut-chart="totalData"
        :total-by-status-bar-chart="totalDataByStatus"
        :total-by-status-line-chart="totalDataByStatus"
      />
    </card-container>


    <card-container v-if="tab === 2 && !loading" :title="authStore.userInfo.practitioner_name" class="w-100">
      <analytics-summary :summary-data="totalDataSummary" />
      <analytics-charts
        :loading="loading"
        :total-bar-chart="totalData"
        :total-doughnut-chart="totalData"
        :total-by-status-bar-chart="totalDataByStatus"
        :total-by-status-line-chart="totalDataByStatus"
      />
      <div class="d-flex flex-column horizontal-bar-charts-wrapper">
        <horizontal-bar-chart :total-bar-chart-data="topComplaintData" title="Top Complaints" class="horizontal-bar-chart" />
        <horizontal-bar-chart :total-bar-chart-data="topDiagnosisData" title="Top Diagnosis" class="horizontal-bar-chart"/>
      </div>
    </card-container>

    <card-container v-else-if="tab === 3 && !loading" :title="authStore.userInfo.practitioner_name" class="w-100">
      <admin-dashboard hide-date-filter />
    </card-container>

    <card-container v-if="tab === 4 && !loading" :title="authStore.userInfo.practitioner_name" class="w-100">
      <div class="d-flex align-center justify-space-around flex-wrap py-4">
        <div class="d-flex flex-column align-center">
          <h6>Age Range</h6>
          <doughnut-chart
            :chart-data="ageRangeData"
            :height="300"
          />
        </div>
        <div class="d-flex flex-column align-center">
          <h6>Smoking Breakdown</h6>
          <doughnut-chart
            :chart-data="smokingBreakdownData"
            :height="300"
          />
        </div>
      </div>
      <div class="d-flex align-center justify-space-around py-4">
        <div class="d-flex flex-column align-center">
          <h6>Gender Breakdown</h6>
          <doughnut-chart
            :chart-data="genderBreakdownData"
            :height="300"
          />
        </div>
        <div class="d-flex flex-column align-center">
          <h6>Registration Methods</h6>
          <doughnut-chart
            :chart-data="registrationMethodData"
            :height="300"
          />
        </div>
      </div>
      <horizontal-bar-chart :total-bar-chart-data="cityBreakdownData" class="horizontal-bar-chart"/>
    </card-container>
   </div>
</template>

<script lang="ts" setup>
import { useAuthStore, useAppointmentStore, useEncounterStore, usePatientRecordStore } from '@/store';
import AnalyticsSummary from '@/components/reports/analytics/AnalyticsSummary.vue';
import AnalyticsCharts from '@/components/reports/analytics/AnalyticsCharts.vue';
import HorizontalBarChart from '@/components/reports/analytics/HorizontalBarChart.vue';
import DoughnutChart from '@/components/charts/DoughnutChart.vue';
import AdminDashboard from '@/views/bed-management/AdminDashboard.vue';
import ToggleBtn from '@/components/inputs/ToggleBtn.vue';
import { onMounted, ref, watch } from 'vue';
import { useI18n } from 'vue-i18n';
import moment from 'moment';
import { forEach } from 'lodash';
import debounce from 'lodash/debounce';
import { IAppointmentSummary } from '@/types';
import { Moment } from 'moment-timezone';

const { t } = useI18n();

const appointmentStore = useAppointmentStore();
const encounterStore = useEncounterStore();
const patientRecordStore = usePatientRecordStore();

const totalData = ref();
const totalDataByStatus = ref();
const totalDataSummary = ref<IAppointmentSummary[]>([]);

const topComplaintData = ref();
const topDiagnosisData = ref();

const genderBreakdownData = ref();
const ageRangeData = ref();
const cityBreakdownData = ref();
const registrationMethodData = ref();
const smokingBreakdownData = ref();

const loading = ref<boolean>(true);

const ToggleBtns = ref<string[]>(['Overview', t('appointments.appointment'), t('common.encounter'), t('bed_management.bed'), t('common.patient')]);
const groupByBtns = ref<string[]>([t('common.day'), t('common.week'), t('common.year')]);
const groupByValue = ['day', 'week', 'year'];

const authStore = useAuthStore();

const tab = ref(0);
const groupBy = ref(0);

const aMonthAgo = new Date();
aMonthAgo.setDate(-30);

const dateRange = ref<Moment[]>([moment(aMonthAgo), moment(new Date())]);

watch(() => dateRange.value, () => {
  loading.value = true;
  getAppointmentsReport();
});

watch(() => groupBy.value, () => {
  loading.value = true;
  getAppointmentsReport();
});

watch(() => tab.value, () => {
  loading.value = true;
  getAppointmentsReport();
});

const getAppointmentsReport = debounce(async () => {
  loading.value = true;

  let res = null;

  if(tab.value === 1) {

    res = await appointmentStore.getAppointmentsReport(groupByValue[groupBy.value], moment(dateRange.value[0]).format('YYYY-MM-DD'), moment(dateRange.value[1]).format('YYYY-MM-DD'));
    res.totalAppointments.datasets[0].label = 'Total Appointments';

    totalData.value = res.totalAppointments;
    totalDataByStatus.value = res.totalAppointmentsByStatus;

  } else if(tab.value === 2) {

    res = await encounterStore.getEncountersReport(groupByValue[groupBy.value], moment(dateRange.value[0]).format('YYYY-MM-DD'), moment(dateRange.value[1]).format('YYYY-MM-DD'));
    res.totalEncounters.datasets[0].label = 'Total Encounters';

    totalData.value = res.totalEncounters;
    totalDataByStatus.value = res.totalEncountersByStatus;

    const { topEncounterComplaints } = await encounterStore.getTopComplaintData(groupByValue[groupBy.value], moment(dateRange.value[0]).format('YYYY-MM-DD'), moment(dateRange.value[1]).format('YYYY-MM-DD'));
    const { topEncounterDiagnosis } = await encounterStore.getTopDiagnosisData(groupByValue[groupBy.value], moment(dateRange.value[0]).format('YYYY-MM-DD'), moment(dateRange.value[1]).format('YYYY-MM-DD'));


    topComplaintData.value = topEncounterComplaints;
    topDiagnosisData.value = topEncounterDiagnosis;

  } else if(tab.value === 4) {
    const { ageRange, genderBreakdown, cityBreakdown, registrationMethod, smokingBreakdown } =  await patientRecordStore.getPatientReportByGender(groupByValue[groupBy.value], moment(dateRange.value[0]).format('YYYY-MM-DD'), moment(dateRange.value[1]).format('YYYY-MM-DD'));

    ageRangeData.value = ageRange;
    genderBreakdownData.value = genderBreakdown;

    cityBreakdown.datasets[0].label = 'City Breakdown';
    cityBreakdownData.value = cityBreakdown;

    registrationMethodData.value = registrationMethod;
    smokingBreakdownData.value = smokingBreakdown;
  }

  if(tab.value === 1 || tab.value === 2) {
    totalDataSummary.value = [];
    forEach(totalData.value.labels, (val: string, index: number) => {
      totalDataSummary.value?.push({
        label: val,
        data: totalData.value.datasets[0].data[index],
      });
    });
  }

  loading.value = false;
}, 750);

onMounted(() => {
  getAppointmentsReport();
});
</script>
<style lang="scss" scoped>
.container {
  width: -webkit-fill-available;
    @media (max-width: 1415px) {
    .tab-filters-wrapper {
      flex-wrap: wrap;
      .filters {
        width: 100%;
      }
    }
  }
}
</style>
