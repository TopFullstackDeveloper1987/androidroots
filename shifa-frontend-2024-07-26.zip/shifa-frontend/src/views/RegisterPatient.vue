<template>
  <patient-profile-form />
</template>

<script lang="ts" setup>
import PatientProfileForm from '@/components/forms/PatientProfileForm.vue';
</script>
