<template>
<div class="container">
  <div class="d-flex justify-end" v-if="!hideDateFilter"><date-range-picker class="align-start" /></div>
  <v-divider class="my-8" v-if="!hideDateFilter"></v-divider>
  <v-row>
    <v-col class="doughnut-chart"><doughnut-chart v-if="!loading" :statistics="statistics" /></v-col>
    <v-col class="line-chart"><line-chart :chart-data="data" :chart-options="options" /></v-col>
  </v-row>
  <v-row>
    <v-col v-for="(ward, i) in bedAnalytics?.wards" :key="i" lg="4" md="4" sm="6" xs="12">
      <statistics-card
         :ward="ward"
      />
    </v-col>
  </v-row>
</div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue';
import DoughnutChart from '@/components/bed-management/DoughnutChart.vue';
import LineChart from '@/components/charts/LineChart.vue';
import StatisticsCard from '@/components/bed-management/StatisticsCard.vue';
import { useBedAvailabilityStore } from '@/store';
import { IBedAnalytics, IBedStatus, IDoughnutDataType } from '@/types';
import { BED_STATUS_CHOICES } from '@/constants';

const props = defineProps({
  hideDateFilter: {
    type: Boolean,
    default: false,
  },
});

const bedAvailabilityStore = useBedAvailabilityStore();

const bedAnalytics = ref<IBedAnalytics>();
const doughnutData = ref<number[]>([]);
const loading = ref<boolean>(true);
const statistics = ref<IDoughnutDataType>(null!);

const data = ref({
  labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
  datasets: [
    {
      label: 'New Admissions',
      backgroundColor: '#f87979',
      data: [40, 39, 10, 40, 39, 80, 40],
    },
  ],
});
const options = ref({
  responsive: true,
  maintainAspectRatio: false,
});

const getBedStatusByWard = async () => {
  loading.value = true;
  bedAnalytics.value = await bedAvailabilityStore.getBedStatusByWard();

  doughnutData.value = [];
  bedAnalytics.value.summary.forEach((val: IBedStatus) => {
    doughnutData.value?.push(val.bed_count);
  });

  statistics.value =
 {
   labels: [BED_STATUS_CHOICES.available, BED_STATUS_CHOICES.needs_cleaning, BED_STATUS_CHOICES.not_in_use, BED_STATUS_CHOICES.occupied],
   datasets: [
     {
       backgroundColor: ['#4CAF50', '#ff9800', '#2196F3', '#F44336'],
       data: doughnutData.value,
     },
   ],
 };

  loading.value = false;
};

onMounted(() => {
  getBedStatusByWard();
});
</script>

<style lang="scss" scoped>
.container {
  height: 100%;
  width: 100%;
}

.doughnut-chart {
  max-width: 30%;
}

.line-chart {
  max-width: 70%;
}
</style>
