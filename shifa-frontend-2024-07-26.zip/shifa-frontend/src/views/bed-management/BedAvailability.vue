<template>
  <div class="container px-8">
    <div class="d-flex justify-space-between w-full">
      <v-chip-group
          v-model="bedStatusFilter"
          class="text-primary pt-0"
          selected-class="bg-primary text-white"
        >
          <v-chip
            v-for="(bedStatus, i) in BedStatusMock"
            :key="i"
            variant="outlined"
            size="large"
            :value="bedStatus.value"
          >
            {{ bedStatus.title }}
          </v-chip>
        </v-chip-group>
        <v-row align="center" justify="end">
          <btn icon="$grid-view" :primary="false" icon-only :variant="toggle === 0 ? 'tonal' : 'text'" @click="toggle = 0"/>
          <btn icon="$list-view" :primary="false" icon-only :variant="toggle === 1 ? 'tonal' : 'text'" @click="toggle = 1"/>
        </v-row>
      </div>
    <v-divider class="my-8"></v-divider>
    <template v-for="(w, index) in wards" :key="index">
      <expansion-panel v-model="panels[index]" class="panels my-3" :title="w.name" >
        <template #actions>
          <btn icon="mdi-plus" :iconBefore="true" primary @click.stop="addBed(w.id)">
          {{ $t('bed_management.bed') }}
          </btn>
        </template>
        <template #content>
          <div v-if="toggle === 0" class="d-flex flex-wrap bed-cards-wrapper">
            <template v-for="(bed, i) in w.beds" :key="i">
              <bed-card :room-number="bed.bed_number" :room-type="bed.bed_type" :room-status="bed.bed_status" @update="updateBed(bed, bed.ward, bed.floor)" @remove="showDeleteBedDialog(bed.id)" />
            </template>
          </div>
          <template v-else>
            <v-table>
              <thead>
                <tr>
                  <th class="text-left">
                    #
                  </th>
                  <th class="text-left">
                    {{ $t('bed_management.bed_number') }}
                  </th>
                  <th class="text-left">
                    {{ $t('bed_management.bed_type') }}
                  </th>
                  <th class="text-left">
                    {{ $t('bed_management.bed_status') }}
                  </th>
                  <th class="text-left">
                    {{ $t('common.actions') }}
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr
                  v-for="(bed, index) in w.beds"
                  :key="index"
                >
                  <td>{{ index }}</td>
                  <td> {{ bed.bed_number }}</td>
                  <td class="text-capitalize">
                    {{ bed.bed_type === BedType.Single ? $t('bed_management.single') : $t('bed_management.double') }}
                    <v-icon v-for="i in (bed.bed_type === 'single' ? 1 : 2)" :key="i" size="25" color="primary">mdi-bed-king</v-icon>
                  </td>
                  <td>
                    <v-chip
                      variant="outlined"
                      size="small"
                      :color="getStatusColor(bed.bed_status)"
                    >
                      {{ BED_STATUS_CHOICES[bed.bed_status] }}
                    </v-chip>
                  </td>
                  <td>
                    <v-menu :close-on-content-click="false" :nudge-right="40" transition="scale-transition" offset-y>
                      <template v-slot:activator="{ props }">
                        <v-btn v-bind="props" variant="text" rounded class="menu-btn">
                          <v-icon>mdi-dots-vertical</v-icon>
                        </v-btn>
                      </template>
                      <v-list>
                        <v-list-item @click="updateBed(bed, bed.ward, bed.floor)">
                          <v-list-item-title>{{ $t('common.edit') }}</v-list-item-title>
                        </v-list-item>
                        <v-list-item v-for="(item, index) in menuOptions" :key="index" @click="handleMenuClick(item)">
                          <v-list-item-title>{{ item }}</v-list-item-title>
                        </v-list-item>
                        <v-list-item @click="showDeleteBedDialog(bed.id)">
                          <v-list-item-title>{{ $t('common.delete') }}</v-list-item-title>
                        </v-list-item>
                      </v-list>
                    </v-menu>
                  </td>
                </tr>
              </tbody>
            </v-table>
          </template>
        </template>
      </expansion-panel>
    </template>
    <add-edit-bed-dialog
      v-model="showDialog"
      :is-create-action="isCreateAction"
      :ward="currentWard"
      :floor="currentFloor"
      :bed="currentBed"
      @refresh="getBeds"
    />
    <BaseConfirmationDialog
      v-model="showDeleteDialog"
      :message="$t('common.are_you_sure_you_want_to_delete_this')"
      @submit="removeBed"
      :type="DialogType.Warning"
      color="warning"
    />
  </div>
</template>

<script lang="ts" setup>
import BedCard from '@/components/bed-management/BedCard.vue';
import AddEditBedDialog from '@/components/bed-management/AddEditBedDialog.vue';
import BaseConfirmationDialog from '@/components/common/BaseConfirmationDialog.vue';
import { useBedAvailabilityStore, useCommonStore } from '@/store';
import { IBed, IWard, ToastType, DialogType, BedType } from '@/types';
import { BED_STATUS_CHOICES, BedStatusMock } from '@/constants';
import { onMounted, ref, Ref, watch } from 'vue';
import { useI18n } from 'vue-i18n';

const { t } = useI18n();

const panels: Ref<number[]> = ref([0]);
const toggle: Ref<number> = ref(0);
const menuOptions: Ref<string[]> = ref(['Admit', 'Transfer', 'Discharge']);
const wards: Ref<IWard[]> = ref([]);
const currentWard = ref<number>();
const currentFloor: Ref<number> = ref(null!);
const currentBedId = ref<number>();
const currentBed: Ref<IBed> = ref(null!);
const bedStatusFilter = ref<string>();
const showDialog: Ref<boolean> = ref(false);
const showDeleteDialog: Ref<boolean> = ref(false);
const isCreateAction: Ref<boolean> = ref(true);

const bedAvailabilityStore = useBedAvailabilityStore();
const commonStore = useCommonStore();

const handleMenuClick = (option: any) => {
  // Handle menu option click here
  console.log('Clicked:', option);
};

const addBed = (ward: number) => {
  currentWard.value = ward;
  currentFloor.value = null!;
  isCreateAction.value = true;
  showDialog.value = true;
};

const updateBed = (bed: IBed, ward: number, floor: number) => {
  currentWard.value = ward;
  currentFloor.value = floor;
  currentBed.value = bed;
  isCreateAction.value = false;
  showDialog.value = true;
};

const getBeds = async () => {
  wards.value = await bedAvailabilityStore.getBeds({
    status: bedStatusFilter.value,
  });
};

const removeBed = async () => {
  await bedAvailabilityStore.removeBed(currentBedId.value!);
  commonStore.showToast(ToastType.Success, t('bed_management.bed_removed'));
  getBeds();
};

const showDeleteBedDialog = (id?: number) => {
  currentBedId.value = id;
  showDeleteDialog.value = true;
};

const getStatusColor = (status: string) => {
  if (!status) return;
  if (status === 'occupied') return 'red';
  else if (status === 'available') return 'green';
  else if (status === 'needs_cleaning') return 'blue';
  else if (status === 'not_in_use') return 'orange';
  else return '';
};

watch(() => bedStatusFilter.value, () => {
  getBeds();
});

onMounted(() => {
  getBeds();
});
</script>

<style lang="scss" scoped>
.container {
  height: 100%;
  width: 100%;

  .bed-cards-wrapper {
    gap: 6px
  }
}

.panels {
  width: 100%;
}
</style>
