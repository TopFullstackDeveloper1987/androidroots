<template>
  <patient-measures-table />
</template>

<script lang="ts" setup>
import { onBeforeMount } from 'vue';
import { useRouter, useRoute } from 'vue-router';

import { usePatientStore } from '@/store';
import PatientMeasuresTable from '@/components/patients/patient-measures/PatientMeasuresTable.vue';

const router = useRouter();
const route = useRoute();

const patientStore = usePatientStore();

onBeforeMount(async () => {
  const patientId = route.params.patientId;
  if (patientId !== patientStore.currentPatientId) {
    // TODO: fetch patient if the user puts patientId in the url manually
    router.push('/dashboard');
    return;
  }
});
</script>
