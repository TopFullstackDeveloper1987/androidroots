<template>
  <div>
    <div v-if="!hideVitalsPanel" class="vitals d-flex flex-wrap">
      <mini-card
        v-for="(card, index) in cards"
        :key="index"
        width="200"
        :icon="card.icon"
        :title="card.title"
        :text="card.text"
        class="mr-3 mb-3"
      />
    </div>

    <personal-information class="mb-3" v-if="!!patientStore.currentPatientId" />
    <upload-documents class="mb-3" v-if="!!patientStore.currentPatientId" />
    <template v-if="!isReceptionist">
      <medical-summary class="mb-3" />
      <appointments class="mb-3" />
      <Procedures class="mb-3" />
    </template>
  </div>
</template>

<script lang="ts" setup>
import { computed, onBeforeMount, onMounted, ref } from 'vue';
import { useRouter, useRoute } from 'vue-router';

import MiniCard from '@/components/common/MiniCard.vue';
import MedicalSummary from '@/components/patients/patient-profile/MedicalSummary.vue';
import PersonalInformation from '@/components/patients/patient-profile/PersonalInformation.vue';
import UploadDocuments from '@/components/patients/patient-profile/UploadDocuments.vue';
import Appointments from '@/components/patients/patient-profile/Appointments.vue';
import Procedures from '@/components/patients/patient-profile/Procedures.vue';
import { usePatientStore, useDefaultSettingsStore, useAuthStore } from '@/store';
import { IConfig, IConfigurationsResponse, UserRole } from '@/types';
import { LocalStorageService } from '@/services';
import { forEach } from 'lodash';

const router = useRouter();
const route = useRoute();

const patientStore = usePatientStore();
const defaultSettingsStore = useDefaultSettingsStore();
const authStore = useAuthStore();

const currentUserRole =
    LocalStorageService.getInstance().getUserRole();

const isReceptionist = computed(() => currentUserRole === UserRole.Receptionist);
const configurations = ref<IConfigurationsResponse[]>();
const hideVitalsPanel = ref<boolean>(false);


const cards = [
  { icon: 'heart-beat', title: 'Heart Rate', text: '120bpm' },
  { icon: 'blood-pressure', title: 'Blood Pressure', text: '128 /30 mm' },
  { icon: 'temperature', title: 'Temperature', text: '38.1C' },
  { icon: 'bmi', title: 'BMI', text: '58kg/144cm' },
  { icon: 'bar-chart', title: 'Glucose level', text: '1230 ml' },
];

onBeforeMount(async () => {
  const patientId = route.params.patientId;
  if (patientId !== patientStore.currentPatientId) {
    // TODO: fetch patient if the user puts patientId in the url manually
    router.push('/dashboard');
    return;
  }
});

onMounted(async () => {
  configurations.value = await defaultSettingsStore.getVitalPanelConfig({
    name: 'hide_vitals_panel',
    entity: 'user',
    entity_id: authStore.userInfo.id,
    output_format: 'list',
  });

  forEach(configurations.value, config => {
    if(config.configuration === 'hide_vitals_panel') {
      hideVitalsPanel.value = config.value === 'true' ? true : false;
    }
  });
});
</script>

<style lang="scss" scoped>
.vitals {
  @media (max-width: 500px) {
    display: none !important;
  }
}
</style>
