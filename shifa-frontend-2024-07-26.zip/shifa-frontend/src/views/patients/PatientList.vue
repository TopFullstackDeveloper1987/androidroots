<template>
  <patient-list-table />
</template>

<script lang="ts" setup>
import PatientListTable from '@/components/patients/patient-list/PatientListTable.vue';
</script>
