<template>
  <div class="d-flex flex-column fill-height w-100">
    <invoices-top-bar
      v-model:dates="dates"
      :statuses="statuses"
      v-model:status="status"
      :practitioners="practitioners"
      v-model:invoice-id="invoiceId"
      v-model:practitioner-id="practitionerId"
      @new-invoice="isShowInvoiceDialog = true"
    />

    <invoices-table
      :dates="dates"
      :status="status"
      :invoiceId="invoiceId"
      :practitioner-id="practitionerId"
      @open-payment-dialog="openPaymentDialog"
    />
  </div>

  <invoice-dialog v-model="isShowInvoiceDialog" />
  <payment-dialog
    v-if="selectedInvoice"
    v-model="isShowPaymentDialog"
    :invoice="selectedInvoice!"
  />
</template>

<script lang="ts" setup>
import { onMounted, ref, computed, ComputedRef } from 'vue';
import InvoicesTopBar from '@/components/billing/invoices/InvoicesTopBar.vue';
import InvoicesTable from '@/components/billing/invoices/InvoicesTable.vue';
import InvoiceDialog from '@/components/billing/invoices/InvoiceDialog.vue';
import PaymentDialog from '@/components/billing/invoices/PaymentDialog.vue';
import { useFacilityStore, usePractitionerSearchStore } from '@/store';
import { IInvoice, IPractitioner, ISelect } from '@/types';
import { invoiceStatusesMock } from '@/constants';

const facilityStore = useFacilityStore();
const practitionerSearchStore = usePractitionerSearchStore();

const status = ref<string>();
const dates = ref<Date[]>([]);
const invoiceId = ref<string>('');
const practitionerId = ref<string>();
const isShowInvoiceDialog = ref(false);

const isShowPaymentDialog = ref(false);
const selectedInvoice = ref<IInvoice>();

const statuses = ref<ISelect<string | null>[]>(invoiceStatusesMock);

const practitioners: ComputedRef<IPractitioner[]> = computed(() => {
  return [
    {
      id: null,
      first_name: 'All',
      last_name: '',
    } as unknown as IPractitioner,
    ...practitionerSearchStore.practitioners,
  ];
});

onMounted(async () => {
  await loadPractitioners();
});

const loadPractitioners = async () => {
  await practitionerSearchStore.searchPractitioners({
    fuuid: facilityStore.currentFacilityId!,
  });
};

const openPaymentDialog = async (invoice: IInvoice) => {
  selectedInvoice.value = invoice;
  isShowPaymentDialog.value = true;
};
</script>
