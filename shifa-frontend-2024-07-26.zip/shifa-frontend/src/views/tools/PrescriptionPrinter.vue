<template>
  <v-card
    :class="`parent-card ${$vuetify.display.xs ? 'pa-4 pt-16' : 'pa-16'}`"
  >
    <Loader v-if="loading" />
    <v-form
      v-else
      v-model="isValidForm"
      @submit.prevent="printPrescription"
      class="login-form d-flex flex-column"
    >
      <div class="card-tag bg-primary d-flex align-center justify-center">
        Prescription
      </div>
      <v-row class="align-items-center justify-center mt-2">
        <v-col class="pt-0">
          <p class="font-weight-bold text-h5">
            {{ practitioner?.full_name }}
          </p>
          <p class="text-subtitle-1">{{ practitioner?.qualification }}</p>
        </v-col>
      </v-row>
      <v-divider class="my-6"></v-divider>
      <v-row>
        <v-col cols="12" sm="6" md="6" class="py-2">
          <text-field
            v-model="formData.patient_details.name"
            :rules="[required]"
            :label="$t('common.name')"
            attr="name"
          />
        </v-col>
        <v-col cols="12" sm="6" md="2" class="py-2">
          <text-field
            v-model="formData.patient_details.age"
            :rules="[required, onlyNumber]"
            :label="$t('common.age')"
            attr="age"
          />
        </v-col>
        <v-col cols="12" sm="12" md="4" class="py-2">
          <v-radio-group
            v-model="formData.patient_details.gender"
            inline
            hide-details
          >
            <v-radio
              v-for="(gender, idx) in gendersMock"
              :key="idx"
              :label="gender.title"
              :value="gender.value"
              color="primary"
            ></v-radio>
          </v-radio-group>
        </v-col>
      </v-row>
      <v-divider class="my-6"></v-divider>
      <data-table-server
        :items="formData?.medications"
        :headers="headers"
        no-gutters
        class="prescription-printer-table"
        :show-search-results-info="false"
        :show-pagination="false"
      >
        <template v-slot:item="{ item, index }">
          <tr>
            <td>
              {{ index }}
            </td>
            <template v-if="!$vuetify.display.xs">
              <td>
                <medication-api-combo-box
                  :label="$t('prescription.medication')"
                  v-model="formData.medications[index].name"
                  :rules="[required]"
                  class="medication-combobox py-3"
                />
              </td>
              <td>
                <text-field
                  :label="$t('prescription.dosage_instructions')"
                  v-model="formData.medications[index].dosage"
                  :rules="[required]"
                  class="medication-dosage py-3"
                />
              </td>
            </template>

            <td v-if="$vuetify.display.xs">
              <medication-api-combo-box
                :label="$t('prescription.medication')"
                v-model="formData.medications[index].name"
                :rules="[required]"
                class="medication-combobox py-1"
              />

              <text-field
                :label="$t('prescription.dosage_instructions')"
                v-model="formData.medications[index].dosage"
                :rules="[required]"
                class="medication-dosage py-1"
              />
            </td>
            <td class="text-end">
              <btn
                :primary="false"
                icon="mdi-delete"
                icon-only
                variant="text"
                size="x-small"
                icon-size="default"
                @click="deleteItemRow(index)"
              />
            </td>
          </tr>
        </template>
      </data-table-server>
      <btn
        icon="mdi-plus"
        icon-only
        variant="text"
        size="x-small"
        icon-size="default"
        @click="addItemRow"
      />
      <v-divider class="my-6"></v-divider>
      <text-area :label="$t('common.notes')" :rows="2" />
      <v-divider class="my-6"></v-divider>
      <v-row justify="end">
        <select-field
          v-model="currentTemplateDesign"
          :items="templateDesigns"
          class="mx-2 my-1 template-designs-select"
          itemTitle="name"
          :returnObject="true"
          :rules="[required]"
        />
        <btn class="print-btn my-1" type="submit">{{ $t('common.print') }}</btn>
      </v-row>
    </v-form>

    <iframe
      id="print-contents-iframe"
      width="100%"
      height="0px"
      frameborder="0"
      style="display: none"
    >
    </iframe>
  </v-card>
</template>

<script lang="ts" setup>
import { useDisplay } from 'vuetify';
import DataTableServer from '@/components/common/DataTableServer.vue';
import MedicationApiComboBox from '@/components/tools/MedicationApiComboBox.vue';
import { gendersMock } from '@/constants';
import { required, onlyNumber } from '@/utils/validations';
import { onMounted, reactive, ref, watch } from 'vue';
import {
  IPractitioner,
  IPrescriptionItem,
  IPatientDetails,
  IConfig,
  IMetaDataTemplateDesigns,
} from '@/types';
import { useI18n } from 'vue-i18n';
import {
  useMedicalToolsStore,
  useMetaDataStore,
  useDefaultSettingsStore,
  useAuthStore,
  useFacilityStore,
} from '@/store';
import { computed } from 'vue';
import { forEach } from 'lodash';

const medicalToolsStore = useMedicalToolsStore();
const metaDataStore = useMetaDataStore();
const defaultSettingsStore = useDefaultSettingsStore();
const authStore = useAuthStore();
const facilityStore = useFacilityStore();

const formData = reactive<{
  patient_details: IPatientDetails;
  medications: IPrescriptionItem[];
}>({
  patient_details: {
    name: '',
    age: null!,
    gender: 'M',
  },
  medications: [],
});

const practitioner = ref<IPractitioner>();
const prescription = ref();
const isValidForm = ref(false);
const loading = ref(false);
const templateDesigns = ref<IMetaDataTemplateDesigns[]>([]);
const defaultTempateDesign = ref<IConfig[]>([]);
const currentTemplateDesign = ref<IMetaDataTemplateDesigns>();

const display = useDisplay();
const { t } = useI18n();

const headers = computed(() => [
  {
    title: '#',
    key: 'id',
    sortable: false,
  },
  ...(display.xs.value
    ? [
      {
        title: `${t('common.name')} / ${t('common.dosage')}`,
        key: 'name',
        sortable: false,
        width: '95%',
      },
    ]
    : [
      {
        title: t('common.name'),
        key: 'name',
        sortable: false,
        width: '45%',
      },
      {
        title: t('common.dosage'),
        key: 'dosage',
        sortable: false,
        width: '45%',
      },
    ]),
  {
    title: '',
    key: 'action',
    sortable: false,
  },
]);

const addItemRow = () => {
  formData.medications.push({
    name: '',
    dosage: '',
  });
};

const deleteItemRow = (index: number) => {
  formData.medications.splice(index, 1);
};

const getPractitionerDetails = async () => {
  loading.value = true;

  try {
    practitioner.value = await medicalToolsStore.getPractitionerDetails();
  } finally {
    loading.value = false;
  }
};

const setDefaultTemplateDesign = () => {
  defaultSettingsStore.setDefaultTemplateDesign({
    configuration: 'default_template_design',
    facility: facilityStore.currentFacilityId!,
    entity: 'practitioner',
    entity_id: authStore.userInfo.practitioner_id!,
    entity_id_type: 'uuid',
    value: currentTemplateDesign.value?.id!,
    value_type: 'int',
  });
};

const getDefaultTemplateDesign = async () => {
  templateDesigns.value = await metaDataStore.getMetaData('template-design/');
  defaultTempateDesign.value =
    await defaultSettingsStore.getDefaultTemplateDesign(
      authStore.userInfo.practitioner_id as string,
    );

  let id: string | number | null = null;

  forEach(defaultTempateDesign.value, (val) => {
    if (val.group === 'Default Settings') {
      forEach(val.sub_groups, (subGroups) => {
        if (subGroups.sub_group === 'UI Preference') {
          forEach(subGroups.items, (item) => {
            if (item.name === 'default_template_design') {
              if (item.value_type !== 'string') {
                id = Number(item.value);
              } else {
                id = item.value;
              }

              forEach(templateDesigns.value, (val) => {
                if (val.id === id) {
                  currentTemplateDesign.value = val;
                }
              });
            }
          });
        }
      });
    }
  });
};

const printPrescription = async () => {
  if (!isValidForm.value) {
    return;
  }

  loading.value = true;
  prescription.value = await medicalToolsStore.printPrescription(
    formData,
    currentTemplateDesign.value?.id!,
  );

  const iframe = document.getElementById(
    'print-contents-iframe',
  ) as HTMLIFrameElement;

  if (iframe) {
    iframe.style.display = 'block'; // Show the iframe for printing
    iframe.contentDocument!.open();
    iframe.contentDocument!.write(prescription.value);
    iframe.contentDocument!.close();

    iframe.onload = function () {
      iframe.contentWindow?.print();
      iframe.style.display = 'none'; // Hide the iframe again
    };
  }

  loading.value = false;
};

onMounted(async () => {
  getPractitionerDetails();
  addItemRow();
  await getDefaultTemplateDesign();

  watch(
    () => currentTemplateDesign.value,
    () => {
      setDefaultTemplateDesign();
    },
    { deep: true },
  );

});
</script>

<style lang="scss">
.parent-card {
  height: 100%;
  width: 100%;

  .card-tag {
    position: absolute;
    top: 0;
    left: 0;
    background: linear-gradient(to top, #f5f7fa 0%, #5f63d7 100%);
    padding: 10px;
    width: 150px;
    border-bottom-right-radius: 20px;
    color: #fff;
  }

  @media (max-width: 600px) {
    .prescription-printer-table {
      .v-table > .v-table__wrapper > table > tbody > tr > td,
      .v-table > .v-table__wrapper > table > tbody > tr > th,
      .v-table > .v-table__wrapper > table > thead > tr > td,
      .v-table > .v-table__wrapper > table > thead > tr > th,
      .v-table > .v-table__wrapper > table > tfoot > tr > td,
      .v-table > .v-table__wrapper > table > tfoot > tr > th {
        padding: 0 12px;
      }
    }
  }

  .template-designs-select {
    max-width: 230px;
  }

  .print-btn {
    margin-right: 11px;
    max-height: 40px;
  }
}
</style>
