<template>
  <v-card
    :class="`parent-card ${$vuetify.display.xs ? 'pa-4 pt-16' : 'pa-16'}`"
  >
    <Loader v-if="printLoading" />
    <v-form
      v-else
      v-model="isValidForm"
      @submit.prevent="generateMedicalReport"
      class="login-form d-flex flex-column"
    >
      <div class="card-tag bg-primary d-flex align-center justify-center">
        {{ $t('layouts.medical_report') }}
      </div>
      <v-row class="align-items-center justify-center mt-2">
        <v-col class="pt-0">
          <p class="font-weight-bold text-h5">
            {{ practitioner?.full_name }}
          </p>
          <p class="text-subtitle-1">{{ practitioner?.qualification }}</p>
        </v-col>
      </v-row>
      <v-divider class="my-6"></v-divider>
      <v-row>
        <v-col cols="12" sm="6" md="6" class="py-2">
          <text-field
            v-model="formData.patient_details.name"
            :rules="[required]"
            :label="$t('common.name')"
            attr="name"
          />
        </v-col>
        <v-col cols="12" sm="6" md="2" class="py-2">
          <text-field
            v-model="formData.patient_details.age"
            :rules="[required]"
            :label="$t('common.age')"
            type="number"
            attr="age"
          />
        </v-col>
        <v-col cols="12" sm="12" md="4" class="py-2">
          <v-radio-group
            v-model="formData.patient_details.gender"
            inline
            hide-details
          >
            <v-radio
              v-for="(gender, idx) in gendersMock"
              :key="idx"
              :label="gender.title"
              :value="gender.value"
              color="primary"
            ></v-radio>
          </v-radio-group>
        </v-col>
      </v-row>
      <v-divider class="my-6"></v-divider>
      <v-row align="center" class="ml-1">
        <SvgLoader icon="medical-notes-6" />
        <p class="text-h5 ml-2">
          {{ $t('encounters.chief_complaints') }}
        </p>
      </v-row>
      <chief-complaints-api-combo-box
        v-model="formData.complaints"
        :label="$t('encounters.chief_complaints')"
        can-add
        multiple
        class="py-3"
      />
      <v-divider class="my-6"></v-divider>
      <v-row align="center" class="ml-1">
        <SvgLoader icon="medical-personnel-doctor-1" />
        <p class="text-h5 ml-2">
          {{ $t('layouts.symptoms') }}
        </p>
      </v-row>
      <text-area
        v-model="formData.symptoms"
        :label="`${$t('layouts.symptoms')}...`"
        class="mt-5"
        :rows="2"
      />
      <v-divider class="my-6"></v-divider>
      <v-row align="center" class="ml-1">
        <SvgLoader icon="medical-personnel-doctor" />
        <p class="text-h5 ml-2">
          {{ $t('encounters.diagnosis') }}
        </p>
      </v-row>
      <diagnosis-api-combo-box
        v-model="formData.diagnosis"
        :label="$t('encounters.diagnosis')"
        can-add
        multiple
        class="py-3"
      />
      <v-divider class="my-6"></v-divider>
      <v-row align="center" class="ml-1">
        <SvgLoader icon="orders" />
        <p class="text-h5 ml-2">
          {{ $t('encounters.medical_prescription') }}
        </p>
      </v-row>
      <medication-api-combo-box
        v-model="formData.medications"
        :label="$t('encounters.medical_prescription')"
        can-add
        multiple
        class="py-3"
      />
      <v-divider class="my-6"></v-divider>
      <v-row align="center" class="ml-1">
        <p class="text-h5">{{ $t('common.notes') }}</p>
      </v-row>
      <text-area
        v-model="formData.additional_notes"
        :label="`${$t('common.notes')}...`"
        class="mt-5"
        :rows="2"
      />
      <v-divider class="my-6"></v-divider>
      <v-col align="center">
        <btn
          type="submit"
          :loading="loading"
          icon="mdi-shimmer"
          variant="primary"
          icon-before
          >{{ $t('medical_report.generate_report') }}</btn
        >
        <Editor v-model="medicalReport.report_text" class="mt-5" />
      </v-col>
      <v-col align="center">
        <btn
          :loading="loading"
          variant="primary"
          width="210"
          height="44"
          :disabled="!isPrintable"
          @click="printMedicalReport"
          >{{ $t('common.print') }}</btn
        >
      </v-col>
    </v-form>
    <iframe
      id="print-contents-iframe"
      width="100%"
      height="0px"
      frameborder="0"
      style="display: none"
    >
    </iframe>
  </v-card>
</template>

<script lang="ts" setup>
import MedicationApiComboBox from '@/components/tools/MedicationApiComboBox.vue';
import ChiefComplaintsApiComboBox from '@/components/tools/ChiefComplaintsApiComboBox.vue';
import DiagnosisApiComboBox from '@/components/tools/DiagnosisApiComboBox.vue';
import { gendersMock } from '@/constants';
import { required } from '@/utils/validations';
import { onMounted, reactive, ref } from 'vue';
import { IMedicalReport, IPatientDetails, IPractitioner } from '@/types';
import { useMedicalToolsStore } from '@/store';

const medicalToolsStore = useMedicalToolsStore();

const practitioner = ref<IPractitioner>();
const medicalReport = ref<IMedicalReport>({
  report_text: '',
});
const medicalReportHtml = ref();

const isValidForm = ref<boolean>(false);
const loading = ref<boolean>(false);
const isPrintable = ref<boolean>(false);
const printLoading = ref<boolean>(false);

const formData = reactive<{
  patient_details: IPatientDetails;
  complaints: [];
  diagnosis: [];
  medications: [];
  symptoms: '';
  additional_notes: '';
}>({
  patient_details: {
    name: '',
    age: null!,
    gender: 'M',
  },
  complaints: [],
  diagnosis: [],
  medications: [],
  symptoms: '',
  additional_notes: '',
});

const getPractitionerDetails = async () => {
  loading.value = true;
  practitioner.value = await medicalToolsStore.getPractitionerDetails();
  loading.value = false;
};

const generateMedicalReport = async () => {
  if (!isValidForm.value) {
    return;
  }
  loading.value = true;
  medicalReport.value = await medicalToolsStore.generateMedicalReport(formData);
  loading.value = false;
  isPrintable.value = true;
};

const printMedicalReport = async () => {
  if (!isValidForm.value) {
    return;
  }
  printLoading.value = true;
  medicalReportHtml.value = await medicalToolsStore.printMedicalReport({
    patient_details: formData.patient_details,
    report_data: medicalReport.value.report_text,
  });

  const iframe = document.getElementById(
    'print-contents-iframe',
  ) as HTMLIFrameElement;

  if (iframe) {
    iframe.style.display = 'block'; // Show the iframe for printing
    iframe.contentDocument!.open();
    iframe.contentDocument!.write(medicalReportHtml.value);
    iframe.contentDocument!.close();

    iframe.onload = function () {
      iframe.contentWindow?.print();
      iframe.style.display = 'none'; // Hide the iframe again
    };
  }

  printLoading.value = false;
};

onMounted(() => {
  getPractitionerDetails();
});
</script>

<style lang="scss" scoped>
.parent-card {
  height: 100%;
  width: 100%;

  .card-tag {
    position: absolute;
    top: 0;
    left: 0;
    background: linear-gradient(to top, #f5f7fa 0%, #5f63d7 100%);
    padding: 10px;
    width: auto;
    border-bottom-right-radius: 20px;
    color: #fff;
  }

  .print-btn {
    margin-right: 11px;
  }
}
</style>
