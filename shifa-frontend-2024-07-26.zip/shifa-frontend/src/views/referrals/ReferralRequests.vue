<template>Referral Requests</template>

<script lang="ts" setup></script>
