<template>
  <div class="d-flex flex-column fill-height w-100">
    <filters-top-bar
      v-model:status="status"
      v-model:name="name"
      v-model:speciality="speciality"
      :new-button-title="$t('config.new_advice')"
      @new="create"
    />
    <custom-encounter-table
      :status="status"
      :name="name"
      :speciality="speciality"
      :encounter-type="CustomEncounterType.Advice"
      @edit="edit"
    />
  </div>

  <custom-encounter-dialog
    v-model="isDialog"
    :encounter="selectedEncounter"
    :encounter-type="CustomEncounterType.Advice"
  />
</template>

<script lang="ts" setup>
import { ref } from 'vue';

import FiltersTopBar from '@/components/configuration/FiltersTopBar.vue';
import CustomEncounterTable from '@/components/configuration/CustomEncounterTable.vue';
import CustomEncounterDialog from '@/components/configuration/CustomEncounterDialog.vue';

import { CustomEncounterType, ICustomEncounter } from '@/types';

const status = ref<string>('all');
const name = ref<string>();
const speciality = ref<number>();
const isDialog = ref(false);
const selectedEncounter = ref<ICustomEncounter>();

const create = () => {
  selectedEncounter.value = undefined;
  isDialog.value = true;
};

const edit = (payload: ICustomEncounter) => {
  selectedEncounter.value = payload;
  isDialog.value = true;
};
</script>
