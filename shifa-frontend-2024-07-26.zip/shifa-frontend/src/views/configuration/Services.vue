<template>
  <div class="d-flex flex-column fill-height w-100">
    <filters-top-bar
      v-model:status="status"
      v-model:name="name"
      v-model:speciality="speciality"
      :new-button-title="$t('config.new_service')"
      @new="create"
    />
    <services-table :status="status" :name="name" :speciality="speciality" @edit="edit" />
  </div>

  <service-dialog :item="selectedItem" v-model="isDialog" />
</template>

<script lang="ts" setup>
import { ref } from 'vue';

import FiltersTopBar from '@/components/configuration/FiltersTopBar.vue';
import ServicesTable from '@/components/configuration/ServicesTable.vue';
import ServiceDialog from '@/components/configuration/ServiceDialog.vue';

import { IService } from '@/types';

const status = ref<string>('all');
const name = ref<string>();
const speciality = ref<number>();
const isDialog = ref(false);
const selectedItem = ref<IService>();

const create = () => {
  selectedItem.value = undefined;
  isDialog.value = true;
};

const edit = (payload: IService) => {
  selectedItem.value = payload;
  isDialog.value = true;
};
</script>
