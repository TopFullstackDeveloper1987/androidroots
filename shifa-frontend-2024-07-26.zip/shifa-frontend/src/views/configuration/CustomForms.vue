<template>
  <div class="d-flex flex-column fill-height w-100">
    <custom-forms-top-bar
      :specialities="specialities"
      v-model:name="name"
      v-model:formType="formType"
      v-model:speciality="speciality"
      :new-button-title="$t('config.new_custom_form')"
      @new="create"
    />
    <custom-forms-table
      :name="name"
      :formType="formType"
      :speciality="speciality"
      @edit="edit"
    />

    <custom-form-dialog
      v-model="isDialog"
      :specialities="specialities"
      :form-type="formType"
      :custom-form="selectedForm"
    />
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue';

import CustomFormsTopBar from '@/components/configuration/CustomFormsTopBar.vue';
import CustomFormsTable from '@/components/configuration/CustomFormsTable.vue';
import CustomFormDialog from '@/components/configuration/CustomFormDialog.vue';

import { useMetaDataStore } from '@/store';
import { ICustomForm, ISpecialty } from '@/types';

const metaDataStore = useMetaDataStore();

const name = ref<string>();
const formType = ref<string>();
const speciality = ref<number>();
const isDialog = ref(false);
const selectedForm = ref<ICustomForm>();
const specialities = ref<ISpecialty[]>([]);

onMounted(() => {
  loadSpecialities();
});

const loadSpecialities = async () => {
  const res = await metaDataStore.getMetaData('speciality');
  specialities.value = res as any;
};

const create = () => {
  selectedForm.value = undefined;
  isDialog.value = true;
};

const edit = (payload: ICustomForm) => {
  selectedForm.value = payload;
  isDialog.value = true;
};
</script>
