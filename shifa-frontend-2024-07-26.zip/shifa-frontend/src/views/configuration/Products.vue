<template>
  <div class="d-flex flex-column fill-height w-100">
    <filters-top-bar
      v-model:status="status"
      v-model:name="name"
      v-model:speciality="speciality"
      :new-button-title="$t('config.new_product')"
      @new="create"
    />
    <products-table
      :status="status"
      :name="name"
      :speciality="speciality"
      @edit="edit"
    />
  </div>

  <product-dialog v-model="isDialog" :item="selectedItem" />
</template>

<script lang="ts" setup>
import { ref } from 'vue';

import FiltersTopBar from '@/components/configuration/FiltersTopBar.vue';
import ProductsTable from '@/components/configuration/ProductsTable.vue';
import ProductDialog from '@/components/configuration/ProductDialog.vue';

import { IProduct } from '@/types';

const status = ref<string>('all');
const name = ref<string>();
const speciality = ref<number>();
const isDialog = ref(false);
const selectedItem = ref<IProduct>();

const create = () => {
  selectedItem.value = undefined;
  isDialog.value = true;
};

const edit = (payload: IProduct) => {
  selectedItem.value = payload;
  isDialog.value = true;
};
</script>
