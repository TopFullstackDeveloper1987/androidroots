<template>
  <div class="d-flex flex-column fill-height w-100">
    <filters-top-bar
      is-medication
      v-model:status="status"
      v-model:name="name"
      v-model:category="category"
      v-model:subCategory="subCategory"
      :categories="categories"
      :new-button-title="$t('config.new_medication')"
      @new="create"
    />
    <custom-encounter-table
      :status="status"
      :name="name"
      :category="category"
      :subCategory="subCategory"
      :encounter-type="CustomEncounterType.Medication"
      @edit="edit"
    />
  </div>

  <custom-encounter-medication-dialog
    v-model="isDialog"
    :categories="categories"
    :encounter="selectedEncounter"
    :encounter-type="CustomEncounterType.Medication"
  />
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue';

import FiltersTopBar from '@/components/configuration/FiltersTopBar.vue';
import CustomEncounterTable from '@/components/configuration/CustomEncounterTable.vue';
import CustomEncounterMedicationDialog from '@/components/configuration/CustomEncounterMedicationDialog.vue';

import { useMetaDataStore } from '@/store';
import { IIdName, CustomEncounterType, ICustomEncounter } from '@/types';

const metaDataStore = useMetaDataStore();

const name = ref<string>();
const category = ref<string>();
const subCategory = ref<string>();
const status = ref<string>('all');
const categories = ref<IIdName[]>([]);
const isDialog = ref(false);
const selectedEncounter = ref<ICustomEncounter>();

onMounted(async () => {
  const res = await metaDataStore.getMetaData('drug-category');
  categories.value = res as any;
});

const create = () => {
  selectedEncounter.value = undefined;
  isDialog.value = true;
};

const edit = (payload: ICustomEncounter) => {
  selectedEncounter.value = payload;
  isDialog.value = true;
};
</script>
