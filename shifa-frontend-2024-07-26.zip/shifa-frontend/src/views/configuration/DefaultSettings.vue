<template>
  <div class="w-full">
    <div class="text-right">
      <btn @click="showDialog = true"> {{ $t('config.add') }} </btn>
    </div>

    <expansion-panel
      v-for="(group, index) in configs"
      :key="index"
      :title="group.group"
      icon="danger"
      v-model="panel[index]"
      class="my-3"
    >
      <template #content>
        <v-sheet class="px-3 py-5 bordered">
          <div v-for="(subGroup, index) in group.sub_groups" :key="index">
            <div class="text-h5">
              {{ subGroup.sub_group }}
            </div>

            <data-table-server
              :items="subGroup.items"
              :headers="headers"
              no-gutters
              :show-search-results-info="false"
              :show-pagination="false"
            >
              <template v-slot:item="{ item }">
                <tr>
                  <td>
                    {{ item.raw.name_display }}
                  </td>
                  <td>
                    {{ item.raw.entity }}
                  </td>
                  <td>
                    {{ item.raw.entity_id }}
                  </td>
                  <td>
                    {{ item.raw.entity_id_type }}
                  </td>
                  <td>
                    {{ item.raw.value }}
                  </td>
                  <td>
                    {{ item.raw.value_type }}
                  </td>
                  <td>
                    <btn
                      :primary="false"
                      icon="mdi-delete"
                      icon-only
                      icon-color="primary"
                      size="x-small"
                      class="my-3 mr-3"
                      variant="text"
                      @click="deleteConfig(item.raw.id)"
                    >
                      <tooltip>{{ $t('common.delete') }}</tooltip>
                    </btn>
                  </td>
                </tr>
              </template>
            </data-table-server>
          </div>
        </v-sheet>
      </template>
    </expansion-panel>

    <config-dialog v-model="showDialog" @updated="loadConfig" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useI18n } from 'vue-i18n';
import { useDefaultSettingsStore } from '@/store';
import { IConfig } from '@/types';
import ConfigDialog from '@/components/configuration/ConfigDialog.vue';
import DataTableServer from '@/components/common/DataTableServer.vue';

const { t } = useI18n();
const defaultSettingsStore = useDefaultSettingsStore();

const panel = ref<number[]>([]);
const configs = ref<IConfig[]>([]);
const showDialog = ref<boolean>(false);

const headers = [
  {
    title: t('config.name'),
    key: 'name',
    sortable: false,
  },
  {
    title: t('config.entity'),
    key: 'entity',
    sortable: false,
  },
  {
    title: t('config.entity_id'),
    key: 'entity_id',
    sortable: false,
  },
  {
    title: t('config.entity_type'),
    key: 'entity_type',
    sortable: false,
  },
  {
    title: t('config.value'),
    key: 'value',
    sortable: false,
  },
  {
    title: t('config.value_type'),
    key: 'value_type',
    sortable: false,
  },
  {
    title: t('common.actions'),
    key: 'actions',
    sortable: false,
  },
];

onMounted(() => {
  loadConfig();
});

const loadConfig = async () => {
  configs.value = await defaultSettingsStore.getConfig({});
};

const deleteConfig = async (id: string) => {
  await defaultSettingsStore.deleteConfig(id);
  loadConfig();
};
</script>

<style scoped></style>
