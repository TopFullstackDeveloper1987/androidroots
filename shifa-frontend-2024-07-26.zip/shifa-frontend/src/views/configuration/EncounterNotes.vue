<template>
  <div class="w-full">
    <div class="text-left">
      <select-field
        :items="practitioners"
        :item-title="getPractitionerFullName"
        item-value="id"
        v-model="practitionerIdValue"
        :label="$t('common.practitioners_doctors')"
        class="max-width-250 mr-4"
      />
    </div>
    <v-divider class="mt-3"></v-divider>
    <v-card
      v-for="(config, index) in configs"
      :key="index"
      class="mx-auto my-3"
      :title="config.name_display"
    >
    <template #prepend><SvgLoader :icon="config.icon || 'medical-notes-6'"/></template>
    <template #append><switch-btn v-model="config.is_selected" @change="updateEncounterConfig(index, config.is_selected)" /></template>
    </v-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, ComputedRef, computed } from 'vue';
import { useFacilityStore, usePractitionerSearchStore, useDefaultSettingsStore, useAuthStore, useCommonStore } from '@/store';
import { IConfiguration, IPractitioner, ToastType } from '@/types';
import { useI18n } from 'vue-i18n';

const authStore = useAuthStore();
const defaultSettingsStore = useDefaultSettingsStore();
const facilityStore = useFacilityStore();
const commonStore = useCommonStore();
const practitionerSearchStore = usePractitionerSearchStore();

const { t } = useI18n();

const practitionerIdValue = ref<string>(authStore.userInfo.practitioner_id as string);
const practitioners: ComputedRef<IPractitioner[]> = computed(() => {
  return [
    ...practitionerSearchStore.practitioners,
  ];
});

const configs = ref<IConfiguration[]>([]);

const updateEncounterConfig = async (index: number, is_selected: boolean) => {
  await defaultSettingsStore.updateConfig(
    practitionerIdValue.value!,
    configs.value[index].name,
  );

  if(is_selected) commonStore.showToast(ToastType.Success, t('notifications.config_added'));
  else commonStore.showToast(ToastType.Success, t('notifications.config_deleted'));

};

const getPractitionerFullName = (practitioner: IPractitioner) =>
  `${practitioner.first_name} ${practitioner.last_name}`;

const loadPractitioners = async () => {
  await practitionerSearchStore.searchPractitioners({
    fuuid: facilityStore.currentFacilityId!,
  });
};

const loadConfigs = async () => {
  configs.value = await defaultSettingsStore.getEncounterConfigs(
    'Encounter Notes',
    'Display settings',
    authStore.userInfo.practitioner_id as string,
  );
};

onMounted(async () => {
  loadPractitioners();
  loadConfigs();
});
</script>

<style scoped></style>
