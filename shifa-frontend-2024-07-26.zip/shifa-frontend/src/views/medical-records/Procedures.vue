<template>
  <div class="d-flex flex-column fill-height w-100">
    <procedures-top-bar
      :types="types"
      :statuses="statuses"
      :practitioners="practitioners"
      v-model:type="type"
      v-model:status="status"
      v-model:dates="dates"
      v-model:practitioner-id="practitionerId"
      @new="create"
    />

    <procedures-table
      :type="type"
      :dates="dates"
      :status="status"
      :practitioner-id="practitionerId"
      @edit="edit"
    />

    <ProcedureDialog
      v-model="isProcedureDialog"
      :item="selectedProcedure"
      :practitioners="practitionerSearchStore.practitioners"
    />
  </div>
</template>

<script lang="ts" setup>
import { useI18n } from 'vue-i18n';
import { onMounted, ref, computed, ComputedRef } from 'vue';
import ProceduresTopBar from '@/components/medical-records/procedures/ProceduresTopBar.vue';
import ProceduresTable from '@/components/medical-records/procedures/ProceduresTable.vue';
import ProcedureDialog from '@/components/medical-records/procedures/ProcedureDialog.vue';
import { useFacilityStore, usePractitionerSearchStore } from '@/store';
import { IPractitioner, IProcedure, ISelect } from '@/types';
import { procedureTypes, procedureStatuses } from '@/constants';

const { t } = useI18n();
const facilityStore = useFacilityStore();
const practitionerSearchStore = usePractitionerSearchStore();

const type = ref<string>();
const status = ref<string>();
const dates = ref<Date[]>([]);
const practitionerId = ref<string>();
const isProcedureDialog = ref<boolean>(false);
const selectedProcedure = ref<IProcedure>();

const types = ref<ISelect<string>[]>(procedureTypes);
const statuses = ref<ISelect<string | null>[]>([
  {
    title: t('common.all'),
    value: null,
  },
  ...procedureStatuses,
]);

const practitioners: ComputedRef<IPractitioner[]> = computed(() => {
  return [
    {
      id: null,
      first_name: 'All',
      last_name: '',
    } as unknown as IPractitioner,
    ...practitionerSearchStore.practitioners,
  ];
});

onMounted(async () => {
  await loadPractitioners();
});

const loadPractitioners = async () => {
  await practitionerSearchStore.searchPractitioners({
    fuuid: facilityStore.currentFacilityId!,
  });
};

const create = () => {
  selectedProcedure.value = undefined;
  isProcedureDialog.value = true;
};

const edit = (payload: IProcedure) => {
  selectedProcedure.value = payload;
  isProcedureDialog.value = true;
};
</script>
