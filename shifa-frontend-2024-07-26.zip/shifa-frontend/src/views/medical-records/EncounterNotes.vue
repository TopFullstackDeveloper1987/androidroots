<template>
  <div class="w-full">
    <div class="text-right mt-3">
      <btn icon="mdi-plus" icon-before @click="isShowInvoiceDialog = true">
        {{ $t('encounters.new_invoice') }}
      </btn>
      <btn class="ml-2">
        {{ $t('encounters.email') }}
      </btn>
      <btn class="ml-2" @click="isShowPrintDialog = true">
        {{ $t('encounters.print') }}
      </btn>
      <btn class="ml-2">
        {{ $t('common.close') }}
      </btn>
    </div>

    <v-card class="my-3">
      <v-slide-group
        v-if="encounters.length"
        :model-value="currentEncounter.id"
        class="w-full pa-4 overflow-x-auto slide-group"
        center-active
        show-arrows
        mandatory
      >
        <v-slide-group-item
          v-for="(encounter, index) in encounters"
          :key="index"
          :value="encounter.id"
        >
          <EncounterCard
            :is-active="encounter.id == currentEncounter.id"
            :encounter="encounter"
            class="mx-4"
            @click="getEncounter(encounter)"
          />
        </v-slide-group-item>
      </v-slide-group>
    </v-card>

    <Loader v-if="loading" />
    <div v-if="encounters.length && currentEncounter && !loading">
      <CustomForm
        v-for="(customForm, index) in customForms"
        :key="index"
        class="mb-3"
        :custom-form="customForm"
      />
      <EncounterItem
        v-if="isVisible('hide_chief_complaints')"
        class="mb-3"
        icon="medical-notes-6"
        :encounter-type="CustomEncounterType.Complaint"
        :encounterItems="currentEncounter.encounter_complaints"
        :title="`${$t('encounters.chief_complaints_and_hpi')}`"
        :placeholder="`${$t('encounters.chief_complaints_placeholder')}`"
        @updated="encounterUpdated"
      >
        <template #actions>
          <v-tooltip
            :text="
              $t('encounters.customise_your_encounter', {
                encounter: CustomEncounterType.Complaint,
              })
            "
            location="top"
          >
            <template v-slot:activator="{ props }">
              <btn
                v-bind="props"
                :primary="false"
                :disabled-tooltip="false"
                color="primary"
                icon="mdi-cog"
                variant="tonal"
                icon-only
                icon-size="25"
                @click="visitConfigPage('complaints')"
              >
              </btn>
            </template>
          </v-tooltip>
        </template>
      </EncounterItem>
      <EncounterItem
        v-if="isVisible('hide_observations')"
        class="mb-3"
        icon="chat"
        :encounter-type="CustomEncounterType.Observation"
        :encounterItems="currentEncounter.encounter_observations"
        :title="`${$t('encounters.observations')}`"
        :placeholder="`${$t('encounters.observation_plcaeholder')}`"
        @updated="encounterUpdated"
      >
        <template #actions>
          <v-tooltip
            :text="
              $t('encounters.customise_your_encounter', {
                encounter: CustomEncounterType.Observation,
              })
            "
            location="top"
          >
            <template v-slot:activator="{ props }">
              <btn
                v-bind="props"
                :primary="false"
                :disabled-tooltip="false"
                color="primary"
                icon="mdi-cog"
                variant="tonal"
                icon-only
                icon-size="25"
                @click="visitConfigPage('observations')"
              >
              </btn>
            </template>
          </v-tooltip>
        </template>
      </EncounterItem>
      <EncounterImagingOrders
        v-if="isVisible('hide_imaging_orders')"
        class="mb-3"
        @updated="encounterUpdated"
        @print="printImagingOrder"
      />
      <EncounterLabOrders
        v-if="isVisible('hide_lab_orders')"
        class="mb-3"
        @updated="encounterUpdated"
        @print="printLabOrder"
      />
      <EncounterItem
        v-if="isVisible('hide_diagnoses')"
        class="mb-3"
        icon="medical-personnel-doctor"
        :encounter-type="CustomEncounterType.Diagnosis"
        :encounterItems="currentEncounter.encounter_diagnosis"
        :title="`${$t('encounters.diagnosis')}`"
        :placeholder="`${$t('encounters.diagnosis_placeholder')}`"
        @updated="encounterUpdated"
      >
        <template #actions>
          <v-tooltip
            :text="
              $t('encounters.customise_your_encounter', {
                encounter: CustomEncounterType.Diagnosis,
              })
            "
            location="top"
          >
            <template v-slot:activator="{ props }">
              <btn
                v-bind="props"
                :primary="false"
                :disabled-tooltip="false"
                color="primary"
                icon="mdi-cog"
                variant="tonal"
                icon-only
                icon-size="25"
                @click="visitConfigPage('diagnosis')"
              >
              </btn>
            </template>
          </v-tooltip>
        </template>
      </EncounterItem>
      <EncounterMedicationOrders
        v-if="isVisible('hide_medication_orders')"
        class="mb-3"
        @updated="encounterUpdated"
        @print="printMedicationOrder"
      >
        <template #actions>
          <v-tooltip
            :text="
              $t('encounters.customise_your_encounter', {
                encounter: CustomEncounterType.Medication,
              })
            "
            location="top"
          >
            <template v-slot:activator="{ props }">
              <btn
                v-bind="props"
                :primary="false"
                :disabled-tooltip="false"
                color="primary"
                icon="mdi-cog"
                variant="tonal"
                icon-only
                icon-size="25"
                @click="visitConfigPage('medication')"
              >
              </btn>
            </template>
          </v-tooltip>
        </template>
      </EncounterMedicationOrders>
      <EncounterItem
        v-if="isVisible('hide_advice')"
        class="mb-3"
        icon="medical-personnel-doctor-1"
        :encounter-type="CustomEncounterType.Advice"
        :encounterItems="currentEncounter.encounter_advice"
        :title="`${$t('encounters.advice')}`"
        :placeholder="`${$t('encounters.advice_plcaeholder')}`"
        @updated="encounterUpdated"
      >
        <template #actions>
          <v-tooltip
            :text="
              $t('encounters.customise_your_encounter', {
                encounter: CustomEncounterType.Advice,
              })
            "
            location="top"
          >
            <template v-slot:activator="{ props }">
              <btn
                v-bind="props"
                :primary="false"
                :disabled-tooltip="false"
                color="primary"
                icon="mdi-cog"
                variant="tonal"
                icon-only
                icon-size="25"
                @click="visitConfigPage('advice')"
              >
              </btn>
            </template>
          </v-tooltip>
        </template>
      </EncounterItem>
      <EncounterFollowUp
        v-if="isVisible('hide_followup')"
        class="mb-3"
        @updated="encounterUpdated"
      />
      <EncounterNotes
        v-if="isVisible('hide_notes')"
        class="mb-3"
        apiKey="notes"
        @updated="encounterUpdated"
      />
    </div>
    <div v-if="!encounters.length && !loading" class="text-center text-h5">
      {{ $t('encounters.no_encounters_found') }}
    </div>
  </div>
  <invoice-dialog
    v-model="isShowInvoiceDialog"
    :current-patient="patientStore.currentPatient"
    :current-encounter="currentEncounter"
  />
  <print-encounter-notes-dialog
    :encounter="currentEncounter"
    v-model="isShowPrintDialog"
  />
  <iframe
    id="print-contents-iframe"
    width="100%"
    height="0px"
    frameborder="0"
    style="display: none"
  >
  </iframe>
</template>

<script lang="ts" setup>
import {
  ref,
  onMounted,
  onBeforeMount,
  watch,
  computed,
  ComputedRef,
  WritableComputedRef,
} from 'vue';
import {
  ConfigurationEvents,
  IConfigByNames,
  ICustomForm,
  IEncounterLabOrder,
  IEncounterMedicationOrder,
} from '@/types';
import { useRouter, useRoute } from 'vue-router';

import EncounterCard from '@/components/medical-records/encounter-notes/EncounterCard.vue';

import EncounterItem from '@/components/medical-records/encounter-notes/EncounterItem.vue';
import CustomForm from '@/components/medical-records/encounter-notes/CustomForm.vue';
import EncounterNotes from '@/components/medical-records/encounter-notes/EncounterNotes.vue';
import EncounterAdvice from '@/components/medical-records/encounter-notes/EncounterAdvice.vue';
import EncounterFollowUp from '@/components/medical-records/encounter-notes/EncounterFollowUp.vue';
import EncounterImagingOrders from '@/components/medical-records/encounter-notes/EncounterImagingOrders.vue';
import EncounterLabOrders from '@/components/medical-records/encounter-notes/EncounterLabOrders.vue';
import EncounterMedicationOrders from '@/components/medical-records/encounter-notes/EncounterMedicationOrders.vue';
import PrintEncounterNotesDialog from '@/components/medical-records/encounter-notes/PrintEncounterNotesDialog.vue';
import InvoiceDialog from '@/components/billing/invoices/InvoiceDialog.vue';

import {
  usePatientStore,
  useEncounterStore,
  useAuthStore,
  useCustomFormsStore,
  useDefaultSettingsStore,
} from '@/store';

import {
  IEncounter,
  IEncounterImagingOrder,
  CustomEncounterType,
} from '@/types';
import { events } from '@/events';

const router = useRouter();
const route = useRoute();

const authStore = useAuthStore();
const patientStore = usePatientStore();
const encounterStore = useEncounterStore();
const customFormsStore = useCustomFormsStore();
const defaultSettingsStore = useDefaultSettingsStore();

const loading = ref(false);
const isShowPrintDialog = ref(false);
const isShowInvoiceDialog = ref(false);
const printableHtml = ref<string>('');

const configs = ref<IConfigByNames[]>([]);

const encounters: WritableComputedRef<IEncounter[]> = computed(() => {
  return encounterStore.encounters;
});

const currentPatientId: WritableComputedRef<string | null> = computed(() => {
  return patientStore.currentPatientId;
});

const currentEncounter: WritableComputedRef<IEncounter> = computed(() => {
  return encounterStore.currentEncounter;
});

const customForms: ComputedRef<ICustomForm[] | undefined> = computed(() => {
  return customFormsStore.searchResults?.results;
});

onBeforeMount(async () => {
  const patientId = route.params.patientId;
  if (patientId !== patientStore.currentPatientId) {
    // TODO: fetch patient if the user puts patientId in the url manually
    router.push('/dashboard');
    return;
  }
});

onMounted(async () => {
  getConfigs();
  getEncounters();
  getCustomForms();

  if (currentPatientId.value) {
    await patientStore.getCurrentPatient();
  }
});

watch(currentPatientId, () => {
  getEncounters();
});

const getCustomForms = () => {
  customFormsStore.searchCustomForms({ page: 1, favored: true });
};

const getEncounters = async () => {
  if (!currentPatientId.value) return;
  loading.value = true;
  await encounterStore.getPatientEncounters(currentPatientId.value);
  loading.value = false;
};

const getConfigs = async () => {
  configs.value = await defaultSettingsStore.getConfigByNames(
    'Encounter Notes',
    'Display settings',
    authStore.userInfo.practitioner_id as string,
  );
};

const visitConfigPage = (encounterType: string) => {
  router.push(`/configuration/${encounterType}`);
};

const encounterUpdated = async () => {
  await encounterStore.getPatientEncounter(currentEncounter.value);
  events.emit(ConfigurationEvents.ReloadCustomEncounters);
};

const getEncounter = async (encounter: IEncounter) => {
  loading.value = true;
  await encounterStore.getPatientEncounter(encounter);
  loading.value = false;
};

const printImagingOrder = (payload: IEncounterImagingOrder) => {
  loading.value = true;
  if (!payload.id) return;
  encounterStore
    .printImagingOrder(payload.id)
    .then((res) => {
      printableHtml.value = res;
      const iframe = document.getElementById(
        'print-contents-iframe',
      ) as HTMLIFrameElement;

      if (iframe) {
        iframe.style.display = 'block'; // Show the iframe for printing
        iframe.contentDocument!.open();
        iframe.contentDocument!.write(printableHtml.value);
        iframe.contentDocument!.close();

        iframe.onload = function () {
          iframe.contentWindow?.print();
          iframe.style.display = 'none'; // Hide the iframe again
        };
      }
    })
    .finally(() => (loading.value = false));
};

const printLabOrder = (payload: IEncounterLabOrder) => {
  loading.value = true;
  if (!payload.id) return;
  encounterStore
    .printLabOrder(payload.id)
    .then((res) => {
      printableHtml.value = res;
      const iframe = document.getElementById(
        'print-contents-iframe',
      ) as HTMLIFrameElement;

      if (iframe) {
        iframe.style.display = 'block'; // Show the iframe for printing
        iframe.contentDocument!.open();
        iframe.contentDocument!.write(printableHtml.value);
        iframe.contentDocument!.close();

        iframe.onload = function () {
          iframe.contentWindow?.print();
          iframe.style.display = 'none'; // Hide the iframe again
        };
      }
    })
    .finally(() => (loading.value = false));
};

const printMedicationOrder = (payload: IEncounterMedicationOrder) => {
  loading.value = true;
  if (!payload.id) return;
  encounterStore
    .printMedicationOrder(payload.id)
    .then((res) => {
      printableHtml.value = res;
      const iframe = document.getElementById(
        'print-contents-iframe',
      ) as HTMLIFrameElement;

      if (iframe) {
        iframe.style.display = 'block'; // Show the iframe for printing
        iframe.contentDocument!.open();
        iframe.contentDocument!.write(printableHtml.value);
        iframe.contentDocument!.close();

        iframe.onload = function () {
          iframe.contentWindow?.print();
          iframe.style.display = 'none'; // Hide the iframe again
        };
      }
    })
    .finally(() => (loading.value = false));
};

const isVisible = (name: string) => {
  let item = configs.value.find((config) => config.configuration.name == name);
  if (!item) return true;
  else if (item.value == 'true' || item.value == true) return false;
};
</script>

<style lang="scss" scoped>
.slide-group {
  max-width: 800px;
}
</style>
