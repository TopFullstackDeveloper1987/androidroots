<template>Medications</template>

<script lang="ts" setup></script>
