import { defineStore } from 'pinia';
import { ref } from 'vue';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';

import { IPatientDocument } from '@/types';

export const usePatientDocumentsStore = defineStore('patient-documents', () => {
  const commonStore = useCommonStore();

  const patientDocuments = ref<IPatientDocument[]>([]);

  const setPatientDocuments = (documents: IPatientDocument[]) => {
    patientDocuments.value = documents;
  };

  const getPatientDocuments = async (patientId: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getPatientDocuments(patientId);

      setPatientDocuments(res.data);
      return res.data;
    });
  };

  const UploadPatientDocument = async (
    payload: FormData,
    patientId: string,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().uploadPatientDocuments(
        payload,
        patientId,
      );
      return res.data;
    });
  };

  const downloadPatientDocument = async (fileId: string) => {
    return commonStore.actionWrapper(async () => {
      const res =
        await ApiService.getInstance().downloadPatientDocument(fileId);
      return res.data;
    });
  };

  const scanDocument = async (payload: FormData) => {
    return commonStore.actionWrapper(async () => {
      const res =
        await ApiService.getInstance().scanDocument(payload);

      console.log('response', res.data);
      return res.data;
    });
  };

  return {
    patientDocuments,
    getPatientDocuments,
    UploadPatientDocument,
    downloadPatientDocument,
    scanDocument,
  };
});
