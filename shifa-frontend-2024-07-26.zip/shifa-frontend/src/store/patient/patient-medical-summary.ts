import { defineStore } from 'pinia';
import { ref } from 'vue';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import { IPatientMedicalSummary } from '@/types';

export const usePatientMedicalSummariestore = defineStore(
  'patient-medical-summary',
  () => {
    const commonStore = useCommonStore();

    const patientMedicalSummaries = ref<IPatientMedicalSummary[]>([]);

    const setPatientMedicalSummaries = (
      conditions: IPatientMedicalSummary[],
    ) => {
      patientMedicalSummaries.value = conditions;
    };

    const getPatientMedicalSummaries = async (patientId: string) => {
      return commonStore.actionWrapper(async () => {
        const res =
          await ApiService.getInstance().getPatientMedicalSummaries(patientId);
        setPatientMedicalSummaries(res.data);

        return res.data;
      });
    };

    const getPatientEncounterSummaries = async (patientId: string) => {
      return commonStore.actionWrapper(async () => {
        const res =
          await ApiService.getInstance().getPatientEncounterSummaries(patientId);

        return res.data;
      });
    };

    return {
      patientMedicalSummaries,
      getPatientMedicalSummaries,
      getPatientEncounterSummaries,
    };
  },
);
