import { defineStore } from 'pinia';
import { ref } from 'vue';

import { useCommonStore } from '../common';
import { usePatientStore } from './patient';
import { useFacilityStore } from '../facility';

import { ApiService } from '@/services';
import {
  IAllergy,
  IAlert,
  IPatientAllergy,
  IPatientAlert,
  IPatientRecord,
  IPatientSurgicalHistory,
  IPatientFamilyHistory,
} from '@/types';

export const usePatientRecordStore = defineStore('patient-record', () => {
  const commonStore = useCommonStore();
  const patientStore = usePatientStore();
  const facilityStore = useFacilityStore();

  const patientRecord = ref<IPatientRecord>();
  const allergies = ref<IAllergy[]>([]);
  const alerts = ref<IAlert[]>([]);
  const surgeries = ref<IPatientSurgicalHistory[]>([]);
  const familyHistories = ref<IPatientFamilyHistory[]>([]);

  const getPatientRecord = (patientId: string) => {
    const id = patientId ? patientId : patientStore.currentPatientId;

    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getMedicalRecord(id as any);
      setPatientRecord(res.data);

      return res.data;
    });
  };

  const getPatientReportByGender = (groupBy: string, fromDate: string, toDate: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getPatientReportByGender(facilityStore.currentFacilityId!, groupBy, fromDate, toDate);
      return res.data;
    });
  };

  const addPatientAllergy = (payload: IPatientAllergy) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addPatientAllergy(payload);
      return res.data;
    });
  };

  const updatePatientAllergy = (payload: IPatientAllergy) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updatePatientAllergy(payload);
      return res.data;
    });
  };

  const deletePatientAllergy = (payload: IPatientAllergy) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deletePatientAllergy(payload);
      return res.data;
    });
  };

  const getAllergies = () => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getAllergies();
      setAllergies(res.data);
      return res.data;
    });
  };

  const getAlerts = () => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getAlerts();
      setAlerts(res.data);
      return res.data;
    });
  };


  const addPatientAlert = (payload: IPatientAlert) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addPatientAlert(payload);
      return res.data;
    });
  };

  const updatePatientAlert = (payload: IPatientAlert) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updatePatientAlert(payload);
      return res.data;
    });
  };

  const deletePatientAlert = (payload: IPatientAlert) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deletePatientAlert(payload);
      return res.data;
    });
  };

  const getSurgeries = () => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getSurgeries();
      setSurgeries(res.data);
      return res.data;
    });
  };

  const getFamilyHistories = () => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getMetaData<unknown, IPatientFamilyHistory>('condition');
      setFamilyHistories(res.data);
      return res.data;
    });
  };

  const addPatientFamilyHistory = (payload: IPatientFamilyHistory) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addPatientFamilyHistory(payload);
      return res.data;
    });
  };

  const updatePatientFamilyHistory = (payload: IPatientFamilyHistory) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updatePatientFamilyHistory(payload);
      return res.data;
    });
  };

  const deleteFamilyHistory = (payload: IPatientFamilyHistory) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deleteFamilyHistory(payload);
      return res.data;
    });
  };

  const addPastSurgicalHistory = (payload: IPatientSurgicalHistory) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addPastSurgicalHistory(payload);
      return res.data;
    });
  };

  const updatePastSurgeryHistory = (payload: IPatientSurgicalHistory) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updatePastSurgeryHistory(payload);
      return res.data;
    });
  };

  const deletePastSurgeryHistory = (payload: IPatientSurgicalHistory) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deletePastSurgeryHistory(payload);
      return res.data;
    });
  };

  const setPatientRecord = (patient: IPatientRecord) => {
    patientRecord.value = patient;
  };

  const setAllergies = (result: IAllergy[]) => {
    allergies.value = result;
  };

  const setAlerts = (result: IAlert[]) => {
    alerts.value = result;
  };

  const setSurgeries = (result: IPatientSurgicalHistory[]) => {
    surgeries.value = result;
  };

  const setFamilyHistories = (result: IPatientFamilyHistory[]) => {
    familyHistories.value = result;
  };

  return {
    allergies,
    patientRecord,
    alerts,
    surgeries,
    familyHistories,

    getPatientRecord,
    getPatientReportByGender,
    setPatientRecord,
    getAllergies,
    addPatientAllergy,
    updatePatientAllergy,
    deletePatientAllergy,
    getAlerts,
    addPatientAlert,
    updatePatientAlert,
    deletePatientAlert,
    getSurgeries,
    addPastSurgicalHistory,
    updatePastSurgeryHistory,
    deletePastSurgeryHistory,
    getFamilyHistories,
    addPatientFamilyHistory,
    updatePatientFamilyHistory,
    deleteFamilyHistory,
  };
});
