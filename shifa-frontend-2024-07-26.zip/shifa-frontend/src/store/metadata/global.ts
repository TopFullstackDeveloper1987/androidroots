import { defineStore } from 'pinia';

import { useCommonStore } from '../common';
import { ApiService } from '@/services';
import { IMetaDataCodeQuery } from '@/types';

export const useMetaDataStore = defineStore('metadata', () => {
  const commonStore = useCommonStore();

  const getMetaData = <T, R>(encounter: string, params?: T) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getMetaData<T, R>(
        encounter,
        params,
      );
      return res.data;
    });
  };

  const getMetaDataDetails = (key: string, id: number) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getMetaDataDetails(key, id);
      return res.data;
    });
  };

  const getMetaDataICDCodes = (params: IMetaDataCodeQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getMetaDataICDCodes(params);
      return res.data;
    });
  };

  const getMetaDataCountryCode = () => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getMetaDataCountryCode();
      return res.data;
    });
  };

  const getMetaDataCPTCodes = (params: IMetaDataCodeQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getMetaDataCPTCodes(params);
      return res.data;
    });
  };

  return {
    getMetaData,
    getMetaDataDetails,
    getMetaDataICDCodes,
    getMetaDataCountryCode,
    getMetaDataCPTCodes,
  };
});
