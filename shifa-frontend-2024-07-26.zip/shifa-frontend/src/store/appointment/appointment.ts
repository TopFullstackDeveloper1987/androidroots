import { defineStore } from 'pinia';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import { AppointmentAction, IPayAppointmentFeePayload } from '@/types';
import { useFacilityStore } from '../facility';

export const useAppointmentStore = defineStore('appointment', () => {
  const commonStore = useCommonStore();
  const facilityStore = useFacilityStore();

  const getAppointmentsReport = async (groupBy: string, fromDate: string, toDate: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getAppointmentsReport(facilityStore.currentFacilityId!, groupBy, fromDate, toDate);

      return res.data;
    });
  };

  const updateAppointmentAction = async (
    appointmentId: string,
    action: AppointmentAction,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateAppointmentAction(
        appointmentId,
        action,
      );
      return res.data;
    });
  };

  const payAppointmentFee = async (
    facilityId: string,
    payload: IPayAppointmentFeePayload,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().payAppointmentFee(
        facilityId,
        payload,
      );

      return res.data;
    });
  };

  return {
    getAppointmentsReport,
    updateAppointmentAction,
    payAppointmentFee,
  };
});
