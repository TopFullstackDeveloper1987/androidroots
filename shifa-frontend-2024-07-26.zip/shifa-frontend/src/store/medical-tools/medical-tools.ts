import { defineStore } from 'pinia';
import { ref } from 'vue';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import { IMedicalReportPayload, IMedicalReportPrintPayload, IPractitioner, IPrescriptionPrintPayload } from '@/types';
import { useAuthStore } from '../auth';

export const useMedicalToolsStore = defineStore('medical-tools', () => {
  const commonStore = useCommonStore();
  const authStore = useAuthStore();
  const practitioner = ref<IPractitioner>();

  const getPractitionerDetails = async () => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getPractitionerDetails(
        authStore.userInfo.practitioner_id!,
      );
      practitioner.value = res.data;

      return res.data;
    });
  };

  const printPrescription = async (payload: IPrescriptionPrintPayload, design: number) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().printPrescription(
        authStore.userInfo.practitioner_id!,
        payload,
        design,
      );

      return res.data;
    });
  };

  const generateMedicalReport = async (payload: IMedicalReportPayload) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().generateMedicalReport(
        authStore.userInfo.practitioner_id!,
        payload,
      );

      return res.data;
    });
  };

  const printMedicalReport = async (payload: IMedicalReportPrintPayload) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().printMedicalReport(
        authStore.userInfo.practitioner_id!,
        payload,
      );

      return res.data;
    });
  };

  return {
    getPractitionerDetails,

    generateMedicalReport,
    printMedicalReport,
    printPrescription,
  };
});
