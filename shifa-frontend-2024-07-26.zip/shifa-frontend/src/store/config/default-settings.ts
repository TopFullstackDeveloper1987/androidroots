import { defineStore } from 'pinia';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import { useFacilityStore } from '../facility';

import {
  IConfig,
  ToastType,
  IConfigQuery,
  IConfigPayload,
  IConfigListQuery,
  ITemplateDesignPayload,
} from '@/types';
import { ref } from 'vue';
import { useI18n } from 'vue-i18n';

export const useDefaultSettingsStore = defineStore('default-settings', () => {
  const commonStore = useCommonStore();
  const facilityStore = useFacilityStore();

  const { t } = useI18n();

  const configs = ref<IConfig[]>([]);

  const getConfig = async (query: IConfigQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getConfig(
        facilityStore.currentFacilityId!,
        query,
      );

      configs.value = res.data;
      return res.data;
    });
  };

  const getConfigList = async (query: IConfigListQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getConfigList(
        facilityStore.currentFacilityId!,
        query,
      );

      return res.data;
    });
  };

  const addConfig = async (payload: IConfigPayload) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addConfig(
        facilityStore.currentFacilityId!,
        payload,
      );
      commonStore.showToast(ToastType.Success, t('notifications.config_added'));
      return res.data;
    });
  };

  const deleteConfig = async (configId: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deleteConfig(
        facilityStore.currentFacilityId!,
        configId,
      );
      commonStore.showToast(
        ToastType.Success,
        t('notifications.config_deleted'),
      );
      return res.data;
    });
  };

  const getConfigByNames = async (
    group: string,
    subGroup: string,
    pruuid: string,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getConfigByNames(
        facilityStore.currentFacilityId!,
        group,
        subGroup,
        pruuid,
      );
      return res.data;
    });
  };

  const getDefaultTemplateDesign = async (pruuid: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getDefaultTemplateDesign(
        facilityStore.currentFacilityId!,
        pruuid,
      );

      return res.data;
    });
  };

  const setDefaultTemplateDesign = async (payload: ITemplateDesignPayload) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().setDefaultTemplateDesign(
        facilityStore.currentFacilityId!,
        payload,
      );

      return res.data;
    });
  };

  const getVitalPanelConfig = async (query: IConfigQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getVitalPanelConfig(
        facilityStore.currentFacilityId!,
        query,
      );

      return res.data;
    });
  };

  const getEncounterConfigs = async (
    group: string,
    subGroup: string,
    pruuid: string,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getEncounterConfigs(
        group,
        subGroup,
        pruuid,
      );
      return res.data;
    });
  };

  const updateConfig = async (practitionerId: string, configName: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateConfig(
        practitionerId,
        facilityStore.currentFacilityId!,
        configName,
      );
      commonStore.showToast(ToastType.Success, t('notifications.config_added'));
      return res.data;
    });
  };

  const getDefaultAppointmentFeeValues = async (
    practitionerId: string,
    group: string,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getDefaultAppointmentFeeValues(
        practitionerId,
        group,
      );

      return res.data;
    });
  };

  return {
    configs,

    getConfigList,
    getConfig,
    addConfig,
    updateConfig,
    deleteConfig,
    getDefaultTemplateDesign,
    setDefaultTemplateDesign,
    getVitalPanelConfig,
    getConfigByNames,
    getEncounterConfigs,
    getDefaultAppointmentFeeValues,
  };
});
