// Complaints, Observations, Diagnosis
import { defineStore } from 'pinia';
import { ref } from 'vue';
import { useI18n } from 'vue-i18n';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import {
  ToastType,
  IPaginatedResponse,
  ICustomEncounter,
  CustomEncounterType,
  IFilterQuery,
  ICreateCustomEncounterPayload,
  ICreateCustomMedicationPayload,
} from '@/types';
import { useAuthStore } from '../auth';

export const useCustomEncountersStore = defineStore('custom-encounters', () => {
  const { t } = useI18n();

  const commonStore = useCommonStore();
  const authStore = useAuthStore();

  const searchResults = ref<IPaginatedResponse<ICustomEncounter>>();

  const searchCustomEncounters = async (
    encounterType: CustomEncounterType,
    params: IFilterQuery,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().searchCustomEncounters(
        authStore.userInfo.practitioner_id!,
        encounterType,
        params,
      );
      searchResults.value = res.data;

      return res.data;
    });
  };

  const createCustomEncounter = async (
    encounterType: CustomEncounterType,
    payload: ICreateCustomEncounterPayload | ICreateCustomMedicationPayload,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().createCustomEncounter(
        encounterType,
        payload,
      );
      commonStore.showToast(
        ToastType.Success,
        t('encounters.add_encounter_item_success', {
          encounter: encounterType,
        }),
      );
      return res.data;
    });
  };

  const updateCustomEncounter = async (
    encounterType: CustomEncounterType,
    payload: ICreateCustomEncounterPayload | ICreateCustomMedicationPayload,
    customEncounterId: number,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateCustomEncounter(
        encounterType,
        payload,
        customEncounterId,
      );
      commonStore.showToast(
        ToastType.Success,
        t('encounters.edit_encounter_item_success', {
          encounter: encounterType,
        }),
      );
      return res.data;
    });
  };

  const deleteCustomEncounter = async (
    encounterType: CustomEncounterType,
    customEncounterTypeId: number,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deleteCustomEncounter(
        authStore.userInfo.practitioner_id!,
        encounterType,
        customEncounterTypeId,
      );
      commonStore.showToast(
        ToastType.Success,
        t('encounters.add_encounter_item_success', {
          encounter: encounterType,
        }),
      );
      return res.data;
    });
  };

  const updateFavoriteCustomEncounter = async (
    encounterType: CustomEncounterType,
    customEncounterTypeId: number,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateFavoriteCustomEncounter(
        authStore.userInfo.practitioner_id!,
        encounterType,
        customEncounterTypeId,
      );

      return res.data;
    });
  };

  return {
    searchResults,

    searchCustomEncounters,
    createCustomEncounter,
    updateCustomEncounter,
    deleteCustomEncounter,
    updateFavoriteCustomEncounter,
  };
});
