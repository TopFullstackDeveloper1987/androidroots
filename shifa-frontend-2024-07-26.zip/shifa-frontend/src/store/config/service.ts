// Complaints, Observations, Diagnosis
import { defineStore } from 'pinia';
import { ref } from 'vue';
import { useI18n } from 'vue-i18n';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import {
  ToastType,
  IService,
  IServicePayload,
  IPaginatedResponse,
  IConfigPaginationQuery,
} from '@/types';
import { useAuthStore } from '../auth';

export const useServiceStore = defineStore('service', () => {
  const { t } = useI18n();

  const commonStore = useCommonStore();
  const authStore = useAuthStore();

  const searchResults = ref<IPaginatedResponse<IService>>();

  const searchServices = async (params?: IConfigPaginationQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().searchServices(
        authStore.userInfo.practitioner_id!,
        params,
      );
      searchResults.value = res.data;

      return res.data;
    });
  };

  const createService = async (payload: IServicePayload) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().createService(payload);
      commonStore.showToast(
        ToastType.Success,
        t('notifications.service_created'),
      );
      return res.data;
    });
  };

  const updateService = async (payload: IServicePayload, id: number) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateService(payload, id);
      commonStore.showToast(
        ToastType.Success,
        t('notifications.service_updated'),
      );
      return res.data;
    });
  };

  const updateFavoriteService = async (id: number) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateFavoriteService(
        authStore.userInfo.practitioner_id!,
        id,
      );

      return res.data;
    });
  };

  return {
    searchResults,

    searchServices,
    createService,
    updateService,
    updateFavoriteService,
  };
});
