// Complaints, Observations, Diagnosis
import { defineStore } from 'pinia';
import { ref } from 'vue';
import { useI18n } from 'vue-i18n';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import {
  ToastType,
  IProduct,
  IProductPayload,
  IPaginatedResponse,
  IConfigPaginationQuery,
} from '@/types';
import { useAuthStore } from '../auth';

export const useProductStore = defineStore('product', () => {
  const { t } = useI18n();

  const commonStore = useCommonStore();
  const authStore = useAuthStore();

  const searchResults = ref<IPaginatedResponse<IProduct>>();

  const searchProducts = async (params?: IConfigPaginationQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().searchProducts(
        authStore.userInfo.practitioner_id!,
        params,
      );
      searchResults.value = res.data;

      return res.data;
    });
  };

  const createProduct = async (payload: IProductPayload) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().createProduct(payload);
      commonStore.showToast(
        ToastType.Success,
        t('notifications.product_created'),
      );
      return res.data;
    });
  };

  const updateProduct = async (payload: IProductPayload, id: number) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateProduct(payload, id);
      commonStore.showToast(
        ToastType.Success,
        t('notifications.product_updated'),
      );
      return res.data;
    });
  };

  const updateFavoriteProduct = async (id: number) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateFavoriteProduct(
        authStore.userInfo.practitioner_id!,
        id,
      );

      return res.data;
    });
  };

  return {
    searchResults,

    searchProducts,
    createProduct,
    updateProduct,
    updateFavoriteProduct,
  };
});
