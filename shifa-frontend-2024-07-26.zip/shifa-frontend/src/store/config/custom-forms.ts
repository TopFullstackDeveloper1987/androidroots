// Complaints, Observations, Diagnosis
import { defineStore } from 'pinia';
import { ref } from 'vue';
import { useI18n } from 'vue-i18n';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import {
  IPaginatedResponse,
  IFilterQuery,
  ICustomForm,
  ToastType,
  ICustomFormPayload,
} from '@/types';
import { useAuthStore } from '../auth';

export const useCustomFormsStore = defineStore('custom-forms', () => {
  const { t } = useI18n();

  const commonStore = useCommonStore();
  const authStore = useAuthStore();

  const searchResults = ref<IPaginatedResponse<ICustomForm>>();

  const searchCustomForms = async (params: IFilterQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().searchCustomForms(
        authStore.userInfo.practitioner_id!,
        params,
      );
      searchResults.value = res.data;

      return res.data;
    });
  };

  const createCustomForm = async (payload: ICustomFormPayload) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().createCustomForm(payload);
      commonStore.showToast(
        ToastType.Success,
        t('notifications.custom_form_created'),
      );
      return res.data;
    });
  };

  const updateCustomForm = async (
    payload: ICustomFormPayload,
    customFormId: number,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateCustomForm(
        payload,
        customFormId,
      );
      commonStore.showToast(
        ToastType.Success,
        t('notifications.custom_form_updated'),
      );
      return res.data;
    });
  };

  const updateFavoriteCustomForm = async (customFormId: number) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateFavoriteCustomForm(
        authStore.userInfo.practitioner_id!,
        customFormId,
      );

      return res.data;
    });
  };

  return {
    searchResults,

    searchCustomForms,
    createCustomForm,
    updateCustomForm,
    updateFavoriteCustomForm,
  };
});
