export * from './bed-availability';
