import { defineStore } from 'pinia';
import { ref } from 'vue';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import { IWard, IBedQuery, IBed } from '@/types';
import { useFacilityStore } from '../facility';

export const useBedAvailabilityStore = defineStore('bed-availability', () => {
  const commonStore = useCommonStore();
  const floors = ref<IWard[]>();
  const facilityStore = useFacilityStore();

  const getBedStatusByWard = async () => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getBedStatusByWard(facilityStore.currentFacilityId!);

      return res.data;
    });
  };

  const getBeds = async (query?: IBedQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getBeds(facilityStore.currentFacilityId!, query);
      floors.value = res.data;

      return res.data;
    });
  };

  const addBed = async (payload: IBed) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addBed(facilityStore.currentFacilityId!, payload);

      return res.data;
    });
  };

  const updateBed = async (payload: IBed) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateBed(facilityStore.currentFacilityId!, payload);

      return res.data;
    });
  };

  const removeBed = async (id: number) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().removeBed(facilityStore.currentFacilityId!, id);

      return res.data;
    });
  };

  return {
    getBeds,
    getBedStatusByWard,
    addBed,
    updateBed,
    removeBed,
  };
});
