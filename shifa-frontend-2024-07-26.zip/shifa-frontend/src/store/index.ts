import { createPinia } from 'pinia';

export * from './appointment';
export * from './auth';
export * from './facility';
export * from './metadata';
export * from './patient';
export * from './common';
export * from './search';
export * from './practitioner';
export * from './orders';
export * from './billing';
export * from './config';
export * from './medical-records';
export * from './medical-tools';
export * from './bed-management';

export default createPinia();
