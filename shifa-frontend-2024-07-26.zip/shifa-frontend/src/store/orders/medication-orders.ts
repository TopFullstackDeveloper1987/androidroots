import { defineStore } from 'pinia';

import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import {
  IPaginatedResponse,
  IMedicationOrder,
  IMedicationOrderQuery,
  IMedicationOrderItemUpdatePayload,
} from '@/types';
import { ref } from 'vue';
import { useFacilityStore } from '../facility';

export const useMedicationOrderStore = defineStore('medication-orders', () => {
  const commonStore = useCommonStore();
  const facilityStore = useFacilityStore();
  const searchResults = ref<IPaginatedResponse<IMedicationOrder>>();

  const searchMedicationOrders = async (query: IMedicationOrderQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().searchMedicationOrders(
        facilityStore.currentFacilityId!,
        query,
      );
      searchResults.value = res.data;

      return res.data;
    });
  };

  const getMedicationItems = async (medicationOrderId: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getMedicationItems(
        facilityStore.currentFacilityId!,
        medicationOrderId,
      );

      return res.data;
    });
  };

  const deleteMedicationOrderItem = async (medicationOrderId: string, medicationOrderItemId: number) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deleteMedicationOrderItem(
        facilityStore.currentFacilityId!,
        medicationOrderId,
        medicationOrderItemId,
      );

      return res.data;
    });
  };

  const updateMedicationItemInstruction = async (medicationOrderId: string, medicationOrderItemId: number, payload: IMedicationOrderItemUpdatePayload) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateMedicationItemInstruction(
        facilityStore.currentFacilityId!,
        medicationOrderId,
        medicationOrderItemId,
        payload,
      );

      return res.data;
    });
  };

  return {
    searchResults,

    searchMedicationOrders,
    getMedicationItems,
    deleteMedicationOrderItem,
    updateMedicationItemInstruction,
  };
});
