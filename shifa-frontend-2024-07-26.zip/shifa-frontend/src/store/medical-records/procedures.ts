import { defineStore } from 'pinia';
import { ref } from 'vue';

import { useI18n } from 'vue-i18n';

import { ApiService } from '@/services';
import { useAuthStore } from '../auth';
import { useCommonStore } from '../common';
import { usePatientStore } from '../patient';
import { useFacilityStore } from '../facility';
import {
  ToastType,
  IPaginatedResponse,
  IProcedureQuery,
  IProcedure,
  IProcedurePayload,
  IProcedureItemQuery,
} from '@/types';

export const useProcedureStore = defineStore('procedures', () => {
  const { t } = useI18n();

  const authStore = useAuthStore();
  const commonStore = useCommonStore();
  const patientStore = usePatientStore();
  const facilityStore = useFacilityStore();
  const searchResults = ref<IPaginatedResponse<IProcedure>>();

  const getProcedures = async (query: IProcedureQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getProcedures(
        facilityStore.currentFacilityId!,
        query,
      );
      searchResults.value = res.data;

      return res.data;
    });
  };

  const getProcedureDetails = async (procedureId: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getProcedureDetails(
        facilityStore.currentFacilityId!,
        procedureId,
      );
      return res.data;
    });
  };

  const getProcedureItems = async (query?: IProcedureItemQuery) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getProcedureItems(
        authStore.userInfo.practitioner_id!,
        query!,
      );
      return res.data;
    });
  };

  const addProcedure = async (payload: IProcedurePayload) => {
    const newPayload = {
      ...payload,
      facility: facilityStore.currentFacilityId,
      patient: patientStore.currentPatientId,
    };
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addProcedure(
        facilityStore.currentFacilityId!,
        newPayload,
      );
      commonStore.showToast(
        ToastType.Success,
        t('notifications.procedure_created'),
      );
      return res.data;
    });
  };

  const updateProcedure = async (id: string, payload: IProcedurePayload) => {
    const newPayload = {
      ...payload,
      facility: facilityStore.currentFacilityId,
      patient: patientStore.currentPatientId,
    };
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateProcedure(
        facilityStore.currentFacilityId!,
        id,
        newPayload,
      );
      commonStore.showToast(
        ToastType.Success,
        t('notifications.procedure_updated'),
      );
      return res.data;
    });
  };

  return {
    searchResults,

    getProcedures,
    getProcedureItems,
    getProcedureDetails,

    addProcedure,
    updateProcedure,
  };
});
