import { defineStore } from 'pinia';

import { ref } from 'vue';
import { ApiService } from '@/services';
import { useCommonStore } from '../common';
import { useFacilityStore } from '../facility';
import {
  IEncounter,
  IEncounterPayload,
  IEncounterItem,
  IEncounterFollowup,
  IImagingOrderPayload,
  ILabOrderPayload,
  IEncounterImagingOrder,
  IEncounterLabOrder,
  IMedicationOrderPayload,
  IEncounterUpdatePayloadItem,
} from '@/types';

export const useEncounterStore = defineStore('encounter', () => {
  const commonStore = useCommonStore();
  const facilityStore = useFacilityStore();

  const encounters = ref<IEncounter[]>([]);
  const currentEncounter = ref<IEncounter>(<IEncounter>{});

  const setEncounters = (_encounters: IEncounter[]) => {
    encounters.value = _encounters;
  };

  const setCurrentEncounter = (encounter: IEncounter) => {
    currentEncounter.value = encounter;
  };

  const getEncountersReport = async (groupBy: string, fromDate: string, toDate: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getEncountersReport(facilityStore.currentFacilityId!, groupBy, fromDate, toDate);

      return res.data;
    });
  };

  const getTopComplaintData = async (groupBy: string, fromDate: string, toDate: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getTopComplaintData(facilityStore.currentFacilityId!, groupBy, fromDate, toDate);

      return res.data;
    });
  };

  const getTopDiagnosisData = async (groupBy: string, fromDate: string, toDate: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getTopDiagnosisData(facilityStore.currentFacilityId!, groupBy, fromDate, toDate);

      return res.data;
    });
  };

  const getPatientEncounters = async (
    patientId: string,
    isLoadDetail = true,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res =
        await ApiService.getInstance().getPatientEncounters(patientId);
      const encounters = res.data.sort((a, b) =>
        a.encounter_date.localeCompare(b.encounter_date),
      );
      setEncounters(encounters);

      if (isLoadDetail) {
        getPatientEncounter(
          encounters.length
            ? encounters[encounters.length - 1]
            : <IEncounter>{},
        );
      }

      return encounters;
    });
  };

  const getPatientEncounter = async (encounter: IEncounter) => {
    if (!encounter.id) return;
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getPatientEncounter(
        encounter.id,
      );
      setCurrentEncounter(res.data);
      return res.data;
    });
  };

  const addPatientEncounter = async (payload: IEncounter) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addPatientEncounter(payload);
      return res.data;
    });
  };

  const updatePatientEncounter = async (encounterId: string, payload: any) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updatePatientEncounter(
        encounterId,
        payload,
      );
      return res.data;
    });
  };

  const updateComplaintEncounter = async (encounterId: string, complaintId: number, payload: IEncounterUpdatePayloadItem) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().updateComplaintEncounter(
        encounterId,
        complaintId,
        payload,
      );
      return res.data;
    });
  };

  const getEncounterItems = async (encounterId: string, key: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getEncounterItems(
        encounterId,
        key,
      );
      return res.data;
    });
  };

  const addEncounterItem = async (
    payload: IEncounterItem | IEncounterFollowup,
    key: string,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addEncounterItem(payload, key);
      return res.data;
    });
  };

  const addEncounter = async (
    payload: IEncounterPayload,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addEncounter(payload);
      return res.data;
    });
  };

  const deleteEncounterItem = async (
    payload: IEncounterItem | IEncounterFollowup,
    key: string,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deleteEncounterItem(
        payload,
        key,
      );
      return res.data;
    });
  };

  const addImagingOrder = async (payload: IImagingOrderPayload) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addImagingOrder(payload);
      return res.data;
    });
  };

  const deleteImagingOrder = async (payload: IEncounterImagingOrder) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deleteImagingOrder(payload);
      return res.data;
    });
  };

  const printImagingOrder = async (imagingOrderId: string) => {
    return commonStore.actionWrapper(async () => {
      const res =
        await ApiService.getInstance().printImagingOrder(imagingOrderId);
      return res.data;
    });
  };

  const downloadImagingOrder = async (imagingOrderId: string) => {
    return commonStore.actionWrapper(async () => {
      const res =
        await ApiService.getInstance().downloadImagingOrder(imagingOrderId);
      return res.data;
    });
  };

  const addLabOrder = async (payload: ILabOrderPayload) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addLabOrder(payload);
      return res.data;
    });
  };

  const deleteLabOrder = async (payload: IEncounterLabOrder) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deleteLabOrder(payload);
      return res.data;
    });
  };

  const printLabOrder = async (labOrderId: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().printLabOrder(labOrderId);
      return res.data;
    });
  };

  const downloadLabOrder = async (labOrderId: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().downloadLabOrder(labOrderId);
      return res.data;
    });
  };

  const getlabTestProfileItems = async (profileId: number) => {
    return commonStore.actionWrapper(async () => {
      const res =
        await ApiService.getInstance().getlabTestProfileItems(profileId);
      return res.data;
    });
  };

  const addMedicationOrder = async (
    facilityId: string,
    payload: IMedicationOrderPayload,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().addMedicationOrder(
        facilityId,
        payload,
      );
      return res.data;
    });
  };

  const deleteMedicationOrder = async (
    facilityId: string,
    medicationOrderId: string,
  ) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().deleteMedicationOrder(
        facilityId,
        medicationOrderId,
      );
      return res.data;
    });
  };

  const printMedicationOrder = async (medicationOrderId: string) => {
    return commonStore.actionWrapper(async () => {
      const res =
        await ApiService.getInstance().printMedicationOrder(medicationOrderId);
      return res.data;
    });
  };

  const downloadMedicationOrder = async (medicationOrderId: string) => {
    return commonStore.actionWrapper(async () => {
      const res =
        await ApiService.getInstance().downloadMedicationOrder(
          medicationOrderId,
        );
      return res.data;
    });
  };

  const getEncounterDocumentPdf = (type: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getEncounterDocumentPdf(
        type,
        currentEncounter.value.id,
      );
      return res.data;
    });
  };

  const getEncounterDocumentHtml = (type: string) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getEncounterDocumentHtml(
        type,
        currentEncounter.value.id,
      );
      return res.data;
    });
  };

  const getCustomForm = (formId: number) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().getCustomForm(
        currentEncounter.value.id,
        formId,
      );
      return res.data;
    });
  };

  const saveCustomForm = (formId: number, payload: any) => {
    return commonStore.actionWrapper(async () => {
      const res = await ApiService.getInstance().saveCustomForm(
        currentEncounter.value.id,
        formId,
        payload,
      );
      return res.data;
    });
  };

  return {
    getPatientEncounters,
    getPatientEncounter,
    addPatientEncounter,
    updatePatientEncounter,

    getEncountersReport,
    getTopComplaintData,
    getTopDiagnosisData,

    getEncounterItems,
    addEncounterItem,
    addEncounter,
    deleteEncounterItem,
    updateComplaintEncounter,

    setCurrentEncounter,

    addImagingOrder,
    deleteImagingOrder,
    printImagingOrder,
    downloadImagingOrder,

    addLabOrder,
    deleteLabOrder,
    printLabOrder,
    downloadLabOrder,
    getlabTestProfileItems,

    addMedicationOrder,
    deleteMedicationOrder,
    printMedicationOrder,
    downloadMedicationOrder,

    getEncounterDocumentPdf,
    getEncounterDocumentHtml,

    getCustomForm,
    saveCustomForm,

    encounters,
    currentEncounter,
  };
});
