import {
  AppointmentEvents,
  IAppointment,
  InvoiceEvents,
  ProcedureEvents,
  ConfigurationEvents,
} from '@/types';
import mitt from 'mitt';

type Events = {
  [AppointmentEvents.ReloadAppointments]: void;
  [AppointmentEvents.ShowAppointmentUpdateDialog]: IAppointment;
  [InvoiceEvents.ReloadInvoices]: void;
  [ConfigurationEvents.ReloadConfig]: void;
  [ConfigurationEvents.ReloadCustomEncounters]: void;
  [ConfigurationEvents.ReloadMedicalRecords]: void;
  [ProcedureEvents.ReloadProcedures]: void;
};

export const events = mitt<Events>();
