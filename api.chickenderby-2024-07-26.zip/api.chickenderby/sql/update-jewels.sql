-- update jewel address besides weth
update races set coinContract = '0xACde0153a05be20eEe9c2771EFcf4918E367f25c' where coinContract != '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619';
update autoRacePools set coinContract = '0xACde0153a05be20eEe9c2771EFcf4918E367f25c' where coinContract != '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619';
update raceHistories set coinContract = '0xACde0153a05be20eEe9c2771EFcf4918E367f25c' where coinContract != '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619';
