class PrizePoolError extends Error {
  data: any;

  constructor(message: string, data: any = null) {
    super(message);

    this.name = this.constructor.name;
    this.data = data;

    // Capturing stack trace, excluding constructor call from it.
    Error.captureStackTrace(this, this.constructor);
  }
}

export default PrizePoolError;
