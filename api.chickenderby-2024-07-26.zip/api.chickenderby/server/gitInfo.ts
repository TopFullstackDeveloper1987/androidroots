import * as fs from 'fs';
import * as path from 'path';
import { execSync } from 'child_process';

import { log } from './utils';

const execSyncWrapper = (command: string) => {
  let stdout = null;
  try {
    stdout = execSync(command).toString().trim();
  } catch (error) {
    log.error(error);
  }
  return stdout;
};

export const updateGitInfo = (filename: string) => {
  const gitBranch = execSyncWrapper('git rev-parse --abbrev-ref HEAD');
  const gitCommitHash = execSyncWrapper('git rev-parse --short=7 HEAD');

  const obj = {
    gitBranch,
    gitCommitHash,
  };

  const filePath = path.resolve(__dirname, filename);
  const fileContents = JSON.stringify(obj, null, 2);

  fs.writeFileSync(filePath, fileContents);
  log.info(`Wrote the following contents to ${filePath}\n${fileContents}`);
};
