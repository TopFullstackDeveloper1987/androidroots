const ERRORS_REQUIRE_NEW_SIGNATURE = [
  'execution reverted: Signer and signature do not match',
];

const ERRORS_REQUIRE_SAME_SIGNATURE = [
  'Transaction was not mined within',
];

export const isErrorRequireNewSignature = (message: string) => Boolean(ERRORS_REQUIRE_NEW_SIGNATURE.find((errorMsg) => message?.includes && message.toLowerCase().includes(errorMsg.toLowerCase())));

export const isErrorRequireSameSignature = (message: string) => Boolean(ERRORS_REQUIRE_SAME_SIGNATURE.find((errorMsg) => message?.includes && message.toLowerCase().includes(errorMsg.toLowerCase())));

export const isErrorRequireRetry = (message: string) => isErrorRequireNewSignature(message) || isErrorRequireSameSignature(message);
