import cors from 'cors';
import * as bunyan from 'bunyan';
import { Request } from 'express';
import { countries } from 'countries-list';

import config from '../config';
import { ValueWeightPair } from '../types/shared/valueWeight';

export const corsHandler = cors({
  origin: config.corsWhiteList,
  // methods: ['GET', 'HEAD', 'PUT', 'PATCH', 'POST', 'DELETE', 'OPTIONS'],
  credentials: true,
  allowedHeaders: [
    'Content-Type',
    'Content-Length',
    'Content-Range',
    'Content-Disposition',
    'Content-Description',
    'Access-Control-Allow-Origin',
    'Access-Control-Request-Method',
    'Authorization',
    'Origin',
    'X-Requested-With',
    'X-AUTH-TOKEN',
    'x-basic-auth-token',
  ],
});

export const log = bunyan.createLogger({
  name: 'CD',
  serializers: {
    err: bunyan.stdSerializers.err,
  },
});

export const truncateToDecimals = (num: number, dec = 2) => {
  const calcDec = 10 ** dec;

  return Math.trunc(num * calcDec) / calcDec;
};

export const sleep = async (ms: number) => new Promise((resolve) => {
  setTimeout(resolve, ms);
});

export const findNthIndex = (array: any[], searchFunc: Function, n: number) => {
  const indices: number[] = [];
  array.forEach((element, i) => {
    if (searchFunc(element)) {
      indices.push(i);
    }
  });

  // Check if undefined to include zero index
  return indices[n] !== undefined ? indices[n] : -1;
};

export const getPaginationInput = (req: Request, {
  defaultPage = 1,
  defaultLimit = 10,
  defaultFilter,
  defaultSort = { field: 'id', order: 'DESC' },
}: {
  defaultPage?: number,
  defaultLimit?: number,
  defaultFilter?: string,
  defaultSort?: { field: string, order: string },
} = {}) => {
  const paginationNoLimitKey = req.headers['x-pg-no-limit-key'];

  const { query } = req;
  const page = query.page ? Number(query.page) : defaultPage;
  let limit = query.limit ? Math.min(Number(query.limit), config.MAX_PAGINATION_LIMIT) : defaultLimit;
  if (paginationNoLimitKey === config.PAGINATION_NO_LIMIT_KEY) {
    limit = query.limit ? Number(query.limit) : defaultLimit;
  }
  const filter = query.filter ? JSON.parse(query.filter as string) : defaultFilter;
  const sort = query.sort ? JSON.parse(query.sort as string) : defaultSort;

  return {
    page,
    limit,
    filter,
    sort,
  };
};

export const getPaginationInputForHawhu = (req: Request, {
  defaultPage = 0,
  defaultPageSize = 10,
}: {
  defaultPage?: number,
  defaultPageSize?: number,
} = {}) => {
  const { query } = req;
  const page = query.page ? Number(query.page) : defaultPage;
  const limit = query.page_size ? Math.min(Number(query.page_size), config.MAX_PAGINATION_LIMIT) : defaultPageSize;

  return {
    page,
    limit,
    updatedStart: query.updated_start && Number(query.updated_start),
    updatedEnd: query.updated_end && Number(query.updated_end),
  };
};

export const getRandomValueIndexFromWeight = <T>(valueWeights: ValueWeightPair<T>[]) => {
  let totalWeight = 0;
  const chances: {
    min: number;
    max: number;
  }[] = [];
  let minChance = 0;
  let maxChance = 0;

  for (const valueWeight of valueWeights) {
    const { weight } = valueWeight;
    minChance = maxChance;
    maxChance = minChance + weight;

    chances.push({
      min: minChance,
      max: maxChance,
    });

    totalWeight += weight;
  }

  const linearWeight = Math.random() * totalWeight;
  const chanceIndex = chances.findIndex((chance) => linearWeight >= chance.min && linearWeight < chance.max);

  return chanceIndex;
};

export const getRandomValueFromWeight = <T>(valueWeights: ValueWeightPair<T>[]) => {
  const chanceIndex = getRandomValueIndexFromWeight(valueWeights);
  return valueWeights[chanceIndex].value;
};

export const getCountryFlagFromName = (countryName: string) => {
  const country = Object.values(countries).find(c => c.name === countryName);
  return country?.emoji;
};

export const shuffleArray = (arr: any[]) => {
  const ar = arr;

  for (let i = ar.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = ar[i];
    ar[i] = ar[j];
    ar[j] = temp;
  }

  return ar;
};
