/* eslint-disable max-len */
export const COLLECTION_MANAGER_CONTRACT = {
  address: process.env.COLLECTION_MANAGER_CONTRACT_ADDRESS || '0x37a4535c4cbb2c08e5371dea3ed97c25a2ed38ae',
  // @ts-ignore
  abi: [{ inputs: [], name: 'CollectionExists', type: 'error' }, { inputs: [], name: 'CollectionNotExists', type: 'error' }, {
    anonymous: false,
    inputs: [{
      indexed: true, internalType: 'address', name: 'nftContract', type: 'address',
    }],
    name: 'CollectionRemoved',
    type: 'event',
  }, {
    anonymous: false,
    inputs: [{
      indexed: true, internalType: 'address', name: 'nftContract', type: 'address',
    }],
    name: 'CollectionWhitelisted',
    type: 'event',
  }, {
    anonymous: false,
    inputs: [{
      indexed: true, internalType: 'address', name: 'previousOwner', type: 'address',
    }, {
      indexed: true, internalType: 'address', name: 'newOwner', type: 'address',
    }],
    name: 'OwnershipTransferred',
    type: 'event',
  }, {
    inputs: [{ internalType: 'address', name: '_nftContract', type: 'address' }], name: 'addCollection', outputs: [], stateMutability: 'nonpayable', type: 'function',
  }, {
    inputs: [{ internalType: 'address', name: '_nftContract', type: 'address' }], name: 'isCollectionWhitelisted', outputs: [{ internalType: 'bool', name: '', type: 'bool' }], stateMutability: 'view', type: 'function',
  }, {
    inputs: [], name: 'owner', outputs: [{ internalType: 'address', name: '', type: 'address' }], stateMutability: 'view', type: 'function',
  }, {
    inputs: [{ internalType: 'address', name: '_nftContract', type: 'address' }], name: 'removeCollection', outputs: [], stateMutability: 'nonpayable', type: 'function',
  }, {
    inputs: [], name: 'renounceOwnership', outputs: [], stateMutability: 'nonpayable', type: 'function',
  }, {
    inputs: [{ internalType: 'address', name: 'newOwner', type: 'address' }], name: 'transferOwnership', outputs: [], stateMutability: 'nonpayable', type: 'function',
  }],
};
