import { BICONOMY_FORWARDER_CONTRACT } from '../abi/biconomyForwarderContract';
import { CHICKEN_CONTRACT } from '../abi/chickenContract';
import { RACE_CONTRACT } from '../abi/raceContract';
import { LAND_CONTRACT } from '../abi/landContract';
import { COLLECTION_MANAGER_CONTRACT } from '../abi/collectionManagerContract';
import { MARKETPLACE_CONTRACT } from '../abi/marketplaceContract';
import { WETH_CONTRACT } from '../abi/wethContract';
import { CLOTHING_CONTRACT } from '../abi/clothingContract';
import { FUSION_CONTRACT } from '../abi/fusionContract';
import { CHAINLINK_ETH_USD_CONTRACT } from '../abi/chainLinkEthUSDContract';
import { CHICKEN_STAKING_CONTRACT } from '../abi/chickenStakingContract';
import { BAWK_PRESALE_CONTRACT } from '../abi/bawkPresaleConract';
import { COIN_PRESALE_CONTRACT } from '../abi/coinPresaleContract';

const ALCHEMY_POLYGON_MAINNET_URL = 'https://polygon-mainnet.g.alchemy.com';
const ALCHEMY_POLYGON_API_KEY = process.env.ALCHEMY_POLYGON_API_KEY || 'nNl47pfectnxG5QF__OWohFxcb6Ua2Ht';

const config = {
  SECRET: process.env.SECRET,
  PORT: process.env.PORT,
  corsWhiteList: [
    'https://www.chickenderby.com', // frontend
    'https://beta.chickenderby.com', // frontend staging
    'http://localhost:3000', // local frontend
    'http://192.168.0.81:3000',

    'https://admin.chickenderby.com', // admin
    'https://admin-dev.chickenderby.com', // admin staging
    'http://localhost:3001', // local admin

    'https://play.chickenderby.com', // game viewer
    'https://play-dev.chickenderby.com', // game viewer staging
    'http://localhost:8080', // game viewer local

    'https://world.chickenderby.com', // virtual world
    'https://world-dev.chickenderby.com', // virtual world staging
    'http://localhost:3002', // virtual world local
  ],
  redis: {
    port: Number(process.env.REDIS_PORT),
    host: process.env.REDIS_HOST,
    password: process.env.REDIS_PASSWORD,

    // @ts-ignore
    maxRetriesPerRequest: null,
    enableReadyCheck: false,
    reconnectOnError: (err: any) => {
      // https://github.com/luin/ioredis#reconnect-on-error
      if (err && err.message && err.message.includes('READONLY')) {
        return true;
      }

      return false;
    },
  },
  defaultJobOptions: {
    removeOnComplete: 1000,
    removeOnFail: 1000,
  },
  MAX_CONCURRENT_WORKERS_FOR_ENTER: 100,
  MAX_CONCURRENT_WORKERS_FOR_PERFORM_RACE: 100,
  MAX_CONCURRENT_WORKERS_FOR_MINT_LAND: 100,
  MAX_CONCURRENT_WORKERS_FOR_MARKETPLACE: 100,
  MAX_CONCURRENT_WORKERS_FOR_FUSION: 100,
  MAX_CONCURRENT_WORKERS_FOR_SERUM_MINT: 100,
  MAX_CONCURRENT_WORKERS_FOR_CHICKEN_SITUATION_RESET: 500,
  lock: {
    assignLane: 'assign-lane-lock-key',
    enterRace: 'enter-race-lock-key',
    mintLand: 'mint-land-lock-key',
    marketplace: 'marketplace-lock-key',
    fusion: 'fusion-lock-key',
    fusionMint: 'fusion-mint-lock-key',
    claimBawkPresaleInviteCode: 'claim-bawk-presale-invite-code-key',
    seasonRanking: 'season-ranking-lock-key',
    training: {
      gachaPull: 'gacha-pull',
    },
    bawkStaking: 'bawk-staking-lock-key',
  },
  MAX_ENTRY_FEE_FOR_RACE: {
    WETH: 0.2,
    JEWEL: 35000, // $500
  },
  MAX_CHICKENS_PER_FREE_RACE: 1,
  MAX_CHICKENS_PER_PAID_RACE: 2,
  AUTH_TOKEN_EXPIRATION_HOURS: 24,
  // to check JWT expiration beforehand on contract write operations
  AUTH_TOKEN_EXPIRATION_CHECK_MINUTES: 30,

  // Web3 Config
  MATIC_CHAIN_ID: 137,
  ETH_CHAIN_ID: 1,
  SEPOLIA_CHAIN_ID: 11155111,
  CHICKEN_CONTRACT,
  RACE_CONTRACT,
  LAND_CONTRACT,
  BICONOMY_FORWARDER_CONTRACT,
  COLLECTION_MANAGER_CONTRACT,
  MARKETPLACE_CONTRACT,
  WETH_CONTRACT,
  CLOTHING_CONTRACT,
  FUSION_CONTRACT,
  CHAINLINK_ETH_USD_CONTRACT,
  CHICKEN_STAKING_CONTRACT,
  BAWK_PRESALE_CONTRACT,
  COIN_PRESALE_CONTRACT,

  ALCHEMY_ETH_API_KEY: process.env.ALCHEMY_ETH_API_KEY,
  ALCHEMY_SEPOILA_API_KEY: process.env.ALCHEMY_SEPOILA_API_KEY || 'LaPBl5MZILY-xto1on-Au8eT4eXfVFQq',
  ALCHEMY_POLYGON_MAINNET_URL,
  ALCHEMY_POLYGON_API_KEY,
  POLYGON_MAINNET_PROVIDER_URL: `${ALCHEMY_POLYGON_MAINNET_URL}/v2/${ALCHEMY_POLYGON_API_KEY}`,
  ETH_MAINNET_PROVIDER_URL: 'https://eth-mainnet.alchemyapi.io/v2/VmxTbO58cEOJSUrJsC5D0_mOHjP8twLv',
  ETH_SEPOLIA_PROVIDER_URL: 'https://eth-sepolia.g.alchemy.com/v2/LaPBl5MZILY-xto1on-Au8eT4eXfVFQq',

  ADMIN_SIGNER_PRIVATE_ADDRESS: process.env.ADMIN_SIGNER_PRIVATE_ADDRESS,
  MARKETPLACE_ADMIN_SIGNER_PRIVATE_ADDRESS: process.env.MARKETPLACE_ADMIN_SIGNER_PRIVATE_ADDRESS,
  FUSION_ADMIN_SIGNER_PRIVATE_ADDRESS: process.env.FUSION_ADMIN_SIGNER_PRIVATE_ADDRESS,

  NUMBER_OF_ENTER_RETRIES: 2,
  NUMBER_OF_PAYOUT_RETRIES: 3,
  BICONOMY_CUSTOM_GAS_LIMIT: Number(process.env.BICONOMY_CUSTOM_GAS_LIMIT) || 500000, // 500K
  BICONOMY_CUSTOM_GAS_LIMIT_FACTOR_FOR_LOOP: Number(process.env.BICONOMY_CUSTOM_GAS_LIMIT_FACTOR_FOR_LOOP) || 0.5, // 50%
  CUSTOM_GAS_LIMIT: Number(process.env.CUSTOM_GAS_LIMIT) || 600000, // 600K

  BICONOMY_API_KEY: 'zoU4ADq2m.965bc4fe-1c7b-47e4-8b14-e48145f7e48d',
  BICONOMY_RACE_ENTER_API_ID: process.env.BICONOMY_RACE_ENTER_API_ID || '426e29e5-a0b8-4358-b530-602cbbc8ea07',
  BICONOMY_RACE_PAYOUT_API_ID: process.env.BICONOMY_RACE_PAYOUT_API_ID || '85e6f42d-3b7d-4873-9fc3-28aad3b79107',

  BICONOMY_LAND_MINT_API_ID: process.env.BICONOMY_LAND_MINT_API_ID || '3e0ec0cb-b779-41bc-8213-4ace6eb77af0',

  BICONOMY_MARKETPLACE_CREATE_MARKET_ITEM_API_ID: process.env.BICONOMY_MARKETPLACE_CREATE_MARKET_ITEM_API_ID || '9d6f5bb7-0fbf-4fd8-a6c8-ad61a0cdd151',
  BICONOMY_MARKETPLACE_EDIT_MARKET_ITEM_API_ID: process.env.BICONOMY_MARKETPLACE_EDIT_MARKET_ITEM_API_ID || '3c81b78c-d369-4562-870e-e00989880b53',
  BICONOMY_MARKETPLACE_CANCEL_MARKET_ITEM_API_ID: process.env.BICONOMY_MARKETPLACE_CANCEL_MARKET_ITEM_API_ID || 'b1df6943-fce8-469b-8896-8e3551a27f81',
  BICONOMY_MARKETPLACE_CANCEL_MULTIPLE_MARKET_ITEMS_API_ID: process.env.BICONOMY_MARKETPLACE_CANCEL_MULTIPLE_MARKET_ITEMS_API_ID || '6897fc14-3258-44b5-b60e-f7cd0ad162ea',
  NUMBER_OF_MARKETPLACE_AUTO_CANCEL_RETRIES: 3,

  BICONOMY_MARKETPLACE_MAKE_OFFER_API_ID: process.env.BICONOMY_MARKETPLACE_MAKE_OFFER_API_ID || '999922f3-2c1d-4fbb-8583-24759263db86',
  BICONOMY_MARKETPLACE_EDIT_OFFER_API_ID: process.env.BICONOMY_MARKETPLACE_EDIT_OFFER_API_ID || '3279d833-25a1-45f2-a1b5-f17b25b0710b',
  BICONOMY_MARKETPLACE_CANCEL_OR_DECLINE_OFFER_API_ID: process.env.BICONOMY_MARKETPLACE_CANCEL_OR_DECLINE_OFFER_API_ID || 'db7fd9a7-5b88-4d49-a9b6-9a3b441c0c28',
  BICONOMY_MARKETPLACE_DECLINE_MULTIPLE_OFFERS_API_ID: process.env.BICONOMY_MARKETPLACE_DECLINE_MULTIPLE_OFFERS_API_ID || '7e12c13c-3e58-45c2-9b3b-b86252619bfb',
  NUMBER_OF_MARKETPLACE_AUTO_DECLINE_RETRIES: 3,

  BICONOMY_SERUM_MINT_API_ID: process.env.BICONOMY_SERUM_MINT_API_ID || 'fab5b136-1643-44c8-828b-7edc89503882',

  BICONOMY_CHICK_STAKING_START_STAKING_PERIOD_API_ID: process.env.BICONOMY_CHICK_STAKING_START_STAKING_PERIOD_API_ID || '6caaf037-001f-4875-8c40-e9a1aa4c6547',
  BICONOMY_BAWK_STAKING_START_API_ID: process.env.BICONOMY_BAWK_STAKING_START_API_ID || '074e3c31-c0ec-4183-b6b7-d2191aed7766',
  BICONOMY_BAWK_STAKING_STAKE_API_ID: process.env.BICONOMY_BAWK_STAKING_STAKE_API_ID || 'db02e5f7-301a-49ca-8e49-610afbe6305c',
  BICONOMY_BAWK_STAKING_UNSTAKE_API_ID: process.env.BICONOMY_BAWK_STAKING_UNSTAKE_API_ID || 'a954909b-90b2-4be9-b33a-0e6e8c9b6878',
  BICONOMY_BAWK_STAKING_CLAIM_API_ID: process.env.BICONOMY_BAWK_STAKING_CLAIM_API_ID || '1022f5cd-e5a0-4df5-b223-44739d8ea7c3',
  BICONOMY_BAWK_ESCROW_STAKE_API_ID: process.env.BICONOMY_BAWK_ESCROW_STAKE_API_ID || '3fa36afe-e626-4d34-9f5f-8b556fed9128',
  BICONOMY_BAWK_ESCROW_UNSTAKE_API_ID: process.env.BICONOMY_BAWK_ESCROW_UNSTAKE_API_ID || '173a7a63-920a-413b-9999-c2939907446f',
  BICONOMY_BAWK_ESCROW_CLAIM_API_ID: process.env.BICONOMY_BAWK_ESCROW_CLAIM_API_ID || '53b095f2-3df5-4759-b417-c738378b6285',
  BICONOMY_BAWK_ESCROW_APPEND_API_ID: process.env.BICONOMY_BAWK_ESCROW_APPEND_API_ID || 'b0f43ecb-fbdd-4379-a865-a4933bf7c705',

  TRANSACTION_RECEIPT_TIMEOUT: 1000, // 1000 seconds (about 250 blocks)

  // git commit files
  SERVER_GIT_JSON: 'serverGit.json',
  RACE_JOBS_GIT_JSON: 'raceJobsGit.json',
  MARKETPLACE_JOBS_GIT_JSON: 'marketplaceJobsGit.json',
  FUSION_JOBS_GIT_JSON: 'fusionJobsGit.json',
  COIN_PRESALE_JOBS_GIT_JSON: 'coinPresaleJobsGit.json',
  slack: {
    raceAlertWebhookUrl: 'https://hooks.slack.com/services/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',
    testingWebhookUrl: 'https://hooks.slack.com/services/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',
  },
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:3000',

  alert: {
    raceFailure: 'race-failure',
  },

  bull: {
    // Keep the bull history only for one week to avoid redis overflow
    historyTTLInHours: 7 * 24,
    admin: {
      name: process.env.BULL_ADMIN_NAME || 'admin',
      password: process.env.BULL_ADMIN_PASSWORD || 'chickenderby',
    },
  },
  G_RECAPTCHA_PROJECT_ID: 'chicken-derby-347717',
  G_RECAPTCHA_SITE_KEY: '6LeXS-YgAAAAAAu4EIlTF6OzNJqATT2MYw-5Ky72',
  FIREBASE_NOTIFICATION_TOKEN:
    // eslint-disable-next-line max-len
    'AAAAU_iCqkE:APA91bHC7TIOzoC6lwniLmmNqXjt3P9pSsJFT8Rfj_PmYumceVHChObsiA0P28NBdv0DRRY5FJbKpVOWRWjOj3DXBPIBdNS2gHSqk_ug32QhzmRS2VP-WDLy-kW0vM8ioqrDNgPI3-Zp',
  DEFAULT_FREE_RACE_COUNTER_LIMIT: 0.0125,
  CMC_API_KEY: process.env.CMC_API_KEY,
  CMC_CACHE_TTL: 30, // CMC API call rate limit: 2 requests a minute
  COOP_LIMIT: 6,
  DISCORD: {
    CLIENT_ID: process.env.DISCORD_CLIENT_ID,
    SECRET: process.env.DISCORD_CLIENT_SECRET,
    BOT_TOKEN: process.env.DISCORD_BOT_TOKEN,
    GUILD_ID: process.env.DISCORD_GUILD_ID,
  },
  CHICK_RACES_LIMIT: 7,
  RACE_SYNC_LIMIT: 100,
  RACE_SYNC_DURATION_MINUTES: Number(process.env.RACE_SYNC_DURATION_MINUTES) || 5,

  BASIC_AUTH_USERNAME: process.env.BASIC_AUTH_USERNAME,
  BASIC_AUTH_PASSWORD: process.env.BASIC_AUTH_PASSWORD,
  REQUIRED_BASIC_AUTH: process.env.REQUIRED_BASIC_AUTH === '1',
  MAX_PAGINATION_LIMIT: 25,
  PAGINATION_NO_LIMIT_KEY: process.env.PAGINATION_NO_LIMIT_KEY,

  POLYGONSCAN_API_URL: 'https://api.polygonscan.com/api',
  POLYGONSCAN_API_KEY: process.env.POLYGONSCAN_API_KEY || '5VNZAC467MABVS53RGMREZGVP3V8ZC7MBB',
  MARKETPLACE_SYNC_DURATION_MINUTES: Number(process.env.MARKETPLACE_SYNC_DURATION_MINUTES) || 5,
  MARKETPLACE_SYNC_ITEM_LIMIT: 100,
  MARKETPLACE_CHICKEN_SALES_REDIS_KEY: 'marketplace-chicken-sales',
  MARKETPLACE_CLOTHING_SALES_REDIS_KEY: 'marketplace-clothing-sales',

  SEASON_PERIOD_NUM: Number(process.env.SEASON_PERIOD_NUM) || 20,
  SEASON_PERIOD_TYPE: process.env.SEASON_PERIOD_TYPE || 'minutes',
  SEASON_INITIAL_POP: 1000,

  aws: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    s3: {
      chickenderby: {
        bucket: 'chicken-derby',
        cloudfront: 'https://d1kai45begfsqo.cloudfront.net',
        chickensDir: process.env.AWS_CHICKENS_DIR || 'dev-chickens',
        chickenClothingsDir: process.env.AWS_CHICKEN_CLOTHINGS_DIR || 'dev-chicken-clothings',
        audio: {
          raceCommentariesDir: process.env.AWS_RACE_COMMENTARIES_AUDIO_DIR || 'mp3/dev/race-commentaries',
        },
      },
    },
  },

  SERUM_TOKEN_ID: 1,
  DEFAULT_FUSION_PRICE: 2,
  CHICKEN_ID_POOL_EXPIRATION_HOURS: 24,
  FUSION_SYNC_LIMIT: 100,
  FUSION_SYNC_DURATION_MINUTES: Number(process.env.FUSION_SYNC_DURATION_MINUTES) || 5,
  FUSION_AUTO_INCREMENT_START: Number(process.env.FUSION_AUTO_INCREMENT_START) || 60000,

  IMAGE_SERVER_URL: process.env.IMAGE_SERVER_URL || 'https://image-dev.chickenderby.com',
  CHICKEN_DEFAULT_IMAGE_SIZE: 848,
  CHICKEN_CLOTHING_IMAGE_SIZE: 350,

  OPEN_AI_API_KEY: process.env.OPEN_AI_API_KEY,
  ELEVEN_LABS_API_KEY: process.env.ELEVEN_LABS_API_KEY,

  DEV_USER_WALLET_IDS: {
    dmytro: '0xD3E38d8452d05E33d5B74Eba937086f67DCf0858',
    yin: '0x1aaBF8E1eE549A64996c05283078DED3a611b723',
    erik: '0x7A0173d11A824cB799df8101D23f16B7e4fA50d6',
    dmitry: '0x815223cf92647Ee4E53Ab93139BAB6454586Bd80',
    ben: '0x8C6698E2de7EDc8F59953860F154926E907dCE8c',
    kawsherOld: '0x0fEdDa5159F353b70e5b4B16578EdB6DeE5A4926',
    kawsherNew: '0x135f9826a0be58dd54477e1B85B3DDf4d6B69E5A',
  },
  WEARABLES_OWNER_PRIVATE_ADDRESS: process.env.WEARABLES_OWNER_PRIVATE_ADDRESS,

  popForPromotion: 75,
  popForDemotion: 0,
  popOncePromoted: 20,
  popOnceDemoted: 20,
  popDisplayPromotionArrow: 65,
  popDisplayDemotionArrow: 5,

  isProduction: process.env.NODE_ENV === 'production',

  RFERRAL_CODE_LENGTH: 6,

  RACE_PRIZE_POOL_PERCENT: 80,
  JEWELS_MULTIPLIER: 70, // 70 USDT
  BAWKS_MULTIPLIER: 30, // 30 USDT
  MIN_CHICKENS_REQUIRED_TO_SCHEDULE: 4,
  MAX_CHICKEN_STAKING_SEASONS: 36,
  STAKING_SEASON_DAYS: Number(process.env.STAKING_SEASON_DAYS || 1),
  BAWK_STAKING_OPEN_DAYS: 10,
};

export default config;
