import Joi from 'joi';

export const gachaPullSchema = Joi.object({
  mode: Joi.string().required(),
});
