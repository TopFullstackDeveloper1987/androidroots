import NP from 'number-precision';

import config from '../config';
import { truncateToDecimals } from '../utils';
import { getRaceContractPrizePercent, getRaceContractFreeRaceMaxPrizePoolSize } from '../services/contracts/raceContractService';
import { RaceCoinType } from '../types/races/raceCoinType';

export const validateFeeWithPrizePool = async (data: {
  coinType: RaceCoinType,
  fee: number,
  prizePool: number,
  maxCapacity: number,
}) => {
  const fee = truncateToDecimals(data.fee, 6);
  const maxEntryFee = config.MAX_ENTRY_FEE_FOR_RACE[data.coinType];

  if (fee > maxEntryFee) {
    throw new Error(
      `Entry fee is not allowed to be more than ${maxEntryFee} ${data.coinType}`,
    );
  }

  // truncate instead of toFixed to prevent prizePool rounding which leads to 'Funds is not enough' error on payout
  const prizePool = truncateToDecimals(data.prizePool, 6);
  if (fee > 0) {
    const racePrizePercent = await getRaceContractPrizePercent();
    const maxPrizePool = truncateToDecimals(
      NP.strip(data.fee * data.maxCapacity * racePrizePercent / 100),
      6,
    );
    if (prizePool > maxPrizePool) {
      throw new Error(
        `prizePool ${prizePool} is not allowed to be more than ${racePrizePercent}% of race funds - ${maxPrizePool}`,
      );
    }
  } else {
    const freeRaceMaxPrizePoolSize = await getRaceContractFreeRaceMaxPrizePoolSize();
    if (prizePool > freeRaceMaxPrizePoolSize) {
      throw new Error(
        `For free races, prizePool is not allowed to be more than ${freeRaceMaxPrizePoolSize} WETH`,
      );
    }
  }

  return prizePool;
};
