import Joi from 'joi';
import { FusionAlphaTrait, FusionBetaTrait, FusionGammaTrait } from '../types/fusion/lockedTraits';

export const assignLaneSchema = Joi.object({
  raceId: Joi.number().required(),
  chickenId: Joi.number().required(),
  signature: Joi.string().optional(),
  deadline: Joi.number().optional(),
  grecaptcha: Joi.string().optional(),
  gasLimit: Joi.number().optional(),
  coupon: Joi.object({
    v: Joi.number().required(),
    r: Joi.string().required(),
    s: Joi.string().required(),
  }).optional(),
});

export const landMintSchema = Joi.object({
  amount: Joi.number().required().min(1),
  signature: Joi.string().optional(),
  deadline: Joi.number().optional(),
  gasLimit: Joi.number().optional(),
});

// Marketplace
export const createMarketItemSchema = Joi.object({
  marketItemId: Joi.number().optional(),
  nftContract: Joi.string().required(),
  tokenId: Joi.number().required(),
  price: Joi.number().required(),
  minimum: Joi.number().optional(),
  tradeType: Joi.number().required(),
  assignmentType: Joi.string().optional(),
  signature: Joi.string().optional(),
  deadline: Joi.number().optional(),
  gasLimit: Joi.number().optional(),
});

export const editMarketItemSchema = Joi.object({
  marketItemId: Joi.number().required(),
  price: Joi.number().optional(),
  minimum: Joi.number().optional(),
  tradeType: Joi.number().optional(),
  assignmentType: Joi.string().optional(),
  signature: Joi.string().optional(),
  deadline: Joi.number().optional(),
  gasLimit: Joi.number().optional(),
});

export const purchaseMarketItemSchema = Joi.object({
  marketItemId: Joi.number().required(),
  assignmentType: Joi.string().optional(),
  transactionHash: Joi.string().optional(),
  gasLimit: Joi.number().optional(),
});

export const cancelMarketItemSchema = Joi.object({
  marketItemId: Joi.number().required(),
  assignmentType: Joi.string().optional(),
  signature: Joi.string().optional(),
  deadline: Joi.number().optional(),
  gasLimit: Joi.number().optional(),
});

export const makeOfferSchema = Joi.object({
  marketItemId: Joi.number().required(),
  tradeOfferId: Joi.number().optional(),
  nftContract: Joi.string().optional(),
  price: Joi.number().optional(),
  tokensAttached: Joi.array().items(Joi.number()).optional(),
  assignmentType: Joi.string().optional(),
  signature: Joi.string().optional(),
  deadline: Joi.number().optional(),
  gasLimit: Joi.number().optional(),
});

export const editOfferSchema = Joi.object({
  tradeOfferId: Joi.number().required(),
  price: Joi.number().optional(),
  nftContract: Joi.string().optional(),
  tokensAttached: Joi.array().items(Joi.number()).optional(),
  assignmentType: Joi.string().optional(),
  signature: Joi.string().optional(),
  deadline: Joi.number().optional(),
  gasLimit: Joi.number().optional(),
});

export const fulfillOfferSchema = Joi.object({
  tradeOfferId: Joi.number().required(),
  assignmentType: Joi.string().optional(),
  transactionHash: Joi.string().optional(),
  gasLimit: Joi.number().optional(),
});

export const cancelOrDeclineOfferSchema = Joi.object({
  tradeOfferId: Joi.number().required(),
  assignmentType: Joi.string().optional(),
  signature: Joi.string().optional(),
  deadline: Joi.number().optional(),
  gasLimit: Joi.number().optional(),
});

export const replaceTradePreferenceSchema = Joi.object({
  nftContract: Joi.string().required(),
  tokenId: Joi.number().optional(),
  preference: Joi.object().required(),
});

export const replaceBlackListSchema = Joi.object({
  stealerUserWalletId: Joi.string().required(),
  contractType: Joi.string().required(),
  tokenId: Joi.number().required(),
  reporterUserName: Joi.string().required(),
  reporterUserWalletId: Joi.string().required(),
  isBlackListed: Joi.boolean().required(),
});

export const fuseSchema = Joi.object({
  materialChickenIds: Joi.array().items(Joi.number()).required(),
  fusedChickenId: Joi.number().optional(),
  serums: Joi.number().required(),
  lockedTraits: Joi.object({
    alpha: Joi.object({
      chickenId: Joi.number().required(),
      trait: Joi.string().valid(
        FusionAlphaTrait.Heritage,
        FusionAlphaTrait.Perfection,
        FusionAlphaTrait.Talent,
        FusionAlphaTrait.Stripes,
      ).required(),
    }).optional(),
    beta: Joi.object({
      chickenId: Joi.number().required(),
      trait: Joi.string().valid(
        FusionBetaTrait.BaseBody,
        FusionBetaTrait.BeakColor,
        FusionBetaTrait.BeakAccessory,
        FusionBetaTrait.CombWattleColor,
        FusionBetaTrait.EyesType,
        FusionBetaTrait.Gender,
        FusionBetaTrait.Legs,
      ).required(),
    }).optional(),
    gamma: Joi.object({
      chickenId: Joi.number().required(),
      trait: Joi.string().valid(
        FusionGammaTrait.DistancePreference,
        FusionGammaTrait.TalentPreference,
        FusionGammaTrait.TerrainPreference,
        FusionGammaTrait.Consistency,
      ).required(),
    }).optional(),
  }).optional(),
  transactionHash: Joi.string().optional(),
  gasLimit: Joi.number().optional(),
  coupon: Joi.object({
    v: Joi.number().required(),
    r: Joi.string().required(),
    s: Joi.string().required(),
  }).optional(),
});

export const serumMintSchema = Joi.object({
  serumId: Joi.number().required(),
  amount: Joi.number().required(),
  signature: Joi.string().optional(),
  deadline: Joi.number().optional(),
  gasLimit: Joi.number().optional(),
});

export const regexLandName = /^[a-zA-Z0-9\-~_]+$/;
export const regexLandEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const createPreRegisterLandSchema = Joi.object({
  name: Joi.string().pattern(regexLandName).required().error(new Error('Invalid plot name')),
  email: Joi.string().pattern(regexLandEmail).required().error(new Error('Invalid email')),
  grecaptcha: Joi.string().required().error(new Error('Required Recaptcha')),
  referralCode: Joi.string().pattern(regexLandName).optional().error(new Error('Invalid referral code')),
});

export const bawkStakingSchema = Joi.object({
  epoch: Joi.number().required(),
  bawkStakingCompanyId: Joi.number().required(),
  amount: Joi.number().optional(),
  type: Joi.string().required(),
  bawkType: Joi.string().optional(),
  signature: Joi.string().optional(),
  deadline: Joi.number().optional(),
  gasLimit: Joi.number().optional(),
  coupon: Joi.object({
    v: Joi.number().required(),
    r: Joi.string().required(),
    s: Joi.string().required(),
  }).optional(),
});
