import * as jwt from 'jsonwebtoken';
import * as moment from 'moment-timezone';
import { RequestHandler } from 'express';

import config from '../config';
import { getClientInfo } from './parseClientInfo';

import { UserWallet } from '../sequelize/models/UserWallet';

export const authWallet: RequestHandler = (req, res, next) => {
  const { authorization } = req.headers;
  if (!authorization) {
    res.status(401).json({
      message: 'Authentication is required!',
    });
    return;
  }

  const token = authorization.replace('Bearer ', '');

  jwt.verify(token, config.SECRET, async (err: any, decoded: any) => {
    if (err) {
      const message = err.message === 'jwt expired' ? 'Token expired, please login' : err.message;
      res.status(401).json({
        message,
      });
      return;
    }

    const userWalletRecord = await UserWallet.unscoped().findOne({ where: { token } });
    if (!userWalletRecord) {
      res.status(401).json({
        message: 'User wallet not found, please login',
      });
      return;
    }

    req.tokenExpiresInSeconds = moment.unix(decoded.exp).diff(moment.utc(), 'seconds');
    req.user = userWalletRecord;

    req.clientInfo = getClientInfo(req);

    next();
  });
};

export const authWalletPublic: RequestHandler = (req, res, next) => {
  const { authorization } = req.headers;
  if (!authorization) {
    next();
    return;
  }

  const token = authorization.replace('Bearer ', '');

  jwt.verify(token, config.SECRET, async (err: any, decoded: any) => {
    if (err) {
      next();
      return;
    }

    const userWalletRecord = await UserWallet.unscoped().findOne({ where: { token } });
    if (!userWalletRecord) {
      next();
      return;
    }

    req.tokenExpiresInSeconds = moment.unix(decoded.exp).diff(moment.utc(), 'seconds');
    req.user = userWalletRecord;

    req.clientInfo = getClientInfo(req);

    next();
  });
};
