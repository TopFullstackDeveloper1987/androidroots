import * as jwt from 'jsonwebtoken';
import * as bcrypt from 'bcrypt';
import * as moment from 'moment-timezone';
import { RequestHandler } from 'express';

import config from '../config';
import { getClientInfo } from './parseClientInfo';

export const authBasic: RequestHandler = (req, res, next) => {
  if (!config.REQUIRED_BASIC_AUTH) {
    req.clientInfo = getClientInfo(req);

    next();
    return;
  }

  const authToken = req.headers['x-basic-auth-token'] as string;

  if (!authToken) {
    res.status(422).json({
      message: 'Authentication is required!',
    });
    return;
  }

  jwt.verify(authToken, config.SECRET, async (err: any, decoded: any) => {
    if (err) {
      const message = err.message === 'jwt expired' ? 'Token expired, please login' : err.message;
      res.status(422).json({
        message,
      });
      return;
    }

    if (config.BASIC_AUTH_PASSWORD === 'ROTATE') {
      const dateString = moment.utc().format('YYYY-MM-DD');
      const originPassword = `ChickenDerby-${dateString}`;

      const isMatchPassword = await bcrypt.compare(originPassword, decoded.password);

      if (!isMatchPassword) {
        res.status(422).json({
          message: 'Invalid token',
        });
        return;
      }
    } else if (decoded.password !== config.BASIC_AUTH_PASSWORD) {
      res.status(422).json({
        message: 'Invalid token',
      });
      return;
    }

    req.clientInfo = getClientInfo(req);

    next();
  });
};
