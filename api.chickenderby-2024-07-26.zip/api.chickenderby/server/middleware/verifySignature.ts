import * as ethUtil from 'ethereumjs-util';
import { RequestHandler } from 'express';

import { Nonce } from '../sequelize/models/Nonce';

import { log } from '../utils';

export const verifySignature: RequestHandler = async (req, res, next) => {
  const { userWalletId, signature } = req.body;

  try {
    const nonceRecord = await Nonce.findByPk(userWalletId);
    if (!nonceRecord) {
      throw new Error('Invalid signature');
    }

    const msgHex = ethUtil.bufferToHex(Buffer.from(nonceRecord.message));
    const msgBuffer = ethUtil.toBuffer(msgHex);
    const msgHash = ethUtil.hashPersonalMessage(msgBuffer);

    const signatureParams = ethUtil.fromRpcSig(signature);
    const publicKey = ethUtil.ecrecover(
      msgHash,
      signatureParams.v,
      signatureParams.r,
      signatureParams.s,
    );
    const addresBuffer = ethUtil.publicToAddress(publicKey);
    const publicAddress = ethUtil.bufferToHex(addresBuffer);

    if (publicAddress?.toLowerCase() === userWalletId?.toLowerCase()) {
      next();
    } else {
      log.error({
        func: 'verifySignature',
        userWalletId,
        signature,
        publicAddress,
      }, 'Verify Signature Error');

      res.status(401).json({
        message: 'Invalid signature',
      });
    }
  } catch (err) {
    log.error({
      func: 'verifySignature',
      userWalletId,
      signature,
      err,
    }, 'Verify Signature Error');

    res.status(401).json({
      message: 'Invalid signature',
    });
  }
};
