import DeviceDetector from 'device-detector-js';
const geoip = require('geoip-country');
import { countries } from 'countries-list';
import { Request } from 'express';

import { ClientInfo } from '../types/clientInfo/clientInfo';
import { User } from '../sequelize/models/User';
import { UserWallet } from '../sequelize/models/UserWallet';

declare global {
  namespace Express {
    interface Request {
      clientInfo: ClientInfo;
      user: Partial<UserWallet | User>;
      tokenExpiresInSeconds?: number;
    }
  }
}

export const getClientInfo = (req: Request) => {
  const clientInfo: ClientInfo = {};

  clientInfo.userAgent = req.headers['user-agent'];
  clientInfo.acceptLanguage = req.headers['accept-language'];

  const deviceDetector = new DeviceDetector();
  const deviceInfo = deviceDetector.parse(clientInfo.userAgent);
  clientInfo.browser = deviceInfo.client ? `${deviceInfo.client.name} ${deviceInfo.client.version}` : null;
  clientInfo.operatingSystem = deviceInfo.os ? `${deviceInfo.os.name} ${deviceInfo.os.version}` : null;

  let device = null;
  if (deviceInfo.device) {
    if (deviceInfo.device.model) {
      device = deviceInfo.device.model;
    } else if (deviceInfo.device.type === 'desktop') {
      device = 'Desktop';
    } else if (deviceInfo.device.type === 'smartphone') {
      device = 'Phone';
    } else if (deviceInfo.device.type === 'tablet') {
      device = 'Tablet';
    } else {
      device = deviceInfo.device.type;
    }
  }

  clientInfo.device = device;

  let ipAddress = req.headers['x-original-forwarded-for'] as string;

  if (!ipAddress && req.headers['x-forwarded-for']) {
    ipAddress = (req.headers['x-forwarded-for'] as string).split(', ').filter((ip: string) => ip).pop();
  }

  clientInfo.ipAddress = ipAddress;

  if (clientInfo.ipAddress) {
    const geo = geoip.lookup(clientInfo.ipAddress);
    if (geo) {
      clientInfo.ipCountry = countries[geo.country as keyof typeof countries].name;
    }
  }

  clientInfo.userId = req.user?.id;
  clientInfo.referer = req.headers.referer;

  return clientInfo;
};
