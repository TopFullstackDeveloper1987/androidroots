import * as jwt from 'jsonwebtoken';
import { RequestHandler } from 'express';

import config from '../config';

import { User } from '../sequelize/models/User';

import { getClientInfo } from './parseClientInfo';

export const auth: RequestHandler = (req, res, next) => {
  const token = req.cookies.auth;

  if (!token) {
    res.status(401).json({ error: true });
    return;
  }

  jwt.verify(token, config.SECRET, async (err: any, decoded: any) => {
    if (err) {
      res.status(401).json({
        message: 'Authorization failed',
      });
      return;
    }

    req.clientInfo = getClientInfo(req);

    const query: any = {
      id: decoded.id,
      token,
    };

    if (req.clientInfo.ipAddress) {
      query.ipAddress = [req.clientInfo.ipAddress, '0.0.0.0'];
    }

    const userModel = await User.unscoped().findOne({
      where: query,
    });

    if (!userModel) {
      res.status(401).json({
        message: 'User not found',
      });
      return;
    }

    req.user = userModel;
    req.clientInfo.userId = req.user.id;

    next();
  });
};

export const authAdmin: RequestHandler = (req, res, next) => {
  const token = req.cookies.auth;

  if (!token) {
    res.status(401).json({ error: true });
    return;
  }

  if (!(req.user as User)?.isAdmin) {
    res.status(403).json({
      message: 'No permission for this action',
    });

    return;
  }

  next();
};
