import { RequestHandler, Response } from 'express';

// Services
import { redisConnect, redisGetAsync } from '../services/redisClient';

// Utils
import { log } from '../utils';

// Cache every 5 seconds by default
export const cache = (ttl = 5): RequestHandler => async (req, res, next) => {
  try {
    const { originalUrl, url } = req;
    const redisCacheKey = `__cache__${originalUrl || url}`;
    const cachedResponseString = await redisGetAsync(redisCacheKey);
    const cachedResponse = cachedResponseString && JSON.parse(cachedResponseString);

    // log.info({
    //   func: 'cache',
    //   originalUrl,
    //   url,
    //   redisCacheKey,
    //   cachedResponse,
    // });

    // TODO: pass status to cachedResponse on error
    if (cachedResponse?.message) {
      res.status(400).json(cachedResponse);
      return;
    }

    if (cachedResponse) {
      res.json(cachedResponse);
      return;
    }

    const sendJson = res.json.bind(res);
    res.json = (response: Response) => {
      const redisClient = redisConnect();
      redisClient.set(redisCacheKey, JSON.stringify(response), 'EX', ttl);

      return sendJson(response);
    };

    next();
  } catch (err: any) {
    log.error({
      func: 'cache',
      originalUrl: req.originalUrl,
      url: req.url,
      err,
    }, 'Cache Middleware Error');

    res.status(400).json({
      message: err.message,
    });
  }
};
