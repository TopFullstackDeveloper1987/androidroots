// Dependencies
import * as express from 'express';
import Sequelize from 'sequelize';
const { Op } = Sequelize;

// Settings
import config from '../config';

// Middlewares
import { authWallet } from '../middleware/authWallet';
import { authBasic } from '../middleware/authBasic';

// Validation Schemas
import { assignLaneSchema } from '../validation/validationSchemas';

// Models
import { Race } from '../sequelize/models/Race';
import { RaceAssignment } from '../sequelize/models/RaceAssignment';
import { Lane } from '../sequelize/models/Lane';
import { Chicken } from '../sequelize/models/Chicken';
import { UserWallet } from '../sequelize/models/UserWallet';

// Services
import { redisLock } from '../services/redisLock';
import { assignLane, increaseRaceEntries } from '../services/raceService';
import { checkDeployment, checkBetaUserOnly } from '../services/settingService';
import { getRecaptcaScore } from '../services/recaptchaService';
import { isOffensiveTalent, isSpeedTalent } from '../services/talentService';
import { checkBlackList } from '../services/blackListService';
import { generateCoupon, getRaceContractChickenIds } from '../services/contracts/raceContractService';
import { checkChickenOwnership, checkChickenStatus } from '../services/chickenService';

// Utils
import { log } from '../utils';

// Types
import { ChickenPeckingOrder } from '../types/chickens/chickenPeckingOrder';
import { ChickenSituation } from '../types/chickens/chickenSituation';
import { RaceAssignmentType } from '../types/races/raceAssignmentType';
import { AssignmentStatus } from '../types/assignments/assignmentStatus';
import { raceEnterWorker } from '../queues/raceQueues';
import { RaceStatus } from '../types/races/raceStatus';
import { JEWEL_CONTRACT } from '../abi/jewelContract';
import { BawkStakingCompany } from '../sequelize/models/BawkStakingCompany';

const router = express.Router();

const recaptchaCheck = async (raceRecord: Race, chickenId: number, grecaptcha: string) => {
  const raceId = raceRecord.id;

  if (raceRecord.peckingOrder === ChickenPeckingOrder.CHICK) { // we don't have recaptcha in CHICK race
    return true;
  }

  if (!grecaptcha) {
    return false;
  }

  try {
    const response = await getRecaptcaScore(grecaptcha);

    log.info({
      func: '/recaptchaCheck',
      raceId,
      grecaptcha,
      chickenId,
      response,
    }, 'Recaptcha Check');

    // Check if the token is valid.
    if (!response.tokenProperties.valid) {
      return false;
    }
    // if (response.tokenProperties.action !== 'Enter') {
    //     return false
    // }

    if (response.riskAnalysis.score <= 0.2) { // High risk score
      return false;
    }

    return true;
  } catch (err) {
    log.error({
      func: '/recaptchaCheck',
      raceId,
      chickenId,
      grecaptcha,
      err,
    }, 'Recaptcha Check Error');

    return false;
  }
};

const checkChickenByRace = (race: Race, chicken: Chicken) => {
  if (race.group === 10 && !isOffensiveTalent(chicken.talent)) {
    throw new Error('This race is limited to chickens with offensive talents');
  }

  if (race.group === 11 && !isSpeedTalent(chicken.talent)) {
    throw new Error('This race is limited to chickens with speed talents');
  }
};

const checkPeckingOrder = async (race: Race, chicken: Chicken) => {
  if (race.unlimitPO) {
    return;
  }

  if (race.peckingOrder === ChickenPeckingOrder.CHICK) {
    const numberOfChickRaces = await Lane.count({
      where: {
        chickenId: chicken.id,
      },
      include: [{
        model: Race,
        where: {
          peckingOrder: ChickenPeckingOrder.CHICK,
        },
      }],
      distinct: true,
    });

    if (numberOfChickRaces >= config.CHICK_RACES_LIMIT) {
      throw new Error(`This chicken has already entered ${numberOfChickRaces} CHICK races.`);
    }
  } else if (race.peckingOrder !== chicken.peckingOrder) {
    throw new Error('This chicken\'s current pecking order prevents it from being entered into this race.');
  }
};

const checkRaceAllowance = (race: Race, userWalletId: string, chickenId: number) => {
  if (race.allowedUserWallets?.length && !race.allowedUserWallets.includes(userWalletId.toLowerCase())) {
    throw new Error('This user wallet is not allowed to enter this race.');
  }

  if (race.allowedChickens?.length && !race.allowedChickens.includes(chickenId)) {
    throw new Error('This chicken is not allowed to enter this race.');
  }
};

const checkCoinContract = (race: Race) => {
  if (race.coinContract?.toLowerCase() !== JEWEL_CONTRACT.address.toLowerCase()) {
    throw new Error('Only jewel races are allowed to enter');
  }
};

const checkBawkStakingCompany = async (race: Race) => {
  const bawkStakingCompany = race.bawkStakingCompanyId && await BawkStakingCompany.findByPk(race.bawkStakingCompanyId);
  if (!bawkStakingCompany) {
    throw new Error('Invalid company');
  }
};

// TODO: move to laneService or raceService
const assignLaneCheck = async (req: express.Request) => {
  const { id: userWalletId } = req.user as UserWallet;

  // check if deployment is in progress
  await checkDeployment();

  // check beta user enabled
  await checkBetaUserOnly(userWalletId, 'Sorry, entry to races is currently limited to beta users.');

  const schemaResult = await assignLaneSchema.validateAsync(req.body);
  const { raceId, chickenId, gasLimit } = schemaResult;

  const chickenRecord = await Chicken.findByPk(chickenId);
  if (!chickenRecord) {
    throw new Error('Invalid chicken.');
  }

  await checkBlackList(config.CHICKEN_CONTRACT.address, chickenId);
  await checkChickenStatus(chickenId);

  const raceModel = await Race.findByPk(raceId, {
    include: [{
      model: Lane,
      as: 'lanes',
    }],
  });
  if (!raceModel) {
    throw new Error('Race not found');
  }

  checkChickenByRace(raceModel, chickenRecord);
  checkRaceAllowance(raceModel, userWalletId, chickenId);
  checkCoinContract(raceModel);
  await checkBawkStakingCompany(raceModel);

  const {
    fee, lanes, maxCapacity, status,
  } = raceModel;

  // check peckingOrder matching
  await checkPeckingOrder(raceModel, chickenRecord);

  const unAssignedLane = lanes.find((laneModel) => !laneModel.chickenId);
  if (!unAssignedLane) {
    throw new Error('Sorry, this race is now full.');
  }

  if (status !== RaceStatus.Open) {
    throw new Error('Sorry, this race is now closed.');
  }

  const assignedLaneWithChicken = lanes.find((laneModel) => laneModel.chickenId === chickenId);
  if (assignedLaneWithChicken) {
    throw new Error('Sorry, you have already entered your chicken into this race.');
  }

  const assignedLanesForUser = lanes.filter((laneModel) => laneModel.userWalletId === userWalletId);
  const maxChickensPerRace = fee > 0 ? config.MAX_CHICKENS_PER_PAID_RACE : config.MAX_CHICKENS_PER_FREE_RACE;
  const isProduction = process.env.NODE_ENV === 'production';

  if (isProduction && assignedLanesForUser.length >= maxChickensPerRace) {
    throw new Error(`You already have ${assignedLanesForUser.length} chicken(s) entered this race.`);
  }

  if (fee > 0) {
    const numberOfPaidRaceAssignments = await RaceAssignment.count({
      where: {
        raceId,
        status: {
          [Op.not]: AssignmentStatus.Error,
        },
      },
    });

    if (numberOfPaidRaceAssignments >= maxCapacity) {
      throw new Error('Sorry, entry to the race isn\'t currently available.');
    }

    const numberOfPendingPaidRaceAssignments = await RaceAssignment.count({
      where: {
        userWalletId,
        status: AssignmentStatus.Pending,
      },
    });
    if (numberOfPendingPaidRaceAssignments > 0) {
      throw new Error('You currently have a race entry pending.');
    }

    const contractChickenIds = await getRaceContractChickenIds(raceId);
    if (contractChickenIds.includes(chickenId)) {
      throw new Error('This chicken has already entered the race');
    }
  }

  await checkChickenOwnership(userWalletId, chickenId);

  if (gasLimit) {
    return {
      raceModel,
      gasLimit,
    };
  }

  const coupon = generateCoupon(fee, raceId, chickenId, maxCapacity, userWalletId);
  return {
    raceModel,
    gasLimit: config.BICONOMY_CUSTOM_GAS_LIMIT,
    coupon,
  };
};

router.put('/lanes/check', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;
  const {
    raceId, chickenId,
  } = req.body;

  try {
    log.info({
      func: 'PUT/lanes/check',
      raceId,
      userWalletId,
      chickenId,
    }, 'Assign Lane Check Start');

    // expires token before 30 minutes
    // edge case: jwt verification passed for /lanes/check => user paid the entry fee => jwt expired on PUT /lanes
    // this will cause the user not entered the race although they paid the entry fee
    if (req.tokenExpiresInSeconds < config.AUTH_TOKEN_EXPIRATION_CHECK_MINUTES * 60) {
      res.status(401).json({
        message: 'Token expired, please login',
      });

      return;
    }

    // heroku TTL is 30 seconds per request
    const { gasLimit, coupon } = await redisLock([`${config.lock.assignLane}/${raceId}`], 30 * 1000, async () => assignLaneCheck(req));

    log.info({
      func: 'PUT/lanes/check',
      raceId,
      userWalletId,
      chickenId,
      gasLimit,
      coupon,
    }, 'Assign Lane Check End');

    res.status(200).json({ raceId, gasLimit, coupon });
  } catch (err: any) {
    log.error({
      func: 'PUT/lanes/check',
      raceId,
      userWalletId,
      chickenId,
      err,
    }, 'Assign Lane Check Failed');

    res.status(400).json({ message: err.message });
  }
});

// only used for free races
router.put('/lanes/free', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;
  const {
    raceId, chickenId, grecaptcha,
  } = req.body;

  try {
    log.info({
      func: 'PUT/lanes/free',
      userWalletId,
      raceId,
      chickenId,
    }, 'Assign Free Lane Start');


    // heroku TTL is 30 seconds per request
    const raceRecord = await redisLock([`${config.lock.assignLane}/${raceId}`], 30 * 1000, async () => {
      const { raceModel } = await assignLaneCheck(req);

      const isValid = await recaptchaCheck(raceModel, chickenId, grecaptcha);
      if (!isValid) {
        throw new Error('Connection error. Please refresh your browser and try again.');
      }

      return Race.sequelize.transaction(async (t) => {
        await assignLane({
          raceId,
          chickenId,
          userWalletId,
          transaction: t,
        });

        await Chicken.update({
          situation: ChickenSituation.RacingPen,
        }, {
          where: {
            id: chickenId,
          },
          transaction: t,
        });

        await increaseRaceEntries(userWalletId, t);

        return raceModel.reload({ transaction: t });
      });
    });

    log.info({
      func: 'PUT/lanes/free',
      userWalletId,
      raceId,
      chickenId,
    }, 'Assign Free Lane Success');

    res.status(200).json({ race: raceRecord });
  } catch (err: any) {
    // TODO: refund the entry fee here
    log.error({
      func: 'PUT/lanes/free',
      userWalletId,
      raceId,
      chickenId,
      err,
    }, 'Assign Free Lane Failed');

    res.status(400).json({ message: err.message });
  }
});

router.put('/lanes/paid', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const {
    raceId, chickenId, signature, deadline, gasLimit, coupon,
  } = req.body;

  try {
    log.info({
      func: 'PUT/lanes/paid',
      userWalletId,
      raceId,
      chickenId,
      signature,
      deadline,
      gasLimit,
    }, 'Assign Paid Lane Start');


    // heroku TTL is 30 seconds per request
    const raceAssignmentModel = await redisLock([`${config.lock.assignLane}/${raceId}`], 30 * 1000, async () => {
      await assignLaneCheck(req);

      return RaceAssignment.sequelize.transaction(async (t) => {
        await Chicken.update({
          situation: ChickenSituation.RacingPen,
        }, {
          where: {
            id: chickenId,
          },
          transaction: t,
        });

        return RaceAssignment.create({
          userWalletId,
          raceId,
          chickenId,
          type: RaceAssignmentType.Enter,
          signature,
          data: {
            deadline,
            gasLimit,
            coupon,
          },
        }, { transaction: t });
      });
    });

    raceEnterWorker.add({
      raceAssignmentId: raceAssignmentModel.id,
    });

    log.info({
      func: 'PUT/lanes/paid',
      userWalletId,
      raceId,
      chickenId,
      signature,
      deadline,
      gasLimit,
      raceAssignmentId: raceAssignmentModel.id,
    }, 'Assign Paid Lane Success');

    res.status(200).json({ raceAssignment: raceAssignmentModel });
  } catch (err: any) {
    // TODO: refund the entry fee here
    log.error({
      func: 'PUT/lanes/paid',
      userWalletId,
      raceId,
      chickenId,
      signature,
      deadline,
      gasLimit,
      err,
    }, 'Assign Paid Lane Failed');

    res.status(400).json({ message: err.message });
  }
});

router.get('/race-assignments/last', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;

  try {
    const raceAssignmentModel = await RaceAssignment.findOne({
      where: {
        userWalletId,
      },
      order: [
        ['id', 'DESC'],
      ],
    });

    res.status(200).json({ raceAssignment: raceAssignmentModel });
  } catch (err: any) {
    log.error({
      func: 'GET/race-assignments/last',
      userWalletId,
      err,
    }, 'Get Last Race Assignment Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
