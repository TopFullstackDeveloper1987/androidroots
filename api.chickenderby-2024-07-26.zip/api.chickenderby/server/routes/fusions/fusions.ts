// Dependencies
import * as express from 'express';

// Config
import config from '../../config';

// Middlewares
import { authWallet } from '../../middleware/authWallet';
import { authBasic } from '../../middleware/authBasic';

// Models
import { FusionAssignment } from '../../sequelize/models/FusionAssignment';

// Services
import { redisLock } from '../../services/redisLock';
import { FusionService } from '../../services/fusions/fusionService';

// Utils
import { log } from '../../utils';

// Schemas
import { fuseSchema } from '../../validation/validationSchemas';
import { fusionWorker } from '../../queues/fusionQueues';

const router = express.Router();

router.post('/fusions/fuse', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const { materialChickenIds, fusedChickenId, transactionHash, gasLimit, serums, lockedTraits } = req.body;

  try {
    log.info({
      func: 'POST/fusions/fuse',
      userWalletId,
      materialChickenId1: materialChickenIds[0],
      materialChickenId2: materialChickenIds[1],
      fusedChickenId,
      transactionHash,
      gasLimit,
      serums,
      lockedTraits,
    }, 'Fuse Start');

    const fusionAssignment = await redisLock(
      `${config.lock.fusion}/${userWalletId}`,
      30 * 1000, async () => FusionAssignment.sequelize.transaction(async (t) => {
        return FusionService.submitFusionAssignment(req, t);
      }));

    fusionWorker.add({
      fusionAssignmentId: fusionAssignment.id,
    });

    log.info({
      func: 'POST/fusions/fuse',
      userWalletId,
      materialChickenId1: materialChickenIds[0],
      materialChickenId2: materialChickenIds[1],
      fusedChickenId,
      transactionHash,
      gasLimit,
      serums,
      lockedTraits,
      fusionAssignmentId: fusionAssignment.id,
    }, 'Fuse Success');

    res.status(200).json(fusionAssignment);
  } catch (err: any) {
    log.error({
      func: 'POST/fusions/fuse',
      userWalletId,
      materialChickenId1: materialChickenIds[0],
      materialChickenId2: materialChickenIds[1],
      fusedChickenId,
      transactionHash,
      gasLimit,
      serums,
      lockedTraits,
      err,
    }, 'Fuse Error');

    res.status(400).json({ message: err.message });
  }
});

router.get('/fusions/price', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;

  try {
    const lockedTraits = JSON.parse(req.query.lockedTraits as string);
    const lockedTraitsSchema = fuseSchema.extract('lockedTraits');
    lockedTraitsSchema.validate(lockedTraits);

    const serums = await FusionService.calculateFusionPrice(lockedTraits);

    res.status(200).json({
      serums,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/fusions/price',
      userWalletId,
      query: req.query,
      err,
    }, 'Fusion Price Error');

    res.status(400).json({ message: err.message });
  }
});

router.get('/fusions/prices', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;

  try {
    const materialChickenIds = (req.query.materialChickenIds as string[]);
    const prices = await FusionService.getAvailableFusionPrices(materialChickenIds);

    res.status(200).json(prices);
  } catch (err: any) {
    log.error({
      func: 'GET/fusions/prices',
      userWalletId,
      query: req.query,
      err,
    }, 'Fusion Prices Error');

    res.status(400).json({ message: err.message });
  }
});

export = router;
