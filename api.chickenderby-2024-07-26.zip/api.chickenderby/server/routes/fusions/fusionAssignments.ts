// Dependencies
import * as express from 'express';
import * as _ from 'lodash';
import { Op } from 'sequelize';

// Config
import config from '../../config';

// Middlewares
import { authWallet } from '../../middleware/authWallet';
import { authBasic } from '../../middleware/authBasic';

// Models
import { FusionAssignment } from '../../sequelize/models/FusionAssignment';
import { Chicken } from '../../sequelize/models/Chicken';

// Services
import { redisLock } from '../../services/redisLock';
import { FusionService } from '../../services/fusions/fusionService';

// Utils
import { log } from '../../utils';
import { chickenHiddenTraits } from '../../utils/constants';

// Types
import { AssignmentStatus } from '../../types/assignments/assignmentStatus';

const router = express.Router();

router.post('/fusion-assignments/check', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const { materialChickenIds, serums, lockedTraits } = req.body;

  try {
    if (req.tokenExpiresInSeconds < config.AUTH_TOKEN_EXPIRATION_CHECK_MINUTES * 60) {
      res.status(401).json({
        message: 'Token expired, please login',
      });
      return;
    }

    // returns a fused chicken id so that the frontend could pass it for the contract call
    const fusionAssignment = await redisLock(
      `${config.lock.fusion}/${userWalletId}`,
      30 * 1000,
      async () => FusionAssignment.sequelize.transaction(async (t) => FusionService.createFusionAssignment(req, t)),
    );

    res.json({
      fusedChickenId: fusionAssignment.fusedChickenId,
      gasLimit: fusionAssignment.data.gasLimit,
      coupon: fusionAssignment.data.coupon,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/fusion-assignments/check',
      userWalletId,
      materialChickenId1: materialChickenIds[0],
      materialChickenId2: materialChickenIds[1],
      serums,
      lockedTraits,
      err,
    }, 'Check Fusion Assignment Failure');

    res.status(400).json({ message: err.message });
  }
});

router.get('/fusion-assignments/last', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;

  try {
    const fusionAssignment = await FusionAssignment.findOne({
      where: {
        userWalletId,
        status: {
          [Op.ne]: AssignmentStatus.Draft,
        },
      },
      include: [{
        model: Chicken,
        as: 'materialChicken1',
      }, {
        model: Chicken,
        as: 'materialChicken2',
      }],
      order: [
        ['id', 'DESC'],
      ],
    });

    const fusionAssignmentData: Partial<FusionAssignment> = fusionAssignment ? {
      ...fusionAssignment.toJSON(),
      chickenData: _.omit(fusionAssignment.toJSON().chickenData, chickenHiddenTraits),
    } : null;

    res.status(200).json({
      fusionAssignment: fusionAssignmentData,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/fusion-assignments/last',
      userWalletId,
      err,
    }, 'Get Last Fusion Assignment Failure');

    res.status(400).json({ message: err.message });
  }
});

export = router;
