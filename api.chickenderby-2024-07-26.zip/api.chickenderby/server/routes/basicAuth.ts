import * as express from 'express';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';
import * as moment from 'moment-timezone';

import config from '../config';

// models
import { log } from '../utils';

const router = express.Router();

router.post('/basicAuth', async (req, res) => {
  const { username, password } = req.body;
  try {
    log.info('config.BASIC_AUTH_PASSWORD', config.BASIC_AUTH_PASSWORD);
    if (config.BASIC_AUTH_PASSWORD === 'ROTATE') {
      const dateString = moment.utc().format('YYYY-MM-DD');
      const originPassword = `ChickenDerby-${dateString}`;

      const isMatch = await bcrypt.compare(originPassword, password);

      if (!isMatch) {
        throw new Error('Invalid password');
      }
    } else if (config.BASIC_AUTH_PASSWORD !== password) {
      throw new Error('Invalid password');
    }

    if (username !== config.BASIC_AUTH_USERNAME) {
      throw new Error('Invalid username');
    }

    const token = jwt.sign({ password }, config.SECRET, { expiresIn: `${config.AUTH_TOKEN_EXPIRATION_HOURS}h` });

    res.status(200).json({
      token,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/basic/login',
      err,
    }, 'Basic Login Error');

    res.status(400).json({
      message: err.message,
      isAuth: false,
    });
  }
});

export = router;
