// Dependencies
import * as express from 'express';

// Models
import { Decoration } from '../sequelize/models/Decoration';

// Utils
import { log } from '../utils';

const router = express.Router();

// serve TokenUri for opensea, super careful
router.get('/decorations/opensea/:decorationId', async (req: express.Request, res: express.Response) => {
  const { decorationId } = req.params;

  try {
    const decoration = decorationId && await Decoration.findByPk(decorationId);
    if (!decoration) {
      throw new Error('Decoration not found');
    }

    res.json({
      id: decoration.id,
      name: decoration.name,
      description: '',
      image_url: decoration.image,
      attributes: [{
        trait_type: 'Type',
        value: decoration.type,
      }, {
        trait_type: 'Set',
        value: decoration.decorationSet,
      }, {
        trait_type: 'Width',
        value: decoration.width,
      }, {
        trait_type: 'Length',
        value: decoration.length,
      }, {
        trait_type: 'Area',
        value: decoration.area,
      }],
    });
  } catch (err: any) {
    log.error({
      func: 'GET/decorations/opensea/:decorationId',
      decorationId,
      err,
    }, 'Get Decoration Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
