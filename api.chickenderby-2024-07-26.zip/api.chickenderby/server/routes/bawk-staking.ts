import * as express from 'express';

import config from '../config';

import { authBasic } from '../middleware/authBasic';
import { authWallet, authWalletPublic } from '../middleware/authWallet';

import { log } from '../utils';
import { BawkStakingService } from '../services/bawk-staking.service';
import { redisLock } from '../services/redisLock';
import { UserWallet } from '../sequelize/models/UserWallet';
import { BawkStakingAssignment } from '../sequelize/models/BawkStakingAssignment';
import { bawkStakingWorker } from '../queues/raceQueues';

const router = express.Router();

router.post('/bawk-staking/check', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;
  const {
    bawkStakingCompanyId,
    epoch,
    amount,
    type,
    bawkType,
  } = req.body;

  try {
    if (req.tokenExpiresInSeconds < config.AUTH_TOKEN_EXPIRATION_CHECK_MINUTES * 60) {
      res.status(401).json({
        message: 'Token expired, please login',
      });

      return;
    }

    log.info({
      func: 'POST/bawk-staking/check',
      userWalletId,
      bawkStakingCompanyId,
      epoch,
      amount,
      type,
      bawkType,
      gasLimit: req.body.gasLimit,
    }, 'Bawk Staking Check Start');

    const {
      gasLimit,
      coupon,
    } = await redisLock([`${config.lock.bawkStaking}/${userWalletId}`], 30 * 1000, async () => BawkStakingService.getInstance().checkBawkStaking(req));

    log.info({
      func: 'POST/bawk-staking/check',
      userWalletId,
      bawkStakingCompanyId,
      epoch,
      amount,
      type,
      bawkType,
      gasLimit,
      coupon,
    }, 'Bawk Staking Check End');

    res.status(200).json({
      gasLimit,
      coupon,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/bawk-staking/check',
      userWalletId,
      bawkStakingCompanyId,
      epoch,
      amount,
      type,
      bawkType,
      gasLimit: req.body.gasLimit,
      err,
    }, 'Bawk Staking Check Error');

    res.status(400).json({ message: err.message });
  }
});

router.post('/bawk-staking', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;

  const {
    bawkStakingCompanyId,
    epoch,
    amount,
    type,
    bawkType,
    signature,
    deadline,
    gasLimit,
    coupon,
  } = req.body;

  try {
    log.info({
      func: 'POST/bawk-staking',
      userWalletId,
      bawkStakingCompanyId,
      epoch,
      amount,
      type,
      bawkType,
      signature,
      deadline,
      gasLimit,
      coupon,
    }, 'Bawk Staking Start');

    const bawkStakingAssignment = await redisLock([`${config.lock.bawkStaking}/${userWalletId}`], 30 * 1000, async () => {
      const { validatedAmount } = await BawkStakingService.getInstance().checkBawkStaking(req);

      return BawkStakingAssignment.create({
        userWalletId,
        bawkStakingCompanyId,
        epoch,
        amount: validatedAmount,
        type,
        bawkType,
        signature,
        data: {
          deadline,
          gasLimit,
          coupon,
        },
      });
    });

    bawkStakingWorker.add({
      bawkStakingAssignmentId: bawkStakingAssignment.id,
    });

    log.info({
      func: 'POST/bawk-staking',
      userWalletId,
      bawkStakingCompanyId,
      epoch,
      amount,
      type,
      bawkType,
      signature,
      deadline,
      gasLimit,
      coupon,
      bawkStakingAssignmentId: bawkStakingAssignment.id,
    }, 'Bawk Staking End');

    res.status(200).json({ bawkStakingAssignment });
  } catch (err: any) {
    log.info({
      func: 'POST/bawk-staking',
      userWalletId,
      bawkStakingCompanyId,
      epoch,
      amount,
      type,
      bawkType,
      gasLimit,
      coupon,
      err,
    }, 'Bawk Staking Error');

    res.status(400).json({ message: err.message });
  }
});

router.get('/bawk-staking/seasons', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  try {
    const result = await BawkStakingService.getInstance().searchSeasons(req);
    res.json(result);
  } catch (err: any) {
    log.info({
      func: 'GET/bawk-staking/seasons',
      userWalletId: req.user.id,
      query: req.query,
      err,
    }, 'Get Bawk Staking Seasons Error');

    res.status(400).json({ message: err.message });
  }
});

router.get('/bawk-staking', [authBasic, authWalletPublic], async (req: express.Request, res: express.Response) => {
  const userWalletId = req.user?.id as string;

  try {
    const companyStats = await BawkStakingService.getInstance().getCompanyStats(userWalletId);
    res.json(companyStats);
  } catch (err: any) {
    log.info({
      func: 'GET/bawk-staking',
      userWalletId,
      err,
    }, 'Get Bawk Staking Error');

    res.status(400).json({ message: err.message });
  }
});

router.get('/bawk-staking-assignments/last', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;

  try {
    const bawkStakingAssignment = await BawkStakingAssignment.findOne({
      where: {
        userWalletId,
      },
      order: [
        ['id', 'DESC'],
      ],
    });

    res.status(200).json({ bawkStakingAssignment });
  } catch (err: any) {
    log.error({
      func: 'GET/bawk-staking-assignments/last',
      userWalletId,
      err,
    }, 'Get Last Bawk Staking Assignment Error');320;

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
