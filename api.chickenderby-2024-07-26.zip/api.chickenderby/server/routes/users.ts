import * as express from 'express';
import * as bcrypt from 'bcrypt';

const saltRounds = 12;
import * as jwt from 'jsonwebtoken';

import { auth, authAdmin } from '../middleware/auth';
import config from '../config';

// models
import { User } from '../sequelize/models/User';
import { log } from '../utils';

const router = express.Router();

router.get('/users/auth', auth, async (req: express.Request, res: express.Response) => {
  res.send({
    isAuth: true,
    id: req.user.id,
    email: req.user.email,
    roles: (req.user as User).roles,
    nickname: (req.user as User).nickname,
  });
});

router.post('/users/login', async (req, res) => {
  try {
    const userModel = await User.unscoped().findOne({ where: { email: req.body.username } });
    if (!userModel) {
      res.status(400).json({
        isAuth: false,
        message: 'Invalid email address',
      });
      return;
    }
    if (userModel) {
      const isMatch = await bcrypt.compare(req.body.password, userModel.password);
      if (!isMatch) {
        res.status(400).json({
          isAuth: false,
          message: 'Invalid password',
        });
        return;
      }

      const token = jwt.sign({ id: userModel.id }, config.SECRET, { expiresIn: `${config.AUTH_TOKEN_EXPIRATION_HOURS}h` });
      userModel.token = token;
      await userModel.save();

      let sameSiteOption: express.CookieOptions = {
        sameSite: 'none',
        secure: true,
      };

      if (process.env.NODE_ENV === 'development') {
        sameSiteOption = {};
      }

      res.cookie('auth', userModel.token, sameSiteOption).send({
        isAuth: true,
        roles: userModel.roles,
        id: userModel.id,
        email: userModel.email,
      });
    }
  } catch (err: any) {
    log.error({
      func: 'POST/users/login',
      err,
    }, 'User Login Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.post('/users/logout', auth, async (req, res) => {
  try {
    const userModel = await User.unscoped().findOne({ where: { token: req.cookies.auth } });

    await userModel.update({
      token: null,
    });

    res.status(200).json({ message: 'User Logged out' });
  } catch (err: any) {
    log.error({
      func: 'POST/users/logout',
      err,
    }, 'User Logout Error');

    res.status(400).json({ message: err.message });
  }
});

router.get('/users/confirm-email/:token', (req, res) => {
  const { token } = req.params;

  jwt.verify(token, config.SECRET, async (err: any, verify: any) => {
    try {
      if (err) {
        throw err;
      }

      const admin = await User.findOne({ where: { email: verify.email } });

      if (!admin) {
        throw new Error('The token is invalid');
      }

      await admin.update({
        isVerified: true,
      });

      res.status(200).json(admin);
    } catch (err2: any) {
      log.error({
        func: 'GET/users/confirm-email/:token',
        err: err2,
      }, 'Confirm Email Error');

      res.status(400).json({
        message: err2.message,
      });
    }
  });
});

router.get('/users', auth, async (req, res) => {
  try {
    const users = await User.findAll();

    res.status(200).json(users);
  } catch (err: any) {
    log.error({
      func: '/api/users',
      err,
    }, 'All Users Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.patch('/users/change-password', auth, async (req, res) => {
  try {
    const { password } = req.body;
    if (!password || password.length < 8) {
      throw new Error('Password should be more than 8 letters.');
    }

    const userModel = req.user as User;
    const salt = await bcrypt.genSalt(saltRounds);
    const hashedPassword = await bcrypt.hash(password, salt);

    await userModel.update({
      password: hashedPassword,
    });

    res.status(200).json(userModel);
  } catch (err: any) {
    log.error({
      func: 'PATCH/users',
      err,
    }, 'Update User Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.patch('/users/:userId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  const { userId } = req.params;
  const {
    nickname, email, password, role,
  } = req.body;

  try {
    const userModel = userId && await User.findByPk(userId);

    if (!userModel) {
      throw new Error('Can not find user');
    }

    const updatedData: Partial<User> = {
      nickname, email, role,
    };

    if (password) {
      const salt = await bcrypt.genSalt(saltRounds);
      updatedData.password = await bcrypt.hash(password, salt);
    }

    await userModel.update(updatedData);

    res.status(200).json(userModel);
  } catch (err: any) {
    log.error({
      func: 'PATCH/users',
      err,
    }, 'Update User Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.delete('/users/:userId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  const { userId } = req.params;

  try {
    const userRecord = userId && await User.findByPk(userId);

    if (!userRecord) {
      throw new Error('Can not find user');
    }

    await userRecord.destroy();

    res.status(200).json({ message: 'Deleted user successfully' });
  } catch (err: any) {
    log.error({
      func: 'DELETE/users',
      err,
    }, 'Delete User Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
