// Dependencies
import * as express from 'express';

// Middlewares
import { authBasic } from '../middleware/authBasic';

// Services
import { bawkToUsdt, ethToUsdt, jewelToUsdt } from '../services/exchangeService';
import { log } from '../utils';

const router = express.Router();

router.get('/coin-rates', authBasic, async (req: express.Request, res: express.Response) => {
  try {
    const eth = await ethToUsdt();
    const jewel = jewelToUsdt();
    const bawk = bawkToUsdt();

    res.json({
      eth,
      jewel,
      bawk,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/coin-rates',
      err,
    }, 'Get Coin Rates Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
