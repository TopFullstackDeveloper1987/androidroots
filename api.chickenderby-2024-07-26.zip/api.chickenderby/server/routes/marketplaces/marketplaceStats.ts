// Dependencies
import * as express from 'express';
import Sequelize from 'sequelize';

const { Op } = Sequelize;

// Models
import { MarketItem } from '../../sequelize/models/MarketItem';
import { TradeOffer } from '../../sequelize/models/TradeOffer';
import { TradeActivity } from '../../sequelize/models/TradeActivity';

// Middlewares
import { authBasic } from '../../middleware/authBasic';

// Contracts
import { getTotalSupply, getNumberOfOwnersForCollection } from '../../services/contracts/alchemyService';

// Utils
import { log } from '../../utils';

const router = express.Router();

router.get('/marketplace-stats/:nftContract', authBasic, async (req, res) => {
  const { nftContract } = req.params;

  try {
    const totalSupply = await getTotalSupply(nftContract);
    const numberOfOwners = await getNumberOfOwnersForCollection(nftContract);

    const marketItemWithLowestPrice = await MarketItem.scope(['defaultScope', 'active']).findOne({
      where: {
        nftContract,
        price: {
          [Op.gt]: 0,
        },
      },
      order: [['price', 'ASC']],
    });
    const floorPrice = marketItemWithLowestPrice?.price || null;

    const tradeActivity = await TradeActivity.findOne({
      attributes: [
        [Sequelize.fn('count', Sequelize.col('id')), 'totalTrades'],
        [Sequelize.fn('sum', Sequelize.col('price')), 'totalVolume'],
      ],
      where: {
        nftContract,
      },
      raw: true,
    });
    const totalTrades = (tradeActivity as any)?.totalTrades || 0;
    const totalVolume = (tradeActivity as any)?.totalVolume || 0;

    const tradeOfferWithHighestPrice = await TradeOffer.scope(['defaultScope', 'active']).findOne({
      where: {
        nftContract,
      },
      order: [['price', 'DESC']],
    });
    const bestOffer = tradeOfferWithHighestPrice?.price || null;

    res.json({
      nftContract,
      totalSupply,
      numberOfOwners,
      floorPrice,
      totalTrades,
      totalVolume,
      bestOffer,
    });
  } catch (err) {
    log.error({
      func: 'GET/marketplace-stats/:nftContract',
      nftContract,
      err,
    }, 'Get Marketplace Stats Failure');
  }
});

export = router;
