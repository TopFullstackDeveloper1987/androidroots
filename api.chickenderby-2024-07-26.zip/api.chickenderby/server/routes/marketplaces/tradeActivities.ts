// Dependencies
import * as express from 'express';
import Sequelize from 'sequelize';
const { Op } = Sequelize;

// Models
import { TradeActivity } from '../../sequelize/models/TradeActivity';
import { Chicken } from '../../sequelize/models/Chicken';
import { TokenTradeActivity } from '../../sequelize/models/TokenTradeActivity';
import { UserWallet } from '../../sequelize/models/UserWallet';

// Middlewares
import { authBasic } from '../../middleware/authBasic';
import { cache } from '../../middleware/cache';

// Contracts
import { getChickenContractAddress } from '../../services/contracts/chickenContractService';

// Utils
import { log, getPaginationInput } from '../../utils';

const router = express.Router();

router.get('/trade-activities/chickens', [authBasic, cache()], async (req: express.Request, res: express.Response) => {
  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req);

    const chickenContractAddress = await getChickenContractAddress();

    const condition: Sequelize.FindAndCountOptions = {
      where: {
        nftContract: chickenContractAddress,
      },
      limit,
      offset: (page - 1) * limit || 0,
      include: [{
        model: UserWallet,
        as: 'sellerUserWallet',
        attributes: ['id', 'username'],
      }, {
        model: UserWallet,
        as: 'buyerUserWallet',
        attributes: ['id', 'username'],
      }, {
        model: TokenTradeActivity,
        where: {
          nftContract: chickenContractAddress,
        },
        required: false,
        include: [{
          model: Chicken,
        }],
      }],
      order: [[sort.field, sort.order]],
      distinct: true,
    };

    if (filter?.userWalletId) {
      condition.where = {
        ...condition.where,
        [Op.or]: [{
          seller: filter.userWalletId,
        }, {
          buyer: filter.userWalletId,
        }],
      };
    }

    if (filter?.chickenId) {
      (condition.include as Sequelize.Includeable[]).push({
        model: Chicken,
        as: 'chicken',
        where: {
          id: filter.chickenId,
        },
      });
    } else {
      (condition.include as Sequelize.Includeable[]).push({
        model: Chicken,
        as: 'chicken',
        required: true,
      });
    }

    const tradeActivities = await TradeActivity.findAndCountAll(condition);

    res.json(tradeActivities);
  } catch (err: any) {
    log.error({
      func: 'GET/trade-activities/chickens',
      query: req.query,
      err,
    }, 'Get Chicken Trade Activities Error');

    res.status(400).json({ message: err.message });
  }
});

export = router;
