// Dependencies
import * as express from 'express';
import Sequelize from 'sequelize';

// Config
import config from '../../config';

// Middlewares
import { authWallet } from '../../middleware/authWallet';
import { authBasic } from '../../middleware/authBasic';

// Models
import { MarketItem } from '../../sequelize/models/MarketItem';
import { TradeOffer } from '../../sequelize/models/TradeOffer';
import { MarketplaceAssignment } from '../../sequelize/models/MarketplaceAssignment';
import { Chicken } from '../../sequelize/models/Chicken';
import { UserWallet } from '../../sequelize/models/UserWallet';
import { TokenTradeOffer } from '../../sequelize/models/TokenTradeOffer';

// Services
import { redisLock } from '../../services/redisLock';
import { checkMarketplaceAssignment } from '../../services/marketplace/marketplaceService';

// Contracts
import { getChickenContractAddress } from '../../services/contracts/chickenContractService';
import { getTransactionByHash } from '../../services/contracts/alchemyService';

// Types
import { MarketplaceAssignmentType } from '../../types/marketplace/marketplaceAssignmentType';
import { AssignmentStatus } from '../../types/assignments/assignmentStatus';

// Utils
import { log, getPaginationInput } from '../../utils';
import { marketplaceWorker } from '../../queues/marketplaceQueues';

const router = express.Router();

router.post('/trade-offers', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const {
    marketItemId,
    nftContract,
    tokensAttached,
    price,
    signature,
    deadline,
    gasLimit,
  } = req.body;

  try {
    log.info({
      func: 'POST/trade-offers',
      userWalletId,
      marketItemId,
      nftContract,
      tokensAttached,
      price,
      signature,
      deadline,
      gasLimit,
    }, 'Make Offer Start');

    // heroku TTL is 30 seconds per request
    const assignmentType = MarketplaceAssignmentType.MakeOffer;
    const marketplaceAssignment = await redisLock([
      `${config.lock.marketplace}/${userWalletId}`,
      `${config.lock.marketplace}/${marketItemId}`,
    ], 30 * 1000, async () => MarketplaceAssignment.sequelize.transaction(async (t) => {
      const { tradeOfferId } = await checkMarketplaceAssignment(assignmentType, req, {
        transaction: t,
      });

      const marketItem = await MarketItem.findByPk(marketItemId);
      return MarketplaceAssignment.create({
        userWalletId,
        type: assignmentType,
        marketItemId,
        tokenId: marketItem.tokenId,
        tradeOfferId,
        nftContract,
        tokensAttached,
        price,
        signature,
        data: {
          deadline,
          gasLimit,
        },
      }, {
        transaction: t,
      });
    }));

    marketplaceWorker.add({
      marketplaceAssignmentId: marketplaceAssignment.id,
    });

    log.info({
      func: 'POST/trade-offers',
      userWalletId,
      marketItemId,
      tradeOfferId: marketplaceAssignment.tradeOfferId,
      nftContract,
      tokensAttached,
      price,
      signature,
      deadline,
      gasLimit,
      marketplaceAssignmentId: marketplaceAssignment.id,
    }, 'Make Offer Success');

    res.status(200).json(marketplaceAssignment);
  } catch (err: any) {
    log.error({
      func: 'POST/trade-offers',
      userWalletId,
      marketItemId,
      nftContract,
      tokensAttached,
      price,
      signature,
      deadline,
      gasLimit,
      err,
    }, 'Make Offer Failure');

    res.status(400).json({ message: err.message });
  }
});

router.patch('/trade-offers/:tradeOfferId/cancel', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const { tradeOfferId } = req.params;
  const {
    signature,
    deadline,
    gasLimit,
  } = req.body;

  try {
    log.info({
      func: 'PATCH/trade-offers/:tradeOfferId/cancel',
      userWalletId,
      tradeOfferId,
      signature,
      deadline,
      gasLimit,
    }, 'Cancel Or Decline Trade Offer Start');

    const tradeOffer = await TradeOffer.findByPk(tradeOfferId);
    if (!tradeOffer) {
      throw new Error('Trade Offer not found');
    }

    // heroku TTL is 30 seconds per request
    const assignmentType = MarketplaceAssignmentType.CancelOrDeclineOffer;
    const marketplaceAssignment = await redisLock([
      `${config.lock.marketplace}/${userWalletId}`,
      `${config.lock.marketplace}/${tradeOffer.marketItemId}`,
    ], 30 * 1000, async () => MarketplaceAssignment.sequelize.transaction(async (t) => {
      await checkMarketplaceAssignment(assignmentType, req, {
        transaction: t,
      });

      await tradeOffer.update({
        assignmentType,
        assignmentStatus: AssignmentStatus.Pending,
        syncedAt: null,
      }, {
        transaction: t,
      });

      const marketItem = await MarketItem.findByPk(tradeOffer.marketItemId);
      return MarketplaceAssignment.create({
        userWalletId,
        type: assignmentType,
        marketItemId: tradeOffer.marketItemId,
        nftContract: tradeOffer.nftContract,
        tokenId: marketItem.tokenId,
        tradeOfferId,
        signature,
        data: {
          deadline,
          gasLimit,
        },
      }, {
        transaction: t,
      });
    }));

    marketplaceWorker.add({
      marketplaceAssignmentId: marketplaceAssignment.id,
    });

    log.info({
      func: 'PATCH/trade-offers/:tradeOfferId/cancel',
      userWalletId,
      tradeOfferId,
      signature,
      deadline,
      gasLimit,
      marketplaceAssignmentId: marketplaceAssignment.id,
    }, 'Cancel Or Decline Trade Offer Success');

    res.status(200).json(marketplaceAssignment);
  } catch (err: any) {
    log.error({
      func: 'PATCH/trade-offers/:tradeOfferId/cancel',
      userWalletId,
      tradeOfferId,
      signature,
      deadline,
      gasLimit,
      err,
    }, 'Cancel Or Decline Trade Offer Failure');

    res.status(400).json({ message: err.message });
  }
});

router.patch('/trade-offers/:tradeOfferId', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const { tradeOfferId } = req.params;
  const {
    price,
    nftContract,
    tokensAttached,
    signature,
    deadline,
    gasLimit,
  } = req.body;

  try {
    log.info({
      func: 'PATCH/trade-offers/:tradeOfferId',
      userWalletId,
      tradeOfferId,
      price,
      nftContract,
      tokensAttached,
      signature,
      deadline,
      gasLimit,
    }, 'Edit Trade Offer Start');

    const tradeOffer = await TradeOffer.findByPk(tradeOfferId);
    if (!tradeOffer) {
      throw new Error('Trade Offer not found');
    }

    // heroku TTL is 30 seconds per request
    const assignmentType = MarketplaceAssignmentType.EditOffer;
    const marketplaceAssignment = await redisLock([
      `${config.lock.marketplace}/${userWalletId}`,
      `${config.lock.marketplace}/${tradeOffer.marketItemId}`,
    ], 30 * 1000, async () => MarketplaceAssignment.sequelize.transaction(async (t) => {
      await checkMarketplaceAssignment(assignmentType, req, {
        transaction: t,
      });

      await tradeOffer.update({
        assignmentType,
        assignmentStatus: AssignmentStatus.Pending,
        syncedAt: null,
      }, {
        transaction: t,
      });

      const marketItem = await MarketItem.findByPk(tradeOffer.marketItemId);
      return MarketplaceAssignment.create({
        userWalletId,
        type: assignmentType,
        marketItemId: tradeOffer.marketItemId,
        tokenId: marketItem.tokenId,
        tradeOfferId,
        price: price !== undefined ? price : tradeOffer.price,
        nftContract: nftContract !== undefined ? nftContract : tradeOffer.nftContract,
        tokensAttached: tokensAttached !== undefined ? tokensAttached : tradeOffer.tokensAttached,
        signature,
        data: {
          deadline,
          gasLimit,
        },
      }, {
        transaction: t,
      });
    }));

    marketplaceWorker.add({
      marketplaceAssignmentId: marketplaceAssignment.id,
    });

    log.info({
      func: 'PATCH/trade-offers/:tradeOfferId',
      userWalletId,
      tradeOfferId,
      price,
      nftContract,
      tokensAttached,
      signature,
      deadline,
      gasLimit,
      marketplaceAssignmentId: marketplaceAssignment.id,
    }, 'Edit Trade Offer Success');

    res.status(200).json(marketplaceAssignment);
  } catch (err: any) {
    log.error({
      func: 'PATCH/trade-offers/:tradeOfferId',
      userWalletId,
      tradeOfferId,
      price,
      nftContract,
      tokensAttached,
      signature,
      deadline,
      gasLimit,
      err,
    }, 'Edit Trade Offer Failure');

    res.status(400).json({ message: err.message });
  }
});

router.post('/trade-offers/:tradeOfferId/fulfill', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const { tradeOfferId } = req.params;
  const { transactionHash, gasLimit } = req.body;

  try {
    log.info({
      func: 'POST/trade-offers/:tradeOfferId/fulfill',
      userWalletId,
      tradeOfferId,
      transactionHash,
      gasLimit,
    }, 'Fulfill Offer Start');

    const tradeOffer = await TradeOffer.findByPk(tradeOfferId);
    if (!tradeOffer) {
      throw new Error('Trade Offer not found');
    }

    const transaction = await getTransactionByHash(transactionHash);
    const nonce = transaction ? Number(transaction.nonce) : undefined;

    // heroku TTL is 30 seconds per request
    const assignmentType = MarketplaceAssignmentType.FulfillOffer;
    const marketplaceAssignment = await redisLock([
      `${config.lock.marketplace}/${userWalletId}`,
      `${config.lock.marketplace}/${tradeOffer.marketItemId}`,
    ], 30 * 1000, async () => MarketplaceAssignment.sequelize.transaction(async (t) => {
      await tradeOffer.update({
        assignmentType,
        assignmentStatus: AssignmentStatus.Pending,
        syncedAt: null,
      }, {
        transaction: t,
      });

      const marketItem = await MarketItem.findByPk(tradeOffer.marketItemId);
      return MarketplaceAssignment.create({
        userWalletId,
        type: assignmentType,
        marketItemId: tradeOffer.marketItemId,
        nftContract: marketItem.nftContract,
        tokenId: marketItem.tokenId,
        tradeOfferId: tradeOffer.id,
        transactionHash,
        txHashes: [transactionHash],
        nonce,
        data: {
          gasLimit,
        },
      }, {
        transaction: t,
      });
    }));

    marketplaceWorker.add({
      marketplaceAssignmentId: marketplaceAssignment.id,
    });

    log.info({
      func: 'POST/trade-offers/:tradeOfferId/fulfill',
      userWalletId,
      tradeOfferId,
      transactionHash,
      gasLimit,
      marketplaceAssignmentId: marketplaceAssignment.id,
    }, 'Fulfill Offer Success');

    res.status(200).json(marketplaceAssignment);
  } catch (err: any) {
    log.error({
      func: 'POST/trade-offers/:tradeOfferId/fulfill',
      userWalletId,
      tradeOfferId,
      transactionHash,
      gasLimit,
      err,
    }, 'Fulfill Offer Failure');

    res.status(400).json({ message: err.message });
  }
});

router.get('/trade-offers/chickens', authBasic, async (req, res) => {
  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req);

    const chickenContractAddress = await getChickenContractAddress();

    const condition: Sequelize.FindAndCountOptions = {
      where: {
      },
      limit,
      offset: (page - 1) * limit || 0,
      include: [{
        model: UserWallet,
        attributes: ['id', 'username'],
      }, {
        model: TokenTradeOffer,
        required: false,
        where: {
          nftContract: chickenContractAddress,
        },
        include: [{
          model: Chicken,
          attributes: ['id', 'name', 'image'],
        }],
      }],
      order: [[sort.field, sort.order]],
      distinct: true,
    };

    const marketItemCondition: Sequelize.Includeable = {
      model: MarketItem.scope(['defaultScope', 'active']),
      where: {
        nftContract: chickenContractAddress,
      },
      include: [{
        model: UserWallet,
        as: 'sellerUserWallet',
        attributes: ['id', 'username'],
      }],
    };

    if (filter?.type === 'received') {
      if (filter.userWalletId) {
        marketItemCondition.where = {
          ...marketItemCondition.where,
          seller: filter.userWalletId,
        };
      }
    } else if (filter?.type === 'made') {
      if (filter.userWalletId) {
        condition.where = {
          ...condition.where,
          offerMaker: filter.userWalletId,
        };
      }
    }

    if (filter?.chickenId) {
      marketItemCondition.include.push({
        model: Chicken,
        as: 'chicken',
        attributes: ['id', 'name', 'image'],
        where: {
          id: filter.chickenId,
        },
      });
    } else {
      marketItemCondition.include.push({
        model: Chicken,
        as: 'chicken',
        attributes: ['id', 'name', 'image'],
        required: true,
      });
    }

    (condition.include as Sequelize.Includeable[]).push(marketItemCondition);
    const tradeOffers = await TradeOffer.scope(['defaultScope', 'active']).findAndCountAll(condition);

    res.json(tradeOffers);
  } catch (err: any) {
    log.error({
      func: 'GET/trade-offers/chickens',
      query: req.query,
      err,
    }, 'Get Chicken Trade Offers Error');

    res.status(400).json({ message: err.message });
  }
});

export = router;
