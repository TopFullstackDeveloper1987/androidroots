// Dependencies
import * as express from 'express';
import Sequelize from 'sequelize';

// Config
import config from '../../config';

// Middlewares
import { authWallet } from '../../middleware/authWallet';
import { authBasic } from '../../middleware/authBasic';

// Models
import { MarketItem } from '../../sequelize/models/MarketItem';
import { Chicken } from '../../sequelize/models/Chicken';
import { TradePreference } from '../../sequelize/models/TradePreference';
import { UserWallet } from '../../sequelize/models/UserWallet';

// Services
import { redisLock } from '../../services/redisLock';
import { getChickenFilter } from '../../services/chickenService';
import { checkReplaceTradePreference, replaceTradePreference, markTradeOffersToDecline } from '../../services/marketplace/marketplaceService';

// Contracts
import { getContractType } from '../../services/contracts/web3Service';
import { getChickenContractAddress } from '../../services/contracts/chickenContractService';

// Utils
import { log, getPaginationInput } from '../../utils';

// Types
import { MarketplaceTradeType } from '../../types/marketplace/marketplaceTradeType';

const router = express.Router();

router.put('/trade-preferences/:nftContract', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;
  const { nftContract } = req.params;
  const {
    tokenId,
    preference,
  } = req.body;

  try {
    log.info({
      func: 'PUT/trade-preferences',
      userWalletId,
      nftContract,
      tokenId,
      preference,
    }, 'Put TradePreference Start');

    const contractType = await getContractType(nftContract);
    if (!contractType) {
      throw new Error('Invalid contract address');
    }

    const lockKeys = [`${config.lock.marketplace}/${userWalletId}`];

    const where: Sequelize.WhereOptions = {
      nftContract,
      seller: userWalletId,
    };

    if (tokenId) {
      where.tokenId = tokenId;
      where.tradeType = MarketplaceTradeType.CustomPreference;
    } else {
      where.tradeType = MarketplaceTradeType.Preference;
    }

    const marketItems = await MarketItem.scope(['defaultScope', 'active']).findAll({ where });
    marketItems.forEach((marketItem) => {
      lockKeys.push(`${config.lock.marketplace}/${marketItem.id}`);
    });

    // heroku TTL is 30 seconds per request
    const tradePreference = await redisLock(lockKeys, 30 * 1000, async () => {
      await checkReplaceTradePreference(req);

      return TradePreference.sequelize.transaction(async (t) => {
        await markTradeOffersToDecline({
          userWalletId,
          nftContract,
          tokenId,
          tradeType: tokenId ? MarketplaceTradeType.CustomPreference : MarketplaceTradeType.Preference,
          preference,
          reason: `The ${contractType} owner has updated the trade preference`,
          transaction: t,
        });

        return replaceTradePreference({
          userWalletId,
          nftContract,
          tokenId,
          preference,
          transaction: t,
        });
      });
    });

    log.info({
      func: 'PUT/trade-preferences',
      userWalletId,
      nftContract,
      tokenId,
      preference,
    }, 'Put TradePreference Success');

    res.status(200).json(tradePreference);
  } catch (err: any) {
    log.error({
      func: 'PUT/trade-preferences',
      userWalletId,
      nftContract,
      tokenId,
      preference,
      err,
    }, 'Put TradePreference Failure');

    res.status(400).json({ message: err.message });
  }
});

router.get('/trade-preferences/chickens', authBasic, async (req, res) => {
  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req);

    const chickenContractAddress = await getChickenContractAddress();

    const condition: Sequelize.FindAndCountOptions = {
      where: {
        nftContract: chickenContractAddress,
      },
      limit,
      offset: (page - 1) * limit || 0,
      include: [],
      order: [[sort.field, sort.order]],
      distinct: true,
    };

    if (filter?.userWalletId) {
      condition.where = {
        ...condition.where,
        userWalletId: filter.userWalletId,
      };
    }

    if (filter?.chickenId) {
      (condition.include as Sequelize.Includeable[]).push({
        model: Chicken,
        as: 'chicken',
        where: {
          id: filter.chickenId,
        },
      });
    } else {
      (condition.include as Sequelize.Includeable[]).push({
        model: Chicken,
        as: 'chicken',
        required: true,
      });
    }

    const tradePreferences = await TradePreference.findAndCountAll(condition);

    for (const tradePreference of tradePreferences.rows) {
      const chickenFilter = await getChickenFilter(filter);
      const potentialCount = await Chicken.count({
        where: chickenFilter,
      });
      (tradePreference as any).potentialCount = potentialCount;
    }

    res.json(tradePreferences);
  } catch (err: any) {
    log.error({
      func: 'GET/trade-preferences/chickens',
      query: req.query,
      err,
    }, 'Get Chicken Trade Preferences Error');

    res.status(400).json({ message: err.message });
  }
});

export = router;
