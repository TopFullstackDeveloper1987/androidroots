// Dependencies
import * as express from 'express';
import { Op } from 'sequelize';

// Config
import config from '../../config';

// Middlewares
import { authWallet } from '../../middleware/authWallet';
import { authBasic } from '../../middleware/authBasic';

// Models
import { MarketplaceAssignment } from '../../sequelize/models/MarketplaceAssignment';
import { TradeOffer } from '../../sequelize/models/TradeOffer';

// Services
import { redisLock } from '../../services/redisLock';
import { checkMarketplaceAssignment } from '../../services/marketplace/marketplaceService';

// Utils
import { log } from '../../utils';

// Types
import { MarketplaceAssignmentType } from '../../types/marketplace/marketplaceAssignmentType';

const router = express.Router();

router.post('/marketplace-assignments/check', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const {
    assignmentType, tradeOfferId, nftContract, tokenId,
  } = req.body;
  let { marketItemId } = req.body;

  try {
    if (req.tokenExpiresInSeconds < config.AUTH_TOKEN_EXPIRATION_CHECK_MINUTES * 60) {
      res.status(401).json({
        message: 'Token expired, please login',
      });
      return;
    }

    if (!marketItemId) {
      const tradeOffer = tradeOfferId && await TradeOffer.findByPk(tradeOfferId);
      marketItemId = tradeOffer?.marketItemId;
    }

    const lockKeys = [`${config.lock.marketplace}/${userWalletId}`];
    if (marketItemId) {
      lockKeys.push(`${config.lock.marketplace}/${marketItemId}`);
    }

    // for createMarketItem and makeOffer, it creates a pending marketItem or tradeOffer and returns id
    // so that the frontend could pass it for the contract call
    const checkResult = await redisLock(
      lockKeys,
      30 * 1000,
      async () => MarketplaceAssignment.sequelize.transaction(async (t) => checkMarketplaceAssignment(assignmentType, req, {
        isCheckTokenApproval: false,
        transaction: t,
      })),
    );

    res.json(checkResult);
  } catch (err: any) {
    log.error({
      func: 'POST/marketplace-assignments/check',
      userWalletId,
      assignmentType,
      marketItemId,
      tradeOfferId,
      nftContract,
      tokenId,
      err,
    }, 'Check Marketplace Assignment Failure');

    res.status(400).json({ message: err.message });
  }
});

router.get('/marketplace-assignments/last', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;

  try {
    const marketplaceAssignment = await MarketplaceAssignment.findOne({
      where: {
        userWalletId,
        type: {
          [Op.notIn]: [MarketplaceAssignmentType.AutoDeclineOffer, MarketplaceAssignmentType.AutoCancelMarketItem],
        },
      },
      include: [{
        model: TradeOffer,
        attributes: ['offerMaker'],
        required: false,
      }],
      order: [
        ['id', 'DESC'],
      ],
    });

    res.status(200).json({ marketplaceAssignment });
  } catch (err: any) {
    log.error({
      func: 'GET/marketplace-assignments/last',
      userWalletId,
      err,
    }, 'Get Last Marketplace Assignment Failure');

    res.status(400).json({ message: err.message });
  }
});

export = router;
