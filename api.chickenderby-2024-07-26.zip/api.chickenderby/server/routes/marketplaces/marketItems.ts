// Dependencies
import * as express from 'express';
import Sequelize from 'sequelize';

const { Op } = Sequelize;

// Config
import config from '../../config';

// Middlewares
import { authWallet } from '../../middleware/authWallet';
import { authBasic } from '../../middleware/authBasic';

// Models
import { MarketItem } from '../../sequelize/models/MarketItem';
import { MarketplaceAssignment } from '../../sequelize/models/MarketplaceAssignment';
import { Chicken } from '../../sequelize/models/Chicken';
import { TradeActivity } from '../../sequelize/models/TradeActivity';
import { UserWallet } from '../../sequelize/models/UserWallet';
import { TradeOffer } from '../../sequelize/models/TradeOffer';

// Contracts
import { toChecksumAddress } from '../../services/contracts/web3Service';
import { getOwnersOfChickens } from '../../services/contracts/chickenContractService';
import { getTransactionByHash } from '../../services/contracts/alchemyService';

// Services
import { redisLock } from '../../services/redisLock';
import { checkMarketplaceAssignment } from '../../services/marketplace/marketplaceService';
import { ethToUsdt } from '../../services/exchangeService';
import { getChickenFilter } from '../../services/chickenService';

// Types
import { MarketplaceAssignmentType } from '../../types/marketplace/marketplaceAssignmentType';
import { AssignmentStatus } from '../../types/assignments/assignmentStatus';
import { MarketplaceTradeType } from '../../types/marketplace/marketplaceTradeType';

// Utils
import { log, getPaginationInput } from '../../utils';
import { marketplaceWorker } from '../../queues/marketplaceQueues';

const router = express.Router();

router.post('/market-items', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const {
    nftContract,
    tokenId,
    price,
    minimum,
    tradeType,
    signature,
    deadline,
    gasLimit,
  } = req.body;

  try {
    log.info({
      func: 'POST/market-items',
      userWalletId,
      nftContract,
      tokenId,
      price,
      minimum,
      tradeType,
      signature,
      deadline,
      gasLimit,
    }, 'Create Market Item Start');

    // heroku TTL is 30 seconds per request
    const assignmentType = MarketplaceAssignmentType.CreateMarketItem;
    const marketplaceAssignment = await redisLock(
      [`${config.lock.marketplace}/${userWalletId}`],
      30 * 1000,
      async () => MarketplaceAssignment.sequelize.transaction(async (t) => {
        const { marketItemId } = await checkMarketplaceAssignment(assignmentType, req, {
          transaction: t,
        });

        return MarketplaceAssignment.create({
          userWalletId,
          type: assignmentType,
          marketItemId,
          nftContract,
          tokenId,
          price,
          minimum,
          tradeType,
          signature,
          data: {
            deadline,
            gasLimit,
          },
        }, {
          transaction: t,
        });
      }),
    );

    marketplaceWorker.add({
      marketplaceAssignmentId: marketplaceAssignment.id,
    });

    log.info({
      func: 'POST/market-items',
      userWalletId,
      marketItemId: marketplaceAssignment.marketItemId,
      nftContract,
      tokenId,
      price,
      minimum,
      tradeType,
      signature,
      deadline,
      gasLimit,
      marketplaceAssignmentId: marketplaceAssignment.id,
    }, 'Create Market Item Success');

    res.status(200).json(marketplaceAssignment);
  } catch (err: any) {
    log.error({
      func: 'POST/market-items',
      userWalletId,
      nftContract,
      tokenId,
      price,
      minimum,
      tradeType,
      signature,
      deadline,
      gasLimit,
      err,
    }, 'Create Market Item Failure');

    res.status(400).json({ message: err.message });
  }
});

router.patch('/market-items/:marketItemId/cancel', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const { marketItemId } = req.params;
  const {
    signature,
    deadline,
    gasLimit,
  } = req.body;

  try {
    log.info({
      func: 'PATCH/market-items/:marketItemId/cancel',
      userWalletId,
      marketItemId,
      signature,
      deadline,
      gasLimit,
    }, 'Cancel Market Item Start');

    // heroku TTL is 30 seconds per request
    const assignmentType = MarketplaceAssignmentType.CancelMarketItem;
    const marketplaceAssignment = await redisLock([
      `${config.lock.marketplace}/${userWalletId}`,
      `${config.lock.marketplace}/${marketItemId}`,
    ], 30 * 1000, async () => MarketplaceAssignment.sequelize.transaction(async (t) => {
      await checkMarketplaceAssignment(assignmentType, req, {
        transaction: t,
      });

      const marketItem = await MarketItem.findByPk(marketItemId);
      await marketItem.update({
        assignmentType,
        assignmentStatus: AssignmentStatus.Pending,
        syncedAt: null,
      }, {
        transaction: t,
      });

      return MarketplaceAssignment.create({
        userWalletId,
        type: assignmentType,
        marketItemId: marketItem.id,
        nftContract: marketItem.nftContract,
        tokenId: marketItem.tokenId,
        signature,
        data: {
          deadline,
          gasLimit,
        },
      }, {
        transaction: t,
      });
    }));

    marketplaceWorker.add({
      marketplaceAssignmentId: marketplaceAssignment.id,
    });

    log.info({
      func: 'PATCH/market-items/:marketItemId/cancel',
      userWalletId,
      marketItemId,
      signature,
      deadline,
      gasLimit,
      marketplaceAssignmentId: marketplaceAssignment.id,
    }, 'Cancel Market Item Success');

    res.status(200).json(marketplaceAssignment);
  } catch (err: any) {
    log.error({
      func: 'PATCH/market-items/:marketItemId/cancel',
      userWalletId,
      marketItemId,
      signature,
      deadline,
      gasLimit,
      err,
    }, 'Cancel Market Item Failure');

    res.status(400).json({ message: err.message });
  }
});

router.patch('/market-items/:marketItemId', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const { marketItemId } = req.params;
  const {
    price,
    minimum,
    tradeType,
    signature,
    deadline,
    gasLimit,
  } = req.body;

  try {
    log.info({
      func: 'PATCH/market-items/:marketItemId',
      userWalletId,
      marketItemId,
      price,
      minimum,
      tradeType,
      signature,
      deadline,
      gasLimit,
    }, 'Edit Market Item Start');

    // heroku TTL is 30 seconds per request
    const assignmentType = MarketplaceAssignmentType.EditMarketItem;
    const marketplaceAssignment = await redisLock([
      `${config.lock.marketplace}/${userWalletId}`,
      `${config.lock.marketplace}/${marketItemId}`,
    ], 30 * 1000, async () => MarketplaceAssignment.sequelize.transaction(async (t) => {
      await checkMarketplaceAssignment(assignmentType, req, {
        transaction: t,
      });

      const marketItem = await MarketItem.findByPk(marketItemId);
      await marketItem.update({
        assignmentType,
        assignmentStatus: AssignmentStatus.Pending,
        syncedAt: null,
      }, {
        transaction: t,
      });

      return MarketplaceAssignment.create({
        userWalletId,
        type: assignmentType,
        marketItemId: marketItem.id,
        nftContract: marketItem.nftContract,
        tokenId: marketItem.tokenId,
        price: price !== undefined ? price : marketItem.price,
        minimum: minimum !== undefined ? minimum : marketItem.minimum,
        tradeType: tradeType !== undefined ? tradeType : marketItem.tradeType,
        signature,
        data: {
          deadline,
          gasLimit,
        },
      }, {
        transaction: t,
      });
    }));

    marketplaceWorker.add({
      marketplaceAssignmentId: marketplaceAssignment.id,
    });

    log.info({
      func: 'PATCH/market-items/:marketItemId',
      userWalletId,
      marketItemId,
      price,
      minimum,
      tradeType,
      signature,
      deadline,
      gasLimit,
      marketplaceAssignmentId: marketplaceAssignment.id,
    }, 'Edit Market Item Success');

    res.status(200).json(marketplaceAssignment);
  } catch (err: any) {
    log.error({
      func: 'PATCH/market-items/:marketItemId',
      userWalletId,
      marketItemId,
      price,
      minimum,
      tradeType,
      signature,
      deadline,
      gasLimit,
      err,
    }, 'Edit Market Item Failure');

    res.status(400).json({ message: err.message });
  }
});

router.post('/market-items/:marketItemId/purchase', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const { marketItemId } = req.params;
  const { transactionHash, gasLimit } = req.body;

  try {
    log.info({
      func: 'POST/market-items/:marketItemId/purchase',
      userWalletId,
      marketItemId,
      transactionHash,
      gasLimit,
    }, 'Purchase Market Item Start');

    const transaction = await getTransactionByHash(transactionHash);
    const nonce = transaction ? Number(transaction.nonce) : undefined;

    // heroku TTL is 30 seconds per request
    const assignmentType = MarketplaceAssignmentType.PurchaseMarketItem;
    const marketplaceAssignment = await redisLock([
      `${config.lock.marketplace}/${userWalletId}`,
      `${config.lock.marketplace}/${marketItemId}`,
    ], 30 * 1000, async () => MarketplaceAssignment.sequelize.transaction(async (t) => {
      const marketItem = await MarketItem.findByPk(marketItemId);
      await marketItem.update({
        assignmentType,
        assignmentStatus: AssignmentStatus.Pending,
        syncedAt: null,
      }, {
        transaction: t,
      });

      return MarketplaceAssignment.create({
        userWalletId,
        type: assignmentType,
        marketItemId: marketItem.id,
        nftContract: marketItem.nftContract,
        tokenId: marketItem.tokenId,
        transactionHash,
        txHashes: [transactionHash],
        nonce,
        data: {
          gasLimit,
        },
      }, {
        transaction: t,
      });
    }));

    marketplaceWorker.add({
      marketplaceAssignmentId: marketplaceAssignment.id,
    });

    log.info({
      func: 'POST/market-items/:marketItemId/purchase',
      userWalletId,
      marketItemId,
      transactionHash,
      gasLimit,
      marketplaceAssignmentId: marketplaceAssignment.id,
    }, 'Purchase Market Item Success');

    res.status(200).json(marketplaceAssignment);
  } catch (err: any) {
    log.error({
      func: 'POST/market-items/:marketItemId/purchase',
      userWalletId,
      marketItemId,
      transactionHash,
      gasLimit,
      err,
    }, 'Purchase Market Item Failure');

    res.status(400).json({ message: err.message });
  }
});

router.get('/market-items/chickens', authBasic, async (req, res) => {
  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req);

    const ethPrice = await ethToUsdt();

    const chickenFilter = await getChickenFilter(filter);
    const condition: Sequelize.WhereOptions = {
      where: chickenFilter,
      limit,
      offset: (page - 1) * limit || 0,
      include: [{
        model: TradeActivity,
        as: 'lastTradeActivity',
        attributes: ['id', 'price'],
        required: false,
      }],
      order: [],
      distinct: true,
    };

    // Sort By
    // price, lastSale, name, marketItemId, id
    if (sort.field === 'price') {
      condition.order.push(
        [Sequelize.fn('isnull', Sequelize.col('lastActiveMarketItemId')), 'ASC'],
        [Sequelize.literal(`lastActiveMarketItem.tradeType = ${MarketplaceTradeType.OfferOnly}`), 'ASC'],
        ['lastActiveMarketItem', 'price', sort.order],
      );
    } else if (sort.field === 'lastSale') {
      condition.order.push(
        [Sequelize.fn('isnull', Sequelize.col('lastTradeActivityId')), 'ASC'],
        ['lastTradeActivity', 'price', sort.order],
      );
    } else if (sort.field === 'lastActiveMarketItemId') {
      condition.order.push(
        [Sequelize.fn('isnull', Sequelize.col('lastActiveMarketItemId')), 'ASC'],
        [sort.field, sort.order],
      );
    } else {
      condition.order.push([sort.field, sort.order]);
    }

    const marketItemCondition = {
      model: MarketItem.scope(['defaultScope', 'active']),
      as: 'lastActiveMarketItem',
      required: false,
      where: {},
    };

    // Price
    if (filter?.priceUsdMin && filter?.priceUsdMax) {
      marketItemCondition.where = {
        ...marketItemCondition.where,
        price: {
          [Op.gte]: Number(filter.priceUsdMin) / ethPrice,
          [Op.lte]: Number(filter.priceUsdMax) / ethPrice,
        },
      };
      marketItemCondition.required = true;
    } else if (filter?.priceUsdMin) {
      marketItemCondition.where = {
        ...marketItemCondition.where,
        price: {
          [Op.gte]: Number(filter.priceUsdMin) / ethPrice,
        },
      };
      marketItemCondition.required = true;
    } else if (filter?.priceUsdMax) {
      marketItemCondition.where = {
        ...marketItemCondition.where,
        price: {
          [Op.lte]: Number(filter.priceUsdMax) / ethPrice,
        },
      };
      marketItemCondition.required = true;
    }

    if (filter?.priceWethMin && filter?.priceWethMax) {
      marketItemCondition.where = {
        ...marketItemCondition.where,
        price: {
          [Op.gte]: Number(filter.priceWethMin),
          [Op.lte]: Number(filter.priceWethMax),
        },
      };
      marketItemCondition.required = true;
    } else if (filter?.priceWethMin) {
      marketItemCondition.where = {
        ...marketItemCondition.where,
        price: {
          [Op.gte]: Number(filter.priceWethMin),
        },
      };
      marketItemCondition.required = true;
    } else if (filter?.priceWethMax) {
      marketItemCondition.where = {
        ...marketItemCondition.where,
        price: {
          [Op.lte]: Number(filter.priceWethMax),
        },
      };
      marketItemCondition.required = true;
    }

    if (filter?.priceUsdMax === 0 || filter?.priceWethMax === 0) {
      // apply only for NoTrade - Buy Now (No Offers)
      marketItemCondition.where = {
        ...marketItemCondition.where,
        [Op.or]: [{
          tradeType: {
            [Op.not]: MarketplaceTradeType.NoTrade,
          },
        }, {
          price: 0,
        }],
      };
      marketItemCondition.required = true;
    }

    if (filter?.tradeTypes?.length) {
      marketItemCondition.where = {
        ...marketItemCondition.where,
        tradeType: filter.tradeTypes,
      };
      marketItemCondition.required = true;
    }

    condition.include.push(marketItemCondition);
    const chickens = await Chicken.scope('active').findAndCountAll(condition);
    const chickenIds = chickens.rows.map((chicken) => chicken.id);
    const userWalletIds = await getOwnersOfChickens(chickenIds);
    const userWallets = await UserWallet.findAll({
      where: {
        id: userWalletIds,
      },
    });

    const rows = [];
    for (let i = 0; i < chickens.rows.length; i += 1) {
      const userWalletId = userWalletIds[i];
      const userWallet = userWalletId && userWallets.find((uw) => toChecksumAddress(uw.id) === toChecksumAddress(userWalletId));

      const chicken = chickens.rows[i];
      const { lastActiveMarketItemId } = chicken;
      const highestTradeOffer = lastActiveMarketItemId && await TradeOffer.scope(['defaultScope', 'active']).findOne({
        where: {
          marketItemId: lastActiveMarketItemId,
        },
        attributes: ['id', 'price'],
        order: [['price', 'DESC']],
      });

      rows.push({
        ...chicken.toJSON(),
        userWalletId,
        username: userWallet?.username || null,
        highestTradeOffer: highestTradeOffer || null,
      });
    }
    chickens.rows = rows;

    res.json(chickens);
  } catch (err: any) {
    log.error({
      func: 'GET/market-items/chickens',
      query: req.query,
      err,
    }, 'Get Chicken Market Items Failure');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
