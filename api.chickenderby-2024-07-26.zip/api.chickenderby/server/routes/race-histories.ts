import * as express from 'express';

import { cache } from '../middleware/cache';
import { authBasic } from '../middleware/authBasic';
import { RaceHistoryService } from '../services/race-histories.service';

const router = express.Router();

router.get('/race-histories/leaderboard', [authBasic, cache()], async (req: express.Request, res: express.Response) => {
  try {
    const stats = await RaceHistoryService.getInstace().getLeaderboardStats();

    res.json(stats);
  } catch (err: unknown) {
    res.status(400).json({
      message: (err as Error).message,
    });
  }
});

router.get('/race-histories/:chickenId', [authBasic, cache()], async (req: express.Request, res: express.Response) => {
  try {
    const stats = await RaceHistoryService.getInstace().getChickenStats(req);

    res.json({
      stats,
    });
  } catch (err: unknown) {
    res.status(400).json({
      message: (err as Error).message,
    });
  }
});

export = router;
