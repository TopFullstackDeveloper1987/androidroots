import * as express from 'express';

import config from '../config';
import { log } from '../utils';

const router = express.Router();

router.get('/git-info', async (req, res) => {
  try {
    const serverGitInfo = require(`../${config.SERVER_GIT_JSON}`);
    const raceJobsGitInfo = require(`../${config.RACE_JOBS_GIT_JSON}`);
    const marketplaceJobsGitInfo = require(`../${config.MARKETPLACE_JOBS_GIT_JSON}`);
    const fusionJobsGitInfo = require(`../${config.FUSION_JOBS_GIT_JSON}`);
    const coinPresaleJobsGitInfo = require(`../${config.COIN_PRESALE_JOBS_GIT_JSON}`);

    log.info({
      func: 'GET/git-info',
      serverGitInfo,
      raceJobsGitInfo,
      marketplaceJobsGitInfo,
      fusionJobsGitInfo,
      coinPresaleJobsGitInfo,
    }, 'Get Git Info');

    res.json({
      server: serverGitInfo,
      raceJobs: raceJobsGitInfo,
      marketplaceJobs: marketplaceJobsGitInfo,
      fusionJobs: fusionJobsGitInfo,
      coinPresale: coinPresaleJobsGitInfo,
    });
  } catch (err: any) {
    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
