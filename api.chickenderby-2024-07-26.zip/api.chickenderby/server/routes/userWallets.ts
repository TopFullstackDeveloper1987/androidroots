// Dependencies
import * as express from 'express';
import Sequelize from 'sequelize';
const { Op } = Sequelize;
import * as jwt from 'jsonwebtoken';

// Middlewares
import { verifySignature } from '../middleware/verifySignature';
import { auth, authAdmin } from '../middleware/auth';
import { authWallet } from '../middleware/authWallet';
import { getClientInfo } from '../middleware/parseClientInfo';

import config from '../config';

const router = express.Router();

// Models
import { UserWallet } from '../sequelize/models/UserWallet';
import { DiscordRole } from '../sequelize/models/DiscordRole';
import { DiscordUserRole } from '../sequelize/models/DiscordUserRole';

// Services
import { retrieveDiscordToken, getDiscordMe, syncUserWalletDiscordUserRoles } from '../services/discordService';
import { createUserWallet, getPreRegisterLandInfo } from '../services/userWalletService';

// Utils
import { log, getPaginationInput } from '../utils';
import { authBasic } from '../middleware/authBasic';
import * as chickenService from '../services/chickenService';

router.post('/user-wallets', [authBasic, verifySignature], async (req: express.Request, res: express.Response) => {
  const { userWalletId } = req.body;

  try {
    const existingUserWallet = await UserWallet.findByPk(userWalletId);
    if (existingUserWallet) {
      throw new Error('User wallet already exists');
    }

    const userWalletModel = await UserWallet.sequelize.transaction(async (t) => {
      const userWallet = await createUserWallet(userWalletId, t);

      const token = jwt.sign({ userWalletId: userWallet.id }, config.SECRET, { expiresIn: `${config.AUTH_TOKEN_EXPIRATION_HOURS}h` });
      await userWallet.update({
        token,
      }, { transaction: t });

      return userWallet;
    });

    res.cookie('wallet_token', userWalletModel.token).send({
      auth: true,
      token: userWalletModel.token,
      id: userWalletModel.id,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/user-wallets',
      userWalletId,
      err,
    }, 'Wallet Register Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.post('/user-wallets/login', [authBasic, verifySignature], async (req: express.Request, res: express.Response) => {
  const { userWalletId } = req.body;

  try {
    const userWalletModel = await UserWallet.unscoped().findByPk(userWalletId);
    if (!userWalletModel) {
      res.status(400).json({
        auth: false,
        message: 'User not found',
      });
      return;
    }

    if (userWalletModel) {
      const token = jwt.sign({ userWalletId: userWalletModel.id }, config.SECRET, { expiresIn: `${config.AUTH_TOKEN_EXPIRATION_HOURS}h` });
      const clientInfo = getClientInfo(req);

      log.info({
        func: 'POST/user-wallets/login',
        userWalletId,
        ...clientInfo,
      }, 'Login With User Wallet');

      await userWalletModel.update({
        token,
        ipAddress: clientInfo.ipAddress,
        ipCountry: clientInfo.ipCountry,
      });

      await userWalletModel.reload({
        include: [DiscordRole],
      });

      const preRegisterLandInfo = await getPreRegisterLandInfo(userWalletModel.id);

      res.cookie('wallet_token', userWalletModel.token).send({
        auth: true,
        id: userWalletModel.id,
        raceEntries: userWalletModel.raceEntries,
        winnings: userWalletModel.winnings,
        winningsJEWEL: userWalletModel.winningsJEWEL,
        token: userWalletModel.token,
        firstName: userWalletModel.firstName,
        lastName: userWalletModel.lastName,
        username: userWalletModel.username,
        email: userWalletModel.email,
        firebaseToken: userWalletModel.firebaseToken,
        isLoggedDiscord: !!userWalletModel.discordId,
        discordRoles: userWalletModel.discordRoles,
        confirmedTosAt: userWalletModel.confirmedTosAt,
        goldNuggets: userWalletModel.goldNuggets,
        bawkGifts: userWalletModel.bawkGifts,
        entryFees: userWalletModel.entryFees,
        firsts: userWalletModel.firsts,
        seconds: userWalletModel.seconds,
        thirds: userWalletModel.thirds,
        preRegisterLandInfo,
        trackEarnings: userWalletModel.trackEarnings,
      });
    }
  } catch (err: any) {
    log.error({
      func: 'POST/user-wallets/login',
      userWalletId,
      err,
    }, 'Wallet Login Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.post('/user-wallets/logout', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  try {
    const userWalletModel = req.user;

    userWalletModel.token = null;
    await userWalletModel.save();

    res.status(200).json({
      auth: false,
      id: userWalletModel.id,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/user-wallets/logout',
      err,
    }, 'Wallet Logout Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.post('/user-wallets/discord-login', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  try {
    const userWalletModel = req.user as UserWallet;
    const accessToken = await retrieveDiscordToken(req.body.code);

    if (!accessToken) {
      throw new Error('Can not retrieve discord token');
    }

    const discordInfo = await getDiscordMe(accessToken);

    await userWalletModel.update({
      discordId: discordInfo.id,
      discordInfo,
    });

    await syncUserWalletDiscordUserRoles(userWalletModel);

    await userWalletModel.reload({
      include: [DiscordRole],
    });

    const preRegisterLandInfo = await getPreRegisterLandInfo(userWalletModel.id);

    res.status(200).json({
      id: userWalletModel.id,
      raceEntries: userWalletModel.raceEntries,
      winnings: userWalletModel.winnings,
      winningsJEWEL: userWalletModel.winningsJEWEL,
      firstName: userWalletModel.firstName,
      lastName: userWalletModel.lastName,
      username: userWalletModel.username,
      email: userWalletModel.email,
      firebaseToken: userWalletModel.firebaseToken,
      isLoggedDiscord: !!userWalletModel.discordId,
      discordRoles: userWalletModel.discordRoles,
      confirmedTosAt: userWalletModel.confirmedTosAt,
      goldNuggets: userWalletModel.goldNuggets,
      bawkGifts: userWalletModel.bawkGifts,
      entryFees: userWalletModel.entryFees,
      firsts: userWalletModel.firsts,
      seconds: userWalletModel.seconds,
      thirds: userWalletModel.thirds,
      preRegisterLandInfo,
      trackEarnings: userWalletModel.trackEarnings,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/user-wallets/discord-login',
      err,
    }, 'Discord Login Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.post('/user-wallets/discord-logout', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  try {
    const userWalletModel = req.user as UserWallet;
    await userWalletModel.update({
      discordId: null,
      discordInfo: null,
    });

    await DiscordUserRole.destroy({
      where: {
        userWalletId: userWalletModel.id,
      },
    });

    const preRegisterLandInfo = await getPreRegisterLandInfo(userWalletModel.id);

    res.status(200).json({
      id: userWalletModel.id,
      raceEntries: userWalletModel.raceEntries,
      winnings: userWalletModel.winnings,
      winningsJEWEL: userWalletModel.winningsJEWEL,
      firstName: userWalletModel.firstName,
      lastName: userWalletModel.lastName,
      username: userWalletModel.username,
      email: userWalletModel.email,
      firebaseToken: userWalletModel.firebaseToken,
      isLoggedDiscord: !!userWalletModel.discordId,
      confirmedTosAt: userWalletModel.confirmedTosAt,
      goldNuggets: userWalletModel.goldNuggets,
      bawkGifts: userWalletModel.bawkGifts,
      entryFees: userWalletModel.entryFees,
      firsts: userWalletModel.firsts,
      seconds: userWalletModel.seconds,
      thirds: userWalletModel.thirds,
      discordRoles: [],
      preRegisterLandInfo,
      trackEarnings: userWalletModel.trackEarnings,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/user-wallets/discord-logout',
      err,
    }, 'Discord Logou Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/user-wallets/me', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  try {
    const userWalletModel = req.user as UserWallet;
    const chickenIds = await chickenService.getChickenIdsForUserWalletId(userWalletModel.id);

    await userWalletModel.reload({
      include: [DiscordRole],
    });

    const preRegisterLandInfo = await getPreRegisterLandInfo(userWalletModel.id);

    res.status(200).json({
      id: userWalletModel.id,
      raceEntries: userWalletModel.raceEntries,
      winnings: userWalletModel.winnings,
      winningsJEWEL: userWalletModel.winningsJEWEL,
      firstName: userWalletModel.firstName,
      lastName: userWalletModel.lastName,
      username: userWalletModel.username,
      email: userWalletModel.email,
      firebaseToken: userWalletModel.firebaseToken,
      isLoggedDiscord: !!userWalletModel.discordId,
      discordRoles: userWalletModel.discordRoles,
      confirmedTosAt: userWalletModel.confirmedTosAt,
      chickenCount: chickenIds?.length || 0,
      preRegisterLandInfo,
      goldNuggets: userWalletModel.goldNuggets,
      bawkGifts: userWalletModel.bawkGifts,
      entryFees: userWalletModel.entryFees,
      firsts: userWalletModel.firsts,
      seconds: userWalletModel.seconds,
      thirds: userWalletModel.thirds,
      trackEarnings: userWalletModel.trackEarnings,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/user-wallets/me',
      err,
    }, 'Get User Wallet Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/user-wallets/discord-mapping', async (req, res) => {
  const { type, q } = req.query;

  try {
    const where: Sequelize.WhereOptions = {};
    if (type === 'user-wallet-id') {
      where.id = q;
    } else if (type === 'discord-id') {
      where.discordId = q;
    } else {
      throw new Error('Unsupported search type');
    }

    const userWallet = await UserWallet.findOne({
      where,
      attributes: ['id', 'discordId'],
    });

    res.json(userWallet);
  } catch (err: any) {
    log.error({
      func: 'GET/user-wallets/discord-mapping',
      type,
      q,
    }, 'Get User Wallet Discord Mapping Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/user-wallets/:userWalletId', authBasic, async (req, res) => {
  try {
    const { userWalletId } = req.params;

    const userWallet = await UserWallet.findOne({
      where: {
        id: userWalletId,
      },
      include: [DiscordRole],
    });

    if (!userWallet) {
      throw new Error(`No user wallet found with ${userWalletId}`);
    }

    const preRegisterLandInfo = await getPreRegisterLandInfo(userWallet.id);

    res.status(200).json({
      id: userWallet.id,
      raceEntries: userWallet.raceEntries,
      winnings: userWallet.winnings,
      winningsJEWEL: userWallet.winningsJEWEL,
      firstName: userWallet.firstName,
      lastName: userWallet.lastName,
      username: userWallet.username,
      email: userWallet.email,
      isLoggedDiscord: userWallet.discordId,
      discordRoles: userWallet.discordRoles,
      preRegisterLandInfo,
      goldNuggets: userWallet.goldNuggets,
      bawkGifts: userWallet.bawkGifts,
      entryFees: userWallet.entryFees,
      firsts: userWallet.firsts,
      seconds: userWallet.seconds,
      thirds: userWallet.thirds,
      trackEarnings: userWallet.trackEarnings,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/user-wallets/:userWalletId',
      err,
    }, 'Get User Wallet By Id Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.patch('/user-wallets', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;

  try {
    const {
      firstName, lastName, username, email, firebaseToken, isConfirmedTos,
    } = req.body;

    if (username) {
      // check double name
      const exist = await UserWallet.findOne({
        where: {
          username,
          id: {
            [Op.not]: userWalletId,
          },
        },
      });

      if (exist) {
        res.status(400).json({
          message: 'The name is already taken.',
        });
        return;
      }
    }

    const userWalletModel = req.user as UserWallet;
    await userWalletModel.update({
      firstName,
      lastName,
      username,
      email,
      firebaseToken,
      confirmedTosAt: isConfirmedTos ? new Date() : undefined,
    });

    await userWalletModel.reload({
      include: [DiscordRole],
    });

    const preRegisterLandInfo = await getPreRegisterLandInfo(userWalletModel.id);

    res.status(200).send({
      id: userWalletModel.id,
      raceEntries: userWalletModel.raceEntries,
      winnings: userWalletModel.winnings,
      winningsJEWEL: userWalletModel.winningsJEWEL,
      firstName: userWalletModel.firstName,
      lastName: userWalletModel.lastName,
      username: userWalletModel.username,
      email: userWalletModel.email,
      firebaseToken: userWalletModel.firebaseToken,
      isLoggedDiscord: !!userWalletModel.discordId,
      discordRoles: userWalletModel.discordRoles,
      confirmedTosAt: userWalletModel.confirmedTosAt,
      goldNuggets: userWalletModel.goldNuggets,
      bawkGifts: userWalletModel.bawkGifts,
      entryFees: userWalletModel.entryFees,
      firsts: userWalletModel.firsts,
      seconds: userWalletModel.seconds,
      thirds: userWalletModel.thirds,
      preRegisterLandInfo,
      trackEarnings: userWalletModel.trackEarnings,
    });
  } catch (err: any) {
    log.error({
      func: 'PATCH/user-wallets',
      userWalletId,
      err,
    }, 'Wallet Update Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

// beta user endpoints
router.patch('/beta-users/:userWalletId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  const { userWalletId } = req.params;
  const { isBetaUser } = req.body;

  try {
    const userWalletModel = await UserWallet.findByPk(userWalletId);
    if (!userWalletModel) {
      throw new Error(`No user wallet found with ${userWalletId}`);
    }

    if (isBetaUser === Boolean(userWalletModel.betaUserAt)) {
      const message = isBetaUser ? 'Already added to beta user' : 'Already removed from beta user';
      throw new Error(message);
    }

    await userWalletModel.update({
      betaUserAt: isBetaUser ? new Date() : null,
    });

    res.json(userWalletModel);
  } catch (err: any) {
    log.error({
      func: '/patch/beta-users',
      userWalletId,
      isBetaUser,
      err,
    }, 'Patch Beta User Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/beta-users', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req, {
      defaultSort: { field: 'username', order: 'ASC' },
    });

    // build where condition
    const condition: Sequelize.FindAndCountOptions = {
      limit,
      offset: (page - 1) * limit || 0,
      order: [[sort.field, sort.order]],
      where: {
        betaUserAt: {
          [Op.not]: null,
        },
      },
    };

    if (filter?.id) {
      condition.where = {
        ...condition.where,
        id: filter.id,
      };
    }

    const userWallets = await UserWallet.findAndCountAll(condition);
    res.json(userWallets);
  } catch (err: any) {
    log.error({
      func: 'GET/beta-users',
      err,
      query: req.query,
    }, 'Get Beta User Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
