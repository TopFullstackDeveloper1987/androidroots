import * as express from 'express';

import { authBasic } from '../middleware/authBasic';
import { cache } from '../middleware/cache';
import { log } from '../utils';
import { ChickenStakingService } from '../services/chickenStakingService';

const router = express.Router();

router.get('/chicken-staking/seasons/live', [authBasic, cache()], async (req: express.Request, res: express.Response) => {
  try {
    const chickenStakingSeason = await ChickenStakingService.getInstance().getLiveSeason();
    res.json({
      chickenStakingSeason,
    });
  } catch (err: any) {
    log.info({
      func: 'GET/chicken-staking/seasons/live',
      err,
    }, 'Get Live Chicken Staking Season Error');

    res.status(400).json({ message: err.message });
  }
});

export = router;
