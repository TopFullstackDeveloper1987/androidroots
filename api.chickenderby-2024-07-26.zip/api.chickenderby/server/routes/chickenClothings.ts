// Dependencies
import * as express from 'express';

import { authBasic } from '../middleware/authBasic';
import { authWallet } from '../middleware/authWallet';

// Models
import { Clothing } from '../sequelize/models/Clothing';
import { Chicken } from '../sequelize/models/Chicken';
import { ChickenClothing } from '../sequelize/models/ChickenClothing';
import { UserWallet } from '../sequelize/models/UserWallet';

import { checkDeployment } from '../services/settingService';
import { getClothingCountByUserWalletId } from '../services/contracts/clothingContractService';
import { checkChickenOwnership, regenerateChickenClothingImage, checkChickenStatus } from '../services/chickenService';
import { log } from '../utils';

const router = express.Router();

router.post('/chicken-clothings', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;
  const { chickenId, clothingId, removeChickenId } = req.body;

  try {
    log.info({
      func: 'POST/chicken-clothings',
      userWalletId,
      removeChickenId,
      chickenId,
      clothingId,
    }, 'Create ChickenClothing Start');

    await checkDeployment();

    const chicken = chickenId && await Chicken.findByPk(chickenId);

    if (!chicken) {
      throw new Error('Chicken not found');
    }

    await checkChickenStatus(chickenId, false);
    await checkChickenOwnership(userWalletId, chickenId);

    if (removeChickenId) {
      await checkChickenOwnership(userWalletId, removeChickenId);
    }

    const clothing = clothingId && await Clothing.findByPk(clothingId);
    if (!clothing) {
      throw new Error('Wearable not equipped');
    }

    const count = await getClothingCountByUserWalletId(userWalletId, clothingId);

    if (count === 0) {
      throw new Error(`You don't have ${clothing.name}`);
    }

    const chickenClothing = await ChickenClothing.sequelize.transaction(async (t) => {
      const existing = await ChickenClothing.findOne({
        where: {
          chickenId,
          clothingId,
          userWalletId,
        },
        transaction: t,
        lock: t.LOCK.UPDATE,
      });
      if (existing) {
        throw new Error(`Already equipped ${clothing.name} to this chicken. Please refresh.`);
      }

      if (removeChickenId) {
        const removingChickenClothing = await ChickenClothing.findOne({
          where: {
            chickenId: removeChickenId,
            clothingId,
            userWalletId,
          },
          transaction: t,
          lock: t.LOCK.UPDATE,
        });

        if (!removingChickenClothing) {
          throw new Error('Wearable to unequip not found');
        }

        await regenerateChickenClothingImage(removeChickenId, t);

        await removingChickenClothing.destroy({ transaction: t });
      }

      const equippedCount = await ChickenClothing.count({
        where: {
          clothingId,
          userWalletId,
        },
        transaction: t,
      });
      if (equippedCount >= count) {
        throw new Error(`Already equipped all your ${clothing.name}(s) to other chicken(s)`);
      }

      const sameTypeChickenClothing = await ChickenClothing.findOne({
        where: {
          chickenId,
          userWalletId,
        },
        include: [{
          model: Clothing,
          where: {
            type: clothing.type,
          },
        }],
        transaction: t,
        lock: t.LOCK.UPDATE,
      });

      if (sameTypeChickenClothing) {
        await sameTypeChickenClothing.destroy({ transaction: t });
      }

      const chickenClothing = await ChickenClothing.create({
        chickenId,
        clothingId,
        userWalletId,
      }, { transaction: t });

      await regenerateChickenClothingImage(chickenId, t);

      await chicken.reload({
        transaction: t,
      });

      return chickenClothing;
    });

    log.info({
      func: 'POST/chicken-clothings',
      userWalletId,
      chickenId,
      clothingId,
      removeChickenId,
    }, 'Create ChickenClothing End');

    res.json(chickenClothing);
  } catch (err: any) {
    log.error({
      func: 'POST/chicken-clothings',
      userWalletId,
      chickenId,
      clothingId,
      removeChickenId,
      err,
    }, 'Create ChickenClothing Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.delete('/chicken-clothings', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const chickenId = Number(req.query.chickenId);
  const clothingId = Number(req.query.clothingId);
  const { id: userWalletId } = req.user as UserWallet;

  log.info({
    func: 'DELETE/chicken-clothings',
    chickenId,
    clothingId,
    userWalletId,
  }, 'Delete Chicken Clothing Start');

  try {
    const chicken = chickenId && await Chicken.findByPk(Number(chickenId));
    if (!chicken) {
      throw new Error('Chicken not found');
    }

    await checkChickenOwnership(userWalletId, chickenId);

    await ChickenClothing.sequelize.transaction(async (t) => {
      const chickenClothing = await ChickenClothing.findOne({
        where: {
          chickenId,
          clothingId,
          userWalletId,
        },
        transaction: t,
        lock: t.LOCK.UPDATE,
      });

      if (!chickenClothing) {
        throw new Error('Wearable not equipped. Please refresh.');
      }

      await chickenClothing.destroy({ transaction: t });

      await regenerateChickenClothingImage(chickenId, t);
    });

    log.info({
      func: 'DELETE/chicken-clothings',
      chickenId,
      clothingId,
      userWalletId,
    }, 'Delete Chicken Clothing End');

    res.json({
      message: 'Chicken Clothing Deleted Successfully',
    });
  } catch (err: any) {
    log.error({
      func: 'DELETE/chicken-clothings',
      chickenId,
      clothingId,
      userWalletId,
      err,
    }, 'Delete Chicken Clothing Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
