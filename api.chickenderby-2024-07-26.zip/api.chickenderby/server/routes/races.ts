import * as express from 'express';
import Sequelize from 'sequelize';

const { Op } = Sequelize;
import * as moment from 'moment-timezone';
import * as _ from 'lodash';

import { auth, authAdmin } from '../middleware/auth';
import { cache } from '../middleware/cache';

import { Race } from '../sequelize/models/Race';
import { Terrain } from '../sequelize/models/Terrain';
import { Result } from '../sequelize/models/Result';
import { Lane } from '../sequelize/models/Lane';
import { UserWallet } from '../sequelize/models/UserWallet';
import { Chicken } from '../sequelize/models/Chicken';
import { ChickenClothing } from '../sequelize/models/ChickenClothing';
import { LaneClothing } from '../sequelize/models/LaneClothing';
import { User } from '../sequelize/models/User';

import { convertCoinToJewel } from '../services/exchangeService';
import { validateFeeWithPrizePool } from '../validation/validatePrizePool';
import { log, getPaginationInput, getPaginationInputForHawhu } from '../utils';
import { authBasic } from '../middleware/authBasic';
import { RaceStatus } from '../types/races/raceStatus';
import { getEligibleChickens, validatePartnerRace } from '../services/raceService';
import { RaceCoinType } from '../types/races/raceCoinType';
import { WETH_CONTRACT } from '../abi/wethContract';
import { JEWEL_CONTRACT } from '../abi/jewelContract';
import { authWalletPublic } from '../middleware/authWallet';
import { getChickenIdsForUserWalletId } from '../services/chickenService';
import { BawkStakingCompany } from '../sequelize/models/BawkStakingCompany';

const router = express.Router();

// create New Race
router.post('/races', auth, async (req: express.Request, res: express.Response) => {
  const {
    name,
    peckingOrder,
    terrainId,
    distance,
    maxCapacity,
    location,
    minimumStartDelay,
    startTime,
    fee,
    unlimitPO,
    type,
    group,
    allowedUserWalletIds,
    allowedChickenIds,
    coinType,
    bawkStakingCompanyId,
  } = req.body;

  try {
    log.info({
      func: 'POST/races',
      name,
      peckingOrder,
      terrainId,
      distance,
      maxCapacity,
      location,
      minimumStartDelay,
      startTime,
      fee,
      prizePool: req.body.prizePool,
      unlimitPO,
      type,
      group,
      allowedUserWalletIds,
      allowedChickenIds,
      coinType,
      bawkStakingCompanyId,
      userId: req.user.id,
      ...req.clientInfo,
    }, 'Race Create Start');

    const prizePool = await validateFeeWithPrizePool(req.body);

    validatePartnerRace(req);

    const feeJEWEL = await convertCoinToJewel(coinType, fee);
    const prizePoolJEWEL = await convertCoinToJewel(coinType, prizePool);

    const data: Partial<Race> = {
      name,
      peckingOrder,
      terrainId,
      distance,
      maxCapacity,
      location,
      minimumStartDelay,
      startTime,
      fee,
      feeJEWEL,
      prizePool,
      prizePoolJEWEL,
      unlimitPO,
      type,
      group,
      allowedUserWalletIds: req.body.allowedUserWalletIds || undefined,
      allowedChickenIds: req.body.allowedChickenIds || undefined,
      coinContract: coinType === RaceCoinType.WETH ? WETH_CONTRACT.address : JEWEL_CONTRACT.address,
      bawkStakingCompanyId,
    };

    if ((req.user as User)?.isPartner) {
      data.userId = (req.user as User).id;
      data.group = 101;
    }

    const raceModel = await Race.create(data);

    for (let i = 0; i < maxCapacity; i += 1) {
      await Lane.create({
        raceId: raceModel.id,
        laneNumber: i + 1,
      });
    }

    log.info({
      func: 'POST/races',
      name,
      raceId: raceModel.id,
      userId: req.user.id,
    }, 'Race Create End');

    res.json({
      message: 'Race added successfully',
    });
  } catch (err: any) {
    log.error({
      func: 'POST/race',
      name,
      userId: req.user.id,
      err,
    }, 'Race Create Error');

    if (err.message === 'Validation error') {
      res.status(400).json({
        message: 'Race Name Should Be Unique',
      });
      return;
    }

    res.status(400).json({
      message: err.message || 'All Fields are Required!',
    });
  }
});

router.delete('/races/:raceId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  const { raceId } = req.params;

  log.info({
    func: 'DELETE/races',
    raceId,
    userId: req.user.id,
  }, 'Delete Race Start');

  try {
    const raceModel = await Race.findByPk(raceId);
    if (!raceModel) {
      throw new Error(`Race not found with the provided id - ${raceId}`);
    }

    await raceModel.sequelize.transaction(async (t) => {
      await Lane.destroy({
        where: {
          raceId,
        },
        transaction: t,
      });
      await raceModel.destroy({
        transaction: t,
      });
    });

    log.info({
      func: 'DELETE/races',
      raceId,
      userId: req.user.id,
    }, 'Delete Race End');

    res.json({
      message: 'Race Deleted Successfully',
    });
  } catch (err: any) {
    log.error({
      func: 'DELETE/races',
      raceId,
      userId: req.user.id,
      err,
    }, 'Delete Race Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.patch('/races/:raceId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  const { raceId } = req.params;
  const {
    name,
    peckingOrder,
    terrainId,
    distance,
    location,
    minimumStartDelay,
    fee,
    unlimitPO,
    type,
    group,
    allowedUserWalletIds,
    allowedChickenIds,
    coinType,
    bawkStakingCompanyId,
  } = req.body;

  try {
    log.info({
      func: 'PATCH/races',
      raceId,
      name,
      peckingOrder,
      terrainId,
      distance,
      location,
      minimumStartDelay,
      startTime: req.body.startTime,
      fee,
      prizePool: req.body.prizePool,
      unlimitPO,
      userId: req.user.id,
      type,
      group,
      allowedUserWalletIds,
      allowedChickenIds,
      coinType,
      bawkStakingCompanyId,
    }, `Race Update Start For Race ${raceId}`);

    const raceModel = await Race.findOne({ where: { id: raceId } });
    if (!raceModel) {
      throw new Error(`Race not found with the provided id - ${raceId}`);
    }

    const prizePool = await validateFeeWithPrizePool(req.body);

    let startTime;
    let startsAt;

    if (raceModel.status === RaceStatus.Finished) {
      // do not allow updating startTime when the race is already finished
      startTime = raceModel.startTime;
      startsAt = raceModel.startsAt;
    } else {
      startTime = req.body.startTime;
      startsAt = raceModel.startsAt;

      if (startTime !== undefined && startsAt) {
        startsAt = moment.utc().add(startTime, 'seconds').toDate();
      }
    }

    const feeJEWEL = await convertCoinToJewel(coinType, fee);
    const prizePoolJEWEL = await convertCoinToJewel(coinType, prizePool);

    await raceModel.update({
      name,
      peckingOrder,
      terrainId,
      distance,
      location,
      minimumStartDelay,
      startTime,
      startsAt,
      fee,
      feeJEWEL,
      prizePool,
      prizePoolJEWEL,
      unlimitPO,
      type,
      group,
      allowedUserWalletIds: allowedUserWalletIds || undefined,
      allowedChickenIds: allowedChickenIds || undefined,
      coinContract: coinType === RaceCoinType.WETH ? WETH_CONTRACT.address : JEWEL_CONTRACT.address,
      bawkStakingCompanyId,
      syncedAt: null,
    });

    log.info({
      func: 'PATCH/races',
      raceId,
      name,
      userId: req.user.id,
    }, `Race Update End For Race ${raceId}`);

    res.json(raceModel);
  } catch (err: any) {
    log.error({
      func: 'PATCH/races',
      raceId,
      name,
      userId: req.user.id,
      err,
    }, `Race Update Error For Race ${raceId}`);

    if (err.name === 'SequelizeUniqueConstraintError') {
      res.status(400).json({
        message: 'Race Name Already Exists',
      });
      return;
    }
    res.status(400).json({
      message: err.message,
    });
  }
});

// used for open/scheduled races on frontend, all races on admin, do not attach authBasic middleware
router.get('/races', authWalletPublic, async (req, res) => {
  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req);
    const user = req.user as UserWallet;

    const raceQuery: Sequelize.WhereOptions<Race> = {
      status: RaceStatus.Open,
    };
    const terrainQuery: Sequelize.WhereOptions = {};
    const laneQuery: Sequelize.WhereOptions = {};

    if (filter?.status?.length) {
      raceQuery.status = filter.status;

      if (filter.status.includes(RaceStatus.Open) && !filter.userId) {
        raceQuery.userId = null;
      }
    }

    if (filter?.userWalletId) {
      laneQuery.userWalletId = filter.userWalletId;
    }

    if (filter?.name?.length) {
      raceQuery.name = {
        [Op.like]: `%${filter.name}%`,
      };
    }

    if (filter?.peckingOrder?.length) {
      raceQuery.peckingOrder = filter.peckingOrder;
    }

    if (filter?.distance?.length) {
      raceQuery.distance = filter.distance;
    }

    if (filter?.terrain?.length) {
      terrainQuery.name = filter.terrain;
    }

    if (filter?.company?.length) {
      raceQuery.bawkStakingCompanyId = filter.company;
    }

    if (filter?.fee_min && filter?.fee_max) {
      raceQuery.feeJEWEL = {
        [Op.gte]: Number(filter.fee_min),
        [Op.lte]: Number(filter.fee_max),
      };
    } else if (filter?.fee_min) {
      raceQuery.feeJEWEL = {
        [Op.gte]: Number(filter.fee_min),
      };
    } else if (filter?.fee_max) {
      raceQuery.feeJEWEL = {
        [Op.lte]: Number(filter.fee_max),
      };
    }

    if (filter?.prize_min && filter?.prize_max) {
      raceQuery.prizePoolJEWEL = {
        [Op.gte]: Number(filter.prize_min),
        [Op.lte]: Number(filter.prize_max),
      };
    } else if (filter?.prize_min) {
      raceQuery.prizePoolJEWEL = {
        [Op.gte]: Number(filter.prize_min),
      };
    } else if (filter?.prize_max) {
      raceQuery.prizePoolJEWEL = {
        [Op.lte]: Number(filter.prize_max),
      };
    }

    if (filter?.unlimitPO?.length) {
      raceQuery.unlimitPO = filter.unlimitPO;
    }

    if (filter?.type?.length) {
      raceQuery.type = filter.type;
    }

    if (filter?.group?.length) {
      raceQuery.group = filter.group;
    }

    if (filter?.paidStatus?.length) {
      raceQuery.paidStatus = filter.paidStatus;
    }

    if (filter?.startId) {
      raceQuery.id = {
        [Op.gte]: filter.startId,
      };
    }

    if (filter?.endId) {
      raceQuery.id = {
        [Op.lte]: filter.endId,
      };
    }

    if (filter?.startsAt) {
      raceQuery.startsAt = {
        [Op.gte]: moment.utc(filter.startsAt).startOf('date').toDate(),
        [Op.lte]: moment.utc(filter.startsAt).endOf('date').toDate(),
      };
    }

    if (filter?.userId) {
      raceQuery.userId = filter.userId;
    }

    if (filter?.allowedUserWalletIds?.length) {
      raceQuery.allowedUserWalletIds = {
        [Op.like]: `%${filter.allowedUserWalletIds}%`,
      };
    }

    if (filter?.allowedChickenIds?.length) {
      raceQuery.allowedChickenIds = {
        [Op.like]: `%${filter.allowedChickenIds}%`,
      };
    }

    if (filter?.coinType?.length) {
      raceQuery.coinContract = filter.coinType.map((coinType: RaceCoinType) => coinType === RaceCoinType.WETH ? WETH_CONTRACT.address : JEWEL_CONTRACT.address);
    }

    if (raceQuery.status === RaceStatus.Open) {
      if (filter?.isIncoming) {
        raceQuery.scheduleAt = { [Op.not]: null };
      } else {
        raceQuery.scheduleAt = null;
      }
    }

    const countInclude = [];
    if (Object.keys(terrainQuery).length > 0) {
      countInclude.push({
        model: Terrain,
        attributes: ['id'],
        where: terrainQuery,
      });
    }

    if (Object.keys(laneQuery).length > 0) {
      countInclude.push({
        model: Lane,
        as: 'lanes',
        attributes: ['id'],
        where: laneQuery,
      });
    }

    const count = await Race.count({
      where: raceQuery,
      include: countInclude,
      distinct: true,
    });

    // CD-985: filter?.clothingIdOnly and filter?.noClothing are only for Ben
    const chickenInclude = [];
    if (raceQuery.status === RaceStatus.Open && !filter?.noClothing) {
      chickenInclude.push({
        model: filter?.clothingIdOnly ? ChickenClothing.scope('includesClothingId') : ChickenClothing.scope('includesClothing'),
      });
    }

    const laneInclude: Sequelize.Includeable[] = [{
      model: UserWallet,
      attributes: ['username'],
    }, {
      model: Chicken,
      include: chickenInclude,
    }];
    if (raceQuery.status !== RaceStatus.Open && !filter?.noClothing) {
      laneInclude.push({
        model: filter?.clothingIdOnly ? LaneClothing.scope('includesClothingId') : LaneClothing.scope('includesClothing'),
      });
    }

    const races = await Race.findAll({
      where: raceQuery,
      include: [{
        model: Terrain,
        attributes: ['name', 'image'],
        where: terrainQuery,
      }, {
        model: BawkStakingCompany,
        attributes: ['name'],
      }, {
        model: Lane,
        as: 'lanes',
        include: laneInclude,
        where: laneQuery,
      }],
      limit,
      offset: (page - 1) * limit || 0,
      order: [[sort.field, sort.order], ['id', 'asc']],
    });

    const chickenIds = user && filter.status === RaceStatus.Open ? await getChickenIdsForUserWalletId(user.id) : [];
    const ownerChickens = chickenIds.length ? await Chicken.findAll({
      where: {
        id: chickenIds,
      },
    }) : [];

    const rows = [];
    for (const raceModel of races) {
      // reload race.lanes to include all the lanes, not just for my chickens
      if (filter?.userWalletId) {
        await raceModel.reload({
          include: [{
            model: Terrain,
            attributes: ['name', 'image'],
          }, {
            model: BawkStakingCompany,
            attributes: ['name'],
          }, {
            model: Lane,
            as: 'lanes',
            include: laneInclude,
          }],
        });
      }

      const race = raceModel.toJSON();
      if (race.status === RaceStatus.Open) {
        race.lanes = race.lanes.filter((lane: Lane) => lane.userWalletId === user?.id);
        const eligibleChickens = getEligibleChickens(user?.id, raceModel, ownerChickens);

        let eligibleLevel = 0;

        if (eligibleChickens.some((chicken) => chicken.terrainPreference === raceModel.terrain?.name && raceModel.distancePreferences.includes(chicken.distancePreference))) {
          eligibleLevel = 2;
        } else if (eligibleChickens.some((chicken) => chicken.terrainPreference === raceModel.terrain?.name)) {
          eligibleLevel = 1;
        } else if (eligibleChickens.some((chicken) => raceModel.distancePreferences.includes(chicken.distancePreference))) {
          eligibleLevel = 1;
        }

        race.eligibleLevel = eligibleLevel;
        race.eligibleChickens = eligibleChickens.length;

        if (race.scheduleAt) {
          race.prizePool = raceModel.getActualPrizePool();
        }
      }

      rows.push(race);
    }

    res.json({
      count,
      rows,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/races',
      query: req.query,
      err,
    }, 'Get Races Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/races/count', authBasic, async (req, res) => {
  try {
    const record = await Race.findOne({
      attributes: [
        [Sequelize.fn('count', Sequelize.col('id')), 'totalRaces'],
        [Sequelize.fn('sum', Sequelize.col('prizePoolJEWEL')), 'totalEarnings'],
      ],
      where: {
        status: RaceStatus.Finished,
      },
      raw: true,
    });

    const totalCoops = await Lane.count({
      distinct: true,
      col: 'userWalletId',
    });

    const totalRaces = (record as any)?.totalRaces || 0;
    const totalEarnings = (record as any)?.totalEarnings || 0;

    res.json({
      totalRaces,
      totalEarnings,
      totalCoops,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/races/count',
      err,
    }, 'Game Results Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/races/:raceId', [authBasic, authWalletPublic], async (req: express.Request, res: express.Response) => {
  const { raceId } = req.params;
  const { user } = req;

  try {
    const raceModel = await Race.findOne({
      where: {
        id: raceId,
      },
      include: [{
        model: Result,
        as: 'result',
        attributes: ['id', 'raceId', 'raceProfiles'],
      }, {
        model: Terrain, attributes: ['name', 'image'],
      }, {
        model: BawkStakingCompany, attributes: ['name'],
      }, {
        model: Lane,
        as: 'lanes',
        include: [{
          model: UserWallet,
          attributes: ['username'],
        }, {
          model: Chicken,
          include: [{
            model: ChickenClothing.scope('includesClothing'),
          }],
        }, {
          model: LaneClothing.scope('includesClothing'),
        }],
      }],
    });

    if (!raceModel) {
      throw new Error('Race not found');
    }

    const raceData = raceModel.toJSON();
    if (raceData.result) {
      raceData.lanes.filter((lane: Lane) => lane.chickenId).forEach((laneRecord: Lane) => {
        const { segments } = raceData.result.raceProfiles[laneRecord.position - 1];
        (laneRecord.chicken as any).cumulativeSegmentSize = segments[segments.length - 1].cumulativeSegmentSize;
      });
      delete raceData.result;
    }

    if (raceData.status === RaceStatus.Open) {
      raceData.lanes = raceData.lanes.filter(
        (lane: Lane) => lane.userWalletId === user?.id,
      );
    }

    res.json(raceData);
  } catch (err: any) {
    log.error({
      func: 'GET/races/:raceId',
      raceId,
      err,
    }, 'Get Race Data');

    res.status(400).json({
      message: err.message,
    });
  }
});

// For Hawku
router.get('/events', [cache()], async (req: express.Request, res: express.Response) => {
  try {
    const {
      page, limit, updatedStart, updatedEnd,
    } = getPaginationInputForHawhu(req);

    const record = await Race.findOne({
      attributes: [
        [Sequelize.fn('count', Sequelize.col('id')), 'totalRaces'],
        [Sequelize.fn('sum', Sequelize.col('prizePoolJEWEL')), 'totalEarnings'],
      ],
      where: {
        status: RaceStatus.Finished,
      },
      raw: true,
    });

    const raceQuery: Sequelize.WhereOptions = {
      status: RaceStatus.Finished,
    };
    const terrainQuery: Sequelize.WhereOptions = {};
    const laneQuery: Sequelize.WhereOptions = {};

    const totalRaces = (record as any)?.totalRaces || 0;
    const totalEarnings = (record as any)?.totalEarnings || 0;

    if (updatedStart && updatedEnd) {
      raceQuery.endsAt = {
        [Op.between]: [moment.unix(updatedStart).toDate(), moment.unix(updatedEnd).toDate()],
      };
    } else if (updatedStart) {
      raceQuery.endsAt = {
        [Op.gte]: moment.unix(updatedStart).toDate(),
      };
    } else if (updatedEnd) {
      raceQuery.endsAt = {
        [Op.lte]: moment.unix(updatedEnd).toDate(),
      };
    }

    const countInclude = [];
    if (Object.keys(terrainQuery).length > 0) {
      countInclude.push({
        model: Terrain,
        attributes: ['id'],
        where: terrainQuery,
      });
    }

    if (Object.keys(laneQuery).length > 0) {
      countInclude.push({
        attributes: ['id'],
        model: Lane,
        as: 'lanes',
        where: laneQuery,
      });
    }

    const count = await Race.count({
      where: raceQuery,
      include: countInclude,
      distinct: true,
    });

    const laneInclude = [{
      model: UserWallet,
      attributes: ['username'],
    }, {
      model: Chicken,
    }, {
      model: LaneClothing.scope('includesClothing'),
    }];

    const races = await Race.findAll({
      where: raceQuery,
      include: [{
        model: Terrain,
        attributes: ['name', 'image'],
        where: terrainQuery,
      }, {
        model: Lane,
        as: 'lanes',
        include: laneInclude,
        where: laneQuery,
      }],
      order: [['endsAt', 'desc'], ['id', 'asc']],
      limit,
      offset: page * limit,
    });

    const events = [];
    for (const race of races) {
      const event = {
        id: race.id,
        event_datetime: moment.utc(race.endsAt).unix(),
        data: _.omit(race.toJSON(), 'lanes'),
        results: race.toJSON().lanes.filter((lane: Lane) => lane.chickenId).sort((a: Lane, b: Lane) => a.position - b.position),
      };
      events.push(event);
    }

    res.json({
      events,
      count,
      totalRaces,
      totalEarnings,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/events',
      query: req.query,
      err,
    }, 'Get Events Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/results', [authBasic, cache()], async (req: express.Request, res: express.Response) => {
  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req, {
      defaultSort: { field: 'startsAt', order: 'DESC' },
    });

    const record = await Race.findOne({
      attributes: [
        [Sequelize.fn('count', Sequelize.col('id')), 'totalRaces'],
        [Sequelize.fn('sum', Sequelize.col('prizePoolJEWEL')), 'totalEarnings'],
      ],
      where: {
        status: RaceStatus.Finished,
      },
      raw: true,
    });

    const raceQuery: Sequelize.WhereOptions = {
      status: RaceStatus.Finished,
    };
    const terrainQuery: Sequelize.WhereOptions = {};
    const laneQuery: Sequelize.WhereOptions = {};

    const totalRaces = (record as any)?.totalRaces || 0;
    const totalEarnings = (record as any)?.totalEarnings || 0;

    if (filter?.peckingOrder?.length) {
      raceQuery.peckingOrder = filter.peckingOrder;
    }

    if (filter?.distance?.length) {
      raceQuery.distance = filter.distance;
    }

    if (filter?.terrain?.length) {
      terrainQuery.name = filter.terrain;
    }

    if (filter?.company?.length) {
      raceQuery.bawkStakingCompanyId = filter.company;
    }

    if (filter?.fee_min) {
      raceQuery.feeJEWEL = {
        [Op.gte]: Number(filter.fee_min),
      };
    }

    if (filter?.fee_max) {
      raceQuery.feeJEWEL = {
        ...raceQuery.feeJEWEL,
        [Op.lte]: Number(filter.fee_max),
      };
    }

    if (filter?.prize_min) {
      raceQuery.prizePoolJEWEL = {
        [Op.gte]: Number(filter.prize_min),
      };
    }

    if (filter?.prize_max) {
      raceQuery.prizePoolJEWEL = {
        ...raceQuery.prizePoolJEWEL,
        [Op.lte]: Number(filter.prize_max),
      };
    }

    // only my chickens
    if (filter?.userWalletId) {
      laneQuery.userWalletId = filter.userWalletId;
    }

    const countInclude = [];
    if (Object.keys(terrainQuery).length > 0) {
      countInclude.push({
        model: Terrain,
        attributes: ['id'],
        where: terrainQuery,
      });
    }

    if (Object.keys(laneQuery).length > 0) {
      countInclude.push({
        attributes: ['id'],
        model: Lane,
        as: 'lanes',
        where: laneQuery,
      });
    }

    const count = await Race.count({
      where: raceQuery,
      include: countInclude,
      distinct: true,
    });

    const laneInclude = [{
      model: UserWallet,
      attributes: ['username'],
    }, {
      model: Chicken,
    }, {
      model: LaneClothing.scope('includesClothing'),
    }];

    const races = await Race.findAll({
      where: raceQuery,
      include: [{
        model: Terrain,
        attributes: ['name', 'image'],
        where: terrainQuery,
      }, {
        model: BawkStakingCompany,
        attributes: ['name'],
      }, {
        model: Lane,
        as: 'lanes',
        include: laneInclude,
        where: laneQuery,
      }],
      order: [[sort.field, sort.order], ['id', 'asc']],
      limit,
      offset: (page - 1) * limit,
    });

    const rows = [];
    for (const race of races) {
      // reload race.lanes to include all the lanes, not just for my chickens
      if (filter?.userWalletId) {
        await race.reload({
          include: [{
            model: Terrain,
            attributes: ['name', 'image'],
          }, {
            model: BawkStakingCompany,
            attributes: ['name'],
          }, {
            model: Lane,
            as: 'lanes',
            include: laneInclude,
          }],
        });
      }

      rows.push({
        ...race.toJSON(),
        // filter out unassigned lanes
        lanes: race.toJSON().lanes.filter((lane: Lane) => lane.chickenId).sort((a: Lane, b: Lane) => a.position - b.position),
      });
    }

    res.json({
      rows,
      count,
      totalRaces,
      totalEarnings,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/results',
      query: req.query,
      err,
    }, 'Get Results Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/races/chickens/:chickenId', [authBasic, cache()], async (req: express.Request, res: express.Response) => {
  const { chickenId } = req.params;

  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req, {
      defaultSort: { field: 'status', order: 'ASC' },
    });

    if (!chickenId) {
      throw new Error('Required chickenId');
    }

    const raceQuery: Sequelize.WhereOptions<Race> = {};
    const terrainQuery: Sequelize.WhereOptions = {};

    if (filter?.status?.length) {
      raceQuery.status = filter.status;
    }

    if (filter?.name?.length) {
      raceQuery.name = {
        [Op.like]: `%${filter.name[0]}%`,
      };
    }

    if (filter?.peckingOrder?.length) {
      raceQuery.peckingOrder = filter.peckingOrder;
    }

    if (filter?.distance?.length) {
      raceQuery.distance = filter.distance;
    }

    if (filter?.terrain?.length) {
      terrainQuery.name = filter.terrain;
    }

    if (filter?.company?.length) {
      raceQuery.bawkStakingCompanyId = filter.company;
    }

    if (filter?.fee_min && filter?.fee_max) {
      raceQuery.feeJEWEL = {
        [Op.gte]: Number(filter.fee_min),
        [Op.lte]: Number(filter.fee_max),
      };
    } else if (filter?.fee_min) {
      raceQuery.feeJEWEL = {
        [Op.gte]: Number(filter.fee_min),
      };
    } else if (filter?.fee_max) {
      raceQuery.feeJEWEL = {
        [Op.lte]: Number(filter.fee_max),
      };
    }

    if (filter?.prize_min && filter?.prize_max) {
      raceQuery.prizePoolJEWEL = {
        [Op.gte]: Number(filter.prize_min),
        [Op.lte]: Number(filter.prize_max),
      };
    } else if (filter?.prize_min) {
      raceQuery.prizePoolJEWEL = {
        [Op.gte]: Number(filter.prize_min),
      };
    } else if (filter?.prize_max) {
      raceQuery.prizePoolJEWEL = {
        [Op.lte]: Number(filter.prize_max),
      };
    }

    const countInclude: Sequelize.Includeable[] = [{
      model: Lane,
      as: 'lanes',
      attributes: ['id'],
      where: {
        chickenId,
      },
    }];
    if (Object.keys(terrainQuery).length > 0) {
      countInclude.push({
        model: Terrain,
        attributes: ['id'],
        where: terrainQuery,
      });
    }

    const count = await Race.count({
      where: raceQuery,
      include: countInclude,
      distinct: true,
    });

    const races = await Race.findAll({
      where: raceQuery,
      include: [{
        model: Terrain,
        attributes: ['name', 'image'],
        where: terrainQuery,
      }, {
        model: BawkStakingCompany,
        attributes: ['name'],
      }, {
        model: Lane,
        as: 'lanes',
        where: {
          chickenId,
        },
      }],
      offset: (page - 1) * limit || 0,
      limit,
      order: [[sort.field, sort.order], ['startsAt', 'DESC']],
    });

    res.json({
      count,
      rows: races,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/races/chickens/:chickenId',
      chickenId,
      err,
    }, 'Get Races By Chicken Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
