// Dependencies
import * as express from 'express';
import Sequelize from 'sequelize';

import { authBasic } from '../middleware/authBasic';
import { authWallet } from '../middleware/authWallet';

const { Op } = Sequelize;

// Models
import { Clothing } from '../sequelize/models/Clothing';
import { TourneyOne } from '../sequelize/models/TourneyOne';
import { ChickenClothing } from '../sequelize/models/ChickenClothing';
import { UserWallet } from '../sequelize/models/UserWallet';

import { getClothingsForUserWalletId, getTotalSupplyByClothingIds, getMaxNumberByClothingIds } from '../services/contracts/clothingContractService';
import { log, getPaginationInput } from '../utils';

const router = express.Router();

// serve TokenUri for opensea, super careful
router.get('/tourneyOnes/opensea/:clothingId', async (req, res) => {
  const { clothingId } = req.params;

  try {
    const tourneyOne = await TourneyOne.findByPk(clothingId);
    if (!tourneyOne) {
      throw new Error('Clothing not found');
    }

    // TODO: placeholder image for clothings
    const src = tourneyOne.image;

    res.json({
      id: tourneyOne.id,
      name: tourneyOne.name,
      description: '',
      image_url: src,
      attributes: [{
        trait_type: 'Type',
        value: tourneyOne.type,
      }, {
        trait_type: 'Set',
        value: tourneyOne.clothingSet,
      }],
    });
  } catch (err: any) {
    log.error({
      func: 'GET/tourneyOnes/opensea/:clothingId',
      clothingId,
      err,
    }, 'Post TourneyOnes Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/clothings/opensea/:clothingId', async (req, res) => {
  const { clothingId } = req.params;

  try {
    const clothingRecord = await Clothing.findByPk(clothingId);
    if (!clothingRecord) {
      throw new Error('Clothing not found');
    }

    // TODO: placeholder image for clothings
    const src = clothingRecord.image;

    res.json({
      id: clothingRecord.id,
      name: clothingRecord.name,
      description: '',
      image_url: src,
      attributes: [{
        trait_type: 'Type',
        value: clothingRecord.type,
      }, {
        trait_type: 'Set',
        value: clothingRecord.clothingSet,
      }],
    });
  } catch (err: any) {
    log.error({
      func: 'GET/clothings/opensea/:clothingId',
      clothingId,
      err,
    }, 'Get Clothings Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/clothings/me', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;

  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req, { defaultSort: { field: 'id', order: 'ASC' } });

    const clothingData = await getClothingsForUserWalletId(userWalletId);
    const clothingIds = Object.keys(clothingData);

    const totalSupplies = await getTotalSupplyByClothingIds(clothingIds);
    const maxSupplies = await getMaxNumberByClothingIds(clothingIds);

    const criteria: Sequelize.WhereOptions = {
      id: clothingIds,
    };

    let order = [sort.field, sort.order];

    if (filter?.type?.length) {
      criteria.type = filter.type;
    }

    if (filter?.name) {
      criteria.name = { [Op.like]: `%${filter.name}%` };
    }

    if (filter?.clothingSet?.length) {
      criteria.clothingSet = filter.clothingSet;
    }

    if (filter?.totalSupplyMin || filter?.totalSupplyMax) {
      const filterFuc = (entry: any[]) => {
        if (filter.totalSupplyMin && filter.totalSupplyMin > Number(entry[1])) {
          return false;
        }

        if (filter.totalSupplyMax && filter.totalSupplyMax < Number(entry[1])) {
          return false;
        }

        return true;
      };

      const ids = Object.entries(totalSupplies).filter(filterFuc).map((entry) => Number(entry[0]));
      criteria.id = ids;
    }

    if (filter?.maxSupplyMin || filter?.maxSupplyMax) {
      const filterFuc = (entry: any[]) => {
        if (filter.maxSupplyMin && filter.maxSupplyMin > Number(entry[1])) {
          return false;
        }

        if (filter.maxSupplyMax && filter.maxSupplyMax < Number(entry[1])) {
          return false;
        }

        return true;
      };

      const ids = Object.entries(maxSupplies).filter(filterFuc).map((entry) => Number(entry[0]));
      criteria.id = ids;
    }

    if (filter?.ownerSupplyMin || filter?.ownerSupplyMax) {
      const filterFuc = (entry: any[]) => {
        if (filter.ownerSupplyMin && filter.ownerSupplyMin > Number(entry[1])) {
          return false;
        }

        if (filter.ownerSupplyMax && filter.ownerSupplyMax < Number(entry[1])) {
          return false;
        }

        return true;
      };

      const ids = Object.entries(clothingData)
        .filter(filterFuc)
        .map((entry) => Number(entry[0]));

      criteria.id = ids;
    }

    if (['totalSupply', 'maxSupply', 'ownerSupply'].includes(sort?.field)) {
      let data = clothingData;

      if (sort.field === 'totalSupply') {
        data = totalSupplies;
      } else if (sort.field === 'maxSupply') {
        data = maxSupplies;
      }

      const ids = Object.entries(data)
        .sort((a, b) => Number(b[1]) - Number(a[1]))
        .map((entry) => entry[0])
        .filter((id) => criteria.id.includes(id));

      criteria.id = ids;
      const sortIds = sort.order === 'ASC' ? ids : ids.reverse();
      order = [Sequelize.literal(sortIds.map((id) => `id=${id}`).join(', '))];
    }

    const clothings = await Clothing.findAndCountAll({
      where: criteria,
      include: [{
        attributes: ['chickenId', 'clothingId', 'userWalletId'],
        model: ChickenClothing,
        where: {
          userWalletId,
        },
        required: false,
      }],
      distinct: true,
      offset: (page - 1) * limit || 0,
      limit,
      order: [order] as Sequelize.Order,
    });

    const totalClothings = await Clothing.findAll({
      attributes: ['id'],
      where: criteria,
    });

    const totalCount = totalClothings.reduce((total, entry) => total + Number(clothingData[entry.id]), 0);

    const data = clothings.rows.map((clothing) => ({
      ...clothing.toJSON(),
      count: Number(clothingData[clothing.id]),
      totalSupply: Number(totalSupplies[clothing.id]),
      max: Number(maxSupplies[clothing.id]),
    }));

    res.status(200).json({
      rows: data,
      count: clothings.count,
      totalCount,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/clothings/me',
      userWalletId,
      query: req.query,
      err,
    }, 'Get Clothings Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/clothings/clothing-set', [authBasic], async (req: express.Request, res: express.Response) => {
  try {
    const clothings = await Clothing.findAll({
      attributes: ['clothingSet'],
      group: ['clothingSet'],
    });

    res.status(200).json(clothings.map((entry) => entry.clothingSet));
  } catch (err: any) {
    log.error({
      func: 'GET//clothings/clothing-set',
      err,
    }, 'Get Clothing Sets Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
