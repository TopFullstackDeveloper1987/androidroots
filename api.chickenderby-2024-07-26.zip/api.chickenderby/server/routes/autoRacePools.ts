import * as express from 'express';
import Sequelize from 'sequelize';
const { Op } = Sequelize;
import * as moment from 'moment-timezone';

import { auth, authAdmin } from '../middleware/auth';
import { validateFeeWithPrizePool } from '../validation/validatePrizePool';
import { AutoRacePool } from '../sequelize/models/AutoRacePool';
import { log, getPaginationInput } from '../utils';
import { convertCoinToJewel } from '../services/exchangeService';
import { RaceCoinType } from '../types/races/raceCoinType';
import { WETH_CONTRACT } from '../abi/wethContract';
import { JEWEL_CONTRACT } from '../abi/jewelContract';

const router = express.Router();

// create new auto race pool
router.post('/auto-race-pools', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  const {
    name,
    peckingOrder,
    terrainId,
    distance,
    maxCapacity,
    location,
    minimumStartDelay,
    startTime,
    fee,
    unlimitPO,
    type,
    group,
    coinType,
    bawkStakingCompanyId,
  } = req.body;

  try {
    log.info({
      func: 'POST/auto-race-pools',
      name,
      peckingOrder,
      terrainId,
      distance,
      maxCapacity,
      location,
      minimumStartDelay,
      startTime,
      fee,
      prizePool: req.body.prizePool,
      unlimitPO,
      type,
      group,
      userId: req.user.id,
      coinType,
      bawkStakingCompanyId,
      ...req.clientInfo,
    }, 'Auto Race Pool Create Start');

    const prizePool = await validateFeeWithPrizePool(req.body);

    const feeJEWEL = await convertCoinToJewel(coinType, fee);
    const prizePoolJEWEL = await convertCoinToJewel(coinType, prizePool);

    const autoRacePoolModel = await AutoRacePool.create({
      name,
      peckingOrder,
      terrainId,
      distance,
      maxCapacity,
      location,
      minimumStartDelay,
      startTime,
      fee,
      feeJEWEL,
      prizePool,
      prizePoolJEWEL,
      unlimitPO,
      type,
      group,
      coinContract: coinType === RaceCoinType.WETH ? WETH_CONTRACT.address : JEWEL_CONTRACT.address,
      bawkStakingCompanyId,
    });

    log.info({
      func: 'POST/auto-race-pools',
      name,
      autoRacePoolId: autoRacePoolModel.id,
      userId: req.user.id,
    }, 'Auto Race Pool Create End');

    res.json({
      message: `Auto Race Pool for ${name} created successfully`,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/auto-race-pool',
      name,
      userId: req.user.id,
      err,
    }, 'Auto Race Pool Create Error');

    if (err.message === 'Validation error') {
      res.status(400).json({
        message: 'Race Name Should Be Unique',
      });

      return;
    }

    res.status(400).json({
      message: err.message || 'All Fields are Required!',
    });
  }
});

// update auto race pool
router.patch('/auto-race-pools/:autoRacePoolId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  const { autoRacePoolId } = req.params;
  const {
    name,
    peckingOrder,
    terrainId,
    distance,
    maxCapacity,
    location,
    minimumStartDelay,
    startTime,
    fee,
    unlimitPO,
    type,
    group,
    coinType,
    bawkStakingCompanyId,
  } = req.body;

  try {
    log.info({
      func: 'PATCH/auto-race-pools',
      autoRacePoolId,
      name,
      peckingOrder,
      terrainId,
      distance,
      maxCapacity,
      location,
      minimumStartDelay,
      startTime,
      fee,
      unlimitPO,
      type,
      group,
      coinType,
      userId: req.user.id,
      bawkStakingCompanyId,
      ...req.clientInfo,
    }, 'Auto Race Pool Update Start');

    if (!autoRacePoolId) {
      throw new Error('Required auto race pool id');
    }

    const autoRacePoolRecord = await AutoRacePool.findByPk(autoRacePoolId);

    if (!autoRacePoolRecord) {
      throw new Error(`Can not find auto race pool for ID: ${autoRacePoolId}`);
    }

    const prizePool = await validateFeeWithPrizePool(req.body);

    const feeJEWEL = await convertCoinToJewel(coinType, fee);
    const prizePoolJEWEL = await convertCoinToJewel(coinType, prizePool);

    await autoRacePoolRecord.update({
      name,
      peckingOrder,
      terrainId,
      distance,
      maxCapacity,
      location,
      minimumStartDelay,
      startTime,
      fee,
      feeJEWEL,
      prizePool,
      prizePoolJEWEL,
      unlimitPO,
      type,
      group,
      coinContract: coinType === RaceCoinType.WETH ? WETH_CONTRACT.address : JEWEL_CONTRACT.address,
      bawkStakingCompanyId,
    });

    log.info({
      func: 'PATCH/auto-race-pools',
      autoRacePoolId,
      name,
      userId: req.user.id,
    }, 'Auto Race Pool Update End');

    res.json({
      message: `Auto Race Pool for ${name} updated successfully`,
    });
  } catch (err: any) {
    log.error({
      func: 'PATCH/auto-race-pools',
      autoRacePoolId,
      name,
      userId: req.user.id,
      err,
    }, 'Auto Race Pool Update Error');

    res.status(400).json({
      message: err.message || 'All Fields are Required!',
    });
  }
});

router.delete('/auto-race-pools/:autoRacePoolId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  const { autoRacePoolId } = req.params;

  try {
    log.info({
      func: 'DELETE/auto-race-pools',
      autoRacePoolId,
      userId: req.user.id,
      ...req.clientInfo,
    }, 'Auto Race Pool Delete Start');

    if (!autoRacePoolId) {
      throw new Error('Required auto race pool id');
    }

    const autoRacePoolRecord = await AutoRacePool.findByPk(autoRacePoolId);

    if (!autoRacePoolRecord) {
      throw new Error(`Can not find auto race pool for ID: ${autoRacePoolId}`);
    }

    await autoRacePoolRecord.destroy();

    log.info({
      func: 'DELETE/auto-race-pools',
      autoRacePoolId,
      userId: req.user.id,
    }, 'Auto Race Pool Delete End');

    res.json({
      message: 'Auto Race Pool deleted successfully',
    });
  } catch (err: any) {
    log.error({
      func: 'DELETE/auto-race-pools',
      autoRacePoolId,
      userId: req.user.id,
      err,
    }, 'Auto Race Pool Delete Error');

    res.status(400).json({
      message: err.message || 'All Fields are Required!',
    });
  }
});

router.get('/auto-race-pools', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req);

    // build where condition
    const condition: Sequelize.FindAndCountOptions = {
      limit,
      offset: (page - 1) * limit || 0,
      order: [[sort.field, sort.order]],
    };

    if (filter?.name?.length) {
      condition.where = {
        ...condition.where,
        name: {
          [Op.like]: `%${filter.name[0]}%`,
        },
      };
    }

    if (filter?.peckingOrder?.length) {
      condition.where = {
        ...condition.where,
        peckingOrder: filter.peckingOrder.join(','),
      };
    }

    if (filter?.distance?.length) {
      condition.where = {
        ...condition.where,
        distance: filter.distance,
      };
    }

    if (filter?.unlimitPO?.length) {
      condition.where = {
        ...condition.where,
        unlimitPO: filter.unlimitPO,
      };
    }

    if (filter?.type?.length) {
      condition.where = {
        ...condition.where,
        type: filter.type,
      };
    }

    if (filter?.group?.length) {
      condition.where = {
        ...condition.where,
        group: filter.group,
      };
    }

    if (filter?.terrain?.length) {
      condition.where = {
        ...condition.where,
        terrainId: filter.terrain,
      };
    }

    if (filter?.company?.length) {
      condition.where = {
        ...condition.where,
        bawkStakingCompanyId: filter.company,
      };
    }

    if (filter?.startsAt) {
      condition.where = {
        ...condition.where,
        startsAt: {
          [Op.gte]: moment.utc(filter.startsAt).startOf('date').toDate(),
          [Op.lte]: moment.utc(filter.startsAt).endOf('date').toDate(),
        },
      };
    }

    if (filter?.coinType?.length) {
      condition.where = {
        ...condition.where,
        coinContract: filter.coinType.map((coinType: RaceCoinType) => coinType === RaceCoinType.WETH ? WETH_CONTRACT.address : JEWEL_CONTRACT.address),
      };
    }

    const autoRacePools = await AutoRacePool.findAndCountAll(condition);

    res.json(autoRacePools);
  } catch (err: any) {
    log.error({
      func: 'GET/auto-race-pools',
      err,
      query: req.query,
    }, 'Auto Race Pool All Query Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
