import * as express from 'express';

import { log } from '../../utils';
import { authWallet } from '../../middleware/authWallet';
import { authBasic } from '../../middleware/authBasic';
import { GachaService } from '../../services';
import * as settingsService from '../../services/settingService';

const router = express.Router();

router.post('/gacha/pull', [authWallet, authBasic], async (req: express.Request, res: express.Response) => {
  try {

    log.info({
      func: 'POST/gacha/pull',
      userWalletId: req.user.id,
      mode: req.body.mode,
    }, 'Gacha Pull Start');

    const isTrainingPartnerEnabled = await settingsService.isTrainingPartnerEnabled();
    if (!isTrainingPartnerEnabled) {
      throw new Error('Training partner is not enabled');
    }

    const trainingPartners = await GachaService.getInstance().pull(req);

    log.info({
      func: 'POST/gacha/pull',
      userWalletId: req.user.id,
      mode: req.body.mode,
      trainingPartnerIds: trainingPartners.map((tp) => tp.id),
    }, 'Gacha Pull End');

    res.json({
      trainingPartners,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/gacha/pull',
      userWalletId: req.user.id,
      mode: req.body.mode,
      err,
    }, 'Gacha Pull Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
