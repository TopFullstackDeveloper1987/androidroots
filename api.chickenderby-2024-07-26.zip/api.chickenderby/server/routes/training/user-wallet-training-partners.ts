import * as express from 'express';
import Sequelize from 'sequelize';

import { authBasic } from '../../middleware/authBasic';
import { authWallet } from '../../middleware/authWallet';

import { UserWallet } from '../../sequelize/models/UserWallet';
import { TrainingPartner } from '../../sequelize/models/TrainingPartner';
import { UserWalletTrainingPartner } from '../../sequelize/models/UserWalletTrainingPartner';

import * as settingsService from '../../services/settingService';
import { log, getPaginationInput } from '../../utils';

const router = express.Router();

router.get('/user-wallet-training-partners/me', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;

  try {
    const isTrainingPartnerEnabled = await settingsService.isTrainingPartnerEnabled();
    if (!isTrainingPartnerEnabled) {
      throw new Error('Training partner is not enabled');
    }

    const {
      page, limit, sort,
    } = getPaginationInput(req, {
      defaultSort: { field: 'id', order: 'ASC' },
      defaultLimit: 50,
    });

    const order: Sequelize.OrderItem = [sort.field, sort.order];

    const totalCount = await TrainingPartner.count();
    const count = await UserWalletTrainingPartner.count({
      where: {
        userWalletId,
      },
    });
    const rows = await UserWalletTrainingPartner.findAll({
      where: {
        userWalletId,
      },
      include: [{
        model: TrainingPartner,
      }],
      offset: (page - 1) * limit || 0,
      limit,
      order: [order],
    });

    res.status(200).json({
      rows,
      count,
      totalCount,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/user-wallet-training-partners/me',
      userWalletId,
      query: req.query,
      err,
    }, 'Get My UserWallet Training Partners Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
