import * as express from 'express';

import { Op } from 'sequelize';

// Middlewares
import { authWallet } from '../middleware/authWallet';
import { authBasic } from '../middleware/authBasic';

// Models
import { Coop } from '../sequelize/models/Coop';
import { CoopChicken } from '../sequelize/models/CoopChicken';
import { UserWallet } from '../sequelize/models/UserWallet';

// Services
import * as chickenService from '../services/chickenService';

// Utils
import { log } from '../utils';

const router = express.Router();

const normalizeCoops = (coops: Coop[], chickenIds: number[]) => {
  const coopList = coops.map((coop) => ({
    id: coop.id,
    name: coop.name,
    count: coop.coopChickens.length,
  }));

  const coopChickenIds: number[] = coops.reduce((data, coop) => [...data, ...coop.coopChickens.map((coopChicken) => coopChicken.chickenId)], []);
  const uncoopedChickenIds = chickenIds.filter((chickenId) => !coopChickenIds.includes(Number(chickenId)));

  coopList.splice(0, 0, {
    id: null,
    name: 'Uncooped',
    count: uncoopedChickenIds.length,
  });

  return coopList;
};

router.patch('/coops/:coopId', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { coopId } = req.params;
  const { id: userWalletId } = req.user as UserWallet;
  const { name } = req.body;

  log.info({
    func: 'PATCH/coops/:coopId',
    coopId,
    userWalletId,
    name,
  }, 'Update Coop');

  try {
    if (!name) {
      throw new Error('Coop name is required');
    }

    const coopRecord = coopId && userWalletId && await Coop.findOne({
      where: {
        id: coopId,
        userWalletId,
      },
    });

    if (!coopRecord) {
      throw new Error('Can not find coop');
    }

    const exists = await Coop.findOne({
      where: {
        id: { [Op.not]: coopId },
        name,
        userWalletId,
      },
    });

    if (exists) {
      throw new Error(`Coop name "${name}" already exists, please try to use another one.`);
    }

    await coopRecord.update({
      name,
    });

    res.status(200).json(coopRecord.toJSON());
  } catch (err: any) {
    log.error({
      func: 'PATCH/coops/:coopId',
      coopId,
      name,
      userWalletId,
      err,
    }, 'Update Coop Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.delete('/coops/:coopId/chickens/:chickenId', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;
  const { coopId } = req.params;
  const chickenId = Number(req.params.chickenId);

  log.info({
    func: 'DELETE/coops/:coopId/chickens/chickenId',
    coopId,
    chickenId,
    userWalletId,
  }, 'Remove Chicken from Coop');

  try {
    const coopRecord = coopId && userWalletId && await Coop.findOne({
      where: {
        id: coopId,
        userWalletId,
      },
    });

    if (!coopRecord) {
      throw new Error('Can not find coop');
    }

    const coopChickenRecord = await CoopChicken.findOne({
      where: {
        chickenId,
      },
      include: {
        model: Coop,
        where: {
          userWalletId,
        },
      },
    });

    if (!coopChickenRecord) {
      throw new Error('Can not find chicken in coop');
    }

    // Validate if chicken in current user
    const chickenIds = await chickenService.getChickenIdsForUserWalletId(userWalletId);

    if (!chickenIds.includes(chickenId)) {
      await coopChickenRecord.destroy();

      throw new Error('Can not find chicken in your wallet');
    }

    await coopChickenRecord.destroy();

    const coopRecords = await Coop.findAll({
      where: {
        userWalletId,
      },
      include: [{
        model: CoopChicken,
        as: 'coopChickens',
        required: false,
        where: {
          chickenId: { [Op.in]: chickenIds },
        },
      }],
      order: [['id', 'asc']],
    });

    res.status(200).json(normalizeCoops(coopRecords, chickenIds));
  } catch (err: any) {
    log.error({
      func: 'DELETE/coops/:coopId/chickens/chickenId',
      coopId,
      chickenId,
      userWalletId,
      err,
    }, 'Remove Chicken from Coop Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.put('/coops/:coopId/chickens/:chickenId', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;
  const { coopId } = req.params;
  const chickenId = Number(req.params.chickenId);

  log.info({
    func: 'PUT/coops/:coopId/chickens/:chickenId',
    coopId,
    chickenId,
    userWalletId,
  }, 'Add Chicken to Coop');

  try {
    const coopRecord = coopId && userWalletId && await Coop.findOne({
      where: {
        id: coopId,
        userWalletId,
      },
    });

    if (!coopRecord) {
      throw new Error('Can not find coop');
    }

    let coopChickenRecord = await CoopChicken.findOne({
      where: {
        chickenId,
      },
      include: {
        model: Coop,
        where: {
          userWalletId,
        },
      },
    });

    // Validate if chicken in current user
    const chickenIds = await chickenService.getChickenIdsForUserWalletId(userWalletId);

    if (!chickenIds.includes(chickenId)) {
      if (coopChickenRecord) { // delete coop chicken if token id is not in auth user
        await coopChickenRecord.destroy();
      }

      throw new Error('Can not find chicken in your wallet');
    }

    if (coopChickenRecord?.coopId === coopRecord.id) {
      throw new Error(`Chicken already in ${coopRecord.name}`);
    }

    if (!coopChickenRecord) {
      // Add chicken to coop if there's no record
      coopChickenRecord = await CoopChicken.create({
        coopId,
        chickenId,
      });
    } else {
      // Move chicken to target coop if it's already in other coop
      await coopChickenRecord.update({
        coopId: coopRecord.id,
      });
    }

    const coopRecords = await Coop.findAll({
      where: {
        userWalletId,
      },
      include: [{
        model: CoopChicken,
        as: 'coopChickens',
        required: false,
        where: {
          chickenId: { [Op.in]: chickenIds },
        },
      }],
      order: [['id', 'asc']],
    });

    res.status(200).json(normalizeCoops(coopRecords, chickenIds));
  } catch (err: any) {
    log.error({
      func: 'PUT/coops/:coopId/chickens/:chickenId',
      coopId,
      chickenId,
      userWalletId,
      err,
    }, 'Add Chicken to Coop Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/coops/me', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;

  try {
    const chickenIds = await chickenService.getChickenIdsForUserWalletId(userWalletId);

    const coopRecords = await Coop.findAll({
      where: {
        userWalletId,
      },
      include: [{
        model: CoopChicken,
        as: 'coopChickens',
        required: false,
        where: {
          chickenId: { [Op.in]: chickenIds },
        },
      }],
      order: [['id', 'asc']],
    });

    const coopIds = coopRecords.map((item) => item.id);

    // delete coop chickens that move to another user
    await CoopChicken.destroy({
      where: {
        coopId: { [Op.in]: coopIds },
        chickenId: { [Op.notIn]: chickenIds },
      },
    });

    res.status(200).json(normalizeCoops(coopRecords, chickenIds));
  } catch (err: any) {
    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
