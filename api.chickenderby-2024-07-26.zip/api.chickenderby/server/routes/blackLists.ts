// Dependencies
import * as express from 'express';
import Sequelize from 'sequelize';
const { Op } = Sequelize;

// Middlewares
import { auth, authAdmin } from '../middleware/auth';

const router = express.Router();

// Models
import { UserWallet } from '../sequelize/models/UserWallet';
import { BlackList } from '../sequelize/models/BlackList';

// Services
import { createUserWallet } from '../services/userWalletService';
import { serializeBlackList } from '../services/blackListService';
import { getContractAddressFromType } from '../services/contracts/web3Service';
import { markMarketItemToCancel } from '../services/marketplace/marketplaceService';

// Utils
import { log, getPaginationInput } from '../utils';

// Schemas
import { replaceBlackListSchema } from '../validation/validationSchemas';

router.put('/black-lists/:stealerUserWalletId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  const { stealerUserWalletId } = req.params;
  const {
    contractType,
    tokenId,
    reporterUserName,
    reporterUserWalletId,
    isBlackListed,
  } = req.body;

  try {
    await replaceBlackListSchema.validateAsync({
      ...req.body,
      stealerUserWalletId,
    });

    log.info({
      func: 'PUT/black-lists/:stealerUserWalletId',
      stealerUserWalletId,
      contractType,
      tokenId,
      reporterUserName,
      reporterUserWalletId,
      isBlackListed,
    }, 'Put blacklist start');

    const blackList = await BlackList.sequelize.transaction(async (t) => {
      const stealerUserWallet = await UserWallet.findByPk(stealerUserWalletId);
      if (!stealerUserWallet) {
        await createUserWallet(stealerUserWalletId, t);
      }

      const reporterUserWallet = await UserWallet.findByPk(reporterUserWalletId);
      if (!reporterUserWallet) {
        await createUserWallet(reporterUserWalletId, t);
      }

      const nftContract = await getContractAddressFromType(contractType);
      if (!nftContract) {
        throw new Error('Invalid contract type');
      }

      const defaults = {
        stealerUserWalletId,
        nftContract,
        tokenId,
        reporterUserName,
        reporterUserWalletId,
        blackListedAt: isBlackListed ? new Date() : null,
      };

      if (isBlackListed) {
        await markMarketItemToCancel(nftContract, tokenId, t);
      }

      return BlackList.findOrCreate({
        where: {
          nftContract,
          tokenId,
        },
        defaults,
        transaction: t,
      }).then(async ([newRecord, created]) => {
        if (created) {
          return newRecord;
        }

        return newRecord.update(defaults, { transaction: t });
      });
    });

    const blackListRes = await serializeBlackList(blackList);
    res.json(blackListRes);
  } catch (err: any) {
    log.error({
      func: 'PUT/black-lists/:stealerUserWalletId',
      stealerUserWalletId,
      contractType,
      tokenId,
      reporterUserName,
      reporterUserWalletId,
      isBlackListed,
      err,
    }, 'Put blacklist error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/black-lists', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req, {
      defaultSort: { field: 'blackListedAt', order: 'DESC' },
    });

    // build where condition
    const condition: Sequelize.FindAndCountOptions = {
      limit,
      offset: (page - 1) * limit || 0,
      order: [[sort.field, sort.order]],
    };

    if (filter?.contractType) {
      const nftContracts = [];
      for (const contractType of filter.contractType) {
        const nftContract = await getContractAddressFromType(contractType);
        nftContracts.push(nftContract);
      }

      condition.where = {
        ...condition.where,
        nftContract: nftContracts,
      };
    }

    if (filter?.stealerUserWalletId) {
      condition.where = {
        ...condition.where,
        stealerUserWalletId: filter.stealerUserWalletId,
      };
    }

    if (filter?.tokenId) {
      condition.where = {
        ...condition.where,
        tokenId: filter.tokenId,
      };
    }

    if (filter?.reporterUserName) {
      condition.where = {
        ...condition.where,
        reporterUserName: {
          [Op.like]: `%${filter.reporterUserName}%`,
        },
      };
    }

    if (filter?.reporterUserWalletId) {
      condition.where = {
        ...condition.where,
        reporterUserWalletId: filter.reporterUserWalletId,
      };
    }

    const blackLists = await BlackList.scope('active').findAndCountAll(condition);
    const rows = [];
    for (const blackList of blackLists.rows) {
      const row = await serializeBlackList(blackList);
      rows.push(row);
    }

    blackLists.rows = rows;

    res.json(blackLists);
  } catch (err: any) {
    log.error({
      func: 'GET/black-lists',
      query: req.query,
      err,
    }, 'Get blacklist error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
