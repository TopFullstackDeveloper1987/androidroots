// Dependencies
import * as express from 'express';

// Middlewares
import { authBasic } from '../middleware/authBasic';

// Models
import { SeasonBadge } from '../sequelize/models/SeasonBadge';
import { ChickenSeasonBadge } from '../sequelize/models/ChickenSeasonBadge';
import { TournamentBadge } from '../sequelize/models/TournamentBadge';
import { ChickenTournamentBadge } from '../sequelize/models/ChickenTournamentBadge';

// Utils
import { log, getPaginationInput } from '../utils';

const router = express.Router();

router.get('/badges/seasons/:chickenId', authBasic, async (req: express.Request, res) => {
  try {
    const { page, limit } = getPaginationInput(req);
    const sort = req.query.sort
      ? JSON.parse(req.query.sort as string)
      : { field: 'createdAt', order: 'DESC' };
    const { chickenId } = req.params;

    const chickenSeasonBadges = await ChickenSeasonBadge.findAndCountAll({
      where: {
        chickenId,
      },
      include: [{
        model: SeasonBadge,
      }],
      limit,
      offset: (page - 1) * limit || 0,
      order: [[sort.field, sort.order]],
      distinct: true,
    });

    res.json(chickenSeasonBadges);
  } catch (err: any) {
    log.error({
      func: 'GET/badges/seasons/:chickenId',
      query: req.query,
      err,
    }, 'Get Season Badges Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/badges/tournaments/:chickenId', authBasic, async (req: express.Request, res) => {
  try {
    const { page, limit } = getPaginationInput(req);
    const sort = req.query.sort
      ? JSON.parse(req.query.sort as string)
      : { field: 'createdAt', order: 'DESC' };
    const { chickenId } = req.params;

    const chickenTournamentBadges = await ChickenTournamentBadge.findAndCountAll({
      where: {
        chickenId,
      },
      include: [{
        model: TournamentBadge,
      }],
      limit,
      offset: (page - 1) * limit || 0,
      order: [[sort.field, sort.order]],
      distinct: true,
    });

    res.json(chickenTournamentBadges);
  } catch (err: any) {
    log.error({
      func: 'GET/badges/tournaments/:chickenId',
      query: req.query,
      err,
    }, 'Get Tournament Badges Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
