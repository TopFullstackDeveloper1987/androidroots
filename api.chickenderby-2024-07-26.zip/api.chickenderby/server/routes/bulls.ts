// Settings

// Dependencies
import * as express from 'express';
const bullArena = require('bull-arena');
const bull = require('bull');
import basicAuth from 'express-basic-auth';

import config from '../config';

const router = express.Router();

const jobs = [{
  name: 'Race Scheduler',
}, {
  name: 'race-schedule-timer',
}, {
  name: 'perform-race-worker',
}, {
  name: 'Race Finish Worker',
}, {
  name: 'Race Payout Worker',
}, {
  name: 'race-admin-worker',
}, {
  name: 'Race Enter Worker',
}, {
  name: 'Race Alert Worker',
}, {
  name: 'Mint Land Worker',
}, {
  name: 'Sync Discord Roles Worker',
}, {
  name: 'marketplace-worker',
}, {
  name: 'marketplace-admin-worker',
}, {
  name: 'marketplace-chicken-sync-worker',
}, {
  name: 'marketplace-clothing-sync-worker',
}, {
  name: 'race-sync-worker',
}, {
  name: 'tournament-status-worker',
}, {
  name: 'fusion-worker',
}, {
  name: 'fusion-sync-worker',
}, {
  name: 'serum-mint-worker',
}, {
  name: 'race-time-limit-monitor',
}, {
  name: 'reset-chicken-situation-worker',
}, {
  name: 'chicken-staking-season-worker',
}, {
  name: 'bawk-staking-worker',
}, {
  name: 'coin-presale-admin-worker',
}];

const jobsList = jobs.map((job) => ({
  ...job,
  hostId: 'jobs',
  redis: {
    host: config.redis.host,
    port: config.redis.port,
    password: config.redis.password,
  },
}));

const arena = bullArena({
  Bull: bull,
  queues: [
    ...jobsList,
  ],
}, {
  basePath: '/jobs-dashboard',
  disableListen: true,
});

router.use('/jobs-dashboard', basicAuth({
  users: {
    [config.bull.admin.name]: config.bull.admin.password,
  },
  challenge: true,
}));

router.use('/', arena);

export = router;
