import * as express from 'express';
import Sequelize from 'sequelize';

const { Op } = Sequelize;
import * as moment from 'moment-timezone';

import { Tournament } from '../sequelize/models/Tournament';
import { TournamentRanking } from '../sequelize/models/TournamentRanking';
import { UserWallet } from '../sequelize/models/UserWallet';
import { Chicken } from '../sequelize/models/Chicken';
import { ChickenClothing } from '../sequelize/models/ChickenClothing';

import { log, getPaginationInput } from '../utils';

import { authBasic } from '../middleware/authBasic';
import { authWallet } from '../middleware/authWallet';

const router = express.Router();

const normalizeTournament = (record: Tournament) => {
  const today = moment.utc().format('YYYY-MM-DD');

  const results = {
    ...record.toJSON(),
  };

  const doubleEvent = record.rules.points?.double?.data.find((item: any) => item.date === today);

  if (doubleEvent) {
    let doubleText = '';

    if (doubleEvent.type === 'feeUSD') {
      doubleText = `Entry Fee at least $${doubleEvent.value.toFixed(2)}`;
    } else if (doubleEvent.type === 'distance') {
      doubleText = `${doubleEvent.value}m`;
    } else if (doubleEvent.type === 'terrain') {
      doubleText = doubleEvent.value;
    } else if (doubleEvent.type === 'multiple') {
      for (let i = 0; i < doubleEvent.value.length; i += 1) {
        const item = doubleEvent.value[i];

        if (item.type === 'feeUSD') {
          doubleText += `Entry Fee at least $${item.value.toFixed(2)}`;
        } else if (item.type === 'distance') {
          doubleText += `${item.value}m`;
        } else if (item.type === 'terrain') {
          doubleText += item.value;
        }

        if (i < doubleEvent.value.length - 2) {
          doubleText += ', ';
        } else if (i === doubleEvent.value.length - 2) {
          doubleText += ' or ';
        }
      }
    }

    results.event = {
      name: 'Double',
      // eslint-disable-next-line no-nested-ternary
      value: doubleText,
    };
  }

  delete results.rules;

  return results;
};

router.get('/tournaments/last', authBasic, async (req, res) => {
  try {
    const now = moment.utc().toDate();
    const record = await Tournament.findOne({
      order: [['startAt', 'ASC']],
      where: {
        [Op.or]: [{
          startAt: { [Op.lte]: now },
          endAt: { [Op.gte]: now },
        }, {
          startAt: { [Op.gte]: now },
        }],
      },
    });

    if (!record) {
      res.json(null);
      return;
    }

    const result = normalizeTournament(record);

    res.json(result);
  } catch (err: any) {
    log.error(
      {
        func: 'GET/tournaments/active',
        err,
      },
      'Get active tournament',
    );

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/tournaments/rankings/master/:url', authBasic, async (req, res) => {
  const { url } = req.params;

  try {
    if (!url) {
      throw new Error('Required url');
    }

    const tournament = await Tournament.findOne({
      where: {
        url,
      },
    });

    if (!tournament) {
      throw new Error(`Can not find tournament for ${url}`);
    }

    const tournamentRankingRecords = await TournamentRanking.findAll({
      where: {
        tournamentId: tournament.id,
        position: 1,
      },
      include: [
        {
          model: UserWallet,
          attributes: ['username'],
        },
        {
          model: Chicken.scope('profile'),
          include: [{
            model: ChickenClothing.scope('includesClothing'),
          }],
        },
      ],
    });

    res.json(tournamentRankingRecords);
  } catch (err: any) {
    log.error(
      {
        func: '/tournaments/rankings/first/:url',
        err,
      },
      'All tournament first Ranking',
    );

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/tournaments/rankings/:url/totals', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;
  const { url } = req.params;

  try {
    const tournament = await Tournament.findOne({
      where: {
        url,
      },
    });

    if (!tournament) {
      throw new Error(`Can not find tournament for ${url}`);
    }

    const conditions: Sequelize.WhereOptions = {
      tournamentId: tournament.id,
      userWalletId,
    };
    const totalPoints = await TournamentRanking.sum('points', {
      where: conditions,
    });

    const totalSecondPoints = await TournamentRanking.sum('secondPoints', {
      where: conditions,
    });

    const totalRaces = await TournamentRanking.sum('races', {
      where: conditions,
    });

    const topTenChickens = await TournamentRanking.findAll({
      attributes: ['position', 'chickenId', 'group'],
      where: {
        ...conditions,
        position: { [Op.lte]: 10 },
      },
    });

    res.json({
      totalPoints,
      totalSecondPoints,
      totalRaces,
      topTenChickens,
    });
  } catch (err: any) {
    log.error({
      func: 'GET//tournaments/rankings/:url/user-data',
      url,
      err,
    }, 'Get tournament ranking user data');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/tournaments/rankings/:url/group', authBasic, async (req, res) => {
  const { url } = req.params;
  const { userWalletId } = req.query;

  try {
    if (!url) {
      throw new Error('Required url');
    }

    const tournament = await Tournament.findOne({
      where: {
        url,
      },
    });

    if (!tournament) {
      throw new Error(`Can not find tournament for ${url}`);
    }

    const tournamentRankingRecords = await TournamentRanking.findAll({
      attributes: [
        'group',
        [Sequelize.fn('sum', Sequelize.col('points')), 'points'],
        [Sequelize.fn('sum', Sequelize.col('races')), 'races'],
        [Sequelize.fn('count', Sequelize.col('userWalletId')), 'players'],
      ],
      where: {
        tournamentId: tournament.id,
      },
      group: ['group'],
    });

    tournamentRankingRecords.sort((a, b) => b.points - a.points);

    let result = tournamentRankingRecords;

    if (userWalletId) {
      const userTournamentRankings = await TournamentRanking.findAll({
        attributes: ['userWalletId', 'group'],
        where: {
          userWalletId,
          tournamentId: tournament.id,
        },
      });

      const userTournamentRankingGroups = userTournamentRankings.map((item) => item.group);

      result = tournamentRankingRecords.map((item: any) => {
        const data = item.toJSON();
        data.isUserGroup = userTournamentRankingGroups.includes(data.group);

        return data;
      });
    }

    res.json(result);
  } catch (err: any) {
    log.error(
      {
        func: '/tournaments/rankings/:url/group',
        err,
      },
      'All tournament group Ranking',
    );

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/tournaments/rankings/:url', authBasic, async (req, res) => {
  const { url } = req.params;

  try {
    const { page, limit } = getPaginationInput(req);

    const { userWalletId, group } = req.query;
    const unqualifiedChickens = req.query.unqualifiedChickens ? Number(req.query.unqualifiedChickens) : 0;

    const sort = req.query.sort
      ? JSON.parse(req.query.sort as string)
      : { field: 'position', order: 'ASC' };

    if (!url) {
      throw new Error('Required url');
    }

    const tournament = await Tournament.findOne({
      where: {
        url,
      },
    });

    if (!tournament) {
      throw new Error(`Can not find tournament for ${url}`);
    }

    if (!group && tournament.groups?.length) {
      throw new Error('Required group');
    }

    // build where condition
    const condition: Sequelize.FindAndCountOptions = {
      where: {
        tournamentId: tournament.id,
      },
      limit,
      offset: (page - 1) * limit || 0,
      include: [
        {
          model: UserWallet,
          attributes: ['username'],
        },
        {
          model: Chicken.scope('profile'),
          include: [{
            model: ChickenClothing.scope('includesClothing'),
          }],
        },
      ],
      order: [
        [sort.field, sort.order],
        ['id', 'asc'],
      ],
      distinct: true,
    };

    if (userWalletId) {
      condition.where = {
        ...condition.where,
        userWalletId,
      };
    }

    if (unqualifiedChickens) {
      condition.where = {
        ...condition.where,
        races: { [Op.lt]: tournament.maxRaces },
      };
    }

    if (group) {
      condition.where = {
        ...condition.where,
        group,
      };
    }

    const tournamentRankingRecords = await TournamentRanking.findAndCountAll(
      condition,
    );

    const chickenIds = tournamentRankingRecords.rows.map((record) => record.chickenId);
    const userWalletIds = tournamentRankingRecords.rows.map((record) => record.userWalletId);
    const results: (TournamentRanking | {
      totalRaces: number,
      totalGroupPoints: number,
    })[] = [];

    const total = await TournamentRanking.findAll({
      attributes: [
        'userWalletId',
        'chickenId',
        [Sequelize.fn('sum', Sequelize.col('races')), 'totalRaces'],
      ],
      where: {
        tournamentId: tournament.id,
        userWalletId: { [Op.in]: userWalletIds },
        chickenId: { [Op.in]: chickenIds },
      },
      group: ['userWalletId', 'chickenId'],
    });

    const totalGroupPointsConditions: Sequelize.WhereOptions = {
      tournamentId: tournament.id,
    };

    if (group) {
      totalGroupPointsConditions.group = group;
    }

    const totalGroupPoints = await TournamentRanking.sum('points', {
      where: totalGroupPointsConditions,
    });

    tournamentRankingRecords.rows.forEach((tournamentRankingRecord) => {
      const totalItem = total.find(
        (item) => item.userWalletId === tournamentRankingRecord.userWalletId && item.chickenId === tournamentRankingRecord.chickenId,
      );

      results.push({
        ...tournamentRankingRecord.toJSON(),
        totalRaces: totalItem?.toJSON()?.totalRaces || 0,
        totalGroupPoints,
      });
    });

    res.json({
      rows: results,
      count: tournamentRankingRecords.count,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/tournaments/rankings/:url',
      url,
      err,
    }, 'All tournament Ranking');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/tournaments/:url', authBasic, async (req, res) => {
  const { url } = req.params;

  try {
    const record = await Tournament.findOne({
      where: {
        url,
      },
    });
    if (!record) {
      throw new Error(`Not found tournament for ${url}`);
    }

    const results = normalizeTournament(record);

    res.json(results);
  } catch (err: any) {
    log.error(
      {
        func: 'GET/tournaments/:url',
        err,
        url,
      },
      'Get tournament by url',
    );

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/tournaments', authBasic, async (req, res) => {
  const { page, limit, sort } = getPaginationInput(req);

  try {
    const condition: Sequelize.FindAndCountOptions = {
      where: {},
      limit,
      offset: (page - 1) * limit || 0,
      order: [[sort.field, sort.order]],
      distinct: true,
    };

    const tournaments = await Tournament.findAndCountAll(condition);

    res.json(tournaments);
  } catch (err: any) {
    log.error({
      func: 'GET/tournaments',
      err,
    }, 'Get tournaments Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
