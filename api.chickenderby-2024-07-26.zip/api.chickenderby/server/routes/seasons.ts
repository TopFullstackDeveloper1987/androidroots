// Dependencies
import * as express from 'express';
import Sequelize from 'sequelize';

// Middlewares
import { authBasic } from '../middleware/authBasic';

// Models
import { Chicken } from '../sequelize/models/Chicken';
import { ChickenClothing } from '../sequelize/models/ChickenClothing';
import { Season } from '../sequelize/models/Season';
import { SeasonRanking } from '../sequelize/models/SeasonRanking';
import { UserWallet } from '../sequelize/models/UserWallet';

// Services
import { toChecksumAddress } from '../services/contracts/web3Service';
import * as chickenService from '../services/contracts/chickenContractService';

// Utils
import { log, getPaginationInput } from '../utils';

// Types
import { SeasonStatus } from '../types/seasons/seasonStatus';

const router = express.Router();

router.get('/seasons/last', authBasic, async (req, res) => {
  try {
    const season = await Season.findOne({
      where: {
        status: [SeasonStatus.Pending, SeasonStatus.Live],
      },
      order: [['id', 'ASC']],
    });

    res.json(season);
  } catch (err: any) {
    log.error({
      func: 'GET/seasons/last',
      err,
    }, 'Get Last Season Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/seasons/:seasonId/rankings', authBasic, async (req, res) => {
  try {
    const { page, limit } = getPaginationInput(req);

    const { seasonId } = req.params;
    const { peckingOrder } = req.query;

    const sort = req.query.sort
      ? JSON.parse(req.query.sort as string)
      : { field: 'position', order: 'ASC' };

    const season = seasonId && await Season.findByPk(seasonId);
    if (!season) {
      throw new Error(`Epoch not found for ${seasonId}`);
    }

    if (!peckingOrder) {
      throw new Error('Pecking order required');
    }

    const chickenQuery: Sequelize.WhereOptions = {};

    if (req.query.userWalletId) {
      const chickenIds = await chickenService.getChickenIdsForUserWalletId(req.query.userWalletId as string);
      chickenQuery.id = chickenIds;
    }

    const seasonRankings = await SeasonRanking.findAndCountAll({
      where: {
        seasonId,
        peckingOrder,
      },
      limit,
      offset: (page - 1) * limit || 0,
      include: [{
        model: Chicken.scope('profile'),
        where: chickenQuery,
        include: [{
          model: ChickenClothing.scope('includesClothing'),
        }],
      }],
      order: [
        [sort.field, sort.order],
        ['id', 'asc'],
      ],
      distinct: true,
    });

    const chickenIds = seasonRankings.rows.map((seasonRanking) => seasonRanking.chickenId);
    const userWalletIds = await chickenService.getOwnersOfChickens(chickenIds);
    const userWallets = await UserWallet.findAll({
      where: {
        id: userWalletIds,
      },
    });

    const rows = [];
    for (let i = 0; i < seasonRankings.rows.length; i += 1) {
      const seasonRanking = seasonRankings.rows[i];
      const { chicken } = seasonRanking;
      const userWalletId = userWalletIds[i];
      const userWallet = userWalletId && userWallets.find((uw) => toChecksumAddress(uw.id) === toChecksumAddress(userWalletId));

      rows.push({
        ...seasonRanking.toJSON(),
        chicken: {
          ...chicken.toJSON(),
          userWalletId,
          username: userWallet?.username || null,
        },
      });
    }

    res.json({
      count: seasonRankings.count,
      rows,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/seasons/:seasonId/rankings',
      seasonId: req.params.seasonId,
      query: req.query,
      err,
    }, 'Get Season Rankings Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/seasons/:seasonId', authBasic, async (req, res) => {
  try {
    const { seasonId } = req.params;
    const season = seasonId && await Season.findByPk(seasonId);

    if (!season) {
      throw new Error(`Epoch not found for ${seasonId}`);
    }

    res.json(season);
  } catch (err: any) {
    log.error({
      func: 'GET/seasons/:seasonId',
      seasonId: req.params.seasonId,
      err,
    }, 'Get Season Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/seasons', authBasic, async (req, res) => {
  try {
    const { page, limit, sort } = getPaginationInput(req);

    const seasons = await Season.findAndCountAll({
      where: {},
      limit,
      offset: (page - 1) * limit || 0,
      order: [[sort.field, sort.order]],
      distinct: true,
    });

    res.json(seasons);
  } catch (err: any) {
    log.error({
      func: 'GET/seasons',
      query: req.query,
      err,
    }, 'Get Seasons Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
