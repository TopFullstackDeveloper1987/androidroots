// Dependencies
import * as express from 'express';
import * as _ from 'lodash';
import Sequelize from 'sequelize';
import { parseAsync } from 'json2csv';
import basicAuth from 'express-basic-auth';

// Config
import config from '../config';

// Middlewares
import { authBasic } from '../middleware/authBasic';
import { authWallet, authWalletPublic } from '../middleware/authWallet';
import { cache } from '../middleware/cache';

// Models
import { Race } from '../sequelize/models/Race';
import { Lane } from '../sequelize/models/Lane';
import { UserWallet } from '../sequelize/models/UserWallet';
import { Chicken } from '../sequelize/models/Chicken';
import { MarketItem } from '../sequelize/models/MarketItem';
import { TradePreference } from '../sequelize/models/TradePreference';
import { TradeActivity } from '../sequelize/models/TradeActivity';
import { Coop } from '../sequelize/models/Coop';
import { CoopChicken } from '../sequelize/models/CoopChicken';
import { ChickenClothing } from '../sequelize/models/ChickenClothing';
import { Clothing } from '../sequelize/models/Clothing';

// Services
import { updateChickenName, getChickenFilter, checkChickenStatus } from '../services/chickenService';
import { checkDeployment } from '../services/settingService';
import { isBlackListedToken, checkBlackList } from '../services/blackListService';
import * as alchemyService from '../services/contracts/alchemyService';
import * as chickenService from '../services/chickenService';

// Contracts
import { getChickenContractAddress, getChickenIdsForUserWalletIds } from '../services/contracts/chickenContractService';

// Utils
import { log, getPaginationInput } from '../utils';

// Types
import { ChickenPeckingOrder } from '../types/chickens/chickenPeckingOrder';
import { OFFENSIVE_TALENTS, SPEED_TALENTS } from '../services/talentService';
import { isZeroAddress } from '../services/contracts/web3Service';
import { Terrain } from '../sequelize/models/Terrain';

const { Op } = Sequelize;

const router = express.Router();

router.get('/chickens/bulk', async (req, res) => {
  const { chickenIds } = req.query;

  try {
    const chickens = await Chicken.findAll({
      where: {
        id: chickenIds,
      },
    });

    res.json(chickens);
  } catch (err: any) {
    log.error({
      func: 'GET/chickens/bulk',
      chickenIds,
      err,
    }, 'Get Bulk Chickens Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

// Only for Ben
router.get('/chickens/export', basicAuth({
  users: {
    admin: config.PAGINATION_NO_LIMIT_KEY,
  },
  challenge: true,
}), async (req, res) => {
  try {
    const owners: string[] = await alchemyService.getOwnersForCollection(config.CHICKEN_CONTRACT.address);
    const filteredOwners = owners.filter(address => !isZeroAddress(address));

    log.info({
      func: 'GET/chickens/export',
      numberOfOwners: owners.length,
      numberOfFilteredOwners: filteredOwners.length,
    });

    const chickenIdsWithUserWalletIds: {
      chickenId: number,
      userWalletId: string,
    }[] = [];
    const limit = 500;
    let userWalletIds: string[] = [];

    for (let i = 0; i < filteredOwners.length; i += 1) {
      userWalletIds.push(filteredOwners[i]);

      if (i % limit === limit - 1 || i === filteredOwners.length - 1) {
        const chickenIdsForUserWalletIds = await getChickenIdsForUserWalletIds(userWalletIds);

        chickenIdsForUserWalletIds.forEach(el => {
          el.chickenIds.forEach(chickenId => {
            chickenIdsWithUserWalletIds.push({
              chickenId,
              userWalletId: el.userWalletId,
            });
          });
        });

        log.info({
          func: 'GET/chickens/export',
          progress: `${i + 1} / ${filteredOwners.length}`,
        });

        userWalletIds = [];
      }
    }

    chickenIdsWithUserWalletIds.sort((a, b) => a.chickenId - b.chickenId);
    const csv = await parseAsync(chickenIdsWithUserWalletIds);

    res.setHeader('Content-disposition', 'attachment; filename=chickens.csv');
    res.set('Content-Type', 'text/csv');
    res.status(200).send(csv);
  } catch (err: any) {
    log.error({
      func: 'GET/chickens/export',
      err,
    });

    res.status(400).json({
      message: err.message,
    });
  }
});

// Only for Ben to pull the chickens in bulk easily
router.post('/chickens/bulk', async (req, res) => {
  const { chickenIds } = req.body;

  try {
    const chickens = await Chicken.findAll({
      where: {
        id: chickenIds,
      },
    });

    res.json(chickens);
  } catch (err: any) {
    log.error({
      func: 'POST/chickens/bulk',
      chickenIds,
      err,
    }, 'Get Bulk Chickens Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

// cache every minute
router.get('/chickens/contract-stats', [authBasic, authWalletPublic, cache(1)], async (req: express.Request, res: express.Response) => {
  try {
    const userWalletId = req.user?.id as string;

    const totalOwners = await chickenService.getTotalOwners();
    const totalSupply = await chickenService.getTotalSupply();
    const totalStaked = await chickenService.getTotalStaked();

    const data = {
      totalOwners,
      totalSupply,
      totalStaked,
      stakedChickens: 0,
      unstakedChickens: 0,
    };

    if (userWalletId) {
      const {
        stakedChickenIds,
        unstakedChickenIds,
      } = await chickenService.getStakedAndUnstakedChickenIds(userWalletId);

      data.stakedChickens = stakedChickenIds.length;
      data.unstakedChickens = unstakedChickenIds.length;
    }

    res.json(data);
  } catch (err: any) {
    log.error({
      func: 'GET/chickens/contract-stats/stats',
      err,
    }, 'Get Chicken Contract Stats Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/chickens', [authBasic], async (req: express.Request, res: express.Response) => {
  try {
    const {
      page, limit, filter, sort,
    } = getPaginationInput(req, { defaultSort: { field: 'id', order: 'ASC' } });
    const userWalletId = filter?.userWalletId;
    let race: Race;

    if (!userWalletId) {
      throw new Error('User wallet ID required');
    }

    const order: Sequelize.OrderItem = [sort.field, sort.order];

    const chickenInclude: Sequelize.Includeable[] = [{
      model: TradeActivity,
      as: 'lastTradeActivity',
      attributes: ['id', 'price'],
      required: false,
    }, {
      model: MarketItem.scope(['defaultScope', 'active']),
      as: 'lastActiveMarketItem',
      required: false,
      attributes: ['id', 'price', 'tradeType'],
    }];

    if (filter?.clothingId) {
      chickenInclude.push({
        attributes: ['chickenId', 'clothingId', 'userWalletId'],
        model: ChickenClothing,
        where: {
          clothingId: filter.clothingId,
          userWalletId,
        },
        required: true,
        include: [{
          attributes: ['id', 'type', 'name', 'image', 'clothingId'],
          model: Clothing,
        }],
      });
    } else {
      chickenInclude.push({
        model: ChickenClothing.scope('includesClothing'),
      });
    }

    const chickenFilter = await getChickenFilter(filter);
    const chickenCriteria: Sequelize.WhereOptions = chickenFilter;
    const chickenIds = chickenFilter.id as number[];

    if (filter?.coopId) {
      const coopChickens = await CoopChicken.findAll({
        where: {
          chickenId: chickenIds,
          coopId: filter.coopId,
        },
        include: [{
          model: Coop,
          where: {
            userWalletId,
          },
        }],
      });

      const coopChickenIds = coopChickens.map((item) => item.chickenId);
      chickenCriteria.id = coopChickenIds;
    } else if (filter?.coopId === null) {
      const coopChickens = await CoopChicken.findAll({
        where: {
          chickenId: chickenIds,
        },
        include: [{
          model: Coop,
          where: {
            userWalletId,
          },
        }],
      });

      const coopChickenIds = coopChickens.map((item) => item.chickenId);
      const uncoopedChickenIds = chickenIds.filter((chickenId) => !coopChickenIds.includes(Number(chickenId)));
      chickenCriteria.id = uncoopedChickenIds;
    }

    if (filter?.coopIds?.length) {
      const coopIds: number[] = filter.coopIds.filter((coopId: number) => coopId);

      const coopChickens = await CoopChicken.findAll({
        where: {
          chickenId: chickenIds,
          coopId: coopIds,
        },
        include: [{
          model: Coop,
          where: {
            userWalletId,
          },
        }],
      });

      const coopChickenIds = coopChickens.map((item) => item.chickenId);
      chickenCriteria.id = coopChickenIds;

      if (filter.coopIds.includes(null)) {
        const otherCoopChickens = await CoopChicken.findAll({
          where: {
            chickenId: chickenIds,
          },
          include: [{
            model: Coop,
            where: {
              userWalletId,
            },
          }],
        });

        const otherCoopChickenIds = otherCoopChickens.map((item) => item.chickenId);
        const uncoopedChickenIds = chickenIds.filter((chickenId) => !otherCoopChickenIds.includes(Number(chickenId)));

        if (coopIds.length) {
          chickenCriteria.id = [
            ...chickenCriteria.id,
            ...uncoopedChickenIds,
          ];
        } else {
          chickenCriteria.id = uncoopedChickenIds;
        }
      }
    }

    if (filter.raceId) {
      race = await Race.findOne({
        where: {
          id: filter.raceId,
        },
        include: [{
          model: Lane,
          as: 'lanes',
          where: {
            chickenId: chickenIds,
          },
          required: false,
        }, {
          model: Terrain,
          attributes: ['name'],
        }],
      });

      if (!race) {
        throw new Error(`Race not found with the provided id - ${filter.raceId}`);
      }

      const enteredCount = race.lanes.length;
      const laneChickenIds = race.lanes.map((lane) => lane.chickenId);
      const maxChickensPerRace = race.fee > 0 ? config.MAX_CHICKENS_PER_PAID_RACE : config.MAX_CHICKENS_PER_FREE_RACE;

      if (process.env.NODE_ENV === 'production' && !race.unlimitPO && enteredCount >= maxChickensPerRace) {
        res.json({
          rows: [],
          count: 0,
          message: `You already have ${enteredCount} chicken${enteredCount > 1 ? 's' : ''} entered this race`,
        });

        return;
      }

      if (laneChickenIds.length) {
        chickenCriteria.id = chickenCriteria.id.filter((chickenId: string) => !laneChickenIds.includes(Number(chickenId)));
      }

      if (!race.unlimitPO) {
        if (race.peckingOrder === ChickenPeckingOrder.CHICK) {
          chickenCriteria.chickRaces = {
            [Op.lt]: config.CHICK_RACES_LIMIT,
          };
        } else {
          chickenCriteria.peckingOrder = race.peckingOrder;
        }
      }

      if (race.group === 10) {
        chickenCriteria.talent = OFFENSIVE_TALENTS;
      } else if (race.group === 11) {
        chickenCriteria.talent = SPEED_TALENTS;
      }

      if (filter.terrainMatch && race.terrain?.name) {
        chickenCriteria.terrainPreference = race.terrain.name;
      }

      if (filter.distanceMatch) {
        chickenCriteria.distancePreference = race.distancePreferences;
      }
    }

    const chickens = await Chicken.findAndCountAll({
      where: chickenCriteria,
      include: chickenInclude,
      offset: (page - 1) * limit || 0,
      limit,
      order: [order],
      distinct: true,
    });

    if (filter?.clothingId) {
      for (const chicken of chickens.rows) {
        await chicken.reload({
          include: [{
            model: TradeActivity,
            as: 'lastTradeActivity',
            attributes: ['id', 'price'],
            required: false,
          }, {
            model: MarketItem.scope(['defaultScope', 'active']),
            as: 'lastActiveMarketItem',
            required: false,
            attributes: ['id', 'price', 'tradeType'],
          }, {
            model: ChickenClothing.scope('includesClothing'),
          }],
        });
      }
    }

    if (page === 1 && chickens.count === 0 && race && !race?.unlimitPO) {
      const otherPeckingOrderChickens = await Chicken.findAll({
        attributes: ['peckingOrder'],
        where: _.omit(chickenCriteria, 'peckingOrder'),
        group: ['peckingOrder'],
      });

      const otherPeckingOrders = otherPeckingOrderChickens.map((chicken) => chicken.peckingOrder);

      (chickens as any).otherPeckingOrders = otherPeckingOrders;
    }

    res.json(chickens);
  } catch (err: any) {
    log.error({
      func: 'GET/chickens',
      query: req.query,
      err,
    }, 'Get Chickens Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/chickens/:chickenId/genealogy', authBasic, async (req, res) => {
  const chickenId = Number(req.params.chickenId);

  try {
    const chicken = await Chicken.findByPk(chickenId);
    if (!chicken) {
      throw new Error('Chicken not found');
    }

    const { familyPath } = chicken;
    const chickenIds = familyPath.split('.').filter(id => id);

    const allChickens = await Chicken.findAll({
      where: {
        id: chickenIds,
      },
      order: [['generation', 'ASC'], ['id', 'ASC']],
    });

    res.json(allChickens);
  } catch (err: any) {
    log.error({
      func: 'GET/chickens/:chickenId/genealogy',
      chickenId,
      err,
    }, 'Get Chicken Genealogy Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/chickens/:chickenId', authBasic, async (req, res) => {
  const chickenId = Number(req.params.chickenId);

  try {
    const chickenRecord = await Chicken.findByPk(chickenId, {
      include: [{
        model: MarketItem.scope(['defaultScope', 'active']),
        required: false,
        as: 'lastActiveMarketItem',
      }, {
        model: ChickenClothing.scope('includesClothing'),
      }],
    });

    if (!chickenRecord) {
      throw new Error('Chicken not found');
    }

    const userWalletId = await chickenService.getOwnerOfChicken(chickenId);
    const userWallet = userWalletId && await UserWallet.findByPk(userWalletId);
    const username = userWallet?.username || null;

    const chickenContractAddress = await getChickenContractAddress();
    const tradePreference = await TradePreference.findOne({
      where: {
        nftContract: chickenContractAddress,
        tokenId: chickenId,
      },
    });

    const isBlackListed = await isBlackListedToken(chickenContractAddress, chickenId);
    res.json({
      ...chickenRecord.toJSON(),
      username,
      userWalletId: userWallet?.id || userWalletId,
      tradePreference: tradePreference?.toJSON() || null,
      isBlackListed,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/chickens/:chickenId',
      chickenId,
      err,
    }, 'Get Chicken Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

// serve ChickenUri for opensea, super careful
router.get('/chickens/opensea/:chickenId', async (req, res) => {
  const { chickenId } = req.params;
  try {
    const chicken = await Chicken.findByPk(chickenId);
    if (!chicken) {
      throw new Error('Chicken not found');
    }

    const src = chicken.image || 'https://firebasestorage.googleapis.com/v0/b/storage-a1fa2.appspot.com/o/placeholder.jpg?alt=media';

    res.json({
      id: chicken.id,
      name: chicken.name,
      description: '',
      image_url: src,
      attributes: [{
        trait_type: 'Gender',
        value: chicken.gender,
      }, {
        trait_type: 'Heritage',
        value: chicken.heritage,
      }, {
        trait_type: 'Stock',
        value: chicken.stock,
      }, {
        trait_type: 'Talent',
        value: chicken.talent,
      }, {
        trait_type: 'baseBody',
        value: chicken.baseBody,
      }, {
        trait_type: 'Stripes',
        value: chicken.stripes,
      }, {
        trait_type: 'beakColor',
        value: chicken.beakColor,
      }, {
        trait_type: 'combColor',
        value: chicken.combColor,
      }, {
        trait_type: 'wattleColor',
        value: chicken.wattleColor,
      }, {
        trait_type: 'eyesType',
        value: chicken.eyesType,
      }, {
        trait_type: 'perfection',
        value: chicken.perfection,
      }, {
        trait_type: 'beakAccessory',
        value: chicken.beakAccessory,
      }, {
        trait_type: 'background',
        value: chicken.background,
      }],
    });
  } catch (err: any) {
    log.error({
      func: 'GET/chickens/opensea/:chickenId',
      chickenId,
      err,
    }, 'Get Chicken Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.patch('/chickens/:chickenId/name', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const chickenId = Number(req.params.chickenId);
  const { name } = req.body;
  const userWallet = req.user as UserWallet;
  const { id: userWalletId } = userWallet;

  try {
    log.info({
      func: 'PATCH/chickens/:chickenId/name',
      chickenId,
      userWalletId,
      name,
    }, 'Update Chicken Name');

    await checkDeployment();
    await checkBlackList(config.CHICKEN_CONTRACT.address, chickenId);
    await checkChickenStatus(chickenId, false);

    const updatedChicken = await updateChickenName({
      chickenId,
      userWalletId,
      name,
    });

    await updatedChicken.reload({
      include: [{
        model: MarketItem.scope(['defaultScope', 'active']),
        required: false,
        as: 'lastActiveMarketItem',
      }, {
        model: ChickenClothing.scope('includesClothing'),
      }],
    });

    const username = userWallet.username || null;

    const chickenContractAddress = await getChickenContractAddress();
    const tradePreference = await TradePreference.findOne({
      where: {
        nftContract: chickenContractAddress,
        tokenId: chickenId,
      },
    });

    const isBlackListed = await isBlackListedToken(chickenContractAddress, chickenId);
    res.json({
      ...updatedChicken.toJSON(),
      username,
      userWalletId,
      tradePreference: tradePreference?.toJSON() || null,
      isBlackListed,
    });
  } catch (err: any) {
    log.error({
      func: 'PATCH/chickens/:chickenId/name',
      chickenId,
      userWalletId,
      name,
      err,
    }, 'Update Chicken Name Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
