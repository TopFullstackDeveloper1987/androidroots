// Dependencies
import * as express from 'express';

// Middlewares
import { authBasic } from '../middleware/authBasic';

// Models
import { RoadMap } from '../sequelize/models/RoadMap';

// Services
import { log } from '../utils';

const router = express.Router();

router.get('/road-maps', authBasic, async (req: express.Request, res: express.Response) => {
  try {
    const roadMaps = await RoadMap.findAll({
      where: {
        isDisabled: false,
      },
      order: [['order', 'ASC']],
    });
    res.json(roadMaps);
  } catch (err: any) {
    log.error({
      func: 'GET/road-maps',
      err,
    }, 'Get Road Maps Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
