import * as express from 'express';
import * as moment from 'moment-timezone';
import { Op } from 'sequelize';

import { Race } from '../sequelize/models/Race';
import { Result } from '../sequelize/models/Result';
import { Terrain } from '../sequelize/models/Terrain';
import { Lane } from '../sequelize/models/Lane';
import { Chicken } from '../sequelize/models/Chicken';
import { UserWallet } from '../sequelize/models/UserWallet';
import { LaneClothing } from '../sequelize/models/LaneClothing';

import { log } from '../utils';
import { PIXELS_PER_METER } from '../utils/constants';
import { cache } from '../middleware/cache';

const router = express.Router();

router.get('/race-performances/:raceId', cache(), async (req, res) => {
  const { raceId } = req.params;
  try {
    const now = moment.utc();
    if (!raceId) {
      res.status(400).json({
        message: 'raceId is required',
      });
      return;
    }

    const raceModel = await Race.findOne({
      where: {
        id: raceId,
      },
      include: [{
        model: Terrain,
      }, {
        model: Lane,
        as: 'lanes',
        where: {
          chickenId: {
            [Op.not]: null,
          },
        },
        include: [{
          model: UserWallet,
          attributes: ['username'],
        }, {
          model: LaneClothing.scope('includesClothing'),
        }],
      }],
    });

    if (!raceModel) {
      res.status(400).json({
        message: 'Invalid raceId is provided',
      });
      return;
    }

    const resultModel = await Result.findOne({
      where: {
        raceId,
      },
      attributes: ['id', 'raceId', 'raceProfiles', 'commentaries', 'cutscenes', 'soundProfiles'],
    });
    if (!resultModel || moment.utc(raceModel.startsAt).isAfter(now)) {
      res.status(400).json({
        message: 'Race data is not ready',
      });
      return;
    }

    const { raceProfiles, cutscenes, soundProfiles, commentaries } = resultModel;

    const chickenIds = raceModel.lanes.map((lane) => lane.chickenId);
    const chickens = await Chicken.findAll({
      where: {
        id: chickenIds,
      },
    });
    const chickenResults = raceModel.lanes.sort((a, b) => a.position - b.position).map((lane, i) => {
      const chickenRecord = chickens.find((chicken) => chicken.id === lane.chickenId);

      return {
        info: {
          ...chickenRecord.toJSON(),
          raceEarnings: lane.raceEarnings,
          bonusBawk: lane.bonusBawk,
          username: lane.userWallet?.username || lane.userWalletId.toUpperCase().slice(2, 8),
          clothings: lane.laneClothings?.map((entry) => entry.clothing) || [],
        },
        segments: raceProfiles[i].segments,
        metas: raceProfiles[i].metas || [],
      };
    });

    const gameInfo = {
      chickens: chickenResults,
      raceStats: {
        ...raceModel.toJSON(),
        pixelsPerMeter: PIXELS_PER_METER,
      },
      commentaries,
      cutscenes,
      soundProfiles,
    };

    res.json(gameInfo);
  } catch (err: any) {
    log.error({
      func: 'GET/race-performances/:raceId',
      err,
    }, 'Performance Sample Data Error');

    res.status(500).json({
      message: err.message || err,
    });
  }
});

export = router;
