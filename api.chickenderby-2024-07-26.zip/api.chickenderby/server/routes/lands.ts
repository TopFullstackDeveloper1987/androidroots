import * as express from 'express';

import { authWallet } from '../middleware/authWallet';
import { authBasic } from '../middleware/authBasic';

import config from '../config';
import { Land } from '../sequelize/models/Land';
import { LandMint } from '../sequelize/models/LandMint';
import { UserWallet } from '../sequelize/models/UserWallet';

import { redisLock } from '../services/redisLock';
import { checkDeployment } from '../services/settingService';
import { getLandIdsForUserWalletId, getIsChickenOwnerSaleActive, getIsPublicSaleActive, getMintPaused } from '../services/contracts/landContractService';
import * as chickenService from '../services/contracts/chickenContractService';
import { log } from '../utils';
import { landMintSchema } from '../validation/validationSchemas';
import { mintLandWorker } from '../queues/raceQueues';

const router = express.Router();

const mintLandCheck = async (req: express.Request) => {
  const { id: userWalletId } = req.user as UserWallet;
  // check if deployment is in progress
  await checkDeployment();

  const { gasLimit, amount } = await landMintSchema.validateAsync(req.body);

  const isPaused = await getMintPaused();
  if (isPaused) {
    throw new Error('Sorry, mint land is currently on hold');
  }

  const isChickenOwnerSaleActive = await getIsChickenOwnerSaleActive();
  const isPublicSaleActive = await getIsPublicSaleActive();

  if (isChickenOwnerSaleActive) {
    const chickenIds = await chickenService.getChickenIdsForUserWalletId(userWalletId);

    if (!chickenIds.length) {
      throw new Error('Sorry, mint land is currently limited to chicken holders');
    }
  } else if (!isPublicSaleActive) {
    throw new Error('Sorry, mint land is currently on hold');
  }

  const numberOfPendingLandMints = await LandMint.count({
    where: {
      userWalletId,
      status: 'pending',
    },
  });
  if (numberOfPendingLandMints > 0) {
    throw new Error('You currently have a pending mint.');
  }

  if (gasLimit) {
    return { gasLimit };
  }

  return { gasLimit: config.BICONOMY_CUSTOM_GAS_LIMIT * amount };
};

router.get('/lands/mint/check', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const { gasLimit } = req.body;

  try {
    log.info({
      func: 'GET/lands/mint/check',
      userWalletId,
      gasLimit,
    }, 'Check Mint Start');

    const checkResult = await mintLandCheck(req);
    res.status(200).json(checkResult);
  } catch (err: any) {
    log.error({
      func: 'GET/lands/mint/check',
      userWalletId,
      gasLimit,
      err,
    }, 'Check Mint Start');

    res.status(400).json({ message: err.message });
  }
});

router.get('/lands/mint/last', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;

  try {
    const landMint = await LandMint.findOne({
      where: {
        userWalletId,
      },
      order: [
        ['id', 'DESC'],
      ],
    });

    res.status(200).json({ landMint });
  } catch (err: any) {
    log.error({
      func: 'GET/lands/mint/last',
      userWalletId,
      err,
    }, 'Get Last Land Mint Error');

    res.status(400).json({ message: err.message });
  }
});

router.post('/lands/mint', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const {
    amount, signature, deadline, gasLimit,
  } = req.body;

  try {
    log.info({
      func: 'POST/lands/mint',
      userWalletId,
      amount,
      signature,
      deadline,
      gasLimit,
    }, 'Mint lands start');

    // heroku TTL is 30 seconds per request
    const landMint = await redisLock([`${config.lock.mintLand}/${userWalletId}`], 30 * 1000, async () => {
      await mintLandCheck(req);

      return LandMint.create({
        userWalletId,
        amount,
        signature,
        data: {
          deadline,
          gasLimit,
        },
      });
    });

    mintLandWorker.add({
      landMintId: landMint.id,
    });

    log.info({
      func: 'POST/lands/mint',
      userWalletId,
      amount,
      signature,
      deadline,
      gasLimit,
      landMintId: landMint.id,
    }, 'Start Land Mint Success');

    res.status(200).json(true);
  } catch (err: any) {
    // TODO: refund the entry fee here
    log.error({
      func: 'POST/lands/mint',
      userWalletId,
      amount,
      signature,
      deadline,
      gasLimit,
      err,
    }, 'Mint Lane Failed');

    res.status(400).json({ message: err.message });
  }
});

router.get('/lands/me', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user as UserWallet;
  try {
    const landIds = await getLandIdsForUserWalletId(userWalletId);

    const lands = await Land.findAll({
      where: {
        id: landIds,
      },
    });

    res.status(200).json(lands);
  } catch (err: any) {
    log.error({
      func: 'GET/lands/me',
      userWalletId,
      err,
    }, 'Get My Lands Error');

    res.status(400).json({ message: err.message });
  }
});

// serve ChickenUri for opensea, super careful
router.get('/lands/opensea/:landId', async (req, res) => {
  const { landId } = req.params;
  try {
    const land = await Land.findByPk(landId);
    if (!land) {
      throw new Error('Land not found');
    }

    const src = land.image || 'https://firebasestorage.googleapis.com/v0/b/storage-a1fa2.appspot.com/o/placeholder.jpg?alt=media';

    res.json({
      id: land.id,
      name: `Land ${land.id}`,
      description: '',
      image_url: src,
      attributes: [{
        trait_type: 'Territory',
        value: land.territory,
      }, {
        trait_type: 'Borough',
        value: land.borough,
      }, {
        trait_type: 'Farming Plots',
        value: land.farmingPlots,
      }, {
        trait_type: 'Building',
        value: land.building,
      }, {
        trait_type: 'Feature',
        value: land.feature,
      }],
    });
  } catch (err: any) {
    log.error({
      func: 'GET/lands/opensea/:landId',
      landId,
      err,
    }, 'Get Land Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
