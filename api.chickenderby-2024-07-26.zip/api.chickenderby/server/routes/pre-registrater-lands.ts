import * as express from 'express';

import { log } from '../utils';
import { authWallet } from '../middleware/authWallet';
import { PreRegisterLandService } from '../services/pre-register-land.service';
import { createPreRegisterLandSchema, regexLandName, regexLandEmail } from '../validation/validationSchemas';
import { PreRegistration } from '../sequelize/models/PreRegistration';
import { isPreRegisterLandEnabled } from '../services/settingService';
import { getRecaptcaScore } from '../services/recaptchaService';

const router = express.Router();

const recaptchaCheck = async (grecaptcha: string) => {
  if (!grecaptcha) {
    return false;
  }

  try {
    const response = await getRecaptcaScore(grecaptcha);

    log.info({
      func: 'POST/pre-register-lands',
      grecaptcha,
      response,
    }, 'Recaptcha Check');

    // Check if the token is valid.
    if (!response.tokenProperties.valid) {
      return false;
    }
    // if (response.tokenProperties.action !== 'Enter') {
    //     return false
    // }

    if (response.riskAnalysis.score <= 0.2) { // High risk score
      return false;
    }

    return true;
  } catch (err) {
    log.error({
      func: 'POST/pre-register-lands',
      grecaptcha,
      err,
    }, 'Recaptcha Check Error');

    return false;
  }
};


router.post('/pre-register-lands', authWallet, async (req, res) => {
  try {
    const userWalletId = req.user.id as string;

    const isEnabled = await isPreRegisterLandEnabled();
    if (!isEnabled) {
      throw new Error('Pre-register land is disabled');
    }

    log.info({
      func: 'POST/pre-register-lands',
      userWalletId,
      ...req.body,
    }, 'Create Pre-Register Land Start');

    const schemaResult = await createPreRegisterLandSchema.validateAsync(req.body);

    const isValid = await recaptchaCheck(req.body.grecaptcha);
    if (!isValid) {
      throw new Error('Connection error. Please refresh your browser and try again.');
    }

    const preRegistration = await PreRegisterLandService.getInstance().createOne(userWalletId, schemaResult);

    res.json(preRegistration);
  } catch (err: any) {
    log.error({
      func: 'POST/pre-register-lands',
      err,
    }, 'Create Pre-Register Land Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.post('/pre-register-lands/validate-name', async (req, res) => {
  const { name } = req.body;

  try {
    if (!regexLandName.test(name)) {
      throw new Error('Invalid plot name');
    }

    const preRegistrationWithName = await PreRegistration.findOne({
      where: {
        name,
      },
    });
    if (preRegistrationWithName) {
      throw new Error('Plot name already exists');
    }

    res.json({
      name,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/pre-register-lands/validate-name',
      name,
      err,
    }, 'Pre-Register Land Validate Name Error');

    res.status(400).json({
      name,
      message: err.message,
    });
  }
});

router.post('/pre-register-lands/validate-email', async (req, res) => {
  const { email } = req.body;

  try {
    if (!regexLandEmail.test(email)) {
      throw new Error('Invalid email');
    }

    const preRegistrationWithEmail = await PreRegistration.findOne({
      where: {
        email,
      },
    });
    if (preRegistrationWithEmail) {
      throw new Error('Email already exists');
    }

    res.json({
      email,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/pre-register-lands/validate-email',
      email,
      err,
    }, 'Pre-Register Land Validate Email Error');

    res.status(400).json({
      email,
      message: err.message,
    });
  }
});

router.get('/pre-register-lands/stats', async (req, res) => {
  try {
    const totalCount = await PreRegisterLandService.getInstance().getTotalCount();

    res.json({
      totalCount,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/pre-register-lands/stats',
      err,
    }, 'Get Pre-Register Land Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
