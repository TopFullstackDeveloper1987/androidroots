// Dependencies
import * as express from 'express';
import config from '../config';

// Middleware
import { authBasic } from '../middleware/authBasic';
import { authWallet } from '../middleware/authWallet';

// Models
import { Serum } from '../sequelize/models/Serum';
import { SerumMint } from '../sequelize/models/SerumMint';

// Services
import { SerumMintService } from '../services/fusions/serumMintService';
import { redisLock } from '../services/redisLock';

// Utils
import { log } from '../utils';
import { serumMintWorker } from '../queues/fusionQueues';

const router = express.Router();

// serve TokenUri for opensea, super careful
router.get('/serums/opensea/:serumId', async (req, res) => {
  const { serumId } = req.params;

  try {
    const serum = serumId && await Serum.findByPk(serumId);
    if (!serum) {
      throw new Error('Serum not found');
    }

    res.json({
      id: serum.id,
      name: serum.name,
      description: '',
      image_url: serum.image,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/serums/opensea/:serumId',
      serumId,
      err,
    }, 'Get Serum Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.post('/serums/mint/check', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const { serumId, amount } = req.body;

  try {
    // returns a gasLimit
    const { gasLimit } = await redisLock(
      `${config.lock.fusionMint}/${userWalletId}`,
      30 * 1000,
      async () => SerumMint.sequelize.transaction(async (t) => SerumMintService.checkSerumMint(req, t)),
    );

    res.json({
      gasLimit,
    });
  } catch (err: any) {
    log.error({
      func: 'POST/serums/mint/check',
      userWalletId,
      serumId,
      amount,
      err,
    }, 'Serum Mint Check Failed');

    res.status(400).json({ message: err.message });
  }
});

router.post('/serums/mint', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;
  const {
    serumId, amount, signature, deadline, gasLimit,
  } = req.body;

  try {
    // returns a serum mint record
    const serumMint = await redisLock(
      `${config.lock.fusionMint}/${userWalletId}`,
      30 * 1000,
      async () => SerumMint.sequelize.transaction(async (t) => SerumMintService.createSerumMint(req, t)),
    );

    serumMintWorker.add({
      serumMintId: serumMint.id,
    });

    log.info({
      func: 'POST/serums/mint',
      userWalletId,
      serumId,
      amount,
      signature,
      deadline,
      gasLimit,
      serumMintId: serumMint.id,
    }, 'Created Serum Mint Success');

    res.status(200).json({ serumMint });
  } catch (err: any) {
    log.error({
      func: 'POST/serums/mint',
      userWalletId,
      serumId,
      amount,
      signature,
      deadline,
      gasLimit,
      err,
    }, 'Serum Mint Failed');

    res.status(400).json({ message: err.message });
  }
});

router.get('/serums/mint/last', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const { id: userWalletId } = req.user;

  try {
    const serumMint = await SerumMint.findOne({
      where: {
        userWalletId,
      },
      order: [
        ['id', 'DESC'],
      ],
    });

    res.status(200).json({ serumMint });
  } catch (err: any) {
    log.error({
      func: 'GET/serums/mint/last',
      userWalletId,
      err,
    }, 'Get Last Serum Mint Error');

    res.status(400).json({ message: err.message });
  }
});

export = router;
