import * as express from 'express';
import { Setting } from '../sequelize/models/Setting';
import { isCoinPresaleEnabled, isDeploying } from '../services/settingService';
import { auth, authAdmin } from '../middleware/auth';
import { log } from '../utils';

const router = express.Router();

router.post('/settings', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  const { name, value, message } = req.body;

  try {
    const settingRecord = await Setting.create({
      name,
      value,
      message,
    });

    res.json(settingRecord);
  } catch (err: any) {
    log.error({
      func: 'POST/settings',
      err,
    }, 'Add Settings Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/settings', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  try {
    const settings = await Setting.findAll();
    res.json(settings);
  } catch (err: any) {
    log.error({
      func: 'GET/settings',
      err,
    }, 'Get All Settings Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/settings/is-deploying', async (req, res) => {
  try {
    const isDeployingSetting = await isDeploying();

    res.json({
      isDeploying: isDeployingSetting,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/settings/is-deploying',
      err,
    }, 'Is Deploying Setting Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/settings/coin-presale-enabled', async (req, res) => {
  try {
    const isEnabled = await isCoinPresaleEnabled();

    res.json({
      isEnabled,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/settings/coin-presale-enabled',
      err,
    }, 'Coin Pre-Sale Enabled Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.get('/settings/:settingId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  try {
    const settingRecord = await Setting.findByPk(req.params.settingId);
    res.json(settingRecord);
  } catch (err: any) {
    log.error({
      func: 'GET/settings/:settingId',
      err,
    }, 'Get Setting Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.patch('/settings/:settingId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  try {
    const { settingId } = req.params;
    const {
      name,
      value,
      message,
    } = req.body;

    const settingModel = await Setting.findByPk(settingId);

    if (!settingModel) {
      res.status(400).json({
        message: 'Setting not found',
      });
      return;
    }

    settingModel.name = name;
    settingModel.value = value;
    settingModel.message = message;

    await settingModel.save();

    res.json(settingModel);
  } catch (err: any) {
    log.error({
      func: 'PATCH/settings/:settingId',
      err,
    }, 'Update Setting Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

router.delete('/settings/:settingId', [auth, authAdmin], async (req: express.Request, res: express.Response) => {
  try {
    const settingRecord = await Setting.findByPk(req.params.settingId);
    if (!settingRecord) {
      res.status(400).json({
        message: 'Setting not found',
      });
      return;
    }

    await settingRecord.destroy();

    res.json({
      message: 'Deleted successfully.',
    });
  } catch (err: any) {
    log.error({
      func: 'DELETE/settings/:settingId',
      err,
    }, 'Delete Setting Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
