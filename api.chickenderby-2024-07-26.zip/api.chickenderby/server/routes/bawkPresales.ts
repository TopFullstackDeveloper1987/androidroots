// Config
import config from '../config';

// Dependencies
import * as express from 'express';
import moment from 'moment-timezone';

// Middlewares
import { authWallet } from '../middleware/authWallet';
import { authBasic } from '../middleware/authBasic';


// Models
import { UserWallet } from '../sequelize/models/UserWallet';
import { GoldenTicket } from '../sequelize/models/GoldenTicket';
import { BawkPresaleInviteCode } from '../sequelize/models/BawkPresaleInviteCode';
import { BawkPresale } from '../sequelize/models/BawkPresale';

// Utils
import { log } from '../utils';

// Services
import { generateRefundSignature, getBawkPresalePeriodDate, getBawkPresaleRefundPeriodDate, getBawkPresaleUserData } from '../services/contracts/bawkPresaleContractService';
import { getChickenIdsForUserWalletId } from '../services/contracts/chickenContractService';
import { redisLock } from '../services/redisLock';

const router = express.Router();

router.get('/bawk-presales/me', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const userWalletModel = req.user as UserWallet;

  try {
    const chickens = await getChickenIdsForUserWalletId(userWalletModel.id);
    const userData = await getBawkPresaleUserData(userWalletModel.id);
    const goldenTicket = await GoldenTicket.findOne({
      where: {
        userWalletId: userWalletModel.id,
      },
    });

    const bawkPresale = await BawkPresale.findOne({
      where: {
        userWalletId: userWalletModel.id,
      },
    });

    const codes = await BawkPresaleInviteCode.getInviteCodes(
      userWalletModel.id,
      chickens.length > 0,
      goldenTicket?.amount > 0 && goldenTicket?.isOriginal,
    );

    res.status(200).json({
      ...userData,
      chickens: bawkPresale?.chickens || chickens.length,
      goldenTickets: bawkPresale?.goldenTickets || goldenTicket?.amount || 0,
      won: bawkPresale?.rafflesSyncedAt ? bawkPresale.won : 'TBA',
      lost: bawkPresale?.rafflesSyncedAt ? bawkPresale.lost : 'TBA',
      codes,
    });
  } catch (err: any) {
    log.error(
      {
        func: 'GET/bawk-presales/status',
        userWalletId: userWalletModel?.id,
        err,
      },
      'Get Bawk Presale status',
    );

    res.status(400).json({
      message: err.message,
    });
  }
},
);

router.get('/bawk-presales/refund', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const userWalletModel = req.user as UserWallet;

  try {
    const bawkPresale = await BawkPresale.findOne({
      where: {
        userWalletId: userWalletModel.id,
      },
    });

    const won = bawkPresale?.won || 0;
    const lost = bawkPresale?.lost || 0;

    if (!lost) {
      throw new Error('You don\'t have any lost lots for a refund.');
    }

    const {
      refundStartAt,
      refundEndAt,
    } = await getBawkPresaleRefundPeriodDate();

    const now = moment.utc();

    if (!refundStartAt) {
      throw new Error('BAWK presale refund is not available at the moment.');
    }

    if (now.isBefore(refundStartAt)) {
      throw new Error('BAWK presale refund will begin shortly. Please stay tuned.');
    }

    if (now.isAfter(refundEndAt)) {
      throw new Error('Sorry, you\'re late. The BAWK presale refund has already ended.');
    }

    const { sales, refunds } = await getBawkPresaleUserData(userWalletModel.id);

    if (!sales) {
      throw new Error('You didn\'t purchase any lots.');
    }

    if (refunds) {
      throw new Error(`We have already refunded the ${refunds} lots you lost.`);
    }

    const signature = await generateRefundSignature(userWalletModel.id, won);

    res.status(200).json({
      won,
      lost,
      signature,
    });
  } catch (err: any) {
    log.error(
      {
        func: 'GET/bawk-presales/refund',
        userWalletId: userWalletModel?.id,
        err,
      },
      'Get Bawk Presale status',
    );

    res.status(400).json({
      message: err.message,
    });
  }
},
);

router.get('/bawk-presales/dates', [authBasic], async (req: express.Request, res: express.Response) => {
  try {
    const {
      presaleStartAt,
      presaleEndAt,
    } = await getBawkPresalePeriodDate();

    const {
      refundStartAt,
      refundEndAt,
    } = await getBawkPresaleRefundPeriodDate();

    const now = moment.utc();

    res.status(200).json({
      presaleStartsInSeconds: presaleStartAt ? presaleStartAt.diff(now, 'seconds') : null,
      presaleEndsInSeconds: presaleEndAt ? presaleEndAt.diff(now, 'seconds') : null,
      presaleRefundStartsInSeconds: refundStartAt ? refundStartAt.diff(now, 'seconds') : null,
      presaleRefundEndsInSeconds: refundEndAt ? refundEndAt.diff(now, 'seconds') : null,
    });
  } catch (err: any) {
    log.error(
      {
        func: 'GET/bawk-presales/dates',
        err,
      },
      'Get Bawk Presale Dates',
    );

    res.status(400).json({
      message: err.message,
    });
  }
},
);

router.post('/bawk-presales/claim-invite-code', [authBasic, authWallet], async (req: express.Request, res: express.Response) => {
  const userWalletModel = req.user as UserWallet;
  const inviteCode = req.body.inviteCode;

  try {
    if (!inviteCode) {
      throw new Error('Required invite code');
    }

    await redisLock(
      `${config.lock.claimBawkPresaleInviteCode}/${inviteCode}`,
      30 * 1000,
      async () => {
        const bawkPresaleInviteCode = await BawkPresaleInviteCode.findByPk(inviteCode);

        if (!bawkPresaleInviteCode) {
          throw new Error(`Invalid invite code: ${inviteCode}`);
        }

        if (bawkPresaleInviteCode.claimedUserWalletId) {
          throw new Error(`Already claimed invite code: ${inviteCode}`);
        }

        if (bawkPresaleInviteCode.userWalletId === userWalletModel.id) {
          throw new Error('Can not claim self-invitation code.');
        }

        await bawkPresaleInviteCode.sequelize.transaction(async (t) => {
          const goldenTicket = await GoldenTicket.findOne({
            where: {
              userWalletId: userWalletModel.id,
            },
            transaction: t,
          });

          await bawkPresaleInviteCode.update({
            claimedUserWalletId: userWalletModel.id,
          }, { transaction: t });

          if (goldenTicket) {
            await goldenTicket.increment('amount', { transaction: t });
          } else {
            await GoldenTicket.create({
              userWalletId: userWalletModel.id,
              amount: 1,
            }, { transaction: t });
          }
        });
      },
    );

    res.status(200).json({
      success: true,
    });
  } catch (err: any) {
    log.error(
      {
        func: 'POST/bawk-presales/claim-invite-code',
        err,
        inviteCode,
        userWalletId: userWalletModel.id,
      },
      'Claim Bawk Presale invite codes',
    );

    res.status(400).json({
      message: err.message,
    });
  }
},
);

export = router;
