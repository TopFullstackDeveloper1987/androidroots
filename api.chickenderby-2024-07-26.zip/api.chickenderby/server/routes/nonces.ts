import * as express from 'express';

import { log } from '../utils';
import { findOrCreateNonce } from '../services/nonceService';
import { UserWallet } from '../sequelize/models/UserWallet';
import { authBasic } from '../middleware/authBasic';

const router = express.Router();

router.get('/nonces/:userWalletId', authBasic, async (req, res) => {
  const { userWalletId } = req.params;

  try {
    const nonceRecord = await findOrCreateNonce(userWalletId);
    const userWalletRecord = await UserWallet.findByPk(userWalletId);

    res.json({
      ...nonceRecord.toJSON(),
      isRegister: !userWalletRecord,
    });
  } catch (err: any) {
    log.error({
      func: 'GET/nonces/:userWalletId',
      err,
    }, 'Get Nonce Error');

    res.status(400).json({
      message: err.message,
    });
  }
});

export = router;
