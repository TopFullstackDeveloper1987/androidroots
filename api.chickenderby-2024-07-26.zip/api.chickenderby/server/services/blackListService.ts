// Services
import { getContractType } from './contracts/web3Service';
import { getOwnersForToken } from './contracts/alchemyService';

// Models
import { BlackList } from '../sequelize/models/BlackList';

export const serializeBlackList = async (blackList: BlackList) => {
  const { nftContract, tokenId } = blackList;

  const contractType = await getContractType(nftContract);
  const ownerUserWalletIds = await getOwnersForToken(nftContract, tokenId);

  return {
    ...blackList.toJSON(),
    contractType,
    ownerUserWalletIds,
  };
};

export const isBlackListedToken = async (nftContract: string, tokenId: number) => {
  const blackList = await BlackList.scope('active').findOne({
    attributes: ['id'],
    where: {
      nftContract,
      tokenId,
    },
  });

  return !!blackList;
};

export const checkBlackList = async (nftContract: string, tokenId: number) => {
  const isBlackListed = await isBlackListedToken(nftContract, tokenId);
  if (isBlackListed) {
    throw new Error('This chicken is blocked from use. Please contact our admins via discord.');
  }
};
