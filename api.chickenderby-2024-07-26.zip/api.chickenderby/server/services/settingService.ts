// Dependencies
import NP from 'number-precision';
import Sequelize from 'sequelize';
const { Op } = Sequelize;

// Config
import config from '../config';

// Models
import { Setting } from '../sequelize/models/Setting';
import { UserWallet } from '../sequelize/models/UserWallet';

// Types
import { ChickenPeckingOrder } from '../types/chickens/chickenPeckingOrder';

export const isBetaUsersOnly = async () => {
  const betaUsersOnlySetting = await Setting.findOne({ where: { name: 'beta_users_only', value: 'true' } });
  return Boolean(betaUsersOnlySetting);
};

export const isBetaUser = async (userWalletId: string) => {
  const betaUser = await UserWallet.findOne({
    where: {
      id: userWalletId,
      betaUserAt: {
        [Op.not]: null,
      },
    },
  });

  return Boolean(betaUser);
};

export const checkBetaUserOnly = async (userWalletId: string, message: string = 'Sorry, this feature is currently limited to beta users.', forceBetaUser = false) => {
  const isBetaUsersOnlySetting = forceBetaUser || await isBetaUsersOnly();
  if (!isBetaUsersOnlySetting) {
    return;
  }

  const isBetaUserOk = await isBetaUser(userWalletId);
  if (!isBetaUserOk) {
    throw new Error(message);
  }
};

export const isAutoRaceGenerationEnabled = async () => {
  const autoRaceGenerationSetting = await Setting.findOne({ where: { name: 'automatic_race_generation', value: 'true' } });
  return Boolean(autoRaceGenerationSetting);
};

export const getChickenSituationResetMinutes = async () => {
  const chickenSituationResetMinutes = await Setting.findOne({
    where: {
      name: 'chicken_situation_reset_minutes',
    },
  });

  return chickenSituationResetMinutes ? Number(chickenSituationResetMinutes?.value) : 0;
};

export const isDeploying = async () => Setting.findOne({ where: { name: 'is_deploying', value: 'true' } });

export const checkDeployment = async () => {
  const isDeployingSetting = await isDeploying();
  if (isDeployingSetting) {
    throw new Error(isDeployingSetting.message || 'Update in progress. Race entries, naming, and marketplace transactions are currently on hold.');
  }
};

export const getFreeRaceCounterLimit = async () => {
  const freeRaceCounterLimitSetting = await Setting.findOne({
    where: {
      name: 'freeRaceCounterLimit',
    },
  });

  return Number(freeRaceCounterLimitSetting?.value) || config.DEFAULT_FREE_RACE_COUNTER_LIMIT;
};

export const getFreeRaceCounter = async (peckingOrder: ChickenPeckingOrder) => {
  const freeRaceCounterName = `freeRaceCounter${peckingOrder}`;

  const freeRaceCounter = await Setting.findOne({
    where: {
      name: freeRaceCounterName,
    },
  });

  return Number(freeRaceCounter?.value) || 0;
};

export const updateFreeRaceCounter = async (peckingOrder: ChickenPeckingOrder, value: number, transaction: Sequelize.Transaction) => {
  const freeRaceCounterName = `freeRaceCounter${peckingOrder}`;

  const freeRaceCounter = await Setting.findOne({
    where: {
      name: freeRaceCounterName,
    },
  });

  if (freeRaceCounter) {
    await freeRaceCounter.update({
      value: String(NP.strip(value)),
    }, { transaction });
  }
};

export const isMarketplaceSyncEnabled = async () => Setting.findOne({ where: { name: 'marketplace-sync', value: 'true' } });
export const isRaceSyncEnabled = async () => Setting.findOne({ where: { name: 'race-sync', value: 'true' } });
export const isFusionSyncEnabled = async () => Setting.findOne({ where: { name: 'fusion-sync', value: 'true' } });
export const isCoinPresaleEnabled = async () => Setting.findOne({ where: { name: 'coin-pre-sale', value: 'true' } });
export const isPreRegisterLandEnabled = async () => Setting.findOne({ where: { name: 'pre-register-land', value: 'true' } });
export const isEnabledCommentary = async () => {
  const isEnabledCommentaryString = await Setting.findOne({ where: { name: 'is-enable-commentary', value: 'true' } });
  return Boolean(isEnabledCommentaryString);
};
export const isTrainingPartnerEnabled = async () => Setting.findOne({ where: { name: 'training-partner', value: 'true' } });
export const getRaceTimerDurationMinutes = async () => {
  const setting = await Setting.findOne({
    where: {
      name: 'race-time-duration-minutes',
    },
  });

  return setting ? Number(setting.value) : null;
};
export const isChickenStakingEnabled = async () => Setting.findOne({ where: { name: 'chicken-staking-enabled', value: 'true' } });
