import * as moment from 'moment-timezone';
import Sequelize from 'sequelize';
const { Op } = Sequelize;
import Web3 from 'web3';
import * as _ from 'lodash';
import NP from 'number-precision';
import { Job } from 'bull';

import config from '../config';

import { Race } from '../sequelize/models/Race';
import { Result } from '../sequelize/models/Result';
import { Terrain } from '../sequelize/models/Terrain';
import { RaceHistory } from '../sequelize/models/RaceHistory';
import { Transaction } from '../sequelize/models/Transaction';
import { UserWallet } from '../sequelize/models/UserWallet';
import { RaceAssignment } from '../sequelize/models/RaceAssignment';
import { AutoRacePool } from '../sequelize/models/AutoRacePool';
import { Lane } from '../sequelize/models/Lane';
import { Chicken } from '../sequelize/models/Chicken';
import { ChickenClothing } from '../sequelize/models/ChickenClothing';
import { LaneClothing } from '../sequelize/models/LaneClothing';
import { User } from '../sequelize/models/User';

import { convertCoinToJewel } from './exchangeService';
import { sleep } from '../utils';
import { waitUntilBiconomyReady, getSuccessfulTransactionHashAndReceipt } from './contracts/web3Service';
import {
  payout,
  enter,
  enterWithAdmin,
  getRaceContractRaceInfo,
  getRaceContractChickenIds,
  getRaceContractPrizePercent,
  getRaceContractAddress,
} from './contracts/raceContractService';
import { redisLock } from './redisLock';
import { postToSlack } from './slackService';
import { sendNotification } from './firebaseService';
import {
  isAutoRaceGenerationEnabled,
  isDeploying,
  isEnabledCommentary,
  isTrainingPartnerEnabled,
  getRaceTimerDurationMinutes,
  getChickenSituationResetMinutes,
} from './settingService';

import { redisConnect, redisGetAsync } from './redisClient';
import { log } from '../utils';
import { getChickensForTalent, getTalentPerformance, applyTalents, transformStartSpeedAndEndSpeed, resolveTalentMetas } from './talentService';
import { bestScoresTournamentService } from './tournaments/bestScoresTournament';

// Types
import { RaceStatus } from '../types/races/raceStatus';
import { RaceType } from '../types/races/raceType';

import { RaceAssignmentType } from '../types/races/raceAssignmentType';
import { AssignmentStatus } from '../types/assignments/assignmentStatus';

import { TransactionPaidStatus } from '../types/transactions/transactionPaidStatus';
import { TransactionType } from '../types/transactions/transactionType';
import { TransactionCategory } from '../types/transactions/transactionCategory';

import { ChickenSituation } from '../types/chickens/chickenSituation';
import { ChickenGender } from '../types/chickens/chickenGender';
import { ChickenHeritage } from '../types/chickens/chickenHeritage';
import { ChickenStock } from '../types/chickens/chickenStock';
import { ChickenPeckingOrder } from '../types/chickens/chickenPeckingOrder';
import { ChickenBeakAccessory } from '../types/chickens/chickenBeakAccessory';
import { ChickenLegs } from '../types/chickens/chickenLegs';
import { ChickenBaseBody } from '../types/chickens/chickenBaseBody';

import { TerrainName } from '../types/terrains/terrainName';
import { Segment } from '../types/races/segment';
import { MasterSegment } from '../types/races/masterSegment';
import { PositionType } from '../types/races/positionType';

import PrizePoolError from '../errors/prizePoolError';
import { CommentaryService } from './commentaryService';
import { performRaceWorker } from '../queues/raceQueues';
import { BAWK_STAKING_CONTRACT } from '../abi/bawkStakingContract';

const getPrizePercentages = (maxCapacity: number) => {
  // https://docs.google.com/document/d/1Vjt71trjsdd7YAuZa_SbnDLXRs3rWStzr2p_qzeCwcU/edit
  if (maxCapacity >= 12) {
    return [
      50,
      25,
      12,
      8,
      5,
    ];
  }

  if (maxCapacity >= 7) {
    return [
      50,
      25,
      13,
      12,
    ];
  }

  return [
    55,
    30,
    15,
  ];
};

export const getPrizes = (race: Race) => {
  const prizePercentages = getPrizePercentages(race.currentCapacity);
  return prizePercentages.map((percentage) => NP.strip(NP.divide(NP.times(race.prizePool, percentage), 100)));
};

// TODO: move the performance logic to performanceService b/c raceService is getting bigger
// https://docs.google.com/document/d/1cRkW2UdUiAgkoRBcPplmTKDC4tVxjRVJ44jpVCGqz1M/edit#heading=h.in4t8a1j4l9n
export const performRace = async (job: Job) => {
  const { raceId } = job.data;

  // generate race report
  try {
    await job.progress(0);
    const raceModel = await Race.findOne({
      where: {
        id: raceId,
      },
      include: [{
        model: Terrain,
        attributes: ['name', 'image'],
      }, {
        model: Lane,
        include: [Chicken],
        as: 'lanes',
      }],
    });

    const resultModel = await Result.findOne({ where: { raceId } });
    if (resultModel) {
      return;
    }

    const initialPerformances: {
      chickenId: number,
      initialPerformance: number
    }[] = [];

    const chickenIds = raceModel.lanes.map((laneModel) => laneModel.chickenId).filter((chickenId) => Boolean(chickenId));

    const chickenList = await Chicken.unscoped().findAll({
      where: {
        id: chickenIds,
      },
    });

    const feeJEWEL = await convertCoinToJewel(raceModel.coinType, raceModel.fee);
    const prizePoolJEWEL = await convertCoinToJewel(raceModel.coinType, raceModel.prizePool);

    const gameInfo: {
      chickens: {
        id: number;
        bonusBawk: boolean;
        raceEarnings?: number;
      }[];
    } = {
      chickens: [],
    };
    const raceChickens: Partial<Chicken>[] = [];

    // for Gender Bonus if 2 or fewer Rosters or hens then initialPerformance + 2
    const henFound = chickenList.filter((chicken) => chicken.gender === ChickenGender.Hen).length <= 2;
    const roosterFound = chickenList.filter((chicken) => chicken.gender === ChickenGender.Rooster).length <= 2;

    for (const chicken of chickenList) {
      const bonusBawk = (henFound && chicken.gender === ChickenGender.Hen) || (roosterFound && chicken.gender === ChickenGender.Rooster);

      gameInfo.chickens.push({
        id: chicken.id,
        bonusBawk,
      });

      raceChickens.push(chicken.toJSON());
    }

    // seting up backend calculation data from initial point
    const terrainCircle = [
      TerrainName.Grass,
      TerrainName.Snow,
      TerrainName.Sand,
      TerrainName.Track,
      TerrainName.Road,
      TerrainName.Rock,
      TerrainName.Dirt,
    ];
    const terrainValueMultiplierList = [10, 8, 4, 0];
    const terrainType = raceModel.terrain.name;

    const chickensForTalent = getChickensForTalent(raceModel, raceChickens);

    const heritageValues = {
      [ChickenHeritage.Serama]: 12,
      [ChickenHeritage.Sultan]: 10,
      [ChickenHeritage.Lakenvelder]: 8,
      [ChickenHeritage.Dorking]: 6,
    };

    const stockValues = {
      [ChickenStock.Spicy]: 5.00,
      [ChickenStock.Boss]: 4.50,
      [ChickenStock.Robust]: 4.50,
      [ChickenStock.Fresh]: 3.85,
      [ChickenStock.Crisp]: 3.05,
      [ChickenStock.Tender]: 2.10,
      [ChickenStock.Bland]: 1.00,
    };

    raceChickens.forEach((chicken) => {
      // for heritage
      const heritageValue = heritageValues[chicken.heritage] || 0;

      // for perfection
      const maximumPerfection = 101;
      const power = -0.10;
      const multiplier = 40;
      const perfectionValue = (maximumPerfection - chicken.perfection) ** power * multiplier;

      // for stock
      const stockValue = stockValues[chicken.stock] || 0;

      // for terrain
      const x1 = terrainCircle.indexOf(terrainType); // x1 = 6 (Dirt)
      const y1 = x1 + terrainCircle.length; // y1 = 13 (Dirt)

      const x2 = terrainCircle.indexOf(chicken.terrainPreference as TerrainName); // x2 = 0 (Grass)
      const y2 = x2 + terrainCircle.length; // y2 = 0 + 7 = 7 (Grass)

      let diff = 0;
      if (x1 > x2) {
        diff = Math.min(x1 - x2, y2 - x1);
      } else {
        diff = Math.min(x2 - x1, y1 - x2);
      }
      const terrainValue = terrainValueMultiplierList[diff] * chicken.terrainPreferenceStrength;
      const isTerrainPreferenceMatch = terrainType === chicken.terrainPreference;

      // for distance
      const isDistancePreferenceMatch = raceModel.distancePreferences.includes(chicken.distancePreference);
      const distanceBonus = 6;
      const distanceValue = isDistancePreferenceMatch ? distanceBonus * chicken.distancePreferenceStrength : 0;

      // for beakAccessory
      const toothPickBonus = (chicken.beakAccessory === ChickenBeakAccessory.Toothpick && isTerrainPreferenceMatch && isDistancePreferenceMatch) ? 2 : 0;

      // for legs
      let legsRaceDistanceBuff = 0;
      if (
        chicken.legs === ChickenLegs.Blades && [100, 120].includes(raceModel.distance) ||
        chicken.legs === ChickenLegs.Hooves && [140, 160].includes(raceModel.distance) ||
        chicken.legs === ChickenLegs.Gingerbread && [180, 200].includes(raceModel.distance) ||
        [ChickenLegs.legsBlackHen, ChickenLegs.legsBlackRooster].includes(chicken.legs) && isDistancePreferenceMatch
      ) {
        legsRaceDistanceBuff = chicken.baseBody === ChickenBaseBody.Black ? 2.0 : 1.0;
      }

      // for consistency
      const min = chicken.beakAccessory === ChickenBeakAccessory.Rose ? 0.3 : 0;
      const max = 1;
      const sign = Math.random() < 0.5 ? 1 : -1;
      const r = (Math.random() * (max - min) + min) * sign;
      const consistencyValue = r * chicken.consistency;

      const chickenIndex = gameInfo.chickens.findIndex((chicken) => chicken.id === chicken.id);
      if (chickenIndex > -1 && r >= 0.97) {
        gameInfo.chickens[chickenIndex].bonusBawk = true;
      }

      // for Stripe if yes then initialPerformance + 1
      const stripeBonus = chicken.stripes ? 1 : 0;

      // for Gender Bonus if 2 or fewer Rosters or hens then initialPerformance + 2
      const genderBonus = ((henFound && chicken.gender === ChickenGender.Hen) || (roosterFound && chicken.gender === ChickenGender.Rooster)) ? 2 : 0;

      // for talent
      const talentPerformance = getTalentPerformance(raceModel, chicken, chickensForTalent);

      // To convert the stats into their relevant values
      const initialPerformance = heritageValue + perfectionValue + stockValue + terrainValue
        + distanceValue + consistencyValue + stripeBonus + genderBonus + talentPerformance + toothPickBonus + legsRaceDistanceBuff;
      initialPerformances.push({ chickenId: chicken.id, initialPerformance });
    });

    const sorted = initialPerformances.sort((a, b) => b.initialPerformance - a.initialPerformance);

    log.info({
      func: 'performRace',
      raceId,
      initialPerformances: sorted,
    }, `After Calculating Initial Performance For Race ${raceId}`);
    /// //////////////////////////////////////////////////////Performance Ends Here////////////////////////////////////////////////////////////

    // for setting up the variables for raceProfile
    // distance time
    const distanceTimes = {
      100: 60,
      120: 71,
      140: 82,
      160: 93,
      180: 104,
      200: 115,
    };

    // terrain time
    const terrainTimes = {
      [TerrainName.Dirt]: -1,
      [TerrainName.Grass]: -2,
      [TerrainName.Road]: -4,
      [TerrainName.Rock]: 3,
      [TerrainName.Sand]: 4,
      [TerrainName.Snow]: 4,
      [TerrainName.Track]: -4,
    };

    // pecking order time
    const peckingOrderTimes = {
      [ChickenPeckingOrder.X]: -4,
      [ChickenPeckingOrder.SSSp]: -4,
      [ChickenPeckingOrder.SSS]: -4,
      [ChickenPeckingOrder.SSp]: -4,
      [ChickenPeckingOrder.SS]: -4,
      [ChickenPeckingOrder.Sp]: -4,
      [ChickenPeckingOrder.S]: -4,
      [ChickenPeckingOrder.Ap]: -2,
      [ChickenPeckingOrder.A]: -2,
      [ChickenPeckingOrder.Bp]: 0,
      [ChickenPeckingOrder.B]: 0,
      [ChickenPeckingOrder.Cp]: 1,
      [ChickenPeckingOrder.C]: 1,
      [ChickenPeckingOrder.Dp]: 2,
      [ChickenPeckingOrder.D]: 2,
      [ChickenPeckingOrder.Ep]: 3,
      [ChickenPeckingOrder.E]: 3,
      [ChickenPeckingOrder.Fp]: 4,
      [ChickenPeckingOrder.F]: 4,
      [ChickenPeckingOrder.CHICK]: 0,
    };

    const settingUpVariables: {
      distanceTime: number,
      terrainTime: number,
      peckingOrderTime: number,
      distanceVariation: number,
      r0?: number,
    } = {
      distanceTime: distanceTimes[raceModel.distance as keyof typeof distanceTimes] || 60,
      terrainTime: terrainTimes[terrainType] || -1,
      peckingOrderTime: peckingOrderTimes[raceModel.peckingOrder] || 0,
      distanceVariation: 25,
    };

    // r0
    const r0Min = -1;
    const r0Max = 1;
    settingUpVariables.r0 = Math.random() * (r0Max - r0Min) + r0Min;

    // for finishData
    const finishData: {
      chickenId: number,
      finishTime: number,
    }[] = [];

    const randomBreakMin = 0;
    const randomBreakMax = 3;
    const randomBreakChance = 0.01; // 1%
    let isRandomBreak = false;

    for (let i = 0; i < sorted.length; i += 1) {
      if (i === 0) {
        const finishTime = settingUpVariables.distanceTime
          + ((settingUpVariables.distanceTime / settingUpVariables.distanceVariation) * settingUpVariables.r0)
          + settingUpVariables.terrainTime + settingUpVariables.peckingOrderTime;
        finishData.push({ chickenId: sorted[i].chickenId, finishTime });
      } else {
        const previousAnimalTime = finishData[i - 1].finishTime;
        const r1Min = 0.01;
        const r1Max = previousAnimalTime / 200;
        const r1 = Math.random() * (r1Max - r1Min) + r1Min;

        let randomBreak = 0;
        if (!isRandomBreak && Math.random() <= randomBreakChance) { // only set random break for 5% chance
          randomBreak = Math.random() * (randomBreakMax - randomBreakMin) + randomBreakMin;
          isRandomBreak = true;
        }

        const finishTime = previousAnimalTime + r1 + randomBreak;
        finishData.push({ chickenId: sorted[i].chickenId, finishTime });
      }
    }
    ///

    // generate master segments
    const segmentSizeMin = 3;
    const segmentSizeMax = 10;
    const masterSegments: MasterSegment[] = [];

    let total = 0;
    for (let i = 1; total < finishData[0].finishTime; i += 1) {
      const segmentSize = Math.random() * (segmentSizeMax - segmentSizeMin) + segmentSizeMin;
      total += segmentSize;
      masterSegments.push({
        segment: i,
        segmentSize,
        cumulativeSegmentSize: total,
      });
    }
    ///

    // set endSpeed to masterSegments
    const minAcceleration = -20;
    const maxAcceleration = 30;

    const minSegmentEndSpeed = 0.5;
    const maxSegmentEndSpeed = 2;

    let previousEndSpeed = 1;
    masterSegments.forEach((item, index) => {
      const r = Math.floor(Math.random() * (maxAcceleration - minAcceleration) + minAcceleration);
      const endSpeed = Math.min(Math.max(previousEndSpeed + (r / 100), minSegmentEndSpeed), maxSegmentEndSpeed);

      masterSegments[index] = { ...item, endSpeed };
      previousEndSpeed = endSpeed;
    });
    ///

    // clone masterSegments for each chicken's segments and some adjustment
    const minESAdjustment = -3;
    const maxESAdjustment = 3;

    const startSpeedMin = 0.95;
    const startSpeedMax = 1.05;

    const segmentData: {
      chickenId: number,
      segments: Segment[],
    }[] = [];
    finishData.forEach((finishDataItem, finishDataIndex) => {
      // finishing sprint
      const finishingSprintChance = Math.random() <= 0.13; // 13% chance
      let finishingSprintBoost = 0;
      if (finishingSprintChance && finishDataIndex <= 4) { // apply finishingSprintBoost to the 1st ~ 5th chickens
        finishingSprintBoost = 0.2;
      }

      // finishing fatigue
      const finsihingFatigueChance = Math.random() <= 0.05; // 5% chance
      let finishingFatigueDrop = 0;
      if (finsihingFatigueChance && finishDataIndex >= 6) { // apply finishingFatigueDrop to the 7th ~ 12th chickens
        finishingFatigueDrop = 0.2;
      }

      segmentData[finishDataIndex] = {
        chickenId: finishData[finishDataIndex].chickenId,
        segments: [],
      };

      let startSpeed = Math.random() * (startSpeedMax - startSpeedMin) + startSpeedMin;
      masterSegments.forEach((masterSegmentItem, masterSegmentIndex) => {
        const r = Math.floor(Math.random() * (maxESAdjustment - minESAdjustment) + minESAdjustment);
        let newEndSpeed = masterSegmentItem.endSpeed + r / 100;

        let segmentChickenAnimation;
        if (masterSegmentIndex >= masterSegments.length - 2) { // apply finishingSprintBoost and finishingFatigueDrop to penultimate and last segments
          newEndSpeed += (finishingSprintBoost - finishingFatigueDrop);
          if (finishingSprintBoost > 0) {
            segmentChickenAnimation = 'chicken_sprint_1';
          }
        }

        if (masterSegmentIndex === masterSegments.length - 1) {
          const difference = finishDataItem.finishTime - masterSegmentItem.cumulativeSegmentSize;

          segmentData[finishDataIndex].segments[masterSegmentIndex] = {
            ...masterSegmentItem,
            cumulativeSegmentSize: finishDataItem.finishTime,
            segmentSize: masterSegmentItem.segmentSize + difference,
            startSpeed,
            endSpeed: newEndSpeed,
            segmentChickenAnimation,
          };
        } else {
          segmentData[finishDataIndex].segments[masterSegmentIndex] = {
            ...masterSegmentItem,
            startSpeed,
            endSpeed: newEndSpeed,
            segmentChickenAnimation,
          };
        }
        startSpeed = newEndSpeed;
      });
    });
    ///

    // apply talents
    const cutscenes: any[] = [];
    const soundProfiles: any[] = [];

    applyTalents(raceModel, chickensForTalent, masterSegments, segmentData, cutscenes, soundProfiles);

    // generate final race profile by transforming startSpeed and endSpeed to fit to the race distance
    const raceProfiles = segmentData.map((item) => {
      transformStartSpeedAndEndSpeed(item.segments, raceModel.distance);
      return item;
    });

    await job.log('generated race profiles');

    log.info({
      func: 'performRace',
      raceId,
      raceProfiles,
    }, 'After Getting Final raceProfiles');

    // apply animations and correct segment index
    raceProfiles.forEach((rp) => {
      rp.segments.forEach((segment, i) => {
        // correct segment index after applying talents
        segment.segment = i + 1;

        // set animation, do not replace if there's already an animation set by finishingSprintBoost or finishingFatigueDrop
        if (i > 5 && segment.endSpeed <= 1.1 && !segment.segmentChickenAnimation) {
          segment.segmentChickenAnimation = 'chicken_tired';
        } else if (segment.endSpeed > 1.6 && segment.endSpeed <= 2 && !segment.segmentChickenAnimation) {
          segment.segmentChickenAnimation = 'chicken_fast_run';
        } else if (segment.endSpeed > 2 && !segment.segmentChickenAnimation) {
          segment.segmentChickenAnimation = 'chicken_sprint_1';
        } else if (!segment.segmentChickenAnimation) {
          segment.segmentChickenAnimation = 'chicken_run';
        }
      });
    });

    // resolve talent segments for meta which are filled with undefined when applying talents
    resolveTalentMetas(raceProfiles);

    // sort chicken order
    gameInfo.chickens.sort((a, b) => {
      const raceProfileA = raceProfiles.find((rp) => rp.chickenId === a.id);
      const raceProfileB = raceProfiles.find((rp) => rp.chickenId === b.id);

      return raceProfileA.segments[raceProfileA.segments.length - 1].cumulativeSegmentSize
        - raceProfileB.segments[raceProfileB.segments.length - 1].cumulativeSegmentSize;
    });
    ///

    // set earnings to chickens in JEWEL
    const prizes = getPrizes(raceModel);
    prizes.forEach((prize, i) => {
      if (gameInfo.chickens[i]) {
        gameInfo.chickens[i].raceEarnings = Number(prize.toFixed(2));
      }
    });

    const numberOfChickens = gameInfo.chickens.length;
    const numberOfLastRaceProfileSegments = raceProfiles[numberOfChickens - 1].segments.length;
    const lastChickenFinishTime = raceProfiles[numberOfChickens - 1].segments[numberOfLastRaceProfileSegments - 1].cumulativeSegmentSize;

    const endsAt = moment.utc(raceModel.startsAt).add(raceModel.minimumStartDelay, 'seconds').add(lastChickenFinishTime, 'seconds').toDate();

    const enabledCommentary = await isEnabledCommentary();
    await job.log(`commentary ${enabledCommentary ? 'enabled' : 'disabled'}`);

    let commentaries: any = null;

    if (enabledCommentary) {
      const commentaryService = new CommentaryService(raceModel, raceProfiles);
      commentaries = await commentaryService.generateRaceCommentaries();

      log.info({
        func: 'performRace',
        raceId,
        commentaries,
      }, 'After Getting Final commentaries');
    }

    await Result.sequelize.transaction(async (t) => {
      for (let i = 0; i < gameInfo.chickens.length; i += 1) {
        const chicken = gameInfo.chickens[i];
        await Lane.update({
          position: i + 1,
          raceEarnings: chicken.raceEarnings,
          bonusBawk: chicken.bonusBawk,
        }, {
          where: {
            raceId,
            chickenId: chicken.id,
          },
          transaction: t,
        });
      }

      await Result.create({
        raceId,
        raceProfiles,
        commentaries,
        cutscenes,
        soundProfiles,
      }, { transaction: t });

      await raceModel.update({
        feeJEWEL,
        prizePoolJEWEL,
        endsAt,
      }, { transaction: t });
    });

    await job.progress(100);
  } catch (err) {
    log.error({
      func: 'performRace',
      raceId,
      err,
    }, 'Perform Race Error');

    throw err;
  }
};

const recordUserWinnings = async (raceModel: Race, transaction: Sequelize.Transaction) => {
  const { lanes } = raceModel;

  try {
    for (let i = 0; i < lanes.length; i += 1) {
      const { userWallet, raceEarnings } = lanes[i];
      if (!userWallet) {
        continue;
      }

      await userWallet.reload({
        transaction,
      });

      const firsts = i === 0 ? userWallet.firsts + 1 : undefined;
      const seconds = i === 1 ? userWallet.seconds + 1 : undefined;
      const thirds = i === 2 ? userWallet.thirds + 1 : undefined;

      if (raceEarnings) {
        await userWallet.update({
          winnings: userWallet.winnings + raceEarnings,
          winningsJEWEL: userWallet.winningsJEWEL + Number(raceEarnings || 0),
          firsts,
          seconds,
          thirds,
        }, { transaction });
      }

      if (raceModel.bawks) {
        await userWallet.update({
          bawkGifts: userWallet.bawkGifts + raceModel.bawks,
        }, { transaction });
      }
    }

    // claim goldNuggets and coins
    const trainingPartnerEnabled = await isTrainingPartnerEnabled();
    if (trainingPartnerEnabled) {
      for (const lane of lanes) {
        const { userWallet, position } = lane;
        if (!userWallet) {
          continue;
        }

        const goldNuggets = raceModel.getGoldNuggets(position);
        const coins = raceModel.getCoins(position);

        await userWallet.reload({
          transaction,
        });

        log.info({
          func: recordUserWinnings.name,
          raceId: raceModel.id,
          userWalletId: userWallet.id,
          originalGoldNuggets: userWallet.goldNuggets,
          goldNuggets,
          originalCoins: userWallet.coins,
          coins,
        }, 'Claim goldNuggets and coins');

        await userWallet.update({
          goldNuggets: userWallet.goldNuggets + goldNuggets,
          coins: userWallet.coins + coins,
        }, {
          transaction,
        });
      }
    }
  } catch (err) {
    log.error({
      func: recordUserWinnings.name,
      raceId: raceModel.id,
      err,
    }, 'Record User Winnings Error');

    throw err;
  }
};

const createRaceHistory = async (raceModel: Race, transaction: Sequelize.Transaction) => {
  const { lanes } = raceModel;

  try {
    // update races, firsts, seconds, thirds, earnings, poPoints
    const { peckingOrder } = raceModel;

    const resetSituationMinutes = await getChickenSituationResetMinutes();
    const resetSituationAt = resetSituationMinutes ? moment.utc().add(resetSituationMinutes, 'minutes').toDate() : null;

    const chickens = [];
    for (let i = 0; i < lanes.length; i += 1) {
      const lane = lanes[i];

      if (!lane.chickenId) {
        continue;
      }

      // Prevent race condition when 2 races are finished at the same time - for ex, raceId: 122631, 122632 for chickenId 30105
      const chicken = await Chicken.findByPk(lane.chickenId, {
        transaction,
        lock: transaction.LOCK.UPDATE,
      });

      const raceHistoryModel = await RaceHistory.findOne({
        where: {
          raceId: raceModel.id,
          chickenId: chicken.id,
        },
      });

      if (raceHistoryModel) {
        continue;
      }

      const races = (chicken.races || 0) + 1;
      const firsts = (chicken.firsts || 0) + (i === 0 ? 1 : 0);
      const seconds = (chicken.seconds || 0) + (i === 1 ? 1 : 0);
      const thirds = (chicken.thirds || 0) + (i === 2 ? 1 : 0);
      const placed = firsts + seconds + thirds;
      const bawkGifts = chicken.bawkGifts + raceModel.bawks;

      const placedPercentage = placed / races * 100;
      const firstPlacedPercentage = firsts / races * 100;

      const chickenInfo: Partial<Chicken> = {
        races,
        firsts,
        seconds,
        thirds,
        earnings: Number(chicken.earnings || 0) + Number(lane.raceEarnings || 0),
        placed,
        placedPercentage,
        firstPlacedPercentage,
        bawkGifts,
        situation: ChickenSituation.Barn,
        resetSituationAt: null,
      };

      if (resetSituationAt) {
        chickenInfo.situation = ChickenSituation.Cooldown;
        chickenInfo.resetSituationAt = resetSituationAt;
      }

      if (peckingOrder === ChickenPeckingOrder.CHICK) {
        chickenInfo.chickRaces = (chicken.chickRaces || 0) + 1;
      }

      chickens.push(chickenInfo);

      const position = i + 1;
      await RaceHistory.create({
        raceId: raceModel.id,
        userWalletId: lane.userWalletId,
        chickenId: chicken.id,
        position,
        raceEarnings: lane.raceEarnings || 0,
        date: moment.utc(raceModel.endsAt).format('YYYY-MM-DD'),
        terrainId: raceModel.terrainId,
        distance: raceModel.distance,
        capacity: raceModel.currentCapacity,
        peckingOrder: raceModel.peckingOrder,
        coinContract: raceModel.coinContract,
        feeJEWEL: raceModel.feeJEWEL,
        positionType: getPositionType(position),

      }, { transaction });

      await chicken.update(chickenInfo, { transaction });

      log.info({
        func: 'createRaceHistory',
        raceId: raceModel.id,
        chickenId: lane.chickenId,
        chickenInfo,
      }, `Updated Chicken - ${lane.chickenId} For Race ${raceModel.id}`);
    }

    log.info({
      func: 'createRaceHistory',
      raceId: raceModel.id,
      chickens,
    }, `Updated ${chickens.length} Chickens For Race ${raceModel.id}`);
  } catch (err) {
    log.error({
      func: 'createRaceHistory',
      raceId: raceModel.id,
      err,
    }, `Create Race History Error For Race ${raceModel.id}`);

    throw err;
  }
};

const raceFinish = async (raceModel: Race) => {
  try {
    await Race.sequelize.transaction(async (t) => {
      // set race as finished
      await raceModel.update({
        status: RaceStatus.Finished,
      }, { transaction: t });
      await recordUserWinnings(raceModel, t);
      await createRaceHistory(raceModel, t);

      if (raceModel.userId) {
        return; // ignore custom races
      }

      await bestScoresTournamentService.trackTournament('presidents-challenge', raceModel, t);
    });
  } catch (err) {
    log.error({
      func: 'raceFinish',
      raceId: raceModel.id,
      resultId: raceModel.result.id,
      err,
    }, 'Race Finish Error');
  }
};

const getSafeRaceStartTime = async (raceModel: Race) => {
  let { startTime } = raceModel;

  if (raceModel.type !== RaceType.Automatic || raceModel.peckingOrder === ChickenPeckingOrder.CHICK) {
    return startTime;
  }

  const scheduledRaces = await Race.findAll({
    where: {
      status: RaceStatus.Scheduled,
      startsAt: {
        [Op.not]: null,
      },
      startTime: {
        [Op.gt]: 0,
      },
    },
  });

  if (!scheduledRaces.length) {
    return startTime;
  }

  const raceTimeBuffer = 60;
  let isSafe = false;

  // check if there are any scheduled races that start between raceTimeBuffer, and if so increase by raceTimeBuffer
  while (!isSafe) {
    isSafe = true;
    for (const scheduledRace of scheduledRaces) {
      if (scheduledRace.startTime > startTime - raceTimeBuffer && scheduledRace.startTime < startTime + raceTimeBuffer) {
        isSafe = false;
        startTime += raceTimeBuffer;

        break;
      }
    }
  }

  return startTime;
};

const autoGenerateRace = async (raceModel: Race, isFreeRaceGeneration = false, transaction?: Sequelize.Transaction) => {
  // https://docs.google.com/document/d/1pR1yyvV0VMOp-25mm_L_OAMUoRqNf74CruyaTCf9DOE/edit#

  if (raceModel.type !== RaceType.Automatic) {
    return;
  }

  const isAutoRaceGenerationSettingEnabled = await isAutoRaceGenerationEnabled();
  if (!isAutoRaceGenerationSettingEnabled) {
    return;
  }

  const {
    peckingOrder,
    group,
  } = raceModel;

  /*
  const freeRaceCounterLimit = await getFreeRaceCounterLimit();
  const freeRaceCounter = await getFreeRaceCounter(peckingOrder);

  if (isFreeRaceGeneration) {
    if (peckingOrder === ChickenPeckingOrder.CHICK) {
      return;
    }

    if (freeRaceCounter < freeRaceCounterLimit) {
      return;
    }
  }
  */

  const activeRaces = await Race.findAll({
    where: {
      status: [RaceStatus.Open, RaceStatus.Scheduled, RaceStatus.InProgress],
    },
  });
  const activeRaceNames = activeRaces.map((activeRace) => activeRace.name);

  const where: Sequelize.WhereOptions<AutoRacePool> = {};

  if (isFreeRaceGeneration) {
    where.fee = 0;
  } else {
    where.group = group;
  }

  const autoRacePoolsGroupedByPeckingOrders = await AutoRacePool.findAll({
    attributes: ['peckingOrder'],
    where,
    group: ['peckingOrder'],
  });
  const peckingOrders = autoRacePoolsGroupedByPeckingOrders
    .map(pool => pool.peckingOrder)
    .filter(po => po.split(',').includes(peckingOrder));

  where.peckingOrder = peckingOrders;
  const autoRacePools = await AutoRacePool.findAll({
    where,
  });

  // filter out ones with the same name as active races
  let filteredAutoRacePools = autoRacePools.filter((pool) => !activeRaceNames.includes(pool.name));

  log.info({
    func: 'autoGenerateRace',
    raceId: raceModel.id,
    isFreeRaceGeneration,
    activeRaceNames,
    filteredAutoRacePoolIds: filteredAutoRacePools.map((pool) => pool.id),
    autoRacePoolIds: autoRacePools.map((pool) => pool.id),
  }, 'Start Generating Auto Race');

  // if there is no auto race pool with the different name as active races, then just ignore the rule and generate
  if (!filteredAutoRacePools.length) {
    filteredAutoRacePools = autoRacePools;
  }

  const index = Math.floor(Math.random() * filteredAutoRacePools.length);
  const autoRacePoolModel = filteredAutoRacePools[index];
  let autoRaceData = null;

  if (autoRacePoolModel) {
    const feeJEWEL = await convertCoinToJewel(autoRacePoolModel.coinType, autoRacePoolModel.fee);
    const prizePoolJEWEL = await convertCoinToJewel(autoRacePoolModel.coinType, autoRacePoolModel.prizePool);

    autoRaceData = {
      ..._.omit(autoRacePoolModel.toJSON(), ['id', 'createdAt', 'updatedAt', 'coinType']),
      peckingOrder,
      feeJEWEL,
      prizePoolJEWEL,
    };

    const newRaceModel = await Race.create(autoRaceData, { transaction });

    for (let i = 0; i < autoRacePoolModel.maxCapacity; i += 1) {
      await Lane.create({
        raceId: newRaceModel.id,
        laneNumber: i + 1,
      }, { transaction });
    }
  }

  /*
  if (isFreeRaceGeneration) {
    await updateFreeRaceCounter(peckingOrder, freeRaceCounter - freeRaceCounterLimit, transaction);
  } else if (peckingOrder !== ChickenPeckingOrder.CHICK) {
    await updateFreeRaceCounter(peckingOrder, freeRaceCounter + raceModel.fee, transaction);
  }
  */

  log.info({
    func: 'autoGenerateRace',
    raceId: raceModel.id,
    isFreeRaceGeneration,
    autoRaceData,
  }, 'Ended Generating Auto Race');
};

const sendRaceScheduledNotificationToUser = async (raceModel: Race, userWalletId: string) => {
  const userWalletModel = await UserWallet.findByPk(userWalletId);
  if (!userWalletModel.firebaseToken) {
    return;
  }

  await sendNotification(
    userWalletModel.firebaseToken,
    'Race Scheduled',
    `${raceModel.name} is now scheduled`,
    `${config.frontendUrl}/race-detail/${raceModel.id}`,
  );
};

const sendRaceScheduledNotification = async (raceModel: Race) => {
  const lanes = await Lane.findAll({
    where: {
      raceId: raceModel.id,
      userWalletId: {
        [Op.not]: null,
      },
    },
  });

  const userWalletIds: string[] = [];
  for (const laneModel of lanes) {
    if (userWalletIds.includes(laneModel.userWalletId)) { // prevent send duplicate notification to same user
      continue;
    }

    sendRaceScheduledNotificationToUser(raceModel, laneModel.userWalletId);
    userWalletIds.push(laneModel.userWalletId);
  }
};

const createLaneClothings = async (lane: Lane, transaction: Sequelize.Transaction) => {
  await lane.reload({
    transaction,
  });

  const chickenClothings = await ChickenClothing.findAll({
    where: {
      chickenId: lane.chickenId,
      userWalletId: lane.userWalletId,
    },
    transaction,
  });

  for (const chickenClothing of chickenClothings) {
    await LaneClothing.create({
      laneId: lane.id,
      clothingId: chickenClothing.clothingId,
    }, { transaction });
  }
};

const adjustRaceAfterTimeLimit = async (race: Race, t: Sequelize.Transaction) => {
  await race.reload({ transaction: t });

  if (race.currentCapacity >= race.maxCapacity) {
    return;
  }

  // adjust prizePool
  if (race.fee > 0) {
    await race.update({
      prizePool: race.getActualPrizePool(),
    }, { transaction: t });
  }

  // adjust lanes
  const lanes = await Lane.findAll({
    where: {
      raceId: race.id,
    },
    transaction: t,
    order: [['laneNumber', 'ASC']],
  });

  // move unassigned lanes to the end
  lanes.sort((a, b) => {
    const aOrder = a.chickenId ? a.laneNumber : 9999;
    const bOrder = b.chickenId ? b.laneNumber : 9999;

    return aOrder - bOrder;
  });

  for (let i = 0; i < lanes.length; i += 1) {
    await lanes[i].update({
      laneNumber: i + 1,
    }, {
      transaction: t,
    });
  }
};

export const scheduleRaces = async (job: Job) => {
  try {
    await job.progress(0);

    const racesToSchedule = await Race.findAll({
      where: {
        status: RaceStatus.Open,
        maxCapacity: {
          [Op.gte]: 3,
        },
        [Op.or]: [
          {
            currentCapacity: {
              [Op.gte]: Sequelize.col('maxCapacity'),
            },
          },
          {
            scheduleAt: {
              [Op.lte]: moment.utc().toDate(),
            },
          },
        ],
        startsAt: null,
      },
    });

    const jobData = {
      raceIdsToSchedule: racesToSchedule.map((raceModel) => raceModel.id),
    };
    await job.update(jobData);

    if (!racesToSchedule.length) {
      await job.progress(100);

      return;
    }

    log.info({
      func: 'scheduleRaces',
      raceIdsToSchedule: jobData.raceIdsToSchedule,
    }, `Start Scheduling ${jobData.raceIdsToSchedule.length} Races`);

    for (let i = 0; i < racesToSchedule.length; i += 1) {
      const raceModel = racesToSchedule[i];
      const startTime = await getSafeRaceStartTime(raceModel);

      let isPendingAssignment = false;
      await Race.sequelize.transaction(async (t) => {
        await redisLock([`${config.lock.assignLane}/${raceModel.id}`], 30 * 1000, async () => {
          if (raceModel.fee > 0) {
            const pendingRaceAssignment = await RaceAssignment.findOne({
              where: {
                raceId: raceModel.id,
                status: AssignmentStatus.Pending,
              },
            });
            if (pendingRaceAssignment) {
              isPendingAssignment = true;
              return;
            }
          }

          await adjustRaceAfterTimeLimit(raceModel, t);

          await raceModel.update({
            startTime,
            startsAt: moment.utc().add(startTime || 0, 'seconds').toDate(),
            status: RaceStatus.Scheduled,
          }, { transaction: t });
        });

        if (isPendingAssignment) {
          return;
        }

        await autoGenerateRace(raceModel, false, t);
        // await autoGenerateRace(raceModel, true, t);
      });

      if (isPendingAssignment) {
        continue;
      }

      performRaceWorker.add({
        raceId: raceModel.id,
      });

      await sendRaceScheduledNotification(raceModel);

      await job.progress(((i + 1) / racesToSchedule.length * 100).toFixed(2));
    }

    log.info({
      func: 'scheduleRaces',
      raceIdsToSchedule: jobData.raceIdsToSchedule,
    }, `Finish Scheduling ${jobData.raceIdsToSchedule.length} Races Successfully`);

    await job.progress(100);
  } catch (err) {
    log.error({
      func: 'scheduleRaces',
      err,
    }, 'Schedule Races Error');

    await job.log(`scheduleRaces Error ${err}`);
  }
};

export const countDownScheduledRaces = async (job: Job) => {
  try {
    await job.progress(0);

    const scheduledRaces = await Race.findAll({
      where: {
        status: RaceStatus.Scheduled,
        startsAt: {
          [Op.not]: null,
        },
        startTime: {
          [Op.gt]: 0,
        },
      },
    });

    const jobData = {
      raceIdsToCountDown: scheduledRaces.map((scheduledRace) => scheduledRace.id),
    };
    await job.update(jobData);

    if (!scheduledRaces.length) {
      await job.progress(100);

      return;
    }

    // Because the race timer runs every 10 seconds, it will be flooding pm2 logs on the server.
    // Instead we could check logs on the bull job dashboard
    /**
            console.log({
                func: 'countDownScheduledRaces',
                raceIdsToCountDown: jobData.raceIdsToCountDown,
            }, `Start Count Down ${jobData.raceIdsToCountDown.length} Races`);
         */

    for (let i = 0; i < scheduledRaces.length; i += 1) {
      const scheduledRace = scheduledRaces[i];

      const nowUTC = moment.utc();
      const startTime = Math.max(moment.utc(scheduledRace.startsAt).diff(nowUTC, 'seconds'), 0);

      await scheduledRace.update({
        startTime,
      });

      await job.progress(((i + 1) / scheduledRaces.length * 100).toFixed(2));
    }

    /**
             console.log({
                 func: 'countDownScheduledRaces',
                raceIdsToCountDown: jobData.raceIdsToCountDown,
            }, `Finish Count Down ${jobData.raceIdsToCountDown.length} Races Successfully`);
         */

    await job.progress(100);
  } catch (err) {
    log.error({
      func: 'countDownScheduledRaces',
      err,
    }, 'Count Down Schedule Races Error');

    await job.log(`countDownScheduledRaces Error ${err}`);
  }
};

export const finishScheduledRaces = async (job: Job) => {
  try {
    await job.progress(0);

    const racesToEnd = await Race.findAll({
      where: {
        status: RaceStatus.Scheduled,
        endsAt: {
          [Op.lt]: moment.utc().toDate(),
        },
      },
      include: [{
        model: Terrain,
        attributes: ['name'],
      }, {
        model: Lane,
        as: 'lanes',
        include: [{
          model: Chicken,
        }, {
          model: UserWallet,
        }],
      }],
    });

    const jobData: {
      raceIdsToEnd?: number[],
    } = {
      raceIdsToEnd: racesToEnd.map((raceModel) => raceModel.id),
    };

    await job.update(jobData);

    if (racesToEnd.length) {
      log.info({
        func: 'finishScheduledRaces',
        raceIdsToEnd: jobData.raceIdsToEnd,
      }, `Ending ${jobData.raceIdsToEnd.length} Races`);

      for (let i = 0; i < racesToEnd.length; i += 1) {
        // move unassigned lanes to the end
        racesToEnd[i].lanes.sort((a, b) => (a.position || 9999) - (b.position || 9999));

        await raceFinish(racesToEnd[i]);

        await job.progress(((i + 1) / racesToEnd.length * 100).toFixed(2));
      }

      log.info({
        func: 'finishScheduledRaces',
        raceIdsToEnd: jobData.raceIdsToEnd,
      }, `Ended ${jobData.raceIdsToEnd.length} Races`);
    }

    await job.progress(100);
  } catch (err) {
    log.error({
      func: 'finishScheduledRaces',
      err,
    }, 'finishScheduledRaces Error');

    await job.log(`finishScheduledRaces Error ${err}`);
  }
};

const isContractPayoutSuccess = async (raceModel: Race) => {
  const contractRaceInfo = await getRaceContractRaceInfo(raceModel.id);
  return contractRaceInfo?.isPaid;
};

const isContractFullyEntered = async (raceModel: Race) => {
  if (!raceModel.fee) {
    return true;
  }

  const contractRaceInfo = await getRaceContractRaceInfo(raceModel.id);
  const contractChickenIds = await getRaceContractChickenIds(raceModel.id);

  const contractCapacity = contractChickenIds.length;
  const isContractFull = contractCapacity >= raceModel.maxCapacity;

  const raceFunds = NP.strip(NP.times(NP.times(raceModel.fee, raceModel.maxCapacity), 1e18));
  const contractFunds = Number(contractRaceInfo.fund);
  const isContractFullyCharged = raceFunds === contractFunds;

  log.info({
    func: 'isContractFullyEntered',
    raceId: raceModel.id,
    contractRaceInfo,
    isContractFull,
    isContractFullyCharged,
  }, 'Is Contract Fully Entered');

  return isContractFull && isContractFullyCharged;
};

const isPrizePoolFine = (race: Race, racePrizePercent = config.RACE_PRIZE_POOL_PERCENT) => {
  const { fee, prizePool, maxCapacity } = race;
  if (!fee) {
    return true;
  }

  const maxPrizePool = NP.strip(fee * maxCapacity * racePrizePercent / 100);
  return prizePool <= maxPrizePool;
};

export const checkPrizePool = (race: Race, racePrizePercent = config.RACE_PRIZE_POOL_PERCENT) => {
  if (!isPrizePoolFine(race, racePrizePercent)) {
    throw new PrizePoolError(`Prize Pool (${race.prizePool}) couldn't be greater than ${racePrizePercent}% of fees`);
  }
};

const payForUnpaidRaces = async (job: Job) => {
  try {
    await job.progress(0);

    const racesToPay = await Race.findAll({
      where: {
        status: RaceStatus.Finished,
        paidStatus: TransactionPaidStatus.Unpaid,
        prizePool: {
          [Op.gt]: 0,
        },
      },
      include: [{
        model: Lane,
        as: 'lanes',
      }],
      order: [['id', 'ASC']],
      limit: config.RACE_SYNC_LIMIT,
    });

    const jobData = {
      raceIdsToPay: racesToPay.map((raceModel) => raceModel.id),
    };
    await job.update(jobData);

    if (!racesToPay.length) {
      await job.progress(100);

      return;
    }

    const raceContractAddress = await getRaceContractAddress();
    const racePrizePercent = await getRaceContractPrizePercent();

    log.info({
      func: 'payForUnpaidRaces',
      raceIdsToPay: jobData.raceIdsToPay,
    }, `Start Paying For ${jobData.raceIdsToPay.length} Races`);

    for (let i = 0; i < racesToPay.length; i += 1) {
      const raceModel = racesToPay[i];
      const { id: raceId, bawkStakingCompanyId, cid } = raceModel;
      // filter out unassigned lanes
      const lanes = raceModel.lanes.filter((lane) => lane.chickenId);

      const txHashes: string[] = [];
      let transactionHash: string = null;
      let payoutAttempts = 0;
      let addressArr: string[] = [];
      let earnings: number[] = null;

      try {
        checkPrizePool(raceModel, racePrizePercent);

        const resultModel = await Result.findOne({
          where: {
            raceId,
          },
        });
        if (!resultModel) {
          log.warn({
            func: 'payForUnpaidRaces',
            raceId,
          }, 'There is no result for race');

          continue;
        }

        addressArr = lanes.sort((a, b) => a.position - b.position).map((l) => l.userWalletId);
        earnings = getPrizes(raceModel);
        // prizePool has 6 floating points and percents are like 0.55, 0.30, 0.15 so 8 fp at maximum
        const amountArr = earnings.map((earning) => Web3.utils.toWei(earning.toFixed(8), 'ether'));

        const chickenIds = lanes.map((l) => l.chickenId);

        log.info({
          func: 'payForUnpaidRaces',
          raceId,
          bawkStakingCompanyId,
          addressArr,
          amountArr,
          chickenIds,
        }, `Payout Started For Race ${raceId}`);

        let paidStatus = TransactionPaidStatus.Paid;

        const transactionReceipt = await new Promise((resolve, reject) => {
          payout(addressArr, amountArr, cid, raceId, {
            onTx: (txHash) => {
              transactionHash = txHash;
              txHashes.push(transactionHash);

              log.info({
                func: 'payForUnpaidRaces',
                raceId,
                transactionHash,
                txHashes,
              }, `Payout On txHash For Race ${raceId}`);
            },
            onReceipt: async (receipt, attempts) => {
              payoutAttempts = attempts;
              // catch err and return undefined
              const isContractSuccess = await isContractPayoutSuccess(raceModel).catch((err) => {
                log.error({
                  func: 'payForUnpaidRaces',
                  raceId,
                  receipt,
                  payoutAttempts,
                  transactionHash,
                  txHashes,
                  err,
                }, `Payout isContractPayoutSuccess Error For Race ${raceId}`);
              });

              log.info({
                func: 'payForUnpaidRaces',
                raceId,
                isContractSuccess,
                receipt,
                payoutAttempts,
                transactionHash,
                txHashes,
              }, `Payout On receipt For Race ${raceId}`);

              /*  if (!isContractSuccess) {
                const err = new Error('Sorry, your payout transaction was failed on the chain. Please try again.');
                return reject(err);
              } */

              resolve(receipt);
            },
            onError: async (err, attempts) => {
              await sleep(6000);
              payoutAttempts = attempts;
              // catch error and return undefined
              const isContractSuccess = await isContractPayoutSuccess(raceModel).catch((err2) => {
                log.error({
                  func: 'payForUnpaidRaces',
                  raceId,
                  payoutAttempts,
                  transactionHash,
                  txHashes,
                  err: err2,
                }, `Payout isContractPayoutSuccess Error For Race ${raceId}`);
              });

              const successfulTransaction = await getSuccessfulTransactionHashAndReceipt(txHashes).catch((err2) => {
                log.error({
                  func: 'payForUnpaidRaces',
                  raceId,
                  payoutAttempts,
                  transactionHash,
                  txHashes,
                  err: err2,
                }, `Payout getSuccessfulTransactionHashAndReceipt Error For Race ${raceId}`);

                return null;
              });

              if (successfulTransaction?.txHash) {
                transactionHash = successfulTransaction.txHash;
              }

              log.error({
                func: 'payForUnpaidRaces',
                raceId,
                isContractSuccess,
                payoutAttempts,
                transactionHash,
                txHashes,
                successfulTransaction,
                err,
              }, `Payout On Error For Race ${raceId}`);

              if (isContractSuccess || successfulTransaction) {
                // edge case: we are raising new transaction if the previous one is not mined within 1000 seconds
                // sometimes the previous transaction is mined while we are generating new one
                // so new one fails with the `Signer and signature do not match` error
                // in that case, we have to mark the transaction as completed because it's actually a successful transaction
                paidStatus = TransactionPaidStatus.Paid;

                resolve(successfulTransaction?.receipt);
              } else if (err.message?.includes('Transaction was not mined within')) {
                paidStatus = TransactionPaidStatus.Postponed;

                resolve(null);
              } else {
                reject(err);
              }
            },
          });
        });

        log.info({
          func: 'payForUnpaidRaces',
          raceId,
          bawkStakingCompanyId,
          addressArr,
          amountArr,
          chickenIds,
          transactionHash,
          transactionReceipt,
        }, `Payout Success For Race ${raceId}`);

        await Race.sequelize.transaction(async (t) => {
          // mark race as paid
          await raceModel.update({
            paidStatus,
            payoutAttempts,
            syncedAt: null,
          }, { transaction: t });

          // record transactions
          for (let j = 0; j < addressArr.length; j += 1) {
            const userWalletId = addressArr[j];

            if (j < 3) {
              await Transaction.create({
                fromAddress: raceContractAddress,
                toAddress: userWalletId,
                type: TransactionType.Out,
                transactionHash,
                status: paidStatus,
                associatedObjectType: 'race',
                associatedObjectId: `${raceId}`,
                amount: earnings[j],
                tokenId: lanes[j].chickenId,
                category: TransactionCategory.RacePayout,
              }, { transaction: t });
            }

            await Transaction.create({
              fromAddress: raceContractAddress,
              toAddress: userWalletId,
              type: TransactionType.Out,
              transactionHash,
              status: paidStatus,
              associatedObjectType: 'race',
              associatedObjectId: `${raceId}`,
              amount: raceModel.bawks,
              tokenId: lanes[j].chickenId,
              category: TransactionCategory.RacePayoutBawk,
            }, { transaction: t });
          }

          if (racePrizePercent < 100) {
            await Transaction.create({
              fromAddress: raceContractAddress,
              toAddress: BAWK_STAKING_CONTRACT.address,
              type: TransactionType.Out,
              transactionHash,
              status: paidStatus,
              associatedObjectType: 'race',
              associatedObjectId: `${raceId}`,
              amount: NP.strip(raceModel.fee * raceModel.currentCapacity * (100 - racePrizePercent) / 100),
              category: TransactionCategory.RacePayoutFee,
            }, { transaction: t });
          }
        });

        log.info({
          func: 'payForUnpaidRaces',
          raceId,
          transactionHash,
          racePrizePercent,
        }, `Payout Finished For Race ${raceId}`);

        await job.progress(((i + 1) / racesToPay.length * 100).toFixed(2));
      } catch (err) {
        const isContractFull = await isContractFullyEntered(raceModel);
        // if contract is fully entered, leave the race.paidStatus as unpaid so it can be paid in the next loop after a minute
        // usually it's an error on biconomy end like 500 internal server error, which can be succeeded next time
        if (err instanceof PrizePoolError || !isContractFull) {
          // mark race paidStatus as error
          await raceModel.update({
            paidStatus: TransactionPaidStatus.Error,
            payoutAttempts,
          });

          for (let j = 0; j < addressArr.length; j += 1) {
            const userWalletId = addressArr[j];

            await Transaction.create({
              fromAddress: raceContractAddress,
              toAddress: userWalletId,
              type: TransactionType.Out,
              transactionHash,
              status: TransactionPaidStatus.Error,
              associatedObjectType: 'race',
              associatedObjectId: `${raceId}`,
              amount: earnings[j],
              tokenId: lanes[j].chickenId,
              category: TransactionCategory.RacePayout,
            });
          }
        } else {
          await raceModel.update({
            payoutAttempts,
          });
        }

        log.error({
          func: 'payForUnpaidRaces',
          raceId,
          bawkStakingCompanyId,
          transactionHash,
          isContractFull,
          err,
        }, `payForUnpaidRaces Error for Race ${raceId}`);

        await job.log(`payForUnpaidRaces Error for Race ${raceId}: ${err}`);
      }

      // add some delay between payouts to overcome alchemy rate limit
      await sleep(6000);
    }

    log.info({
      func: 'payForUnpaidRaces',
      raceIdsToPay: jobData.raceIdsToPay,
    }, `Finish Paying For ${jobData.raceIdsToPay.length} Races`);
  } catch (err) {
    log.error({
      func: 'payForUnpaidRaces',
      err,
    }, 'payForUnpaidRaces Error');

    await job.log(`payForUnpaidRaces Error ${err}`);
  }
};

const updateRaceAssignment = async ({
  chickenId,
  raceAssignmentModel,
  status,
  paidStatus,
  transactionHash,
  txHashes,
  errorMsg,
  transaction,
}: {
  chickenId?: number,
  raceAssignmentModel: RaceAssignment,
  status: AssignmentStatus,
  paidStatus: TransactionPaidStatus,
  transactionHash: string,
  txHashes: string[],
  errorMsg?: string,
  transaction: Sequelize.Transaction,
}) => {
  await raceAssignmentModel.update({
    status,
    paidStatus,
    error: errorMsg
      ? {
        message: errorMsg,
      }
      : null,
    transactionHash,
    txHashes,
  }, { transaction });

  if (errorMsg) {
    await Chicken.update({
      situation: ChickenSituation.Barn,
      resetSituationAt: null,
    }, {
      where: {
        id: chickenId,
      },
      transaction,
    });
  }
};

const updateRaceEntries = async (race: Race, userWalletId: string, chickenId: number, transaction: Sequelize.Transaction) => {
  const userWallet = await UserWallet.findByPk(userWalletId, { transaction });
  const chicken = await Chicken.findByPk(chickenId, { transaction });

  if (userWallet) {
    await userWallet.update({
      entryFees: userWallet.entryFees + race.feeJEWEL,
      raceEntries: userWallet.raceEntries + 1,
    }, { transaction });
  }

  if (chicken) {
    await chicken.update({
      entryFees: chicken.entryFees + race.feeJEWEL,
    }, { transaction });
  }
};

export const increaseRaceEntries = async (userWalletId: string, transaction: Sequelize.Transaction) => {
  await UserWallet.increment('raceEntries', { by: 1, where: { id: userWalletId }, transaction });
};

const isContractEnterSuccess = async (raceModel: Race, chickenId: number) => {
  const chickenIds = await getRaceContractChickenIds(raceModel.id);
  return chickenIds.includes(chickenId);
};

export const assignLane = async ({
  raceId, chickenId, userWalletId, transaction,
}: {
  raceId: number, chickenId: number, userWalletId: string, transaction: Sequelize.Transaction,
}) => {
  const raceModel = await Race.findByPk(raceId, {
    include: [{
      model: Lane,
      as: 'lanes',
    }],
    transaction,
    lock: transaction.LOCK.UPDATE,
  });

  const { lanes } = raceModel;
  const unAssignedLanes = lanes.filter((laneModel) => !laneModel.chickenId);
  const availableLaneNumbers = unAssignedLanes.map((laneModel) => laneModel.laneNumber);

  const selectedLaneNumber = availableLaneNumbers[Math.floor(Math.random() * availableLaneNumbers.length)];
  const selectedLane = lanes.find((laneModel) => laneModel.laneNumber === selectedLaneNumber);

  // This is just for retry on wrong transaction status, it won't happen in a normal flow
  if (!selectedLane) {
    return;
  }

  const chicken = await Chicken.findByPk(chickenId, {
    transaction,
  });

  await Lane.update({
    chickenId,
    assignedAt: new Date(),
    userWalletId,
    clothingImage: chicken.clothingImage,
  }, {
    where: {
      id: selectedLane.id,
    },
    transaction,
  });

  await createLaneClothings(selectedLane, transaction);

  await raceModel.increment('currentCapacity', {
    transaction,
  });

  await raceModel.update({
    syncedAt: null,
  }, { transaction });
};

const assignLaneWithLock = async ({
  raceId, chickenId, userWalletId, transaction,
}: {
  raceId: number, chickenId: number, userWalletId: string, transaction: Sequelize.Transaction,
}) => redisLock([`${config.lock.assignLane}/${raceId}`], 30 * 1000, async () => assignLane({
  raceId, chickenId, userWalletId, transaction,
}));

const afterEnterRace = async (raceAssignmentModel: RaceAssignment, {
  paidStatus,
  transactionHash,
  txHashes,
  raceModel,
}: {
  paidStatus: TransactionPaidStatus,
  transactionHash: string,
  txHashes: string[],
  raceModel: Race,
}) => {
  const {
    raceId, chickenId, userWalletId,
  } = raceAssignmentModel;

  await Race.sequelize.transaction(async (t) => {
    await assignLaneWithLock({
      raceId,
      chickenId,
      userWalletId,
      transaction: t,
    });

    const raceContractAddress = await getRaceContractAddress();

    await Transaction.create({
      fromAddress: userWalletId,
      toAddress: raceContractAddress,
      type: TransactionType.In,
      transactionHash,
      status: paidStatus,
      associatedObjectType: 'race',
      associatedObjectId: `${raceId}`,
      amount: raceModel.fee,
      tokenId: chickenId,
      category: TransactionCategory.RaceEnter,
    }, { transaction: t });

    await updateRaceAssignment({
      raceAssignmentModel,
      status: AssignmentStatus.Success,
      paidStatus,
      transactionHash,
      txHashes,
      transaction: t,
    });

    await updateRaceEntries(raceModel, userWalletId, chickenId, t);
  });
};

export const enterRace = async (job: Job) => {
  const txHashes: string[] = [];
  let transactionHash: string = null;
  let raceAssignmentModel: RaceAssignment = null;

  try {
    const { raceAssignmentId } = job.data;
    raceAssignmentModel = await RaceAssignment.findByPk(raceAssignmentId);

    const {
      raceId, chickenId, userWalletId, signature, type, status, data,
    } = raceAssignmentModel;

    log.info({
      func: 'enterRace',
      raceId,
      raceAssignmentId,
      chickenId,
      userWalletId,
      signature,
      data,
    }, `Start Entering Race ${raceId}`);

    await job.progress(0);

    if (type !== RaceAssignmentType.Enter || status !== 'pending') {
      log.warn({
        func: 'enterRace',
        raceId,
        raceAssignmentId,
        chickenId,
        userWalletId,
        signature,
        status,
      }, `Already Entered Race ${raceId} with RaceAssignment ${raceAssignmentId}`);

      return;
    }

    const raceModel = await Race.findByPk(raceId);
    let paidStatus = TransactionPaidStatus.Paid;

    await new Promise((resolve, reject) => {
      enter(raceModel, chickenId, userWalletId, signature, data, {
        onTx: (txHash) => {
          transactionHash = txHash;
          txHashes.push(transactionHash);

          log.info({
            func: 'enterRace',
            raceId,
            raceAssignmentId,
            chickenId,
            userWalletId,
            signature,
            data,
            transactionHash,
            txHashes,
          }, `Enter Race On txHash For Race ${raceId}`);
        },
        onReceipt: async (receipt) => {
          // catch error and return undefined
          const isContractSuccess = await isContractEnterSuccess(raceModel, chickenId).catch((err) => {
            log.error({
              func: 'enterRace',
              raceId,
              raceAssignmentId,
              chickenId,
              userWalletId,
              signature,
              data,
              receipt,
              transactionHash,
              txHashes,
              err,
            }, `Enter Race isContractEnterSuccess Error For Race ${raceId}`);
          });

          log.info({
            func: 'enterRace',
            raceId,
            raceAssignmentId,
            chickenId,
            userWalletId,
            signature,
            data,
            isContractSuccess,
            receipt,
            transactionHash,
            txHashes,
          }, `Enter Race On receipt For Race ${raceId}`);

          /* if (!isContractSuccess) {
                    const err = new Error('Sorry, your enter transaction was failed on the chain. Please try again.');

                    await updateRaceAssignment({
                        chickenId,
                        raceAssignmentModel,
                        status: 'error',
                        paidStatus: 'error',
                        transactionHash,
                        txHashes,
                        errorMsg: err.message,
                    });

                    return reject(err);
                } */

          resolve(receipt);
        },
        onError: async (err) => {
          await sleep(6000);
          // catch error and return undefined
          const successfulTransaction = await getSuccessfulTransactionHashAndReceipt(txHashes).catch((err2) => {
            log.error({
              func: 'enterRace',
              raceId,
              raceAssignmentId,
              chickenId,
              userWalletId,
              signature,
              data,
              transactionHash,
              txHashes,
              err: err2,
            }, `Enter Race getSuccessfulTransactionHashAndReceipt Error For Race ${raceId}`);

            return null;
          });
          if (successfulTransaction?.txHash) {
            transactionHash = successfulTransaction.txHash;
          }

          // catch error and return undefined
          const isContractSuccess = await isContractEnterSuccess(raceModel, chickenId).catch((err2) => {
            log.error({
              func: 'enterRace',
              raceId,
              raceAssignmentId,
              chickenId,
              userWalletId,
              signature,
              data,
              transactionHash,
              txHashes,
              err: err2,
            }, `Enter Race isContractEnterSuccess Error For Race ${raceId}`);
          });

          log.error({
            func: 'enterRace',
            raceId,
            raceAssignmentId,
            chickenId,
            userWalletId,
            signature,
            data,
            isContractSuccess,
            transactionHash,
            txHashes,
            successfulTransaction,
            err,
          }, `Enter Race On Error For Race ${raceId}`);

          let errorMsg = err.message;

          if (isContractSuccess || successfulTransaction) {
            // edge case: we are raising new transaction if the previous one is not mined within 1000 seconds
            // sometimes the previous transaction is mined while we are generating new one
            // so new one fails with the `Signer and signature do not match` error
            // in that case, we have to mark the transaction as completed because it's actually a successful transaction
            paidStatus = TransactionPaidStatus.Paid;

            resolve(successfulTransaction?.receipt);
            return;
          } if (errorMsg?.includes('Transaction was not mined within')) {
            paidStatus = TransactionPaidStatus.Postponed;

            resolve(null);
            return;
          }

          if (errorMsg?.includes('execution reverted: Signer and signature do not match')) {
            errorMsg += '\n This might be because your previous transaction was not minded yet. Please try again.';
          }

          reject(new Error(errorMsg));
        },
      });
    });

    await afterEnterRace(raceAssignmentModel, {
      paidStatus,
      transactionHash,
      txHashes,
      raceModel,
    });

    await job.progress(100);

    log.info({
      func: 'enterRace',
      raceId,
      raceAssignmentId,
      chickenId,
      userWalletId,
      signature,
      data,
      transactionHash,
      txHashes,
    }, `Finish Entering Race ${raceId}`);
  } catch (err: any) {
    log.error({
      func: 'enterRace',
      raceAssignmentId: job?.data?.raceAssignmentId,
      transactionHash,
      txHashes,
      err,
    }, 'enterRace Error');

    if (raceAssignmentModel) {
      const { userWalletId, raceId, chickenId } = raceAssignmentModel;
      await RaceAssignment.sequelize.transaction(async (t) => {
        await updateRaceAssignment({
          chickenId,
          raceAssignmentModel,
          status: AssignmentStatus.Error,
          paidStatus: TransactionPaidStatus.Error,
          transactionHash,
          txHashes,
          errorMsg: err.message,
          transaction: t,
        });

        const raceContractAddress = await getRaceContractAddress();
        const raceModel = await Race.findByPk(raceId);

        await Transaction.create({
          fromAddress: userWalletId,
          toAddress: raceContractAddress,
          type: TransactionType.In,
          transactionHash,
          status: TransactionPaidStatus.Error,
          associatedObjectType: 'race',
          associatedObjectId: `${raceId}`,
          amount: raceModel.fee,
          tokenId: chickenId,
          category: TransactionCategory.RaceEnter,
        }, { transaction: t });
      });
    }

    await job.log(`enterRace Error ${err}`);
  }
};

const afterAutoEnterRace = async (raceAssignmentModel: RaceAssignment, {
  paidStatus,
  transactionHash,
  txHashes,
  fee,
}: {
  paidStatus: TransactionPaidStatus,
  transactionHash: string,
  txHashes: string[],
  fee: number,
}) => {
  const {
    raceId, chickenId, userWalletId,
  } = raceAssignmentModel;

  await Race.sequelize.transaction(async (t) => {
    await Race.update({
      paidStatus: TransactionPaidStatus.Unpaid,
    }, {
      where: {
        id: raceId,
        currentCapacity: {
          [Op.gte]: Sequelize.col('maxCapacity'),
        },
        paidStatus: TransactionPaidStatus.Error,
      },
      transaction: t,
    });

    const raceContractAddress = await getRaceContractAddress();

    await Transaction.create({
      fromAddress: userWalletId,
      toAddress: raceContractAddress,
      type: TransactionType.In,
      transactionHash,
      status: paidStatus,
      associatedObjectType: 'race',
      associatedObjectId: `${raceId}`,
      amount: fee,
      tokenId: chickenId,
      category: TransactionCategory.RaceEnter,
    }, { transaction: t });

    await updateRaceAssignment({
      raceAssignmentModel,
      status: AssignmentStatus.Success,
      paidStatus,
      transactionHash,
      txHashes,
      transaction: t,
    });
  });
};

const autoEnterRace = async (job: Job) => {
  const raceAssignments = await RaceAssignment.findAll({
    where: {
      type: RaceAssignmentType.AutoEnter,
      status: AssignmentStatus.Pending,
    },
    include: [{
      model: Race,
      where: {
        fee: {
          [Op.gt]: 0,
        },
      },
    }],
    order: [['id', 'ASC']],
    limit: config.RACE_SYNC_LIMIT,
  });

  if (raceAssignments.length === 0) {
    return;
  }

  await job.progress(0);
  await job.update({
    raceIdsToAutoEnter: raceAssignments.map((raceAssignment) => raceAssignment.raceId),
  });

  for (let i = 0; i < raceAssignments.length; i += 1) {
    const raceAssignmentModel = raceAssignments[i];
    const {
      id: raceAssignmentId, raceId, chickenId, userWalletId, race,
    } = raceAssignmentModel;

    let paidStatus = TransactionPaidStatus.Paid;

    const txHashes: string[] = [];
    let transactionHash: string = null;

    try {
      await new Promise((resolve, reject) => {
        enterWithAdmin(race, chickenId, userWalletId, {
          onTx: (txHash) => {
            transactionHash = txHash;
            txHashes.push(transactionHash);

            log.info({
              func: 'autoEnterRace',
              raceId,
              raceAssignmentId,
              chickenId,
              userWalletId,
              transactionHash,
              txHashes,
            }, `Auto Enter Race On txHash For Race ${raceId}`);
          },
          onReceipt: async (receipt) => {
            log.info({
              func: 'autoEnterRace',
              raceId,
              raceAssignmentId,
              chickenId,
              userWalletId,
              receipt,
              transactionHash,
              txHashes,
            }, `Auto Enter Race On receipt For Race ${raceId}`);

            resolve(receipt);
          },
          onError: async (err) => {
            await sleep(6000);

            // catch error and return undefined
            const successfulTransaction = await getSuccessfulTransactionHashAndReceipt(txHashes).catch((err2) => {
              log.error({
                func: 'autoEnterRace',
                raceId,
                raceAssignmentId,
                chickenId,
                userWalletId,
                transactionHash,
                txHashes,
                err: err2,
              }, `Auto Enter Race getSuccessfulTransactionHashAndReceipt Error For Race ${raceId}`);

              return null;
            });
            if (successfulTransaction?.txHash) {
              transactionHash = successfulTransaction.txHash;
            }

            // catch error and return undefined
            const isContractSuccess = await isContractEnterSuccess(race, chickenId).catch((err2) => {
              log.error({
                func: 'autoEnterRace',
                raceId,
                raceAssignmentId,
                chickenId,
                userWalletId,
                transactionHash,
                txHashes,
                err: err2,
              }, `Auto Enter Race isContractEnterSuccess Error For Race ${raceId}`);
            });

            log.error({
              func: 'autoEnterRace',
              raceId,
              raceAssignmentId,
              chickenId,
              userWalletId,
              isContractSuccess,
              transactionHash,
              txHashes,
              successfulTransaction,
              err,
            }, `Auto Enter Race On Error For Race ${raceId}`);

            let errorMsg = err.message;

            if (isContractSuccess || successfulTransaction) {
              // edge case: we are raising new transaction if the previous one is not mined within 1000 seconds
              // sometimes the previous transaction is mined while we are generating new one
              // so new one fails with the `Signer and signature do not match` error
              // in that case, we have to mark the transaction as completed because it's actually a successful transaction
              paidStatus = TransactionPaidStatus.Paid;

              resolve(successfulTransaction?.receipt);
              return;
            } if (errorMsg?.includes('Transaction was not mined within')) {
              paidStatus = TransactionPaidStatus.Postponed;

              resolve(null);
              return;
            }

            if (errorMsg?.includes('execution reverted: Signer and signature do not match')) {
              errorMsg += '\n This might be because your previous transaction was not minded yet. Please try again.';
            }

            reject(new Error(errorMsg));
          },
        });
      });

      await afterAutoEnterRace(raceAssignmentModel, {
        paidStatus,
        transactionHash,
        txHashes,
        fee: race.fee,
      });

      await job.progress((i / raceAssignments.length * 100).toFixed(20));

      log.info({
        func: 'autoEnterRace',
        raceId,
        raceAssignmentId,
        chickenId,
        userWalletId,
        transactionHash,
        txHashes,
      }, `Finish Auto Entering Race ${raceId}`);
    } catch (err) {
      log.error({
        func: 'autoEnterRace',
        raceId,
        raceAssignmentId,
        chickenId,
        userWalletId,
        transactionHash,
        txHashes,
        err,
      }, `Auto Enter Race Error For ${raceId}`);

      await job.log(`Auto Enter Race Error For ${raceId}, ${err}`);
    }

    // add some delay between payouts to overcome alchemy rate limit
    await sleep(6000);
  }
};

export const handleRaceAdminJobs = async (job: Job) => {
  // handle all race contract calls done by admin wallet in a single place, otherwise it will get the 'signer and signature mismatch' error
  try {
    await job.progress(0);

    const isDeployingSetting = await isDeploying();
    if (isDeployingSetting) {
      await job.progress(100);
      await job.log('Deployment is in progress, postpone handleRaceAdminJobs');

      log.info({
        func: 'handleRaceAdminJobs',
      }, 'Deployment is in progress, postpone handleRaceAdminJobs');

      return;
    }

    await payForUnpaidRaces(job);
    await autoEnterRace(job);
  } catch (err) {
    log.error({
      func: 'handleRaceAdminJobs',
      err,
    }, 'handleRaceAdminJobs Error');

    await job.log(`handleRaceAdminJobs Error ${err}`);
  }
};

const alertRaceFailure = async (raceModel: Race, description: string) => {
  // const text = `<!channel|channel> ${raceModel.name} (${raceModel.location}) might be stuck`;

  const contractRaceInfo = await getRaceContractRaceInfo(raceModel.id);
  const contractChickenIds = await getRaceContractChickenIds(raceModel.id);

  const title = `${raceModel.name} (${raceModel.location})`;
  const text = `<!channel|channel> ${title} ${description}`;

  const fields = [{
    title: 'Race ID',
    value: raceModel.id,
    short: true,
  }, {
    title: 'Race URL',
    value: `${config.frontendUrl}/race-detail/${raceModel.id}`,
    short: true,
  }, {
    title: 'Entry Fee',
    value: raceModel.fee,
    short: true,
  }, {
    title: 'Prize Pool',
    value: raceModel.prizePool,
    short: true,
  }, {
    title: 'Race Capacity',
    value: raceModel.currentCapacity,
    short: true,
  }, {
    title: 'Max Capacity',
    value: raceModel.maxCapacity,
    short: true,
  }, {
    title: 'Race Status',
    value: _.capitalize(raceModel.status),
    short: true,
  }, {
    title: 'Paid Status',
    value: _.capitalize(raceModel.paidStatus),
    short: true,
  }, {
    title: 'Contract Race Capacity',
    value: contractChickenIds.length,
    short: true,
  }, {
    title: 'Contract Paid Status',
    value: contractRaceInfo.isPaid ? 'Paid' : 'Unpaid',
    short: true,
  }];

  return postToSlack(title, 'raceAlert', {
    text,
    fields,
  });
};

const alertStuckRaces = async (job: Job) => {
  const redisClient = redisConnect();

  const racesToCheckStuck = await Race.findAll({
    where: {
      status: RaceStatus.Open,
      maxCapacity: {
        [Op.gte]: 3,
      },
      currentCapacity: {
        [Op.lt]: Sequelize.col('maxCapacity'),
      },
      fee: {
        [Op.gt]: 0,
      },
    },
    include: [{
      model: RaceAssignment,
      as: 'raceAssignments',
      where: {
        [Op.or]: [{
          status: {
            [Op.not]: AssignmentStatus.Pending,
          },
          updatedAt: {
            [Op.lte]: moment.utc().subtract(5, 'minutes').toDate(),
          },
        }, {
          status: AssignmentStatus.Pending,
          updatedAt: {
            [Op.lte]: moment.utc().subtract(30, 'minutes').toDate(),
          },
        }],
      },
    }],
  });

  const racesStuck = [];
  for (const raceModel of racesToCheckStuck) {
    const pendingAssignments = raceModel.raceAssignments.filter((raceAssignmentModel) => raceAssignmentModel.status === 'pending');
    const isNoPendingAssignment = pendingAssignments.length === 0;

    if (isNoPendingAssignment && raceModel.raceAssignments.length < raceModel.maxCapacity) {
      continue;
    }

    const isRaceAlerted = await redisGetAsync(`${config.alert.raceFailure}/${raceModel.id}`);
    if (isRaceAlerted) {
      continue;
    }

    if (isNoPendingAssignment) {
      const contractChickenIds = await getRaceContractChickenIds(raceModel.id);
      if (contractChickenIds.length < raceModel.maxCapacity) {
        continue;
      }
    }

    racesStuck.push(raceModel);
  }

  const jobData = {
    raceIdsStuck: racesStuck.map((raceModel) => raceModel.id),
  };
  await job.update(jobData);

  if (racesStuck.length) {
    log.info({
      func: 'alertStuckRaces',
      raceIdsStuck: jobData.raceIdsStuck,
    }, `Alerting ${racesStuck.length} Stuck Races`);

    for (let i = 0; i < racesStuck.length; i += 1) {
      const raceModel = racesStuck[i];
      await alertRaceFailure(raceModel, 'might be stuck!');

      redisClient.set(`${config.alert.raceFailure}/${raceModel.id}`, '1', 'EX', 24 * 3600); // 24 hours expiration

      await job.progress(((i + 1) / racesStuck.length * 100).toFixed(2));
    }

    log.info({
      func: 'alertStuckRaces',
      raceIdsStuck: jobData.raceIdsStuck,
    }, `Finished Alerting ${racesStuck.length} Stuck Races`);
  }
};

const alertPayoutDelay = async (job: Job) => {
  const redisClient = redisConnect();

  const racesToCheckPayoutDelay = await Race.findAll({
    where: {
      paidStatus: [TransactionPaidStatus.Unpaid, TransactionPaidStatus.Error],
      prizePool: {
        [Op.gt]: 0,
      },
      status: RaceStatus.Finished,
      endsAt: {
        [Op.lte]: moment.utc().subtract(30, 'minutes').toDate(),
      },
    },
    raw: true,
  });

  const racesDelayedPayout = [];
  for (const raceModel of racesToCheckPayoutDelay) {
    const isRaceAlerted = await redisGetAsync(`${config.alert.raceFailure}/${raceModel.id}`);
    if (isRaceAlerted) {
      continue;
    }

    racesDelayedPayout.push(raceModel);
  }

  const jobData = {
    raceIdsDelayedPayout: racesDelayedPayout.map((raceModel) => raceModel.id),
  };
  await job.update(jobData);

  if (racesDelayedPayout.length) {
    log.info({
      func: 'alertPayoutDelay',
      raceIdsDelayedPayout: jobData.raceIdsDelayedPayout,
    }, `Alerting ${racesDelayedPayout.length} Payout Delayed Races`);

    for (let i = 0; i < racesDelayedPayout.length; i += 1) {
      const raceModel = racesDelayedPayout[i];
      const { id: raceId, paidStatus } = raceModel;

      let message = 'has been delayed to pay out!';
      if (!isPrizePoolFine(raceModel)) {
        message = 'has been failed to pay out due to Prize Pool mismatch!';
      } else if (paidStatus === TransactionPaidStatus.Error) {
        message = 'has been failed to pay out!';
      }

      await alertRaceFailure(raceModel, message);

      redisClient.set(`${config.alert.raceFailure}/${raceId}`, '1', 'EX', 24 * 3600); // 24 hours expiration

      await job.progress(((i + 1) / racesDelayedPayout.length * 100).toFixed(2));
    }

    log.info({
      func: 'alertPayoutDelay',
      raceIdsDelayedPayout: jobData.raceIdsDelayedPayout,
    }, `Finished Alerting ${racesDelayedPayout.length} Payout Delayed Races`);
  }
};

export const alertFailedRaces = async (job: Job) => {
  try {
    await job.progress(0);

    await waitUntilBiconomyReady();

    await alertStuckRaces(job);
    await alertPayoutDelay(job);

    await job.progress(100);
  } catch (err) {
    log.error({
      func: 'alertFailedRaces',
      err,
    }, 'alertFailedRaces Error');

    await job.log(`alertFailedRaces Error ${err}`);
  }
};

export const resetChickenSituation = async (job: Job) => {
  try {
    await job.progress(0);

    const chickens = await Chicken.findAll({
      where: {
        situation: ChickenSituation.Cooldown,
        resetSituationAt: {
          [Op.lt]: moment.utc().toDate(),
        },
      },
    });

    const chickenIds = chickens.map((chicken) => chicken.id);

    log.info({
      func: resetChickenSituation.name,
      chickenIds,
    }, 'Reset Chicken Situation Start');

    await Chicken.update({
      situation: ChickenSituation.Barn,
      resetSituationAt: null,
    }, {
      where: {
        id: chickenIds,
      },
    });

    await job.update({
      chickenIds,
    });

    log.info({
      func: resetChickenSituation.name,
      chickenIds,
    }, 'Reset Chicken Situation End');

    await job.progress(100);
  } catch (err) {
    log.error({
      func: resetChickenSituation.name,
      err,
    }, 'Reset Chicken Situation Error');

    await job.log(`${resetChickenSituation.name} Error ${err}`);
  }
};

export const validatePartnerRace = (req: any) => {
  if ((req.user as User).roles.includes('admin')) {
    return;
  }

  const {
    peckingOrder,
    maxCapacity,
    type,
    group,
    fee,
    prizePool,
  } = req.body;

  if (!['S', 'A', 'B', 'C', 'D', 'E'].includes(peckingOrder)) {
    throw new Error('Invalid Pecking Order');
  }

  if (group && group !== 101) {
    throw new Error('Invalid Group');
  }

  if (type && type !== 'manual') {
    throw new Error('Invalid Type');
  }

  if (maxCapacity > 12 || maxCapacity < 4) {
    throw new Error('Invalid Max Capacity');
  }

  if (fee === 0 && prizePool > 0) {
    throw new Error('Free races couldn\'t have prize pool');
  }
};

export const setRaceScheduleAt = async (job: Job) => {
  try {
    const raceTimerDurationMinutes = await getRaceTimerDurationMinutes();
    if (!raceTimerDurationMinutes) {
      return;
    }

    await job.progress(0);

    const races = await Race.findAll({
      where: {
        status: RaceStatus.Open,
        scheduleAt: null,
        [Op.and]: [
          {
            currentCapacity: {
              [Op.gte]: config.MIN_CHICKENS_REQUIRED_TO_SCHEDULE,
            },
          },
          {
            currentCapacity: {
              [Op.lt]: Sequelize.col('maxCapacity'),
            },
          },
        ],
      },
    });

    const jobData = {
      raceIds: races.map((race) => race.id),
    };
    await job.update(jobData);

    if (!races.length) {
      await job.progress(100);

      return;
    }

    for (let i = 0; i < races.length; i += 1) {
      const race = races[i];

      await race.update({
        scheduleAt: moment.utc().add(raceTimerDurationMinutes, 'minutes').toDate(),
      });

      await job.progress(((i + 1) / races.length * 100).toFixed(2));
    }

    console.log({
      func: setRaceScheduleAt.name,
      raceIds: jobData.raceIds,
    }, `Set Schedule At For ${jobData.raceIds.length} Races Done`);

    await job.progress(100);
  } catch (err) {
    log.error({
      func: setRaceScheduleAt.name,
      err,
    }, 'Set Race Schedule At Error');

    await job.log(`${setRaceScheduleAt.name} Error ${err}`);
  }
};

export const getPositionType = (position: number) => {
  if (position === 1) {
    return PositionType.Win;
  }

  if ([2, 3].includes(position)) {
    return PositionType.Podium;
  }

  if (position === 4) {
    return PositionType.Show;
  }

  if (position === 5) {
    return PositionType.Miss;
  }

  return null;
};

export const getEligibleChickens = (userWalletId: string, race: Race, chickens: Chicken[]) => {
  const enteredCount = race.lanes.filter((lane) => lane.userWalletId === userWalletId).length;
  const maxChickensPerRace = race.fee > 0 ? config.MAX_CHICKENS_PER_PAID_RACE : config.MAX_CHICKENS_PER_FREE_RACE;

  if (!race.unlimitPO && enteredCount >= maxChickensPerRace) {
    return [];
  }

  if (race.peckingOrder === ChickenPeckingOrder.CHICK) {
    return chickens.filter((chicken) => (race.unlimitPO || chicken.chickRaces < config.CHICK_RACES_LIMIT) && chicken.situation === ChickenSituation.Barn);
  }

  return chickens.filter((chicken) => (race.unlimitPO || race.peckingOrder === chicken.peckingOrder) && chicken.situation === ChickenSituation.Barn);
};
