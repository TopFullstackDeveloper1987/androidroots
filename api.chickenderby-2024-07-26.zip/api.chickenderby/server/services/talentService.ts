import * as _ from 'lodash';

// Utils
import { log, findNthIndex, getRandomValueIndexFromWeight } from '../utils';
import { PIXELS_PER_METER } from '../utils/constants';

// Models
import { Race } from '../sequelize/models/Race';
import { Chicken } from '../sequelize/models/Chicken';

// Types
import { MasterSegment } from '../types/races/masterSegment';
import { RaceProfile } from '../types/races/raceProfile';
import { Segment } from '../types/races/segment';
import { TerrainName } from '../types/terrains/terrainName';
import { ChickenTalentPreference } from '../types/chickens/chickenTalentPreference';
import { ChickenBeakAccessory } from '../types/chickens/chickenBeakAccessory';
import { ChickenTalent } from '../types/chickens/chickenTalent';
import { ChickenEyesType } from '../types/chickens/chickenEyesType';
import { ChickenBaseBody } from '../types/chickens/chickenBaseBody';
import { ChickenBeakColor } from '../types/chickens/chickenBeakColor';
import { ChickenWattleColor } from '../types/chickens/chickenWattleColor';
import { ChickenLegs } from '../types/chickens/chickenLegs';
import { ChickenCombColorAdditional } from '../types/chickens/chickenCombColor';
import { ValueWeightPair } from '../types/shared/valueWeight';

// https://docs.google.com/document/d/1nmb9Rqia81elVZFQ7JCOfRMpULtEwCi_pbvcWOMLVTQ/edit#heading=h.z2pcnxelw34k
// https://docs.google.com/spreadsheets/d/15KvWSY0pgJmDeej9M83DmZki2TOJyLpu4KewZ0bT9cc/edit#gid=1304509290

const TALENTS = [
  ChickenTalent.Anvil,
  ChickenTalent.BlueRooster,
  ChickenTalent.Chickenapult,
  ChickenTalent.CK47,
  ChickenTalent.Coober,
  ChickenTalent.Flight,
  ChickenTalent.Growth,
  ChickenTalent.Machete,
  ChickenTalent.Rollerblades,
  ChickenTalent.Teleport,
  ChickenTalent.BlueEgg,
  ChickenTalent.Dig,
  ChickenTalent.FanGroup,
  ChickenTalent.Helicopter,
  ChickenTalent.Jetpack,
  ChickenTalent.ColdSnap,
  ChickenTalent.Devolution,
  ChickenTalent.MovingWalkway,
  ChickenTalent.BlackHole,
  ChickenTalent.RoyalProcession,
  ChickenTalent.FeatherRain,
  ChickenTalent.RunicRush,
];

export const OFFENSIVE_TALENTS = [
  ChickenTalent.Anvil,
  ChickenTalent.BlackHole,
  ChickenTalent.BlueEgg,
  ChickenTalent.ColdSnap,
  ChickenTalent.CK47,
  ChickenTalent.Devolution,
  ChickenTalent.Helicopter,
  ChickenTalent.Machete,
  ChickenTalent.Teleport,
  ChickenTalent.FeatherRain,
];

export const SPEED_TALENTS = [
  ChickenTalent.BlueRooster,
  ChickenTalent.Chickenapult,
  ChickenTalent.Coober,
  ChickenTalent.Dig,
  ChickenTalent.FanGroup,
  ChickenTalent.Flight,
  ChickenTalent.Growth,
  ChickenTalent.Jetpack,
  ChickenTalent.MovingWalkway,
  ChickenTalent.Rollerblades,
  ChickenTalent.RoyalProcession,
  ChickenTalent.RunicRush,
];

const TRANSLUCENT_BODIES = [
  ChickenBaseBody.TranslucentRed,
  ChickenBaseBody.TranslucentPurple,
  ChickenBaseBody.TranslucentGreen,
  ChickenBaseBody.TranslucentYellow,
];

interface ChickenForTalent {
  source: Partial<Chicken>;
  targets: Partial<Chicken>[];
}

const getNumberOfTalents = (distance: number) => {
  // ┌─────┬──────────────┬───────────┬───────────────┬───────────────────┐
  // │  #  │   distance   │   r = 1   │   r = 2 or 3  │   r = 4 or 5 or 6 │
  // ├─────┼──────────────┼───────────┼───────────────┼───────────────────┤
  // │  1  │     100m     │     2     │       1       │         2         │
  // ├─────┼──────────────┼───────────┼───────────────┼───────────────────┤
  // │  2  │     120m     │     3     │       2       │         2         │
  // ├─────┼──────────────┼───────────┼───────────────┼───────────────────┤
  // │  3  │     140m     │     4     │       3       │         2         │
  // ├─────┼──────────────┼───────────┼───────────────┼───────────────────┤
  // │  4  │     160m     │     4     │       3       │         3         │
  // ├─────┼──────────────┼───────────┼───────────────┼───────────────────┤
  // │  5  │     180m     │     5     │       4       │         3         │
  // ├─────┼──────────────┼───────────┼───────────────┼───────────────────┤
  // │  6  │     200m     │     3     │       5       │         4         │
  // └─────┴──────────────┴───────────┴───────────────┴───────────────────┘

  const minR = 1;
  const maxR = 6;
  const r = Math.round(Math.random() * (maxR - minR) + minR);

  let numberOfTalents = 0;

  switch (distance) {
    case 100:
      if (r < 2) {
        numberOfTalents = 2;
      } else if (r >= 2 && r <= 3) {
        numberOfTalents = 1;
      } else {
        numberOfTalents = 2;
      }
      break;
    case 120:
      if (r < 2) {
        numberOfTalents = 3;
      } else if (r >= 2 && r <= 3) {
        numberOfTalents = 2;
      } else {
        numberOfTalents = 2;
      }
      break;
    case 140:
      if (r < 2) {
        numberOfTalents = 4;
      } else if (r >= 2 && r <= 3) {
        numberOfTalents = 3;
      } else {
        numberOfTalents = 2;
      }
      break;
    case 160:
      if (r < 2) {
        numberOfTalents = 4;
      } else if (r >= 2 && r <= 3) {
        numberOfTalents = 3;
      } else {
        numberOfTalents = 3;
      }
      break;
    case 180:
      if (r < 2) {
        numberOfTalents = 5;
      } else if (r >= 2 && r <= 3) {
        numberOfTalents = 4;
      } else {
        numberOfTalents = 3;
      }
      break;
    case 200:
      if (r < 2) {
        numberOfTalents = 3;
      } else if (r >= 2 && r <= 3) {
        numberOfTalents = 5;
      } else {
        numberOfTalents = 4;
      }
      break;
    default:
      break;
  }

  return numberOfTalents; // 1 for testing purpose
};

const getTalentWeight = (chicken: Partial<Chicken>) => {
  // ┌─────┬────────────────────┬───────────────┬─────────────────┐
  // │  #  │  talent            │ talentType    │ talentWeight    │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  1  │  Anvil             │ Weapon        │ 5               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  2  │  Blue Rooster      │ Magic         │ 3               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  3  │  Chickenapult      │ Technology    │ 3               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  4  │  CK-47             │ Weapon        │ 4               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  5  │  Coober            │ Technology    │ 3               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  6  │  Flight?           │ Spirit        │ 3               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  7  │  Growth            │ Magic         │ 3               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  8  │  Machete           │ Weapon        │ 4               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  9  │  Rollerblades      │ Spirit        │ 2               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  10 │  Teleport          │ Technology    │ 3               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  11 │  Blue Egg          │ Weapon        │ 5               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  12 │  Dig               │ Spirit        │ 3               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  13 │  Fan Group         │ Spirit        │ 3               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  14 │  Helicopter        │ Weapon        │ 4               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  15 │  Jetpack           │ Technology    │ 3               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  16 │  Cold Snap         │ Magic         │ 4               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  17 │  Devolution        │ Magic         │ 4               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  18 │  Moving Walkway    │ Technology    │ 3               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  19 │  Black Hole        │ Magic         │ 2               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  20 │  Royal Procession  │ Spirit        │ 2               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  21 │  Feather Rain      │ Weapon        │ 2               │
  // ├─────┼────────────────────┼───────────────┼─────────────────┤
  // │  22 │  Runic Rush        │ Magic         │ 2               │
  // └─────┴────────────────────┴───────────────┴─────────────────┘

  const talents: {
    [talent in ChickenTalent]: {
      talentType: ChickenTalentPreference,
      talentWeight: number,
    }
  } = {
    [ChickenTalent.Anvil]: {
      talentType: ChickenTalentPreference.Weapon,
      talentWeight: 5,
    },
    [ChickenTalent.BlueRooster]: {
      talentType: ChickenTalentPreference.Magic,
      talentWeight: 3,
    },
    [ChickenTalent.Chickenapult]: {
      talentType: ChickenTalentPreference.Technology,
      talentWeight: 3,
    },
    [ChickenTalent.CK47]: {
      talentType: ChickenTalentPreference.Weapon,
      talentWeight: 4,
    },
    [ChickenTalent.Coober]: {
      talentType: ChickenTalentPreference.Technology,
      talentWeight: 3,
    },
    [ChickenTalent.Flight]: {
      talentType: ChickenTalentPreference.Spirit,
      talentWeight: 3,
    },
    [ChickenTalent.Growth]: {
      talentType: ChickenTalentPreference.Magic,
      talentWeight: 3,
    },
    [ChickenTalent.Machete]: {
      talentType: ChickenTalentPreference.Weapon,
      talentWeight: 4,
    },
    [ChickenTalent.Rollerblades]: {
      talentType: ChickenTalentPreference.Spirit,
      talentWeight: 2,
    },
    [ChickenTalent.Teleport]: {
      talentType: ChickenTalentPreference.Technology,
      talentWeight: 3,
    },
    [ChickenTalent.BlueEgg]: {
      talentType: ChickenTalentPreference.Weapon,
      talentWeight: 5,
    },
    [ChickenTalent.Dig]: {
      talentType: ChickenTalentPreference.Spirit,
      talentWeight: 3,
    },
    [ChickenTalent.FanGroup]: {
      talentType: ChickenTalentPreference.Spirit,
      talentWeight: 3,
    },
    [ChickenTalent.Helicopter]: {
      talentType: ChickenTalentPreference.Weapon,
      talentWeight: 4,
    },
    [ChickenTalent.Jetpack]: {
      talentType: ChickenTalentPreference.Technology,
      talentWeight: 3,
    },
    [ChickenTalent.ColdSnap]: {
      talentType: ChickenTalentPreference.Magic,
      talentWeight: 4,
    },
    [ChickenTalent.Devolution]: {
      talentType: ChickenTalentPreference.Magic,
      talentWeight: 4,
    },
    [ChickenTalent.MovingWalkway]: {
      talentType: ChickenTalentPreference.Technology,
      talentWeight: 3,
    },
    [ChickenTalent.BlackHole]: {
      talentType: ChickenTalentPreference.Magic,
      talentWeight: 2,
    },
    [ChickenTalent.RoyalProcession]: {
      talentType: ChickenTalentPreference.Spirit,
      talentWeight: 2,
    },
    [ChickenTalent.FeatherRain]: {
      talentType: ChickenTalentPreference.Weapon,
      talentWeight: 2,
    },
    [ChickenTalent.RunicRush]: {
      talentType: ChickenTalentPreference.Magic,
      talentWeight: 2,
    },
  };

  const talentTypeAndWeight = talents[chicken.talent];
  if (talentTypeAndWeight?.talentType === chicken.talentPreference) {
    talentTypeAndWeight.talentWeight += chicken.talentPreferenceStrength;
  }

  if (!talentTypeAndWeight?.talentWeight) {
    throw new Error(
      `Invalid talentWeight for chicken - ${chicken.id} (${chicken.talent}, ${chicken.talentPreference}, ${chicken.talentPreferenceStrength})`,
    );
  }

  return talentTypeAndWeight.talentWeight;
};

export const isTranslucentBody = (baseBody: ChickenBaseBody) => TRANSLUCENT_BODIES.includes(baseBody);
export const isOffensiveTalent = (talent: ChickenTalent) => OFFENSIVE_TALENTS.includes(talent);
export const isSpeedTalent = (talent: ChickenTalent) => SPEED_TALENTS.includes(talent);

// Chickens with translucent bodies are 50% less likely to be targeted for offensive talents
const getValueWeightsForTargetChickens = (chickens: Partial<Chicken>[]): ValueWeightPair<Number>[] => chickens.map((chicken) => ({
  value: chicken.id,
  weight: isTranslucentBody(chicken.baseBody) ? 1 : 2,
}));

const getChickensWithSpecialTalents = (chickens: Partial<Chicken>[]) => {
  return _.cloneDeep(
    chickens
      .filter((chicken) => [ChickenBaseBody.Plucked, ChickenBaseBody.Runic].includes(chicken.baseBody))
      .map((chicken) => ({
        ...chicken,
        talent: chicken.baseBody === ChickenBaseBody.Plucked ? ChickenTalent.FeatherRain : ChickenTalent.RunicRush,
      })),
  );
};

export const getChickensForTalent = (raceModel: Race, chickens: Partial<Chicken>[]) => {
  const numberOfTalents = getNumberOfTalents(raceModel.distance);
  const chickensToPerformTalent: {
    source: Partial<Chicken>,
    targets: Partial<Chicken>[],
  }[] = [];

  for (let i = 0; i < numberOfTalents; i += 1) {
    let minTalentChance = 0;
    let maxTalentChance = 0;
    const talentChances = [];
    let totalTalentWeight = 0;
    // deep copy on every talent loop, treat a chicken with special talents with 2 chickens - one with a normal talent, another with a speical talent
    const chickensWithNormalTalents = _.cloneDeep(chickens);
    const chickensWithSpecialTalents = getChickensWithSpecialTalents(chickens);
    const chickensForTalent = chickensWithNormalTalents.concat(chickensWithSpecialTalents);

    for (const chicken of chickensForTalent) {
      const talentWeight = getTalentWeight(chicken);
      minTalentChance = maxTalentChance;
      maxTalentChance = minTalentChance + talentWeight;

      talentChances.push({
        minTalentChance,
        maxTalentChance,
      });

      totalTalentWeight += talentWeight;
    }

    const talentNumber = Math.random() * totalTalentWeight;
    const talentIndex = talentChances.findIndex(
      (talentChance) => talentNumber >= talentChance.minTalentChance && talentNumber < talentChance.maxTalentChance,
    );

    log.info({
      func: 'getChickensForTalent',
      raceId: raceModel.id,
      totalTalentWeight,
      talentNumber,
      talentIndex,
      talentChances,
    }, 'After Getting Talent Chances');

    if (talentIndex > -1) {
      const source = chickensForTalent[talentIndex];
      const chickensForTarget = chickensWithNormalTalents.filter((chicken) => chicken.id !== source.id);
      const targets = [];

      switch (source.talent) {
        case ChickenTalent.Anvil:
          {
            const selfAnvilChance = source.talentPreference === ChickenTalentPreference.Weapon ? 0 : Math.random() < 0.01; // 1% chance
            if (selfAnvilChance) {
              targets.push(source);
            } else {
              const valueWeights = getValueWeightsForTargetChickens(chickensForTarget);
              const targetIndex = getRandomValueIndexFromWeight(valueWeights);
              if (chickensForTarget[targetIndex]) {
                targets.push(chickensForTarget.splice(targetIndex, 1)[0]);
              }
            }
          }
          break;

        case ChickenTalent.ColdSnap:
          {
            const terrainBonus = raceModel.terrain.name === TerrainName.Snow ? 1 : 0;
            const magicBonus = source.talentPreference === ChickenTalentPreference.Magic ? 1 : 0;
            const numberOfTargetChickens = Math.min(5 + terrainBonus + magicBonus, chickensForTarget.length);
            for (let j = 0; j < numberOfTargetChickens; j += 1) {
              const valueWeights = getValueWeightsForTargetChickens(chickensForTarget);
              const targetIndex = getRandomValueIndexFromWeight(valueWeights);
              if (chickensForTarget[targetIndex]) {
                targets.push(chickensForTarget.splice(targetIndex, 1)[0]);
              }
            }
          }
          break;

        case ChickenTalent.Flight:
          {
            const successfulFlightChance = source.talentPreference === ChickenTalentPreference.Spirit ? 1 : 0.75;
            (source as any).successfulFlight = Math.random() < successfulFlightChance;
          }
          break;

        case ChickenTalent.CK47:
          {
            // filter out unassigned lanes
            const lanes = raceModel.lanes.filter(lane => lane.chickenId);

            const sourceChickenLane = lanes.find((laneModel) => laneModel.chickenId === source.id);
            const { laneNumber, userWalletId } = sourceChickenLane;

            const adjacentChickensList = [];
            const adjacentListWithDifferentOwner = [];

            for (let j = 1; j <= lanes.length - 1; j += 1) {
              if (j !== laneNumber && j + 1 !== laneNumber) {
                const targetChickenLaneJ = lanes.find((laneModel) => laneModel.laneNumber === j);
                const targetIndexJ = chickensForTarget.findIndex((chicken) => chicken.id === targetChickenLaneJ.chickenId);

                const targetChickenLaneJ1 = lanes.find((laneModel) => laneModel.laneNumber === j + 1);
                const targetIndexJ1 = chickensForTarget.findIndex((chicken) => chicken.id === targetChickenLaneJ1.chickenId);

                if (targetIndexJ > -1 && targetIndexJ1 > -1) {
                  adjacentChickensList.push([
                    chickensForTarget[targetIndexJ],
                    chickensForTarget[targetIndexJ1],
                  ]);

                  if (![targetChickenLaneJ.userWalletId, targetChickenLaneJ1.userWalletId].includes(userWalletId)) {
                    adjacentListWithDifferentOwner.push([
                      chickensForTarget[targetIndexJ],
                      chickensForTarget[targetIndexJ1],
                    ]);
                  }
                }
              }
            }

            const filteredList = adjacentListWithDifferentOwner.length > 0 ? adjacentListWithDifferentOwner : adjacentChickensList;
            const valueWeights: ValueWeightPair<Number>[] = filteredList.map(
              (adjacentChickens, index) => adjacentChickens.some(
                (chicken) => isTranslucentBody(chicken.baseBody),
              ) ? { value: index, weight: 1 } : { value: index, weight: 2 },
            );
            const targetIndex = getRandomValueIndexFromWeight(valueWeights);
            const adjacentChickens = filteredList[targetIndex];
            if (adjacentChickens) {
              targets.push(...adjacentChickens);
            }
          }
          break;

        case ChickenTalent.Machete:
          {
            const numberOfTargetChickens = Math.min(raceModel.terrain.name === TerrainName.Grass ? 4 : 3, chickensForTarget.length);
            for (let j = 0; j < numberOfTargetChickens; j += 1) {
              const valueWeights = getValueWeightsForTargetChickens(chickensForTarget);
              const targetIndex = getRandomValueIndexFromWeight(valueWeights);
              if (chickensForTarget[targetIndex]) {
                targets.push(chickensForTarget.splice(targetIndex, 1)[0]);
              }
            }
          }
          break;

        case ChickenTalent.Teleport:
          {
            const teleportSelfChance = source.talentPreference === ChickenTalentPreference.Technology ? 1 : 0.5;
            const isTeleportSelf = Math.random() < teleportSelfChance;

            if (isTeleportSelf) {
              targets.push(source);
            } else {
              const valueWeights = getValueWeightsForTargetChickens(chickensForTarget);
              const targetIndex = getRandomValueIndexFromWeight(valueWeights);
              if (chickensForTarget[targetIndex]) {
                targets.push(chickensForTarget.splice(targetIndex, 1)[0]);
              }
            }
          }
          break;

        case ChickenTalent.BlueEgg:
          {
            const numberOfTargetChickens = source.eyesType === ChickenEyesType.Buttons ? 2 : 1;
            const blueEggTargets = _.flatten(chickensToPerformTalent.map(({ source, targets }) => targets));
            let filteredChickens = chickensForTarget.filter((chicken) => !blueEggTargets.find((target) => target.id === chicken.id));

            if (filteredChickens.length < numberOfTargetChickens) {
              filteredChickens = chickensForTarget;
            }

            for (let j = 0; j < numberOfTargetChickens; j += 1) {
              const valueWeights = getValueWeightsForTargetChickens(filteredChickens);
              const targetIndex = getRandomValueIndexFromWeight(valueWeights);
              if (filteredChickens[targetIndex]) {
                const target = filteredChickens.splice(targetIndex, 1)[0];
                targets.push(target);
              }
            }
          }
          break;

        case ChickenTalent.Helicopter:
          {
            const numberOfChickensHit = source.eyesType === ChickenEyesType.Eyepatch ? 3 : 2;
            for (let j = 0; j < numberOfChickensHit; j += 1) {
              const valueWeights = getValueWeightsForTargetChickens(chickensForTarget);
              const targetIndex = getRandomValueIndexFromWeight(valueWeights);
              if (chickensForTarget[targetIndex]) {
                targets.push(chickensForTarget.splice(targetIndex, 1)[0]);
              }
            }
          }
          break;

        case ChickenTalent.BlackHole:
          chickensForTarget.forEach((chicken) => {
            if (!isTranslucentBody(chicken.baseBody)) {
              targets.push(chicken);
            } else if (Math.random() < 0.5) {
              targets.push(chicken);
            }
          });
          break;

        case ChickenTalent.Devolution:
          {
            const numberOfTargetChickens = 2;
            for (let j = 0; j < numberOfTargetChickens; j += 1) {
              const valueWeights = getValueWeightsForTargetChickens(chickensForTarget);
              const targetIndex = getRandomValueIndexFromWeight(valueWeights);
              if (chickensForTarget[targetIndex]) {
                targets.push(chickensForTarget.splice(targetIndex, 1)[0]);
              }
            }
          }
          break;

        case ChickenTalent.FeatherRain:
          {
            const numberOfTargetChickens = source.beakAccessory === ChickenBeakAccessory.Vampire ? 7 : 6;
            for (let j = 0; j < numberOfTargetChickens; j += 1) {
              const valueWeights = getValueWeightsForTargetChickens(chickensForTarget);
              const targetIndex = getRandomValueIndexFromWeight(valueWeights);
              if (chickensForTarget[targetIndex]) {
                targets.push(chickensForTarget.splice(targetIndex, 1)[0]);
              }
            }
          }
          break;

        default:
          break;
      }

      chickensToPerformTalent.push({
        source,
        targets,
      });
    }
  }

  log.info({
    func: 'getChickensForTalent',
    raceId: raceModel.id,
    numberOfTalents,
    chickensToPerformTalent,
  }, 'After Getting Chickens For Talent');

  if (chickensToPerformTalent.length !== numberOfTalents) {
    throw new Error('Number of chickens to perform talent should be equivalent to the total number of talents');
  }

  return chickensToPerformTalent;
};

export const getTalentPerformance = (raceModel: Race, chicken: Partial<Chicken>, chickensToPerformTalent: ChickenForTalent[]) => {
  const {
    id: chickenId,
  } = chicken;

  let talentPerformance = 0;

  for (const chickenForTalent of chickensToPerformTalent) {
    const { source, targets } = chickenForTalent;

    const isSource = source.id === chickenId;
    const isTarget = targets.find((target) => target.id === chickenId);

    if (!isSource && !isTarget) {
      continue;
    }

    const { talent } = source;

    switch (talent) {
      case ChickenTalent.Anvil:
        if (isTarget) {
          talentPerformance -= 8.0;

          if (raceModel.terrain.name === TerrainName.Rock) {
            talentPerformance -= 2.0;
          }

          if (source.beakAccessory === ChickenBeakAccessory.Vampire) {
            talentPerformance -= 1.0;
          }

          if (chicken.beakAccessory === ChickenBeakAccessory.Ring) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.BlueRooster:
        if (isSource) {
          talentPerformance += 1.0;
          if (raceModel.terrain.name === TerrainName.Track) {
            talentPerformance += 0.5;
          }
        }
        break;

      case ChickenTalent.Chickenapult:
        if (isSource) {
          talentPerformance += 1.0;

          if (source.baseBody === ChickenBaseBody.Robot) {
            talentPerformance += 1.0;
          }

          if (source.eyesType === ChickenEyesType.Cyclops) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.CK47:
        if (isTarget) {
          talentPerformance -= 4.0;

          if (source.eyesType === ChickenEyesType.Eyepatch) {
            talentPerformance -= 1.0;
          }

          if (source.beakAccessory === ChickenBeakAccessory.Vampire) {
            talentPerformance -= 1.0;
          }

          if (chicken.beakAccessory === ChickenBeakAccessory.Ring) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.Coober:
        if (isSource) {
          talentPerformance += 1.0;

          if (raceModel.terrain.name === TerrainName.Road) {
            talentPerformance += 0.5;
          }

          if (source.baseBody === ChickenBaseBody.Robot) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.Flight:
        if (isSource && (source as any).successfulFlight) {
          talentPerformance += 1.3;
          if (source.eyesType === ChickenEyesType.Owl) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.Growth:
        if (isSource) {
          talentPerformance += 1.0;
          if (source.eyesType === ChickenEyesType.Lizard) {
            talentPerformance += 0.5;
          }
        }
        break;

      case ChickenTalent.Machete:
        if (isTarget) {
          talentPerformance -= 2.4;

          if (source.beakAccessory === ChickenBeakAccessory.Vampire) {
            talentPerformance -= 1.0;
          }

          if (chicken.beakAccessory === ChickenBeakAccessory.Ring) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.Rollerblades:
        if (isSource) {
          talentPerformance += 0.8;
        }
        break;

      case ChickenTalent.Teleport:
        // Teleport Self
        if (isSource && isTarget) {
          talentPerformance += 2.0;

          if (source.eyesType === ChickenEyesType.Alien) {
            talentPerformance += 0.5;
          }

          if (source.baseBody === ChickenBaseBody.Robot) {
            talentPerformance += 1.0;
          }
        } else if (isTarget) {
          talentPerformance -= 2.0;

          if (source.beakAccessory === ChickenBeakAccessory.Vampire) {
            talentPerformance -= 1.0;
          }

          if (source.eyesType === ChickenEyesType.Alien) {
            talentPerformance -= 1.0;
          }

          if (source.baseBody === ChickenBaseBody.Robot) {
            talentPerformance -= 1.0;
          }

          if (chicken.beakAccessory === ChickenBeakAccessory.Ring) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.BlueEgg:
        if (isTarget) {
          talentPerformance -= 12.5;

          if (source.beakAccessory === ChickenBeakAccessory.Vampire) {
            talentPerformance -= 2.0;
          }

          if (chicken.beakAccessory === ChickenBeakAccessory.Ring) {
            talentPerformance += 2.0;
          }
        }
        break;

      case ChickenTalent.Dig:
        if (isSource) {
          talentPerformance += 1.9;
          if (raceModel.terrain.name === TerrainName.Dirt) {
            talentPerformance += 0.5;
          }
        }
        break;

      case ChickenTalent.FanGroup:
        if (isSource) {
          talentPerformance += 1.9;

          if (source.eyesType === ChickenEyesType.Buttons) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.Helicopter:
        if (isSource) {
          talentPerformance += 0.7;
        } else if (isTarget) {
          talentPerformance -= 4.0;

          if (source.beakAccessory === ChickenBeakAccessory.Vampire) {
            talentPerformance -= 1.0;
          }

          if (chicken.beakAccessory === ChickenBeakAccessory.Ring) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.Jetpack:
        if (isSource) {
          talentPerformance += 1.9;

          if (source.baseBody === ChickenBaseBody.Robot) {
            talentPerformance += 1.0;
          }

          if (source.eyesType === ChickenEyesType.Cyclops) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.ColdSnap:
        if (isTarget) {
          talentPerformance -= 4.3;

          if (source.beakAccessory === ChickenBeakAccessory.Vampire) {
            talentPerformance -= 1.0;
          }

          if (chicken.beakAccessory === ChickenBeakAccessory.Ring) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.Devolution:
        if (isSource) {
          talentPerformance += 1.61;

          if (source.eyesType === ChickenEyesType.Lizard) {
            talentPerformance += 0.5;
          }
        } else if (isTarget) {
          talentPerformance -= 2.9;

          if (source.beakAccessory === ChickenBeakAccessory.Vampire) {
            talentPerformance -= 1.0;
          }

          if (chicken.beakAccessory === ChickenBeakAccessory.Ring) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.MovingWalkway:
        if (isSource) {
          talentPerformance += 2.85;

          if (raceModel.terrain.name === TerrainName.Sand) {
            talentPerformance += 0.5;
          }

          if (source.baseBody === ChickenBaseBody.Robot) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.BlackHole:
        if (isTarget) {
          talentPerformance -= 5.7;
        }
        break;

      case ChickenTalent.RoyalProcession:
        if (isSource) {
          talentPerformance += 5.7;
          if (source.eyesType === ChickenEyesType.Owl) {
            talentPerformance += 1.0;
          }
        }
        break;

      case ChickenTalent.FeatherRain:
        if (isTarget) {
          talentPerformance -= 7.85;
          if (chicken.beakAccessory === ChickenBeakAccessory.Ring) {
            talentPerformance += 2.0;
          }
        }
        break;

      case ChickenTalent.RunicRush:
        if (isSource) {
          talentPerformance += 4.27;
        }
        break;

      default:
        break;
    }
  }

  log.info({
    func: 'getTalentPerformance',
    raceId: raceModel.id,
    chickenId,
    talentPerformance,
  }, 'After Getting Talent Performance');

  return talentPerformance;
};

const getSingleSegmentAndLock = (
  raceModel: Race,
  masterSegments: MasterSegment[],
  raceProfile: RaceProfile,
  {
    talent,
    segmentSizeMin = 0,
    segmentSizeMax = 9999,
    isExcludeLastSegment = true,
  }: {
    talent?: string,
    segmentSizeMin?: number,
    segmentSizeMax?: number,
    isExcludeLastSegment?: boolean,
  } = {}) => {
  const segmentList = [];
  const { segments } = raceProfile;

  const length = isExcludeLastSegment ? segments.length - 1 : segments.length;
  for (let i = 0; i < length; i += 1) {
    const segmentA = segments[i];
    const masterSegmentA = masterSegments.find((ms) => ms.segment === segmentA.segment);

    // talent segments don't have segment initially so there is no corresponding master segment
    if (!masterSegmentA) {
      continue;
    }

    const isMasterSegmentsUnlocked = !masterSegmentA.segmentLocked;
    const isSegmentSizeOk = segmentA.segmentSize >= segmentSizeMin && segmentA.segmentSize <= segmentSizeMax;

    if (isMasterSegmentsUnlocked && isSegmentSizeOk) {
      segmentList.push(segmentA.segment);
    }
  }

  if (segmentList.length === 0) {
    log.info({
      func: 'getSingleSegmentAndLock',
      raceId: raceModel.id,
      masterSegments,
      raceProfile,
      segmentSizeMin,
      segmentSizeMax,
    }, 'There is no available master segments');

    return null;
  }

  const index = Math.floor(Math.random() * segmentList.length);
  const selectedSegment = segmentList[index];

  // lock masterSegments
  masterSegments.forEach((ms) => {
    if (selectedSegment === ms.segment) {
      ms.segmentLocked = talent;
    }
  });

  log.info({
    func: 'getSingleSegmentAndLock',
    raceId: raceModel.id,
    selectedSegment,
    masterSegments,
    raceProfile,
    segmentSizeMin,
    segmentSizeMax,
  }, 'Get Single Segment And Lock Success');

  return selectedSegment;
};

const getTwoAdjacentSegmentsAndLock = (raceModel: Race, masterSegments: MasterSegment[], raceProfile: RaceProfile, {
  talent,
  firstSegmentSizeMin = 0,
  firstSegmentSizeMax = 9999,
  firstSegmentIndexMin = 1, // segment index starts from 1
  secondSegmentSizeMin = 0,
  secondSegmentSizeMax = 9999,
  secondSegmentIndexMin = 1, // segment index starts from 1
  cumulativeSegmentSizeMin = 0,
  cumulativeSegmentSizeMax = 9999,
  isExcludeLastSegment = true,
  isExcludeSecondLastSegment = false,
  isExcludeAdjacentTalentSegments = false,
}: {
  talent?: string,
  firstSegmentSizeMin?: number,
  firstSegmentSizeMax?: number,
  firstSegmentIndexMin?: number, // segment index starts from 1
  secondSegmentSizeMin?: number,
  secondSegmentSizeMax?: number,
  secondSegmentIndexMin?: number, // segment index starts from 1
  cumulativeSegmentSizeMin?: number,
  cumulativeSegmentSizeMax?: number,
  isExcludeLastSegment?: boolean,
  isExcludeSecondLastSegment?: boolean,
  isExcludeAdjacentTalentSegments?: boolean,
} = {}) => {
  const adjacentSegmentList = [];
  const { segments } = raceProfile;

  let length = isExcludeLastSegment ? segments.length - 2 : segments.length - 1;
  length = isExcludeSecondLastSegment ? segments.length - 3 : length;

  for (let i = 0; i < length; i += 1) {
    const segmentA = segments[i];
    const segmentB = segments[i + 1];
    const segmentA1 = segments[i - 1];
    const segmentB1 = segments[i + 2];
    const masterSegmentA = masterSegments.find((ms) => ms.segment === segmentA.segment);
    const masterSegmentB = masterSegments.find((ms) => ms.segment === segmentB.segment);
    const masterSegmentA1 = segmentA1 && masterSegments.find((ms) => ms.segment === segmentA1.segment);
    const masterSegmentB1 = segmentB1 && masterSegments.find((ms) => ms.segment === segmentB1.segment);

    // talent segments don't have segment initially so there is no corresponding master segment
    if (!masterSegmentA || !masterSegmentB) {
      continue;
    }

    const isMasterSegmentsUnlocked = !masterSegmentA.segmentLocked && !masterSegmentB.segmentLocked;
    const cumulativeSegmentSize = segmentA.segmentSize + segmentB.segmentSize;
    const isSegmentSizeOk = cumulativeSegmentSize >= cumulativeSegmentSizeMin && cumulativeSegmentSize <= cumulativeSegmentSizeMax
      && segmentA.segmentSize >= firstSegmentSizeMin && segmentA.segmentSize <= firstSegmentSizeMax && segmentA.segment >= firstSegmentIndexMin
      && segmentB.segmentSize >= secondSegmentSizeMin && segmentB.segmentSize <= secondSegmentSizeMax && segmentB.segment >= secondSegmentIndexMin;
    const isAdjacentSegmentsOk = !isExcludeAdjacentTalentSegments
      || ((!masterSegmentA1 || masterSegmentA1.segmentLocked !== talent) && (!masterSegmentB1 || masterSegmentB1.segmentLocked !== talent));

    if (isMasterSegmentsUnlocked && isSegmentSizeOk && isAdjacentSegmentsOk) {
      adjacentSegmentList.push([segmentA.segment, segmentB.segment]);
    }
  }

  if (adjacentSegmentList.length === 0) {
    log.info({
      func: 'getTwoAdjacentSegmentsAndLock',
      talent,
      raceId: raceModel.id,
      masterSegments,
      raceProfile,
      firstSegmentSizeMin,
      firstSegmentSizeMax,
      secondSegmentSizeMin,
      secondSegmentSizeMax,
      cumulativeSegmentSizeMin,
      cumulativeSegmentSizeMax,
    }, 'There is no available master segments');

    return [];
  }

  const index = Math.floor(Math.random() * adjacentSegmentList.length);
  const adjacentSegments = adjacentSegmentList[index];

  // lock masterSegments
  masterSegments.forEach((ms) => {
    if (adjacentSegments.find((segment) => segment === ms.segment)) {
      ms.segmentLocked = talent;
    }
  });

  log.info({
    func: 'getTwoAdjacentSegmentsAndLock',
    talent,
    raceId: raceModel.id,
    adjacentSegments,
    masterSegments,
    raceProfile,
    firstSegmentSizeMin,
    firstSegmentSizeMax,
    secondSegmentSizeMin,
    secondSegmentSizeMax,
    cumulativeSegmentSizeMin,
    cumulativeSegmentSizeMax,
  }, 'Get Two Adjacent Segments And Lock Success');

  return adjacentSegments;
};

const getThreeAdjacentSegmentsAndLock = (raceModel: Race, masterSegments: MasterSegment[], raceProfile: RaceProfile, {
  talent,
  firstSegmentSizeMin = 0,
  firstSegmentSizeMax = 9999,
  firstSegmentIndexMin = 1, // segment index starts from 1
  secondSegmentSizeMin = 0,
  secondSegmentSizeMax = 9999,
  thirdSegmentSizeMin = 0,
  thirdSegmentSizeMax = 9999,
  cumulativeSecondAndThirdSegmentSizeMin = 0,
  cumulativeSecondAndThirdSegmentSizeMax = 9999,
  isExcludeLastSegment = true,
}: {
  talent?: string,
  firstSegmentSizeMin?: number,
  firstSegmentSizeMax?: number,
  firstSegmentIndexMin?: number, // segment index starts from 1
  secondSegmentSizeMin?: number,
  secondSegmentSizeMax?: number,
  thirdSegmentSizeMin?: number,
  thirdSegmentSizeMax?: number,
  cumulativeSecondAndThirdSegmentSizeMin?: number,
  cumulativeSecondAndThirdSegmentSizeMax?: number,
  isExcludeLastSegment?: boolean,
} = {}) => {
  const adjacentSegmentList: number[][] = [];
  const { segments } = raceProfile;

  const length = isExcludeLastSegment ? segments.length - 3 : segments.length - 2;
  for (let i = 0; i < length; i += 1) {
    const segmentA = segments[i];
    const segmentB = segments[i + 1];
    const segmentC = segments[i + 2];
    const masterSegmentA = masterSegments.find((ms) => ms.segment === segmentA.segment);
    const masterSegmentB = masterSegments.find((ms) => ms.segment === segmentB.segment);
    const masterSegmentC = masterSegments.find((ms) => ms.segment === segmentC.segment);

    // talent segments (A1, A2, A3, ...) don't have segment (index) initially so there is no corresponding master segment
    if (!masterSegmentA || !masterSegmentB || !masterSegmentC) {
      continue;
    }

    const isMasterSegmentsUnlocked = !masterSegmentA.segmentLocked && !masterSegmentB.segmentLocked && !masterSegmentC.segmentLocked;
    const cumulativeSecondAndThirdSegmentSize = segmentB.segmentSize + segmentC.segmentSize;
    const isSegmentSizeOk = cumulativeSecondAndThirdSegmentSize >= cumulativeSecondAndThirdSegmentSizeMin
      && cumulativeSecondAndThirdSegmentSize <= cumulativeSecondAndThirdSegmentSizeMax
      && segmentA.segmentSize >= firstSegmentSizeMin && segmentA.segmentSize <= firstSegmentSizeMax && segmentA.segment >= firstSegmentIndexMin
      && segmentB.segmentSize >= secondSegmentSizeMin && segmentB.segmentSize <= secondSegmentSizeMax
      && segmentC.segmentSize >= thirdSegmentSizeMin && segmentC.segmentSize <= thirdSegmentSizeMax;

    if (isMasterSegmentsUnlocked && isSegmentSizeOk) {
      adjacentSegmentList.push([segmentA.segment, segmentB.segment, segmentC.segment]);
    }
  }

  if (adjacentSegmentList.length === 0) {
    log.info({
      func: 'getThreeAdjacentSegmentsAndLock',
      raceId: raceModel.id,
      masterSegments,
      raceProfile,
      firstSegmentSizeMin,
      firstSegmentSizeMax,
      secondSegmentSizeMin,
      secondSegmentSizeMax,
      thirdSegmentSizeMin,
      thirdSegmentSizeMax,
      cumulativeSecondAndThirdSegmentSizeMin,
      cumulativeSecondAndThirdSegmentSizeMax,
    }, 'There is no available master segments');

    return [];
  }

  const index = Math.floor(Math.random() * adjacentSegmentList.length);
  const adjacentSegments = adjacentSegmentList[index];

  // lock masterSegments
  masterSegments.forEach((ms) => {
    if (adjacentSegments.find((segment) => segment === ms.segment)) {
      ms.segmentLocked = talent;
    }
  });

  log.info({
    func: 'getThreeAdjacentSegmentsAndLock',
    raceId: raceModel.id,
    adjacentSegments,
    masterSegments,
    raceProfile,
    firstSegmentSizeMin,
    firstSegmentSizeMax,
    secondSegmentSizeMin,
    secondSegmentSizeMax,
    thirdSegmentSizeMin,
    thirdSegmentSizeMax,
    cumulativeSecondAndThirdSegmentSizeMin,
    cumulativeSecondAndThirdSegmentSizeMax,
  }, 'Get Three Adjacent Segments And Lock Success');

  return adjacentSegments;
};

const applyBlueRooster = (
  raceModel: Race,
  chickenForTalent: ChickenForTalent,
  raceProfiles: RaceProfile[],
  adjacentSegments: number[],
  cutscenes: any[],
  soundProfiles: any[],
) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalSegmentSizeB = talentSegmentB.segmentSize;

  const blueRoosterSpeed = talentSegmentA.endSpeed * 1.3;
  const blueRoosterDuration = raceModel.terrain.name === TerrainName.Track ? 4.8 : 4.0;
  const segmentSizeA1 = 4.63;
  const segmentSizeA2 = 0.8;
  const segmentSizeA3 = blueRoosterDuration;
  const remainderDuration = (originalSegmentSizeA + originalSegmentSizeB - segmentSizeA1 - segmentSizeA2 - segmentSizeA3) / 2;
  const segmentSizeA = remainderDuration;
  const segmentSizeB = remainderDuration;

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: talentSegmentA.endSpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: 'BlueRooster_Drink',
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: blueRoosterSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: 'BlueRooster_Sprint',
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: blueRoosterSpeed,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: 'BlueRooster_Sprint',
  };

  talentSegmentB.segmentSize = segmentSizeB;
  talentSegmentB.startSpeed = talentSegmentA3.endSpeed;

  // insert talentSegmentA1, A2, A3 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3);

  const cutscene = {
    type: 'talent',
    startTime: Math.max(0, talentSegmentA.cumulativeSegmentSize - 2), // The startTime of tSA + 1, -2 seconds
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize + 0.87, // The startTime segment tSA + 1 + 0.87 seconds
    duration: 10,
    sound: 'SFX_BlueRooster_Open',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize + 1.67, // The startTime segment tSA + 1 + 1.67 seconds
    duration: 10,
    sound: 'SFX_BlueRooster_Drink',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize + 3.7, // The startTime segment tSA + 1 + 3.7 seconds
    duration: 10,
    sound: 'SFX_BlueRooster_PowerUp',
  }, {
    type: 'effect',
    loop: true,
    startTime: talentSegmentA1.cumulativeSegmentSize, // The startTime segment tSA + 2
    duration: blueRoosterDuration + 0.4, // blueRoosterDuration + 0.4 seconds
    sound: 'SFX_BlueRooster_Run',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA3.cumulativeSegmentSize, // The startTime segment tSB
    duration: 10,
    sound: 'SFX_BlueRooster_PowerDown',
  }];
  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyBlueRooster',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const applyChickenapult = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSize = talentSegmentA.segmentSize + talentSegmentB.segmentSize;

  const bodyBonus = source.baseBody === ChickenBaseBody.Robot ? 0.3 : 0;
  const eyesBonus = source.eyesType === ChickenEyesType.Cyclops ? 0.3 : 0;
  const launchSpeed = talentSegmentA.endSpeed * (2.1 + bodyBonus + eyesBonus);

  const segmentSizeA = 2.0;
  const segmentSizeA1 = 2.0;
  const segmentSizeA2 = 1.67;
  const segmentSizeA3 = 1.67;
  const segmentSizeA4 = 2.1;
  const segmentSizeB = originalSegmentSize - segmentSizeA - segmentSizeA1 - segmentSizeA2 - segmentSizeA3 - segmentSizeA4;

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;
  talentSegmentA.endSpeed = talentSegmentA.startSpeed;
  talentSegmentA.segmentChickenAnimation = 'Chickenapult_Spawn';

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: talentSegmentA.endSpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: 'Chickenapult_Roll',
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: launchSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: 'Chickenapult_Launch',
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: launchSpeed,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: 'Chickenapult_Airtime',
  };

  const talentSegmentA4 = {
    segmentSize: segmentSizeA4,
    startSpeed: talentSegmentA3.endSpeed,
    endSpeed: talentSegmentB.startSpeed,
    cumulativeSegmentSize: talentSegmentA3.cumulativeSegmentSize + segmentSizeA4,
    segmentChickenAnimation: 'Chickenapult_Landing',
  };

  talentSegmentB.segmentSize = segmentSizeB;

  // insert talentSegmentA1, A2, A3, A4 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3, talentSegmentA4);

  const cutscene = {
    type: 'talent',
    startTime: talentSegmentA.cumulativeSegmentSize - segmentSizeA, // The startTime of tSA
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize - segmentSizeA, // The startTime segment tSA
    duration: 10,
    sound: 'Chickenapult_Spawn',
  }, {
    type: 'effect',
    loop: true,
    startTime: talentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 1
    duration: talentSegmentA1.segmentSize, // The segmentSize of segment tSA + 1
    sound: 'Chiceknapult_Roll',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA1.cumulativeSegmentSize, // The startTime segment tSA + 2
    duration: 10,
    sound: 'Chickenapult_Launch',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA3.cumulativeSegmentSize, // The startTime segment tSB
    duration: 10,
    sound: 'Chickenapult_Landing',
  }];
  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyChickenapult',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const applyGrowth = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalSegmentSizeB = talentSegmentB.segmentSize;

  const growthSpeed = talentSegmentA.endSpeed * 1.3;
  const growthDuration = source.eyesType === ChickenEyesType.Lizard ? 5 : 4;
  const segmentSizeA1 = 5.5;
  const segmentSizeA2 = growthDuration;
  const segmentSizeA3 = 1.37;
  const segmentSizeB = 1.00;
  const segmentSizeA = originalSegmentSizeA + originalSegmentSizeB - (segmentSizeA1 + segmentSizeA2 + segmentSizeA3 + segmentSizeB);

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: growthSpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: 'Growth_Grow',
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: growthSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: 'Growth_Run',
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: talentSegmentA.endSpeed,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: 'Growth_Shrink',
  };

  talentSegmentB.segmentSize = segmentSizeB;
  talentSegmentB.startSpeed = talentSegmentA3.endSpeed;

  // insert talentSegmentA1, A2, A3 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3);

  const cutscene = {
    type: 'talent',
    startTime: Math.max(0, talentSegmentA.cumulativeSegmentSize - 2), // The startTime of  tSA + 1, -2
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize + 1, // The startTime segment tSA + 1, + 1 second
    duration: 10,
    sound: 'Growth_Drink',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize + 1.8, // The startTime segment tSA + 1, + 1.8 seconds
    duration: 10,
    sound: 'Growth_Grow',
  }, {
    type: 'effect',
    loop: true,
    startTime: talentSegmentA1.cumulativeSegmentSize, // The startTime segment tSA + 2
    duration: talentSegmentA2.segmentSize, // The segmentSze of segment tSA + 2
    sound: 'Growth_Stomp',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA3.cumulativeSegmentSize, // The startTime segment tSB
    duration: 10,
    sound: 'Growth_Shrink',
  }];
  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyGrowth',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const applyColdSnap = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
  const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

  if (!targetRaceProfiles?.length) {
    return;
  }

  // performing chicken
  if (sourceRaceProfile) {
    const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
    const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
    const talentSegmentA = sourceRaceProfile.segments[talentIndexA];

    const originalSegmentSizeA = talentSegmentA.segmentSize;
    const originalAnimationA = talentSegmentA.segmentChickenAnimation;

    const segmentSizeA = 3.73;
    const segmentSizeA1 = originalSegmentSizeA - segmentSizeA;

    talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize + segmentSizeA;
    talentSegmentA.segmentSize = segmentSizeA;
    talentSegmentA.segmentChickenAnimation = 'ColdSnap_Manta';

    // build segment except segment (index to mark as talent segment)
    const talentSegmentA1 = {
      segmentSize: segmentSizeA1,
      startSpeed: talentSegmentA.endSpeed,
      endSpeed: talentSegmentA.endSpeed,
      cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
      segmentChickenAnimation: originalAnimationA,
    };

    // insert talentSegmentA1 between talentSegmentA and talentSegmentB
    sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1);

    const cutscene = {
      type: 'talent',
      startTime: (talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize) + 1, // The startTime of tSA, +1 second
      chickens: [source.id],
    };
    cutscenes.push(cutscene);

    const soundProfilesForTalent = [{
      type: 'effect',
      loop: false,
      startTime: talentSegmentA.cumulativeSegmentSize + 0.5, // The startTime of the performing chicken’s segment tSA + 1 +0.5 seconds
      duration: 10,
      sound: 'SFX_Coldsnap_Cast',
    }];
    soundProfiles.push(...soundProfilesForTalent);

    log.info({
      func: 'applyColdSnap',
      raceId: raceModel.id,
      chickenId: source.id,
      talent,
      beakAccessory: source.beakAccessory,
      eyesType: source.eyesType,
      targets: targets.map((target) => target.id),
      sourceRaceProfile,
      cutscene,
      soundProfilesForTalent,
    }, `Apply ${talent} To Source Successfully`);
  }

  // target chickens
  if (targetRaceProfiles.length > 0) {
    const soundProfilesForTalent: any[] = [];

    targets.forEach((target, index) => {
      const targetRaceProfile = targetRaceProfiles.find((rp) => rp.chickenId === target.id);

      const talentIndexA = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
      const talentIndexB = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
      const talentSegmentA = targetRaceProfile.segments[talentIndexA];
      const talentSegmentB = targetRaceProfile.segments[talentIndexB];

      const originalSegmentSizeA = talentSegmentA.segmentSize;
      const originalSegmentSizeB = talentSegmentB.segmentSize;
      const originalSpeedA = talentSegmentA.endSpeed;

      const csSpeed = originalSpeedA * 0.7;

      const vampBonus = source.beakAccessory === ChickenBeakAccessory.Vampire ? 1.67 : 0;
      const ringBonus = target.beakAccessory === ChickenBeakAccessory.Ring ? -1.67 : 0;
      const csDuration = 3.33 + vampBonus + ringBonus;

      const segmentSizeA = 3.00;
      const segmentSizeA1 = 2.33;
      const segmentSizeA2 = csDuration;
      const segmentSizeA3 = 2.73;
      const segmentSizeB = originalSegmentSizeA + originalSegmentSizeB - (segmentSizeA + segmentSizeA1 + segmentSizeA2 + segmentSizeA3);

      talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize + segmentSizeA;
      talentSegmentA.segmentSize = segmentSizeA;

      const talentSegmentA1 = {
        segmentSize: segmentSizeA1,
        startSpeed: talentSegmentA.endSpeed,
        endSpeed: csSpeed,
        cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
        segmentChickenAnimation: 'ColdSnap_GotSnap',
      };

      const talentSegmentA2 = {
        segmentSize: segmentSizeA2,
        startSpeed: csSpeed,
        endSpeed: csSpeed,
        cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
        segmentChickenAnimation: 'ColdSnap_Run',
      };

      const talentSegmentA3 = {
        segmentSize: segmentSizeA3,
        startSpeed: csSpeed,
        endSpeed: originalSpeedA,
        cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
        segmentChickenAnimation: 'ColdSnap_BackRun',
      };

      talentSegmentB.segmentSize = segmentSizeB;
      talentSegmentB.startSpeed = talentSegmentA3.endSpeed;

      // insert talentSegmentA1, A2, A3 between talentSegmentA and talentSegmentB
      targetRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3);

      if (index === 0) {
        soundProfilesForTalent.push({
          type: 'effect',
          loop: false,
          startTime: talentSegmentA.cumulativeSegmentSize + 0.73, // The startTime of a targeted chicken’s segment tSA + 1 + 0.73 seconds
          duration: 10,
          sound: 'SFX_Coldsnap_Freeze',
        }, {
          type: 'effect',
          loop: false,
          // The startTime of a targeted chicken’s segment tSA + 3 segment
          startTime: talentSegmentA3.cumulativeSegmentSize - talentSegmentA3.segmentSize,
          duration: 10,
          sound: 'SFX_Coldsnap_Thaw',
        });
        soundProfiles.push(...soundProfilesForTalent);
      }

      log.info({
        func: 'applyColdSnap',
        raceId: raceModel.id,
        chickenId: target.id,
        talent,
        beakAccessory: target.beakAccessory,
        targetRaceProfile,
        soundProfilesForTalent,
      }, `Apply ${talent} To Target Successfully`);
    });
  }
};

const applyAnvil = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;
  // only one target for anvil
  const target = targets[0];

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
  const targetRaceProfile = raceProfiles.find((rp) => rp.chickenId === target?.id);

  if (!targetRaceProfile) {
    return;
  }

  // performing chicken
  if (sourceRaceProfile) {
    const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
    const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
    const talentSegmentA = sourceRaceProfile.segments[talentIndexA];

    const originalSegmentSizeA = talentSegmentA.segmentSize;

    const segmentSizeA1 = 2.93;
    const segmentSizeA2 = 0.07;
    const segmentSizeA = originalSegmentSizeA - (segmentSizeA1 + segmentSizeA2);

    talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
    talentSegmentA.segmentSize = segmentSizeA;

    // build segment except segment (index to mark as talent segment)
    const talentSegmentA1 = {
      segmentSize: segmentSizeA1,
      startSpeed: talentSegmentA.endSpeed,
      endSpeed: talentSegmentA.endSpeed,
      cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
      segmentChickenAnimation: 'Anvil_Throw',
    };

    const talentSegmentA2 = {
      segmentSize: segmentSizeA2,
      startSpeed: talentSegmentA1.endSpeed,
      endSpeed: talentSegmentA1.endSpeed,
      cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    };

    // insert talentSegmentA1, A2 between talentSegmentA and talentSegmentB
    sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2);

    const cutscene = {
      type: 'talent',
      startTime: Math.max(0, (talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize) - 1), // The startTime of tSA, -1 second
      chickens: [source.id],
    };
    cutscenes.push(cutscene);

    const soundProfilesForTalent = [{
      type: 'effect',
      loop: false,
      startTime: talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize, // The startTime of the performing chicken’s segment tSA
      duration: 10,
      sound: 'Anvil_Throw',
    }];
    soundProfiles.push(...soundProfilesForTalent);

    log.info({
      func: 'applyAnvil',
      raceId: raceModel.id,
      chickenId: source.id,
      talent,
      beakAccessory: source.beakAccessory,
      eyesType: source.eyesType,
      targets: targets.map((t) => t.id),
      sourceRaceProfile,
      cutscene,
      soundProfilesForTalent,
    }, `Apply ${talent} To Source Successfully`);
  }

  // target chickens
  if (targetRaceProfile) {
    const talentIndexB = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
    const talentIndexC = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[2] === segment.segment);
    const talentSegmentB = targetRaceProfile.segments[talentIndexB];
    const talentSegmentC = targetRaceProfile.segments[talentIndexC];

    const originalSegmentSizeB = talentSegmentB.segmentSize;
    const originalSegmentSizeC = talentSegmentC.segmentSize;

    const rockBonus = raceModel.terrain.name === TerrainName.Rock ? 0.77 : 0;
    const vampBonus = source.beakAccessory === ChickenBeakAccessory.Vampire ? 0.77 : 0;
    const ringBonus = target.beakAccessory === ChickenBeakAccessory.Ring ? -0.77 : 0;
    const squashedDuration = Math.max(rockBonus + vampBonus + ringBonus, 0);

    const segmentSizeB1 = 0.1;
    const segmentSizeB2 = 0.03;
    const segmentSizeB3 = 1.63;
    const segmentSizeB4 = squashedDuration;
    const segmentSizeB5 = 1.53;
    const segmentSizeB6 = 0.01;
    const remainderDuration = (originalSegmentSizeB + originalSegmentSizeC - segmentSizeB1 - segmentSizeB2 - segmentSizeB3 - segmentSizeB4 - segmentSizeB5 - segmentSizeB6) / 2;
    const segmentSizeB = remainderDuration;
    const segmentSizeC = remainderDuration;

    const targetOriginalEndSpeedC = talentSegmentC.endSpeed;
    talentSegmentB.segmentSize = segmentSizeB;
    talentSegmentB.endSpeed = talentSegmentB.startSpeed;
    talentSegmentB.cumulativeSegmentSize = talentSegmentB.cumulativeSegmentSize - originalSegmentSizeB + segmentSizeB;

    const talentSegmentB1 = {
      segmentSize: segmentSizeB1,
      startSpeed: talentSegmentB.endSpeed,
      endSpeed: talentSegmentB.endSpeed,
      cumulativeSegmentSize: talentSegmentB.cumulativeSegmentSize + segmentSizeB1,
      segmentChickenAnimation: 'Anvil_Lands_1',
    };

    const talentSegmentB2 = {
      segmentSize: segmentSizeB2,
      startSpeed: talentSegmentB1.endSpeed,
      endSpeed: 0,
      cumulativeSegmentSize: talentSegmentB1.cumulativeSegmentSize + segmentSizeB2,
      segmentChickenAnimation: 'Anvil_Lands_2',
    };

    const talentSegmentB3 = {
      segmentSize: segmentSizeB3,
      startSpeed: talentSegmentB2.endSpeed,
      endSpeed: 0,
      cumulativeSegmentSize: talentSegmentB2.cumulativeSegmentSize + segmentSizeB3,
      segmentChickenAnimation: 'Anvil_Lands_3',
    };

    const talentSegmentB4 = {
      segmentSize: segmentSizeB4,
      startSpeed: talentSegmentB3.endSpeed,
      endSpeed: 0,
      cumulativeSegmentSize: talentSegmentB3.cumulativeSegmentSize + segmentSizeB4,
      segmentChickenAnimation: 'Anvil_Squashed',
    };

    const talentSegmentB5 = {
      segmentSize: segmentSizeB5,
      startSpeed: talentSegmentB4.endSpeed,
      endSpeed: 0,
      cumulativeSegmentSize: talentSegmentB4.cumulativeSegmentSize + segmentSizeB5,
      segmentChickenAnimation: 'Anvil_Get_Up',
    };

    const talentSegmentB6 = {
      segmentSize: segmentSizeB6,
      startSpeed: talentSegmentB5.endSpeed,
      endSpeed: targetOriginalEndSpeedC,
      cumulativeSegmentSize: talentSegmentB5.cumulativeSegmentSize + segmentSizeB6,
    };

    talentSegmentC.segmentSize = segmentSizeC;
    talentSegmentC.startSpeed = talentSegmentB6.endSpeed;

    // insert talentSegmentB1, B2, B3, B4, B5 between talentSegmentB and talentSegmentC
    targetRaceProfile.segments.splice(
      talentIndexC,
      0,
      talentSegmentB1,
      talentSegmentB2,
      talentSegmentB3,
      talentSegmentB4,
      talentSegmentB5,
      talentSegmentB6,
    );

    const soundProfilesForTalent = [{
      type: 'effect',
      loop: false,
      startTime: talentSegmentB.cumulativeSegmentSize, // The startTime of a targeted chicken’s segment tSB + 1
      duration: 10,
      sound: 'Anvil_Lands',
    }, {
      type: 'effect',
      loop: false,
      startTime: talentSegmentB3.cumulativeSegmentSize, // The startTime of a targeted chicken’s segment tSB + 4.
      duration: 10,
      sound: 'Anvil_Get_Up',
    }];
    soundProfiles.push(...soundProfilesForTalent);

    log.info({
      func: 'applyAnvil',
      raceId: raceModel.id,
      chickenId: target.id,
      talent,
      beakAccessory: source.beakAccessory,
      targetRaceProfile,
      soundProfilesForTalent,
    }, `Apply ${talent} To Target Successfully`);
  }
};

const applyFlight = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;
  const successfulFlight = (source as any).successfulFlight;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSize = talentSegmentA.segmentSize + talentSegmentB.segmentSize;
  const flightSpeed = talentSegmentA.endSpeed * 1.3;

  const soundProfilesForTalent = [];

  if (successfulFlight) {
    const eyesBonus = source.eyesType === ChickenEyesType.Owl ? 1.0 : 0;
    const flightDuration = 3.63 + eyesBonus;

    const segmentSizeA = 0.3;
    const segmentSizeA1 = 4.87;
    const segmentSizeA2 = flightDuration;
    const segmentSizeA3 = 1.40;
    const segmentSizeB = originalSegmentSize - (segmentSizeA + segmentSizeA1 + segmentSizeA2 + segmentSizeA3);

    talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize + segmentSizeA;
    talentSegmentA.segmentSize = segmentSizeA;

    // build segment except segment (index to mark as talent segment)
    const talentSegmentA1 = {
      segmentSize: segmentSizeA1,
      startSpeed: talentSegmentA.endSpeed,
      endSpeed: flightSpeed,
      cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
      segmentChickenAnimation: 'Flight_TakeOff',
    };

    const talentSegmentA2 = {
      segmentSize: segmentSizeA2,
      startSpeed: talentSegmentA1.endSpeed,
      endSpeed: flightSpeed,
      cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
      segmentChickenAnimation: 'Flight_Flapping',
    };

    const talentSegmentA3 = {
      segmentSize: segmentSizeA3,
      startSpeed: talentSegmentA2.endSpeed,
      endSpeed: talentSegmentB.startSpeed,
      cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
      segmentChickenAnimation: 'Flight_Land_Safe',
    };

    talentSegmentB.segmentSize = segmentSizeB;

    // insert talentSegmentA1, A2, A3 between talentSegmentA and talentSegmentB
    sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3);

    soundProfilesForTalent.push({
      type: 'effect',
      loop: false,
      startTime: talentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 1
      duration: 10,
      sound: 'Flight_TakeOff',
    }, {
      type: 'effect',
      loop: false,
      startTime: talentSegmentA1.cumulativeSegmentSize, // the startTime segment tSA + 2
      duration: 10,
      sound: 'Flight_Flapping',
    }, {
      type: 'effect',
      loop: false,
      startTime: talentSegmentA2.cumulativeSegmentSize, // the startTime segment tSA + 3
      duration: 10,
      sound: 'Flight_Land_Safe',
    });
  } else {
    const segmentSizeA = 0.3;
    const segmentSizeA1 = 4.87;
    const segmentSizeA2 = 2.13;
    const segmentSizeB = originalSegmentSize - (segmentSizeA + segmentSizeA1 + segmentSizeA2);

    talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize + segmentSizeA;
    talentSegmentA.segmentSize = segmentSizeA;

    // build segment except segment (index to mark as talent segment)
    const talentSegmentA1 = {
      segmentSize: segmentSizeA1,
      startSpeed: talentSegmentA.endSpeed,
      endSpeed: flightSpeed,
      cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
      segmentChickenAnimation: 'Flight_TakeOff',
    };

    const talentSegmentA2 = {
      segmentSize: segmentSizeA2,
      startSpeed: talentSegmentA1.endSpeed,
      endSpeed: talentSegmentB.startSpeed,
      cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
      segmentChickenAnimation: 'Flight_Land_Crash',
    };

    talentSegmentB.segmentSize = segmentSizeB;

    // insert talentSegmentA1, A2 between talentSegmentA and talentSegmentB
    sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2);

    soundProfilesForTalent.push({
      type: 'effect',
      loop: false,
      startTime: talentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 1
      duration: 10,
      sound: 'Flight_TakeOff',
    }, {
      type: 'effect',
      loop: true,
      startTime: talentSegmentA1.cumulativeSegmentSize, // the startTime segment tSA + 2
      duration: talentSegmentA2.segmentSize, // The segmentSze of segment tSA + 2
      sound: 'Flight_Land_Crash',
    });
  }

  const cutscene = {
    type: 'talent',
    startTime: Math.max(talentSegmentA.cumulativeSegmentSize - 2, 0), // The startTime of  tSA + 1, -2
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyFlight',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    successfulFlight,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const getCK47Meta = ({
  targetLanes,
  targetChickenIds,
  shootingDuration,
}: {
  targetLanes: number[],
  targetChickenIds: number[],
  shootingDuration: number,
}) => {
  // Duplicate Chicken
  const duplicateFiringDistance = 1; // in meters
  const duplicateSpawnDelay = 0.15; // seconds
  const tSA3Segment: number = undefined; // will be filled after applying all talents because it might change later
  const startPosition: number = undefined;
  const startTime: number = undefined;
  const meta = {
    talent: ChickenTalent.CK47,

    duplicateFiringDistance,
    duplicateSpawnDelay,
    tSA3Segment,
    startPosition,
    startTime,

    targetLanes,
    targetChickenIds,

    segments: [{
      segmentSize: 1.17,
      segmentChickenAnimation: 'CK-47_LandBackwards',
    }, {
      segmentSize: shootingDuration,
      segmentChickenAnimation: 'CK-47_FireBackward',
    }, {
      segmentSize: 1.83,
      segmentChickenAnimation: 'CK-47_LeapBack',
    }],
  };

  return meta;
};

const applyCK47 = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
  const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

  if (!targetRaceProfiles?.length) {
    return;
  }

  // performing chicken
  const sourceTalentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const sourceTalentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const sourceTalentSegmentA = sourceRaceProfile.segments[sourceTalentIndexA];
  const sourceTalentSegmentB = sourceRaceProfile.segments[sourceTalentIndexB];

  const sourceOriginalSegmentSizeA = sourceTalentSegmentA.segmentSize;
  const sourceOriginalSegmentSizeB = sourceTalentSegmentB.segmentSize;

  const eyesBonus = source.eyesType === ChickenEyesType.Eyepatch ? 0.53 : 0;
  const vampBonus = source.beakAccessory === ChickenBeakAccessory.Vampire ? 0.53 : 0;
  const ringBonus = targets.some((target) => target.beakAccessory === ChickenBeakAccessory.Ring) ? -0.53 : 0;
  const shootingDuration = 3.2 + eyesBonus + vampBonus + ringBonus;

  const sourceSegmentSizeA1 = 0.53;
  const sourceSegmentSizeA2 = 1.63;
  const sourceSegmentSizeA3 = 2.8 + shootingDuration;
  const sourceSegmentSizeA4 = 1.07;
  const sourceRemainderDuration = (
    sourceOriginalSegmentSizeA + sourceOriginalSegmentSizeB - sourceSegmentSizeA1 - sourceSegmentSizeA2 - sourceSegmentSizeA3 - sourceSegmentSizeA4
  ) / 2;
  const sourceSegmentSizeA = sourceRemainderDuration;
  const sourceSegmentSizeB = sourceRemainderDuration;

  sourceTalentSegmentA.cumulativeSegmentSize = sourceTalentSegmentA.cumulativeSegmentSize - sourceOriginalSegmentSizeA + sourceSegmentSizeA;
  sourceTalentSegmentA.segmentSize = sourceSegmentSizeA;

  // build segment except segment (index to mark as talent segment)
  const sourceTalentSegmentA1 = {
    segmentSize: sourceSegmentSizeA1,
    startSpeed: sourceTalentSegmentA.endSpeed,
    endSpeed: sourceTalentSegmentA.endSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA.cumulativeSegmentSize + sourceSegmentSizeA1,
    segmentChickenAnimation: 'CK-47_Draw',
  };

  const sourceTalentSegmentA2 = {
    segmentSize: sourceSegmentSizeA2,
    startSpeed: sourceTalentSegmentA1.endSpeed,
    endSpeed: sourceTalentSegmentA1.endSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA1.cumulativeSegmentSize + sourceSegmentSizeA2,
    segmentChickenAnimation: 'CK-47_LeapAway',
  };

  const sourceTalentSegmentA3 = {
    segmentSize: sourceSegmentSizeA3,
    startSpeed: sourceTalentSegmentA2.endSpeed,
    endSpeed: sourceTalentSegmentA2.endSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA2.cumulativeSegmentSize + sourceSegmentSizeA3,
    segmentChickenAnimation: 'DoNotDrawChicken',
  };

  const sourceTalentSegmentA4 = {
    segmentSize: sourceSegmentSizeA4,
    startSpeed: sourceTalentSegmentA3.endSpeed,
    endSpeed: sourceTalentSegmentA3.endSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA3.cumulativeSegmentSize + sourceSegmentSizeA4,
    segmentChickenAnimation: 'CK-47_LandForward',
  };

  sourceTalentSegmentB.segmentSize = sourceSegmentSizeB;
  sourceTalentSegmentB.startSpeed = sourceTalentSegmentA4.endSpeed;

  // insert talentSegmentA1, A2, A3, A4 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(
    sourceTalentIndexB,
    0,
    sourceTalentSegmentA1,
    sourceTalentSegmentA2,
    sourceTalentSegmentA3,
    sourceTalentSegmentA4,
  );

  const cutscene = {
    type: 'talent',
    // The startTime of tSA, -1.5 seconds
    startTime: Math.max((sourceTalentSegmentA.cumulativeSegmentSize - sourceTalentSegmentA.segmentSize) - 1.5, 0),
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const sourceSoundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: sourceTalentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 1 for the performing chicken
    duration: 10,
    sound: 'CK-47_Spawn',
  }, {
    type: 'effect',
    loop: false,
    startTime: sourceTalentSegmentA1.cumulativeSegmentSize, // The startTime segment tSA + 2 for the performing chicken
    duration: 10,
    sound: 'CK-47_LeapAway',
  }, {
    type: 'effect',
    loop: false,
    startTime: sourceTalentSegmentA3.cumulativeSegmentSize, // The startTime segment tSA + 4 for the performing chicken
    duration: 10,
    sound: 'CK-47_Land',
  }];
  soundProfiles.push(...sourceSoundProfilesForTalent);

  log.info({
    func: 'applyCK47',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    sourceSoundProfilesForTalent,
  }, `Apply ${talent} To Source Successfully`);

  // target chickens
  targets.forEach((target) => {
    const targetRaceProfile = targetRaceProfiles.find((rp) => rp.chickenId === target.id);

    const targetTalentIndexA = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
    const targetTalentIndexB = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
    const targetTalentSegmentA = targetRaceProfile.segments[targetTalentIndexA];
    const targetTalentSegmentB = targetRaceProfile.segments[targetTalentIndexB];

    const targetOriginalSegmentSizeA = targetTalentSegmentA.segmentSize;
    const targetOriginalSegmentSizeB = targetTalentSegmentB.segmentSize;
    const targetOriginalEndSpeedA = targetTalentSegmentA.endSpeed;

    const startDelay = sourceRemainderDuration + 2.57;
    const targetSegmentSizeA = startDelay;
    const targetSegmentSizeA1 = 0.01;
    const targetSegmentSizeA2 = shootingDuration;
    const targetRemainderDuration = targetOriginalSegmentSizeA + targetOriginalSegmentSizeB
      - targetSegmentSizeA - targetSegmentSizeA1 - targetSegmentSizeA2;
    const targetSegmentSizeB = targetRemainderDuration;

    targetTalentSegmentA.cumulativeSegmentSize = targetTalentSegmentA.cumulativeSegmentSize - targetOriginalSegmentSizeA + targetSegmentSizeA;
    targetTalentSegmentA.segmentSize = targetSegmentSizeA;

    const winceSpeed = targetOriginalEndSpeedA * 0.7;

    const targetTalentSegmentA1 = {
      segmentSize: targetSegmentSizeA1,
      startSpeed: targetTalentSegmentA.endSpeed,
      endSpeed: winceSpeed,
      cumulativeSegmentSize: targetTalentSegmentA.cumulativeSegmentSize + targetSegmentSizeA1,
      segmentChickenAnimation: 'CK-47_Wince',
    };

    const targetTalentSegmentA2 = {
      segmentSize: targetSegmentSizeA2,
      startSpeed: targetTalentSegmentA1.endSpeed,
      endSpeed: winceSpeed,
      cumulativeSegmentSize: targetTalentSegmentA1.cumulativeSegmentSize + targetSegmentSizeA2,
      segmentChickenAnimation: 'CK-47_Wince',
    };

    targetTalentSegmentB.segmentSize = targetSegmentSizeB;
    targetTalentSegmentB.startSpeed = targetTalentSegmentA1.endSpeed;
    targetTalentSegmentB.segmentChickenAnimation = 'Dizzy_running';

    // insert talentSegmentA1, A2 between talentSegmentA and talentSegmentB
    targetRaceProfile.segments.splice(targetTalentIndexB, 0, targetTalentSegmentA1, targetTalentSegmentA2);

    const targetSoundProfilesForTalent = [{
      type: 'effect',
      loop: false,
      startTime: targetTalentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 1
      duration: 10,
      sound: 'CK-47_Hit',
    }];

    soundProfiles.push(...targetSoundProfilesForTalent);

    log.info({
      func: 'applyCK47',
      raceId: raceModel.id,
      chickenId: target.id,
      talent,
      beakAccessory: target.beakAccessory,
      targetRaceProfile,
      targetSoundProfilesForTalent,
    }, `Apply ${talent} To Target Successfully`);
  });

  const targetLanes = raceModel.lanes.filter(
    (laneModel) => targets.find((target) => target.id === laneModel.chickenId),
  ).map((laneModel) => laneModel.laneNumber);
  const targetChickenIds = targets.map((target) => target.id);

  // Duplicate Chicken
  const meta = getCK47Meta({
    targetLanes,
    targetChickenIds,
    shootingDuration,
  });

  if (sourceRaceProfile.metas?.length) {
    sourceRaceProfile.metas.push(meta);
  } else {
    sourceRaceProfile.metas = [meta];
  }
};

const applyMachete = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
  const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

  if (!targetRaceProfiles?.length) {
    return;
  }

  let reminderPerfDuration: number;

  // performing chicken
  if (sourceRaceProfile) {
    const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
    const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
    const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
    const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

    const originalSegmentSizeA = talentSegmentA.segmentSize;
    const originalSegmentSizeB = talentSegmentB.segmentSize;

    const segmentSizeA1 = 1.6;
    const segmentSizeA2 = 0.87;
    const segmentSizeA3 = 1.33;
    const segmentSizeA4 = 1.13;
    reminderPerfDuration = (originalSegmentSizeA + originalSegmentSizeB - segmentSizeA1 - segmentSizeA2 - segmentSizeA3 - segmentSizeA4) / 2;
    const segmentSizeA = reminderPerfDuration;
    const segmentSizeB = reminderPerfDuration;

    talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
    talentSegmentA.segmentSize = segmentSizeA;

    // build segment except segment (index to mark as talent segment)
    const talentSegmentA1 = {
      segmentSize: segmentSizeA1,
      startSpeed: talentSegmentA.endSpeed,
      endSpeed: talentSegmentA.endSpeed,
      cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
      segmentChickenAnimation: 'Machete_Draw',
    };

    const talentSegmentA2 = {
      segmentSize: segmentSizeA2,
      startSpeed: talentSegmentA1.endSpeed,
      endSpeed: talentSegmentA1.endSpeed,
      cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
      segmentChickenAnimation: 'Machete_Leap',
    };

    const talentSegmentA3 = {
      segmentSize: segmentSizeA3,
      startSpeed: talentSegmentA2.endSpeed,
      endSpeed: talentSegmentA2.endSpeed,
      cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
      segmentChickenAnimation: 'Machete_Slash',
    };

    const talentSegmentA4 = {
      segmentSize: segmentSizeA4,
      startSpeed: talentSegmentA3.endSpeed,
      endSpeed: talentSegmentA3.endSpeed,
      cumulativeSegmentSize: talentSegmentA3.cumulativeSegmentSize + segmentSizeA4,
      segmentChickenAnimation: 'Machete_Fall',
    };

    talentSegmentB.segmentSize = segmentSizeB;
    talentSegmentB.startSpeed = talentSegmentA4.endSpeed;

    // insert talentSegmentA1, A2, A3, A4 between talentSegmentA and talentSegmentB
    sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3, talentSegmentA4);

    const cutscene = {
      type: 'talent',
      startTime: Math.max(talentSegmentA.cumulativeSegmentSize - 2, 0), // The startTime of the performing chicken’s tSA + 1 , -2 seconds
      chickens: [source.id],
    };
    cutscenes.push(cutscene);

    const soundProfilesForTalent = [{
      type: 'effect',
      loop: false,
      startTime: talentSegmentA.cumulativeSegmentSize, // The startTime of the performing chicken’s segment tSA + 1
      duration: 10,
      sound: 'Machete_Draw',
    }, {
      type: 'effect',
      loop: false,
      startTime: talentSegmentA2.cumulativeSegmentSize, // The startTime of the performing chicken’s segment tSA + 3
      duration: 10,
      sound: 'Machete_Slash',
    }];
    soundProfiles.push(...soundProfilesForTalent);

    log.info({
      func: 'applyMachete',
      raceId: raceModel.id,
      chickenId: source.id,
      talent,
      beakAccessory: source.beakAccessory,
      eyesType: source.eyesType,
      targets: targets.map((target) => target.id),
      sourceRaceProfile,
      cutscene,
      soundProfilesForTalent,
    }, `Apply ${talent} To Source Successfully`);
  }

  // target chickens
  if (targetRaceProfiles.length > 0) {
    const soundProfilesForTalent: any[] = [];

    targets.forEach((target, index) => {
      const targetRaceProfile = targetRaceProfiles.find((rp) => rp.chickenId === target.id);

      const talentIndexA = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
      const talentIndexB = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
      const talentSegmentA = targetRaceProfile.segments[talentIndexA];
      const talentSegmentB = targetRaceProfile.segments[talentIndexB];

      const originalSegmentSizeA = talentSegmentA.segmentSize;
      const originalSegmentSizeB = talentSegmentB.segmentSize;

      const tSADuration = reminderPerfDuration + 2.47;

      const vampBonus = source.beakAccessory === ChickenBeakAccessory.Vampire ? 0.67 : 0;
      const ringBonus = target.beakAccessory === ChickenBeakAccessory.Ring ? -1.33 : 0;
      const headlessDuration = 4.00 + vampBonus + ringBonus;
      const headlessSpeed = talentSegmentA.endSpeed * 0.8;

      const segmentSizeA = tSADuration;
      const segmentSizeA1 = 0.53;
      const segmentSizeA2 = headlessDuration;
      const segmentSizeA3 = 1.33;
      const reminderTargetDuration = originalSegmentSizeA + originalSegmentSizeB - (segmentSizeA + segmentSizeA1 + segmentSizeA2 + segmentSizeA3);
      const segmentSizeB = reminderTargetDuration;

      talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
      talentSegmentA.segmentSize = segmentSizeA;

      const talentSegmentA1 = {
        segmentSize: segmentSizeA1,
        startSpeed: talentSegmentA.endSpeed,
        endSpeed: headlessSpeed,
        cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
        segmentChickenAnimation: 'Machete_Decapitate',
      };

      const talentSegmentA2 = {
        segmentSize: segmentSizeA2,
        startSpeed: headlessSpeed,
        endSpeed: headlessSpeed,
        cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
        segmentChickenAnimation: 'Machete_HeadlessRun',
      };

      const talentSegmentA3 = {
        segmentSize: segmentSizeA3,
        startSpeed: headlessSpeed,
        endSpeed: headlessSpeed,
        cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
        segmentChickenAnimation: 'Machete_HeadRegrow',
      };

      talentSegmentB.segmentSize = segmentSizeB;
      talentSegmentB.startSpeed = talentSegmentA3.endSpeed;

      // insert talentSegmentA1, A2, A3 between talentSegmentA and talentSegmentB
      targetRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3);

      if (index === 0) {
        soundProfilesForTalent.push({
          type: 'effect',
          loop: false,
          startTime: talentSegmentA2.cumulativeSegmentSize, // The startTime of each targeted chicken’s segment tSA + 3
          duration: 10,
          sound: 'Machete_HeadRegrow',
        });
        soundProfiles.push(...soundProfilesForTalent);
      }

      log.info({
        func: 'applyMachete',
        raceId: raceModel.id,
        chickenId: target.id,
        talent,
        beakAccessory: target.beakAccessory,
        targetRaceProfile,
        soundProfilesForTalent,
      }, `Apply ${talent} To Target Successfully`);
    });
  }
};

const applyRollerblades = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalSegmentSizeB = talentSegmentB.segmentSize;

  const skateSpeed = talentSegmentA.endSpeed * 1.2;
  const trickSpeed = talentSegmentA.endSpeed * 1.4;
  const isTerrainPreference = raceModel.terrain.name === source.terrainPreference;

  const segmentSizeA = isTerrainPreference ? 0.2 : 1.8;
  const segmentSizeA1 = 1.73;
  const segmentSizeA2 = 3.2;
  const segmentSizeA3 = isTerrainPreference ? 3.93 : 2.33;
  const remainderTime = originalSegmentSizeA + originalSegmentSizeB - segmentSizeA - segmentSizeA1 - segmentSizeA2 - segmentSizeA3;
  const segmentSizeB = remainderTime;

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;
  talentSegmentA.endSpeed = talentSegmentA.startSpeed;

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: skateSpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: 'Rollerblades_Spawn',
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: skateSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: 'Rollerblades_Roll',
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: trickSpeed,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: isTerrainPreference ? 'Rollerblades_TrickAwesome' : 'Rollerblades_TrickGood',
  };

  talentSegmentB.segmentSize = segmentSizeB;
  talentSegmentB.startSpeed = talentSegmentA3.endSpeed;

  // insert talentSegmentA1, A2, A3 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3);

  const cutscene = {
    type: 'talent',
    startTime: Math.max(0, talentSegmentA.cumulativeSegmentSize - 2), // The startTime of tSA + 1, -2 seconds
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize, // The startTime of segment tSA + 1
    duration: 10,
    sound: 'Rollerblades_Spawn',
  }, {
    type: 'effect',
    loop: true,
    startTime: talentSegmentA1.cumulativeSegmentSize, // The startTime segment tSA + 2
    duration: talentSegmentA2.segmentSize, // The duration of segment tSA + 2
    sound: 'Rollerblades_Roll',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA2.cumulativeSegmentSize, // the startTime of tSA + 3
    duration: 10,
    sound: isTerrainPreference ? 'Rollerblades_TrickAwesome' : 'Rollerblades_TrickGood',
  }];

  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyRollerblades',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const applyTeleport = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;
  // only one target for teleport
  const target = targets[0];

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
  const targetRaceProfile = raceProfiles.find((rp) => rp.chickenId === target?.id);

  if (!targetRaceProfile) {
    return;
  }

  const selectedSegment = adjacentSegments[0];

  const isTeleportSelf = source.id === target.id;

  // performing chicken
  if (isTeleportSelf) {
    const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => segment.segment === selectedSegment);
    const talentSegmentA = sourceRaceProfile.segments[talentIndexA];

    const originalSegmentSizeA = talentSegmentA.segmentSize;
    const originalEndSpeedA = talentSegmentA.endSpeed;
    const eyesBonus = source.eyesType === ChickenEyesType.Alien ? 2 : 0;
    const robotBonus = source.baseBody === ChickenBaseBody.Robot ? 2 : 0;
    const teleportSpeed = originalEndSpeedA * (3 + eyesBonus + robotBonus);

    const segmentSizeA1 = 1.83;
    const segmentSizeA2 = 0.9;
    const segmentSizeA3 = 0.01;
    const segmentSizeA4 = 0.98;
    const segmentSizeA5 = 0.01;
    const segmentSizeA6 = 1.53;
    const remainderDuration = (
      originalSegmentSizeA - (segmentSizeA1 + segmentSizeA2 + segmentSizeA3 + segmentSizeA4 + segmentSizeA5 + segmentSizeA6)
    ) / 2;
    const segmentSizeA7 = remainderDuration;
    const segmentSizeA = remainderDuration;

    talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
    talentSegmentA.segmentSize = segmentSizeA;
    talentSegmentA.endSpeed = talentSegmentA.startSpeed;

    // build segment except segment (index to mark as talent segment)
    const talentSegmentA1 = {
      segmentSize: segmentSizeA1,
      startSpeed: talentSegmentA.endSpeed,
      endSpeed: talentSegmentA.endSpeed,
      cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
      segmentChickenAnimation: 'Teleporter_Button_Press',
    };

    const talentSegmentA2 = {
      segmentSize: segmentSizeA2,
      startSpeed: talentSegmentA1.endSpeed,
      endSpeed: talentSegmentA1.endSpeed,
      cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
      segmentChickenAnimation: 'Teleporter_Dematerialising',
    };

    const talentSegmentA3 = {
      segmentSize: segmentSizeA3,
      startSpeed: talentSegmentA2.endSpeed,
      endSpeed: teleportSpeed,
      cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
      segmentChickenAnimation: 'DoNotDrawChicken',
    };

    const talentSegmentA4 = {
      segmentSize: segmentSizeA4,
      startSpeed: talentSegmentA3.endSpeed,
      endSpeed: teleportSpeed,
      cumulativeSegmentSize: talentSegmentA3.cumulativeSegmentSize + segmentSizeA4,
      segmentChickenAnimation: 'DoNotDrawChicken',
    };

    const talentSegmentA5 = {
      segmentSize: segmentSizeA5,
      startSpeed: talentSegmentA4.endSpeed,
      endSpeed: originalEndSpeedA,
      cumulativeSegmentSize: talentSegmentA4.cumulativeSegmentSize + segmentSizeA5,
      segmentChickenAnimation: 'DoNotDrawChicken',
    };

    const talentSegmentA6 = {
      segmentSize: segmentSizeA6,
      startSpeed: talentSegmentA5.endSpeed,
      endSpeed: originalEndSpeedA,
      cumulativeSegmentSize: talentSegmentA5.cumulativeSegmentSize + segmentSizeA6,
      segmentChickenAnimation: 'Teleporter_Rematerialising',
    };

    const talentSegmentA7 = {
      segmentSize: segmentSizeA7,
      startSpeed: talentSegmentA6.endSpeed,
      endSpeed: originalEndSpeedA,
      cumulativeSegmentSize: talentSegmentA6.cumulativeSegmentSize + segmentSizeA7,
    };

    // insert talentSegmentA1, A2, A3, A4, A5, A6, A7 after talentSegmentA
    sourceRaceProfile.segments.splice(
      talentIndexA + 1,
      0,
      talentSegmentA1,
      talentSegmentA2,
      talentSegmentA3,
      talentSegmentA4,
      talentSegmentA5,
      talentSegmentA6,
      talentSegmentA7,
    );

    const cutscene = {
      type: 'talent',
      startTime: Math.max(0, (talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize) - 1), // The startTime of tSA, -1 second
      chickens: [source.id],
    };
    cutscenes.push(cutscene);

    const soundProfilesForTalent = [{
      type: 'effect',
      loop: false,
      startTime: talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize, // The startTime of the performing chicken’s segment tSA
      duration: 10,
      sound: 'Teleporter_Activate',
    }, {
      type: 'effect',
      loop: false,
      // The startTime of the performing chicken’s segment tSA + 1.33 seconds
      startTime: talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize + 1.33,
      duration: 10,
      sound: 'Teleporter_Dematerialising',
    }, {
      type: 'effect',
      loop: false,
      startTime: talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize + 5, // the startTime of the performing chicken’s tSA + 5
      duration: 10,
      sound: 'Teleporter_Remateriialising',
    }];
    soundProfiles.push(...soundProfilesForTalent);

    log.info({
      func: 'applyTeleport',
      raceId: raceModel.id,
      chickenId: source.id,
      talent,
      beakAccessory: source.beakAccessory,
      eyesType: source.eyesType,
      targets: targets.map((t) => t.id),
      sourceRaceProfile,
      cutscene,
      soundProfilesForTalent,
    }, `Apply ${talent} To Source Successfully`);
  } else {
    // performing chicken
    {
      const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => segment.segment === selectedSegment);
      const talentSegmentA = sourceRaceProfile.segments[talentIndexA];

      const originalSegmentSizeA = talentSegmentA.segmentSize;
      const originalEndSpeedA = talentSegmentA.endSpeed;

      const segmentSizeA = 1.83;
      const segmentSizeA1 = originalSegmentSizeA - segmentSizeA;

      talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
      talentSegmentA.segmentSize = segmentSizeA;
      talentSegmentA.endSpeed = talentSegmentA.startSpeed;
      talentSegmentA.segmentChickenAnimation = 'Teleporter_Button_Press';

      // build segment except segment (index to mark as talent segment)
      const talentSegmentA1 = {
        segmentSize: segmentSizeA1,
        startSpeed: talentSegmentA.endSpeed,
        endSpeed: originalEndSpeedA,
        cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
      };

      // insert talentSegmentA1 after talentSegmentA
      sourceRaceProfile.segments.splice(talentIndexA + 1, 0, talentSegmentA1);

      const soundProfilesForTalent = [{
        type: 'effect',
        loop: false,
        startTime: talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize, // The startTime of the performing chicken’s segment tSA
        duration: 10,
        sound: 'Teleporter_Activate',
      }, {
        type: 'effect',
        loop: false,
        // The startTime of the performing chicken’s segment tSA + 1.33 seconds
        startTime: talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize + 1.33,
        duration: 10,
        sound: 'Teleporter_Dematerialising',
      }];
      soundProfiles.push(...soundProfilesForTalent);
    }

    // target chicken
    {
      const talentIndexA = targetRaceProfile.segments.findIndex((segment) => segment.segment === selectedSegment);
      const talentSegmentA = targetRaceProfile.segments[talentIndexA];

      const originalSegmentSizeA = talentSegmentA.segmentSize;
      const originalEndSpeedA = talentSegmentA.endSpeed;

      const vampBonus = source.beakAccessory === ChickenBeakAccessory.Vampire ? -0.05 : 0;
      const eyesBonus = source.eyesType === ChickenEyesType.Alien ? -0.05 : 0;
      const ringBonus = target.beakAccessory === ChickenBeakAccessory.Ring ? 0.1 : 0;
      const robotBonus = source.baseBody === ChickenBaseBody.Robot ? -0.05 : 0;
      const teleportSpeed = Math.max(0.1 + vampBonus + ringBonus + eyesBonus + robotBonus, 0);

      const segmentSizeA = 1.33;
      const segmentSizeA1 = 0.9;
      const segmentSizeA2 = 0.01;
      const segmentSizeA3 = 0.98;
      const segmentSizeA4 = 0.01;
      const segmentSizeA5 = 1.53;
      const remainderTime = originalSegmentSizeA - (segmentSizeA + segmentSizeA1 + segmentSizeA2 + segmentSizeA3 + segmentSizeA4 + segmentSizeA5);
      const segmentSizeA6 = remainderTime;

      talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
      talentSegmentA.segmentSize = segmentSizeA;
      talentSegmentA.endSpeed = talentSegmentA.startSpeed;

      // build segment except segment (index to mark as talent segment)
      const talentSegmentA1 = {
        segmentSize: segmentSizeA1,
        startSpeed: talentSegmentA.endSpeed,
        endSpeed: talentSegmentA.endSpeed,
        cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
        segmentChickenAnimation: 'Teleporter_Dematerialising',
      };

      const talentSegmentA2 = {
        segmentSize: segmentSizeA2,
        startSpeed: talentSegmentA1.endSpeed,
        endSpeed: teleportSpeed,
        cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
        segmentChickenAnimation: 'DoNotDrawChicken',
      };

      const talentSegmentA3 = {
        segmentSize: segmentSizeA3,
        startSpeed: talentSegmentA2.endSpeed,
        endSpeed: teleportSpeed,
        cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
        segmentChickenAnimation: 'DoNotDrawChicken',
      };

      const talentSegmentA4 = {
        segmentSize: segmentSizeA4,
        startSpeed: talentSegmentA3.endSpeed,
        endSpeed: originalEndSpeedA,
        cumulativeSegmentSize: talentSegmentA3.cumulativeSegmentSize + segmentSizeA4,
        segmentChickenAnimation: 'DoNotDrawChicken',
      };

      const talentSegmentA5 = {
        segmentSize: segmentSizeA5,
        startSpeed: talentSegmentA4.endSpeed,
        endSpeed: originalEndSpeedA,
        cumulativeSegmentSize: talentSegmentA4.cumulativeSegmentSize + segmentSizeA5,
        segmentChickenAnimation: 'Teleporter_Rematerialising',
      };

      const talentSegmentA6 = {
        segmentSize: segmentSizeA6,
        startSpeed: talentSegmentA5.endSpeed,
        endSpeed: originalEndSpeedA,
        cumulativeSegmentSize: talentSegmentA5.cumulativeSegmentSize + segmentSizeA6,
      };

      // insert talentSegmentA1, A2, A3, A4, A5, A6 after talentSegmentA
      targetRaceProfile.segments.splice(
        talentIndexA + 1,
        0,
        talentSegmentA1,
        talentSegmentA2,
        talentSegmentA3,
        talentSegmentA4,
        talentSegmentA5,
        talentSegmentA6,
      );

      // Alien Eyes
      // When teleportSelf = FALSE, there is an alienEyesChance (0.5%) chance that the teleported chicken will return with eyesType Alien
      const alienEyesChance = 0.5 / 100;
      const isAlienEyes = Math.random() < alienEyesChance;
      (talentSegmentA2 as any).isAlienEyes = isAlienEyes;

      const soundProfilesForTalent = [{
        type: 'effect',
        loop: false,
        startTime: talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + 5, // the startTime of the targeted chicken’s tSA + 5 segment
        duration: 10,
        sound: 'Teleporter_Remateriialising',
      }];
      soundProfiles.push(...soundProfilesForTalent);
    }

    log.info({
      func: 'applyTeleport',
      raceId: raceModel.id,
      chickenId: target.id,
      talent,
      beakAccessory: target.beakAccessory,
      targetRaceProfile,
    }, `Apply ${talent} To Target Successfully`);
  }
};

const getDigMeta = () => {
  const meta: any = {
    talent: ChickenTalent.Dig,

    tSA1Segment: undefined,
    startTime: undefined,
    startPosition: undefined,
    startAnimation: 'Dig_Start_7',
    endTime: undefined,
    endTimeOffset: 0.3, // Though isn’t spawned until 0.3 seconds after the start of tSA+3
    endPosition: undefined,
    endAnimation: 'Dig_Trail_11',
    movingAnimations: undefined,
    dirtMoundSpawnDistance: 40 / PIXELS_PER_METER, // 40 pixels, 1m = 300 pixels
    dirtMoundDisappearDistance: 5, // All of these entities remain on the track until they are 5 meters behind the 12th place chicken
  };

  return meta;
};

const applyDig = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => segment.segment === adjacentSegments[0]);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => segment.segment === adjacentSegments[1]);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalSegmentSizeB = talentSegmentB.segmentSize;
  const originalEndSpeedA = talentSegmentA.endSpeed;

  const digDuration = raceModel.terrain.name === TerrainName.Dirt ? 5.6 : 4.2;
  const digSpeed = originalEndSpeedA * 1.5;

  const segmentSizeA1 = 1.3;
  const segmentSizeA2 = 0.01;
  const segmentSizeA3 = digDuration;
  const segmentSizeA4 = 1.14;
  const remainderDuration = (originalSegmentSizeA + originalSegmentSizeB - segmentSizeA1 - segmentSizeA2 - segmentSizeA3 - segmentSizeA4) / 2;
  const segmentSizeA = remainderDuration;
  const segmentSizeB = remainderDuration;

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;
  talentSegmentA.endSpeed = talentSegmentA.startSpeed;

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: 0,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: 'Dig_Dive',
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: digSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: 'DoNotDrawChicken',
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: digSpeed,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: 'DoNotDrawChicken',
  };

  const talentSegmentA4 = {
    segmentSize: segmentSizeA4,
    startSpeed: talentSegmentA3.endSpeed,
    endSpeed: talentSegmentA3.endSpeed,
    cumulativeSegmentSize: talentSegmentA3.cumulativeSegmentSize + segmentSizeA4,
    segmentChickenAnimation: 'Dig_Appear',
  };

  talentSegmentB.segmentSize = segmentSizeB;
  talentSegmentB.startSpeed = talentSegmentA4.endSpeed;

  // insert talentSegmentA1, A2, A3, A4 between talentSegmentA and B
  sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3, talentSegmentA4);

  // Dirt Trail
  const meta = getDigMeta();

  if (sourceRaceProfile.metas?.length) {
    sourceRaceProfile.metas.push(meta);
  } else {
    sourceRaceProfile.metas = [meta];
  }

  const cutscene = {
    type: 'talent',
    startTime: Math.max(0, talentSegmentA.cumulativeSegmentSize - 2), // The startTime of tSA + 1, -2 seconds
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 1
    duration: 10,
    sound: 'Dig_Dive',
  }, {
    type: 'effect',
    loop: true,
    startTime: talentSegmentA1.cumulativeSegmentSize, // he startTime segment tSA + 2
    duration: digDuration,
    sound: 'Dig_Burrow',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA2.cumulativeSegmentSize, // The startTime segment tSA + 3
    duration: 10,
    sound: 'Dig_Emerge',
  }];
  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyDig',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const applyJetpackFinish = (raceModel: Race, source: Partial<Chicken>, sourceRaceProfile: RaceProfile, cutscenes: any[], soundProfiles: any[]) => {
  const { length } = sourceRaceProfile.segments;
  const talentSegmentA = sourceRaceProfile.segments[length - 2];
  const talentSegmentB = sourceRaceProfile.segments[length - 1];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalSegmentSizeB = talentSegmentB.segmentSize;
  const segmentSizeA1 = 4.67;
  const segmentSizeA2 = 0.01;
  const segmentSizeB = 2.0;
  const segmentSizeA = originalSegmentSizeA + originalSegmentSizeB - segmentSizeA1 - segmentSizeA2 - segmentSizeB;
  const jetpackFinishSpeed = talentSegmentA.endSpeed * 3.2;
  const jetpackTransitionAnimation = (source.baseBody === ChickenBaseBody.Robot || source.eyesType === ChickenEyesType.Cyclops) ? 'Jetpack_TransitionRed' : 'Jetpack_Transition';
  const jetpackFlyAnimation = (source.baseBody === ChickenBaseBody.Robot || source.eyesType === ChickenEyesType.Cyclops) ? 'Jetpack_FlyRed' : 'Jetpack_Fly';

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;
  talentSegmentA.endSpeed = talentSegmentA.startSpeed;

  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: talentSegmentA.endSpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: jetpackTransitionAnimation,
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: jetpackFinishSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: jetpackFlyAnimation,
  };

  talentSegmentB.segmentSize = segmentSizeB;
  talentSegmentB.startSpeed = talentSegmentA2.endSpeed;
  talentSegmentB.endSpeed = jetpackFinishSpeed;
  talentSegmentB.segmentChickenAnimation = jetpackFlyAnimation;

  sourceRaceProfile.segments.splice(length - 1, 0, talentSegmentA1, talentSegmentA2);

  const { chickenId } = sourceRaceProfile;
  const cutscene = {
    type: 'talent',
    startTime: Math.max(0, talentSegmentA.cumulativeSegmentSize - 2), // The startTime of tSA + 1, -2 seconds
    chickens: [chickenId],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 1
    duration: 10,
    sound: 'Jetpack_Launch',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA1.cumulativeSegmentSize, // The startTime segment tSA + 2
    duration: 10,
    sound: 'Jetpack_Fly',
  }];
  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyJetpackFinish',
    raceId: raceModel.id,
    chickenId,
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, 'Apply JetpackFinish Successfully');
};

const applyJetpack = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[], isJetpackFinishChance = false) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const penultimateSegment = sourceRaceProfile.segments[sourceRaceProfile.segments.length - 2];
  const lastSegment = sourceRaceProfile.segments[sourceRaceProfile.segments.length - 1];
  const isLast2SegmentSizeOk = penultimateSegment.segmentSize + lastSegment.segmentSize >= 7;
  const isJetpackFinish = isJetpackFinishChance && isLast2SegmentSizeOk;
  if (isJetpackFinish) {
    applyJetpackFinish(raceModel, source, sourceRaceProfile, cutscenes, soundProfiles);
    return;
  }

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalEndSpeedA = talentSegmentA.endSpeed;
  const originalSegmentSizeB = talentSegmentB.segmentSize;

  const robotBonus = source.baseBody === ChickenBaseBody.Robot ? 0.6 : 0;
  const eyesBonus = source.eyesType === ChickenEyesType.Cyclops ? 0.6 : 0;
  const jetpackSpeed = originalEndSpeedA * (3.2 + robotBonus + eyesBonus);
  const segmentSizeA1 = 4.67;
  const segmentSizeA2 = 0.01;
  const segmentSizeA3 = 2.0;
  const landingDuration =
    (source.talentPreference === ChickenTalentPreference.Technology || source.baseBody === ChickenBaseBody.Robot || source.eyesType === ChickenEyesType.Cyclops) ? 2.07 : 2.8;
  const segmentSizeA4 = landingDuration;
  const remainderDuration = (originalSegmentSizeA + originalSegmentSizeB - segmentSizeA1 - segmentSizeA2 - segmentSizeA3 - segmentSizeA4) / 2;
  const segmentSizeA = remainderDuration;
  const segmentSizeB = remainderDuration;
  const jetpackTransitionAnimation = (source.baseBody === ChickenBaseBody.Robot || source.eyesType === ChickenEyesType.Cyclops) ? 'Jetpack_TransitionRed' : 'Jetpack_Transition';
  const jetpackFlyAnimation = (source.baseBody === ChickenBaseBody.Robot || source.eyesType === ChickenEyesType.Cyclops) ? 'Jetpack_FlyRed' : 'Jetpack_Fly';
  const landingAnimation =
    (source.baseBody === ChickenBaseBody.Robot || source.eyesType === ChickenEyesType.Cyclops) ? 'Jetpack_SafeLandingRed'
    : source.talentPreference === ChickenTalentPreference.Technology ? 'Jetpack_SafeLanding' : 'Jetpack_Landing';

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: talentSegmentA.endSpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: jetpackTransitionAnimation,
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: jetpackSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: jetpackFlyAnimation,
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: jetpackSpeed,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: jetpackFlyAnimation,
  };

  const talentSegmentA4 = {
    segmentSize: segmentSizeA4,
    startSpeed: talentSegmentA3.endSpeed,
    endSpeed: originalEndSpeedA,
    cumulativeSegmentSize: talentSegmentA3.cumulativeSegmentSize + segmentSizeA4,
    segmentChickenAnimation: landingAnimation,
  };

  talentSegmentB.segmentSize = segmentSizeB;

  // insert talentSegmentA1, A2, A3, A4 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3, talentSegmentA4);

  const cutscene = {
    type: 'talent',
    startTime: Math.max(0, talentSegmentA.cumulativeSegmentSize - 2), // The startTime of tSA + 1, -2 seconds
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 1
    duration: 10,
    sound: 'Jetpack_Launch',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA1.cumulativeSegmentSize, // The startTime segment tSA + 2
    duration: 10,
    sound: 'Jetpack_Fly',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA2.cumulativeSegmentSize, // The startTime segment tSA + 3
    duration: 10,
    sound: source.talentPreference === ChickenTalentPreference.Technology ? 'Jetpack_Land' : 'Jetpack_Crash',
  }];
  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyJetpack',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    isJetpackFinishChance,
    isLast2SegmentSizeOk,
    isJetpackFinish,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const applyRoyalProcession = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalEndSpeedA = talentSegmentA.endSpeed;
  const originalSegmentSizeB = talentSegmentB.segmentSize;

  const royalProcessionSpeed = originalEndSpeedA * 1.4;
  const eyesBonus = source.eyesType === ChickenEyesType.Owl ? 0.67 : 0;
  const royalProcessionDuration = 6.0 + eyesBonus;
  const segmentSizeA1 = 2.16;
  const segmentSizeA2 = royalProcessionDuration;
  const segmentSizeA3 = 2.99;
  const remainderDuration = (originalSegmentSizeA + originalSegmentSizeB - segmentSizeA1 - segmentSizeA2 - segmentSizeA3) / 2;
  const segmentSizeA = remainderDuration;
  const segmentSizeB = remainderDuration;

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;
  talentSegmentA.endSpeed = talentSegmentA.startSpeed;

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: royalProcessionSpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: 'RoyalProcession_Appear',
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: royalProcessionSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: 'RoyalProcession_Idle',
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: originalEndSpeedA,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: 'RoyalProcession_Dissapear',
  };

  talentSegmentB.segmentSize = segmentSizeB;
  talentSegmentB.startSpeed = talentSegmentA3.endSpeed;
  talentSegmentB.endSpeed = originalEndSpeedA;

  const talentSegmentB1 = sourceRaceProfile.segments[talentIndexB + 1];
  if (talentSegmentB1) {
    talentSegmentB1.startSpeed = talentSegmentB.endSpeed;
  }

  // insert talentSegmentA1, A2, A3 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3);

  const cutscene = {
    type: 'talent',
    startTime: Math.max(0, talentSegmentA.cumulativeSegmentSize - 2), // The startTime of tSA + 1, -2 seconds
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 1
    duration: 10,
    sound: 'RoyalProvession_FanFare',
  }, {
    type: 'music', // (temporarily replaces normal background music)
    loop: false,
    startTime: talentSegmentA1.cumulativeSegmentSize, // The startTime segment tSA + 2
    duration: 6,
    sound: 'RoyalProvession_March',
  }];
  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyRoyalProcession',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const getMovingWalkwayMeta = ({
  startTimeOffset,
  leftTimeOffset,
  rightTimeOffset,
}: {
  startTimeOffset: number,
  leftTimeOffset: number,
  rightTimeOffset: number,
}) => {
  const meta = {
    talent: ChickenTalent.MovingWalkway,

    startTimeOffset,
    leftTimeOffset,
    rightTimeOffset,
  };

  return meta;
};

const applyMovingWalkway = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalEndSpeedA = talentSegmentA.endSpeed;
  const originalSegmentSizeB = talentSegmentB.segmentSize;

  const movingWalkwaySpeed = originalEndSpeedA * 1.5;
  const terrainBonus = raceModel.terrain.name === TerrainName.Sand ? 1.47 : 0;
  const robotBonus = source.baseBody === ChickenBaseBody.Robot ? 1.47 : 0;
  const movingWalkwayDuration = 2.93 + terrainBonus + robotBonus;
  const segmentSizeA1 = 1.07;
  const segmentSizeA2 = movingWalkwayDuration;
  const segmentSizeA3 = 1.3;
  const segmentSizeB = 0.01;
  const remainderDuration = originalSegmentSizeA + originalSegmentSizeB - segmentSizeA1 - segmentSizeA2 - segmentSizeA3 - segmentSizeB;
  const segmentSizeA = remainderDuration;

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;
  talentSegmentA.endSpeed = talentSegmentA.startSpeed;

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: movingWalkwaySpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: 'MovingWalkway_GetOn',
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: movingWalkwaySpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: 'MovingWalkway_Stand',
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: talentSegmentA2.endSpeed,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: 'MovingWalkway_GetOff',
  };

  talentSegmentB.segmentSize = segmentSizeB;
  talentSegmentB.startSpeed = talentSegmentA3.endSpeed;

  const talentSegmentB1 = sourceRaceProfile.segments[talentIndexB + 1];
  if (talentSegmentB1) {
    talentSegmentB1.startSpeed = talentSegmentB.endSpeed;
  }

  // insert talentSegmentA1, A2, A3 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3);

  // The Moving Walkway
  const meta = getMovingWalkwayMeta({
    startTimeOffset: 2.5,
    leftTimeOffset: 0.5,
    rightTimeOffset: 1,
  });

  if (sourceRaceProfile.metas?.length) {
    sourceRaceProfile.metas.push(meta);
  } else {
    sourceRaceProfile.metas = [meta];
  }

  const cutscene = {
    type: 'talent',
    startTime: Math.max(0, talentSegmentA.cumulativeSegmentSize - 2), // The startTime of tSA + 1, -2 seconds
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'music',
    loop: true,
    startTime: talentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 2
    duration: movingWalkwayDuration,
    sound: 'RoyalProvession_March',
  }];
  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyMovingWalkway',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const applyBlueEgg = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;
  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  if (targets.length === 0) {
    return;
  }

  // performing chicken
  if (sourceRaceProfile) {
    const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
    const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
    const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
    const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

    const originalSegmentSizeA = talentSegmentA.segmentSize;
    const originalSegmentSizeB = talentSegmentB.segmentSize;
    const originalEndSpeedA = talentSegmentA.endSpeed;

    const eyesBonus = source.eyesType === ChickenEyesType.Buttons ? 2.33 : 0;
    const launchDuration = 2.33 + eyesBonus;

    const segmentSizeA = 0.5;
    const segmentSizeA1 = launchDuration;
    const segmentSizeA2 = 5.00;
    const remainderDuration = originalSegmentSizeA + originalSegmentSizeB - segmentSizeA - segmentSizeA1 - segmentSizeA2;
    const segmentsizeB = remainderDuration;

    talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
    talentSegmentA.segmentSize = segmentSizeA;
    talentSegmentA.endSpeed = talentSegmentA.startSpeed;

    // build segment except segment (index to mark as talent segment)
    const talentSegmentA1 = {
      segmentSize: segmentSizeA1,
      startSpeed: talentSegmentA.endSpeed,
      endSpeed: talentSegmentA.endSpeed,
      cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
      segmentChickenAnimation: 'BlueEgg_Launch',
    };

    const talentSegmentA2 = {
      segmentSize: segmentSizeA2,
      startSpeed: talentSegmentA1.endSpeed,
      endSpeed: originalEndSpeedA,
      cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    };

    talentSegmentB.segmentSize = segmentsizeB;

    // insert talentSegmentA1, A2 between talentSegmentA and talentSegmentB
    sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2);

    const cutscene = {
      type: 'talent',
      startTime: Math.max(0, (talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize) - 1), // The startTime of tSA, -1 second
      chickens: [source.id],
    };
    cutscenes.push(cutscene);

    const soundProfilesForTalent = [{
      type: 'effect',
      loop: false,
      startTime: talentSegmentA.cumulativeSegmentSize, // The startTime of the performing chicken’s segment tSA +1
      duration: 10,
      sound: 'BlueEgg_Launch',
    }];
    soundProfiles.push(...soundProfilesForTalent);

    log.info({
      func: 'applyBlueEgg',
      raceId: raceModel.id,
      chickenId: source.id,
      talent,
      beakAccessory: source.beakAccessory,
      eyesType: source.eyesType,
      targets: targets.map((t) => t.id),
      sourceRaceProfile,
      cutscene,
      soundProfilesForTalent,
    }, `Apply ${talent} To Source Successfully`);
  }

  // target chickens
  for (let i = 0; i < targets.length; i += 1) {
    const target = targets[i];
    const targetRaceProfile = raceProfiles.find((rp) => rp.chickenId === target?.id);
    const talentIndexA = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
    const talentIndexB = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);

    // Manipulating the target into 1st Place
    // After the targeted chicken is determined and all other talents are implemented,
    // multiple the endSpeed and startSpeed of all segments up to and including tSB by blueEggSpeed (1.05).
    const blueEggSpeed = 1.05;

    for (let i = 0; i <= talentIndexB; i += 1) {
      const segment = targetRaceProfile.segments[i];
      segment.startSpeed *= blueEggSpeed;
      segment.endSpeed *= blueEggSpeed;
    }

    const talentSegmentA = targetRaceProfile.segments[talentIndexA];
    const talentSegmentB = targetRaceProfile.segments[talentIndexB];

    const originalSegmentSizeA = talentSegmentA.segmentSize;
    const originalSegmentSizeB = talentSegmentB.segmentSize;
    const originalEndSpeedA = talentSegmentA.endSpeed;

    const dizzySpeed = originalEndSpeedA * 0.7;

    const vampBonus = source.beakAccessory === ChickenBeakAccessory.Vampire ? 1 : 0;
    const ringBonus = target.beakAccessory === ChickenBeakAccessory.Ring ? -1 : 0;
    const dizzyDuration = 2 + vampBonus + ringBonus;

    const impactDelay = 2.33 * i;
    const segmentSizeA = 3.0 + impactDelay;
    const segmentSizeA1 = 0.9;
    const segmentSizeA2 = 1.9;
    const segmentSizeA3 = 0.77;
    const segmentSizeA4 = dizzyDuration;
    const remainderDuration = originalSegmentSizeA + originalSegmentSizeB
      - segmentSizeA - segmentSizeA1 - segmentSizeA2 - segmentSizeA3 - segmentSizeA4;
    const segmentSizeB = remainderDuration;

    talentSegmentA.segmentSize = segmentSizeA;
    talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
    talentSegmentA.endSpeed = talentSegmentA.startSpeed;

    const talentSegmentA1 = {
      segmentSize: segmentSizeA1,
      startSpeed: talentSegmentA.endSpeed,
      endSpeed: talentSegmentA.endSpeed,
      cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
      segmentChickenAnimation: 'BlueEgg_Impact_1',
    };

    const talentSegmentA2 = {
      segmentSize: segmentSizeA2,
      startSpeed: talentSegmentA1.endSpeed,
      endSpeed: 0,
      cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
      segmentChickenAnimation: 'BlueEgg_Impact_2',
    };

    const talentSegmentA3 = {
      segmentSize: segmentSizeA3,
      startSpeed: talentSegmentA2.endSpeed,
      endSpeed: dizzySpeed,
      cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
      segmentChickenAnimation: 'BlueEgg_Impact_3',
    };

    const talentSegmentA4 = {
      segmentSize: segmentSizeA4,
      startSpeed: talentSegmentA3.endSpeed,
      endSpeed: dizzySpeed,
      cumulativeSegmentSize: talentSegmentA3.cumulativeSegmentSize + segmentSizeA4,
      segmentChickenAnimation: 'BlueEgg_Impact_3',
    };

    talentSegmentB.segmentSize = segmentSizeB;
    talentSegmentB.startSpeed = talentSegmentA4.endSpeed;

    // insert talentSegmentA1, A2, A3, A4 between talentSegmentA and talentSegmentB
    targetRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3, talentSegmentA4);

    const soundProfilesForTalent = [{
      type: 'effect',
      loop: false,
      startTime: talentSegmentA.cumulativeSegmentSize, // The startTime of the targeted chicken’s segment tSA + 1
      duration: 10,
      sound: 'BlueEgg_Explosion',
    }];
    soundProfiles.push(...soundProfilesForTalent);

    log.info({
      func: 'applyBlueEgg',
      raceId: raceModel.id,
      chickenId: target.id,
      talent,
      beakAccessory: target.beakAccessory,
      targetRaceProfile,
      soundProfilesForTalent,
    }, `Apply ${talent} To Target Successfully`);
  }
};

const getFanGroupMeta = (numberOfFans: 3 | 4) => {
  // Chicken Fans
  const tSA1Segment: number = undefined; // will be filled after applying all talents because it might change later

  const fansSpawnSpeedMultiplier = 1.5; // Performing chickens speed x 1.5
  const fansSpawnDistanceOffset = 2; // ( fansStartDuration x fansSpawnSpeed ) + 2

  const timeWhenFansSlowDown = 4;
  const tSA2Segment: number = undefined;

  const disappearDistance = 10; // in meters
  const chickens = [];

  const animations = [
    'FanGroup_Fan_Autograph',
    'FanGroup_Fan_Camera',
    'FanGroup_Fan_Cheer',
    'FanGroup_Fan_Kiss',
    'FanGroup_Fan_TVCamera',
  ];

  const specialBaseBodyChance = 0.02 / 100; // 0.02% chance of having either Black, Classic or Robot
  const specialBaseBodies = [
    ChickenBaseBody.Black,
    ChickenBaseBody.Classic,
    ChickenBaseBody.Robot,
  ];
  const normalBaseBodies = [
    ChickenBaseBody.PurpleWine,
    ChickenBaseBody.ScreaminGreen,
    ChickenBaseBody.Rose,
    ChickenBaseBody.BaldChicken,
    ChickenBaseBody.CherryDusk,
    ChickenBaseBody.EnglishMustard,
    ChickenBaseBody.WildMoss,
    ChickenBaseBody.MerahRed,
    ChickenBaseBody.RoyalViolet,
    ChickenBaseBody.OrangeWill,
    ChickenBaseBody.JokersJade,
    ChickenBaseBody.Sapphire,
    ChickenBaseBody.Eggshell,
    ChickenBaseBody.ManicMint,
    ChickenBaseBody.Istanblue,
    ChickenBaseBody.ShockingPink,
  ];

  const normalBeakColors = [
    ChickenBeakColor.White,
    ChickenBeakColor.Orange,
    ChickenBeakColor.Yellow,
    ChickenBeakColor.Gold,
  ];

  const normalCombColors = [
    ChickenWattleColor.Orange,
    ChickenWattleColor.Green,
    ChickenWattleColor.Red,
    ChickenWattleColor.Pink,
    ChickenWattleColor.White,
    ChickenWattleColor.Blue,
  ];

  const specialBeakAccessoryChance = 0.03 / 100; // 0.03% chance of having either Ring or Vampire
  const specialBeakAccessories = [
    ChickenBeakAccessory.Vampire,
    ChickenBeakAccessory.Ring,
  ];

  const specialEyesTypeChance = 0.05 / 100; // 0.05% chance of either Alien, Lizard or Eyepatch
  const specialEyesTypes = [
    ChickenEyesType.Alien,
    ChickenEyesType.Lizard,
    ChickenEyesType.Eyepatch,
  ];
  const normalEyesTypes = [
    ChickenEyesType.Cockeyed,
    ChickenEyesType.Angry,
    ChickenEyesType.Bloodshot,
    ChickenEyesType.Sad,
    ChickenEyesType.Bulging,
    ChickenEyesType.Determined,
    ChickenEyesType.Shocked,
    ChickenEyesType.Exhausted,
    ChickenEyesType.Sleepy,
    ChickenEyesType.Crosseyed,
    ChickenEyesType.Beauty,
  ];

  for (let i = 0; i < numberOfFans; i += 1) {
    const chicken: {
      animation?: string,
      baseBody?: string,
      legs?: string,
      beakColor?: string,
      combColor?: string,
      wattleColor?: string,
      stripes?: string,
      beakAccessory?: string,
      eyesType?: string,
    } = {};

    // animation
    const animationIndex = Math.floor(Math.random() * animations.length);
    const [animation] = animations.splice(animationIndex, 1);
    chicken.animation = animation;

    // baseBody
    const isSpecialBaseBody = Math.random() < specialBaseBodyChance;
    if (isSpecialBaseBody) {
      const index = Math.floor(Math.random() * specialBaseBodies.length);
      const [baseBody] = specialBaseBodies.splice(index, 1);
      chicken.baseBody = baseBody || ChickenBaseBody.Black;
    } else {
      const index = Math.floor(Math.random() * normalBaseBodies.length);
      const [baseBody] = normalBaseBodies.splice(index, 1);
      chicken.baseBody = baseBody;
    }

    // legs
    const isLegsHen = Math.random() < 0.5;
    if (chicken.baseBody === ChickenBaseBody.Black) {
      chicken.legs = isLegsHen ? ChickenLegs.legsBlackHen : ChickenLegs.legsBlackRooster;
    } else {
      chicken.legs = isLegsHen ? ChickenLegs.legsHen : ChickenLegs.legsRooster;
    }

    // beakColor
    if (chicken.baseBody === ChickenBaseBody.Black) {
      chicken.beakColor = ChickenBeakColor.Black;
    } else {
      const index = Math.floor(Math.random() * normalBeakColors.length);
      const [beakColor] = normalBeakColors.splice(index, 1);
      chicken.beakColor = beakColor;
    }

    // combColor & wattleColor
    if (chicken.baseBody === ChickenBaseBody.Robot) {
      chicken.combColor = ChickenCombColorAdditional.Studs;

      const index = Math.floor(Math.random() * normalCombColors.length);
      const [wattleColor] = normalCombColors.splice(index, 1);
      chicken.wattleColor = wattleColor;
    } else {
      const index = Math.floor(Math.random() * normalCombColors.length);
      const [combColor] = normalCombColors.splice(index, 1);
      chicken.combColor = combColor;

      chicken.wattleColor = chicken.combColor;
    }

    // stripes
    chicken.stripes = null;

    // beackAccessory
    const isSpecialBeakAccessory = Math.random() < specialBeakAccessoryChance;
    if (isSpecialBeakAccessory) {
      const index = Math.floor(Math.random() * specialBeakAccessories.length);
      chicken.beakAccessory = specialBeakAccessories.splice(index, 1)[0] || null;
    } else {
      chicken.beakAccessory = null;
    }

    // eyesType
    const isSpecialEyes = Math.random() < specialEyesTypeChance;
    if (isSpecialEyes) {
      const index = Math.floor(Math.random() * specialEyesTypes.length);
      const [eyesType] = specialEyesTypes.splice(index, 1);
      chicken.eyesType = eyesType || ChickenEyesType.Alien;
    } else if (chicken.baseBody === ChickenBaseBody.Robot) {
      chicken.eyesType = ChickenEyesType.Robot;
    } else {
      const index = Math.floor(Math.random() * normalEyesTypes.length);
      const [eyesType] = normalEyesTypes.splice(index, 1);
      chicken.eyesType = eyesType;
    }

    chickens.push(chicken);
  }

  const meta: any = {
    talent: ChickenTalent.FanGroup,

    fansStartDuration: undefined,
    tSA1Segment,
    fansSpawnSpeedMultiplier,
    fansSpawnDistanceOffset,
    fansStartPosition: undefined,

    timeWhenFansSlowDown,
    tSA2Segment,

    disappearDistance,
    chickens,
  };

  return meta;
};

const applyFanGroup = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalSegmentSizeB = talentSegmentB.segmentSize;
  const originalEndSpeedA = talentSegmentA.endSpeed;

  const eyesBonus = source.eyesType === ChickenEyesType.Buttons ? 0.2 : 0;
  const fanGroupSpeed = talentSegmentA.endSpeed * (1.35 + eyesBonus);
  const segmentSizeA = 0.5;
  const segmentSizeA1 = 1.5;
  const segmentSizeA2 = 5.2;
  const segmentSizeA3 = 1.7;
  const remainderDuration = originalSegmentSizeA + originalSegmentSizeB - segmentSizeA - segmentSizeA1 - segmentSizeA2 - segmentSizeA3;
  const segmentSizeB = remainderDuration;

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;
  talentSegmentA.endSpeed = talentSegmentA.startSpeed;

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: fanGroupSpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: 'FanGroup_Startle',
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: fanGroupSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: 'FanGroup_Run',
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: originalEndSpeedA,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: 'FanGroup_Relief',
  };

  talentSegmentB.segmentSize = segmentSizeB;
  talentSegmentB.startSpeed = talentSegmentA3.endSpeed;

  // insert talentSegmentA1, A2, A3 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3);

  // Chicken Fans
  const numberOfFans = source.eyesType === ChickenEyesType.Buttons ? 4 : 3;
  const meta = getFanGroupMeta(numberOfFans);

  if (sourceRaceProfile.metas?.length) {
    sourceRaceProfile.metas.push(meta);
  } else {
    sourceRaceProfile.metas = [meta];
  }

  const cutscene = {
    type: 'talent',
    startTime: Math.max(0, talentSegmentA.cumulativeSegmentSize - 2), // The startTime of tSA + 1, -2 seconds
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize, // The startTime segment tSA + 1
    duration: 10,
    sound: 'FanGroup_Startle',
  }, {
    type: 'effect',
    loop: true,
    startTime: talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize, // The startTime segment tSA
    duration: originalSegmentSizeA + originalSegmentSizeB, // tSA’s orginal segmentSize + tSB’s orginal segmentSize
    sound: 'FanGroup_Stampede',
  }];
  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyFanGroup',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const applyHelicopter = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
  const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

  if (!targetRaceProfiles?.length) {
    return;
  }

  // performing chicken
  const sourceTalentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const sourceTalentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const sourceTalentSegmentA = sourceRaceProfile.segments[sourceTalentIndexA];
  const sourceTalentSegmentB = sourceRaceProfile.segments[sourceTalentIndexB];

  const sourceOriginalSegmentSizeA = sourceTalentSegmentA.segmentSize;
  const sourceOriginalSegmentSizeB = sourceTalentSegmentB.segmentSize;
  const sourceOriginalEndSpeedA = sourceTalentSegmentA.endSpeed;

  const helicopterSpeed = sourceTalentSegmentA.endSpeed * 1.2;
  const shootingDuration = 1.4 * targets.length;

  const sourceSegmentSizeA = 0.1;
  const sourceSegmentSizeA1 = 2.33;
  const sourceSegmentSizeA2 = shootingDuration;
  const sourceSegmentSizeA3 = 1.33;
  const sourceSegmentSizeA4 = 1.49;
  const sourceRemainderDuration = sourceOriginalSegmentSizeA + sourceOriginalSegmentSizeB
    - sourceSegmentSizeA - sourceSegmentSizeA1 - sourceSegmentSizeA2 - sourceSegmentSizeA3 - sourceSegmentSizeA4;
  const sourceSegmentSizeB = sourceRemainderDuration;

  sourceTalentSegmentA.cumulativeSegmentSize = sourceTalentSegmentA.cumulativeSegmentSize - sourceOriginalSegmentSizeA + sourceSegmentSizeA;
  sourceTalentSegmentA.segmentSize = sourceSegmentSizeA;
  sourceTalentSegmentA.endSpeed = sourceTalentSegmentA.startSpeed;

  // build segment except segment (index to mark as talent segment)
  const sourceTalentSegmentA1 = {
    segmentSize: sourceSegmentSizeA1,
    startSpeed: sourceTalentSegmentA.endSpeed,
    endSpeed: helicopterSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA.cumulativeSegmentSize + sourceSegmentSizeA1,
    segmentChickenAnimation: 'Helicopter_Mount_Ladder',
  };

  const sourceTalentSegmentA2 = {
    segmentSize: sourceSegmentSizeA2,
    startSpeed: helicopterSpeed,
    endSpeed: helicopterSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA1.cumulativeSegmentSize + sourceSegmentSizeA2,
    segmentChickenAnimation: 'Helicopter_Shooting',
  };

  const sourceTalentSegmentA3 = {
    segmentSize: sourceSegmentSizeA3,
    startSpeed: helicopterSpeed,
    endSpeed: helicopterSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA2.cumulativeSegmentSize + sourceSegmentSizeA3,
    segmentChickenAnimation: 'Helicopter_Holding_Ladder_Fired',
  };

  const sourceTalentSegmentA4 = {
    segmentSize: sourceSegmentSizeA4,
    startSpeed: helicopterSpeed,
    endSpeed: sourceOriginalEndSpeedA,
    cumulativeSegmentSize: sourceTalentSegmentA3.cumulativeSegmentSize + sourceSegmentSizeA4,
    segmentChickenAnimation: 'Helicopter_Dismount_Ladder',
  };

  sourceTalentSegmentB.segmentSize = sourceSegmentSizeB;

  // insert talentSegmentA1, A2, A3, A4 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(
    sourceTalentIndexB,
    0,
    sourceTalentSegmentA1,
    sourceTalentSegmentA2,
    sourceTalentSegmentA3,
    sourceTalentSegmentA4,
  );

  const cutscene = {
    type: 'talent',
    startTime: Math.max(sourceTalentSegmentA.cumulativeSegmentSize - 2, 0), // The startTime of the performing chicken’s tSA + 1 , -2 seconds
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const sourceSoundProfilesForTalent = [{
    type: 'effect',
    loop: true,
    startTime: sourceTalentSegmentA.cumulativeSegmentSize - sourceTalentSegmentA.segmentSize, // The startTime of the performing chicken’s segment tSA
    duration: 10,
    sound: 'Helicopter_Blades',
  }, {
    type: 'effect',
    loop: false,
    startTime: sourceTalentSegmentA.cumulativeSegmentSize, // The startTime of the performing chicken’s segment tSA + 1
    duration: 10,
    sound: 'Helicopter_GrabLadder',
  }, {
    type: 'effect',
    loop: false,
    startTime: sourceTalentSegmentA3.cumulativeSegmentSize, // The startTime of the performing chicken’s segment tSA + 4
    duration: 10,
    sound: 'Helicopter_DropOff',
  }];
  soundProfiles.push(...sourceSoundProfilesForTalent);

  log.info({
    func: 'applyHelicopter',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    sourceSoundProfilesForTalent,
  }, `Apply ${talent} To Source Successfully`);

  // target chickens
  const targetSoundProfilesForTalent: any[] = [];
  const hitNumbers = targets.length <= 2 ? [1, 2] : [1, 2, 3];

  targets.forEach((target) => {
    const targetRaceProfile = targetRaceProfiles.find((rp) => rp.chickenId === target.id);

    const targetTalentIndexA = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
    const targetTalentIndexB = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
    const targetTalentSegmentA = targetRaceProfile.segments[targetTalentIndexA];
    const targetTalentSegmentB = targetRaceProfile.segments[targetTalentIndexB];

    const targetOriginalSegmentSizeA = targetTalentSegmentA.segmentSize;
    const targetOriginalSegmentSizeB = targetTalentSegmentB.segmentSize;

    const hitNumberIndex = Math.floor(Math.random() * hitNumbers.length);
    const hitNumber = hitNumbers.splice(hitNumberIndex, 1)[0];

    const dizzySpeed = targetTalentSegmentA.endSpeed * 0.8;

    const vampBonus = source.beakAccessory === ChickenBeakAccessory.Vampire ? 0.77 : 0;
    const ringBonus = target.beakAccessory === ChickenBeakAccessory.Ring ? -0.77 : 0;
    const dizzyDuration = 2.3 + vampBonus + ringBonus;

    const targetSegmentSizeA1 = 0.36;
    const targetSegmentSizeA2 = 0.03;
    const targetSegmentSizeA3 = 1.13;
    const targetSegmentSizeA4 = 0.77;
    const targetSegmentSizeA5 = dizzyDuration;
    const missileDuration = Math.min(
      2.5 + hitNumber * 1.4,
      targetOriginalSegmentSizeA + targetOriginalSegmentSizeB
      - targetSegmentSizeA1 - targetSegmentSizeA2 - targetSegmentSizeA3 - targetSegmentSizeA4 - targetSegmentSizeA5,
    );
    const targetSegmentSizeA = missileDuration;
    const targetReminderDuration = targetOriginalSegmentSizeA + targetOriginalSegmentSizeB
      - (targetSegmentSizeA + targetSegmentSizeA1 + targetSegmentSizeA2 + targetSegmentSizeA3 + targetSegmentSizeA4 + targetSegmentSizeA5);
    const targetSegmentSizeB = targetReminderDuration;

    targetTalentSegmentA.cumulativeSegmentSize = targetTalentSegmentA.cumulativeSegmentSize - targetOriginalSegmentSizeA + targetSegmentSizeA;
    targetTalentSegmentA.segmentSize = targetSegmentSizeA;

    const targetTalentSegmentA1 = {
      segmentSize: targetSegmentSizeA1,
      startSpeed: targetTalentSegmentA.endSpeed,
      endSpeed: targetTalentSegmentA.endSpeed,
      cumulativeSegmentSize: targetTalentSegmentA.cumulativeSegmentSize + targetSegmentSizeA1,
      segmentChickenAnimation: 'Helicopter_Missile_Hit_1',
    };

    const targetTalentSegmentA2 = {
      segmentSize: targetSegmentSizeA2,
      startSpeed: targetTalentSegmentA1.endSpeed,
      endSpeed: 0,
      cumulativeSegmentSize: targetTalentSegmentA1.cumulativeSegmentSize + targetSegmentSizeA2,
      segmentChickenAnimation: 'Helicopter_Missile_Hit_2',
    };

    const targetTalentSegmentA3 = {
      segmentSize: targetSegmentSizeA3,
      startSpeed: targetTalentSegmentA2.endSpeed,
      endSpeed: 0,
      cumulativeSegmentSize: targetTalentSegmentA2.cumulativeSegmentSize + targetSegmentSizeA3,
      segmentChickenAnimation: 'Helicopter_Missile_Hit_3',
    };

    const targetTalentSegmentA4 = {
      segmentSize: targetSegmentSizeA4,
      startSpeed: targetTalentSegmentA3.endSpeed,
      endSpeed: dizzySpeed,
      cumulativeSegmentSize: targetTalentSegmentA3.cumulativeSegmentSize + targetSegmentSizeA4,
      segmentChickenAnimation: 'Dizzy_running',
    };

    const targetTalentSegmentA5 = {
      segmentSize: targetSegmentSizeA5,
      startSpeed: targetTalentSegmentA4.endSpeed,
      endSpeed: dizzySpeed,
      cumulativeSegmentSize: targetTalentSegmentA4.cumulativeSegmentSize + targetSegmentSizeA5,
      segmentChickenAnimation: 'Dizzy_running',
    };

    targetTalentSegmentB.segmentSize = targetSegmentSizeB;
    targetTalentSegmentB.startSpeed = targetTalentSegmentA5.endSpeed;

    // insert talentSegmentA1, A2, A3, A4 between talentSegmentA and talentSegmentB
    targetRaceProfile.segments.splice(
      targetTalentIndexB,
      0,
      targetTalentSegmentA1,
      targetTalentSegmentA2,
      targetTalentSegmentA3,
      targetTalentSegmentA4,
      targetTalentSegmentA5,
    );

    targetSoundProfilesForTalent.push({
      type: 'effect',
      loop: false,
      startTime: targetTalentSegmentA1.cumulativeSegmentSize, // The startTime of a targeted chicken’s segment tSA + 2
      duration: 10,
      sound: 'Helicopter_LaunchMissile',
    }, {
      type: 'effect',
      loop: false,
      startTime: targetTalentSegmentA1.cumulativeSegmentSize + 1.4, // The startTime of a targeted chicken’s segment tSB + 2 + 1.4s
      duration: 10,
      sound: 'Helicopter_LaunchMissile',
    }, {
      type: 'effect',
      loop: false,
      startTime: targetTalentSegmentA.cumulativeSegmentSize, // The startTime of each targeted chicken’s segment tSA + 1
      duration: 10,
      sound: 'Helicopter_MissileHit',
    });
    if (hitNumber === 3) {
      // The startTime of a targeted chicken’s segment tSA + 2 + 2.8s (only if 3 missiles are fired),
      targetSoundProfilesForTalent.push({
        type: 'effect',
        loop: false,
        startTime: targetTalentSegmentA1.cumulativeSegmentSize + 2.8,
        duration: 10,
        sound: 'Helicopter_LaunchMissile',
      });
    }
    soundProfiles.push(...targetSoundProfilesForTalent);

    log.info({
      func: 'applyHelicopter',
      raceId: raceModel.id,
      chickenId: target.id,
      talent,
      beakAccessory: target.beakAccessory,
      targetRaceProfile,
      targetSoundProfilesForTalent,
    }, `Apply ${talent} To Target Successfully`);
  });
};

export const getPositionByTime = (segments: Segment[], elapsedTime: number) => {
  let position = 0; // in meters
  let segIndex = 0;

  // position until full segments
  for (let i = 0; i < segments.length; i += 1) {
    const segment = segments[i];
    const {
      segmentSize,
      cumulativeSegmentSize,
      startSpeed,
      endSpeed,
    } = segment;

    if (cumulativeSegmentSize < elapsedTime) {
      const avgSpeed = (startSpeed + endSpeed) / 2;
      position += avgSpeed * segmentSize;
      segIndex = i + 1;
    }
  }

  // position for the last segment passed partially
  if (segIndex < segments.length) {
    const segment = segments[segIndex];
    const {
      segmentSize,
      cumulativeSegmentSize,
      startSpeed,
      endSpeed,
    } = segment;

    const timeInSeg = segmentSize - (cumulativeSegmentSize - elapsedTime);
    const f = timeInSeg / segmentSize;
    const currentSpeed = (endSpeed - startSpeed) * f + startSpeed;
    const avgSpeed = (startSpeed + currentSpeed) / 2;
    position += avgSpeed * timeInSeg;
  }

  return position;
};

const applyBlackHole = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[], isKillChicken = false) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
  const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

  if (!targetRaceProfiles?.length) {
    return;
  }

  // performing chicken
  const sourceTalentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const sourceTalentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const sourceTalentSegmentA = sourceRaceProfile.segments[sourceTalentIndexA];
  const sourceTalentSegmentB = sourceRaceProfile.segments[sourceTalentIndexB];

  const sourceOriginalSegmentSizeA = sourceTalentSegmentA.segmentSize;
  const sourceOriginalSegmentSizeB = sourceTalentSegmentB.segmentSize;
  const sourceOriginalEndSpeedA = sourceTalentSegmentA.endSpeed;

  const sourceSegmentSizeA = 0.1;
  const sourceSegmentSizeA1 = 1.3;
  const sourceSegmentSizeA2 = 6.0;
  const sourceRemainderDuration = sourceOriginalSegmentSizeA + sourceOriginalSegmentSizeB
    - sourceSegmentSizeA - sourceSegmentSizeA1 - sourceSegmentSizeA2;
  const sourceSegmentSizeB = sourceRemainderDuration;

  sourceTalentSegmentA.cumulativeSegmentSize = sourceTalentSegmentA.cumulativeSegmentSize - sourceOriginalSegmentSizeA + sourceSegmentSizeA;
  sourceTalentSegmentA.segmentSize = sourceSegmentSizeA;
  sourceTalentSegmentA.endSpeed = sourceTalentSegmentA.startSpeed;

  // build segment except segment (index to mark as talent segment)
  const sourceTalentSegmentA1 = {
    segmentSize: sourceSegmentSizeA1,
    startSpeed: sourceTalentSegmentA.endSpeed,
    endSpeed: sourceTalentSegmentA.endSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA.cumulativeSegmentSize + sourceSegmentSizeA1,
    segmentChickenAnimation: 'BlackHole_Spit',
  };

  const sourceTalentSegmentA2 = {
    segmentSize: sourceSegmentSizeA2,
    startSpeed: sourceTalentSegmentA1.endSpeed,
    endSpeed: sourceOriginalEndSpeedA,
    cumulativeSegmentSize: sourceTalentSegmentA1.cumulativeSegmentSize + sourceSegmentSizeA2,
  };

  sourceTalentSegmentB.segmentSize = sourceSegmentSizeB;
  sourceTalentSegmentB.startSpeed = sourceTalentSegmentA2.endSpeed;

  // insert talentSegmentA1 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(sourceTalentIndexB, 0, sourceTalentSegmentA1, sourceTalentSegmentA2);

  const cutscene = {
    type: 'talent',
    startTime: Math.max(sourceTalentSegmentA.cumulativeSegmentSize - 2, 0), // The startTime of the performing chicken’s tSA + 1 , -2 seconds
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const sourceSoundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: sourceTalentSegmentA.cumulativeSegmentSize, // The startTime of the performing chicken’s segment tSA + 1
    duration: 10,
    sound: 'BlackHole_Spit',
  }];
  soundProfiles.push(...sourceSoundProfilesForTalent);

  log.info({
    func: 'applyBlackHole',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    sourceSoundProfilesForTalent,
  }, `Apply ${talent} To Source Successfully`);

  // target chickens
  const targetSoundProfilesForTalent: any[] = [];

  const blackHoleStartTime = sourceTalentSegmentA1.cumulativeSegmentSize;

  // The black hole is a seperate entity that is spawned during the race.
  // It is created at the start of bh3. Its initial position is to lineup with the black hole that is spat out by the performing chicken.
  // It is to immediately start the BlackHole_Expand animation and move to be centre of the screen.
  // Vertical position is to between lanes 6 & 7, horizontal position center should be the center of the performing chicken.
  // This move should take exactly 1.00 seconds
  const segmentSizebHS1 = 1.00;
  const blackHoleCenterTime = blackHoleStartTime + segmentSizebHS1;
  const blackHoleRadius = 2; // 2m

  const blackHoleCenterPosition = getPositionByTime(sourceRaceProfile.segments, blackHoleCenterTime);
  let farthestChickenDistance = 0;
  const distanceFromBlackHole: {
    [chickenId: number]: number,
  } = {};

  for (const raceProfile of raceProfiles) {
    const distance = Math.abs(blackHoleCenterPosition - getPositionByTime(raceProfile.segments, blackHoleCenterTime));
    if (distance > farthestChickenDistance) {
      farthestChickenDistance = distance;
    }
    distanceFromBlackHole[raceProfile.chickenId] = distance;
  }

  const blackHoleSlowness = 0.80;
  const maxFallTime = 1.8;

  const numberOfTargetChickensExceptForDNF = isKillChicken ? targets.length - 1 : targets.length;
  const spitPositions: number[] = [];
  for (let i = 0; i < numberOfTargetChickensExceptForDNF; i += 1) {
    spitPositions.push(i);
  }

  // filter out unassigned lanes
  const numberOfLanes = raceModel.lanes.filter((lane) => lane.chickenId).length;
  const copyChickens: any[] = [];

  targets.forEach((target, index) => {
    const targetChickenId = target.id;
    const targetRaceProfile = targetRaceProfiles.find((rp) => rp.chickenId === targetChickenId);

    const targetTalentIndexA = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
    const targetTalentIndexB = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
    const targetTalentSegmentA = targetRaceProfile.segments[targetTalentIndexA];
    const targetTalentSegmentB = targetRaceProfile.segments[targetTalentIndexB];

    const targetOriginalSegmentSizeA = targetTalentSegmentA.segmentSize;
    const targetOriginalSegmentSizeB = targetTalentSegmentB.segmentSize;
    const targetOriginalEndSpeedA = targetTalentSegmentA.endSpeed;

    const targetFinishOrder = raceProfiles.findIndex((raceProfile) => raceProfile.chickenId === targetChickenId);
    const isLastChicken = targetFinishOrder === raceProfiles.length - 1;
    const isDnfChicken = isKillChicken && isLastChicken;

    const blackHoleSpeed = targetOriginalEndSpeedA * 0.5;
    const spitPositionIndex = Math.floor(Math.random() * spitPositions.length);
    const spitPosition = (!isDnfChicken && spitPositions.splice(spitPositionIndex, 1)[0]) || 0;
    const spitDelay = spitPosition * 0.04;
    const targetLane = raceModel.lanes.find((lane) => lane.chickenId === targetChickenId);
    const fallDuration = 0.1 + targetLane.laneNumber / numberOfLanes * maxFallTime;
    const suckDelay = distanceFromBlackHole[targetChickenId] / farthestChickenDistance;
    const blackHoleDuration = 5.70 + spitDelay - suckDelay + fallDuration;

    const targetSegmentSizeA = 2.40 + suckDelay;
    const targetSegmentSizeA1 = blackHoleDuration;
    const targetRemainderDuration = targetOriginalSegmentSizeA + targetOriginalSegmentSizeB - targetSegmentSizeA - targetSegmentSizeA1;
    const targetSegmentSizeB = targetRemainderDuration;

    targetTalentSegmentA.cumulativeSegmentSize = targetTalentSegmentA.cumulativeSegmentSize - targetOriginalSegmentSizeA + targetSegmentSizeA;
    targetTalentSegmentA.segmentSize = targetSegmentSizeA;
    targetTalentSegmentA.endSpeed = targetTalentSegmentA.startSpeed;

    const targetTalentSegmentA1 = {
      segmentSize: targetSegmentSizeA1,
      startSpeed: targetTalentSegmentA.endSpeed,
      endSpeed: blackHoleSpeed,
      cumulativeSegmentSize: targetTalentSegmentA.cumulativeSegmentSize + targetSegmentSizeA1,
      segmentChickenAnimation: 'DoNotDrawChicken',
    };

    targetTalentSegmentB.segmentSize = targetSegmentSizeB;
    targetTalentSegmentB.startSpeed = targetTalentSegmentA1.endSpeed;

    if (isDnfChicken) {
      for (let i = targetTalentIndexA + 1; i < targetRaceProfile.segments.length; i += 1) {
        targetRaceProfile.segments[i].segmentChickenAnimation = 'DoNotDrawChicken';
      }
      (targetRaceProfile as any).isDnfChicken = isDnfChicken;
    }

    // insert talentSegmentA1 between talentSegmentA and talentSegmentB
    targetRaceProfile.segments.splice(targetTalentIndexB, 0, targetTalentSegmentA1);

    const spitAngleMin = -5;
    const spitAngleMax = 5;
    const spitAngle = Math.random() * (spitAngleMax - spitAngleMin) + spitAngleMin;

    const copyChicken: any = {
      chickenId: targetChickenId,
      startTime: targetTalentSegmentA.cumulativeSegmentSize,
      startPosition: undefined, // target chicken's position
      spitPosition,
      spitAngle,
      isDnfChicken,
      segments: [{
        duration: 2.73,
        animation: 'Spaghettification',
      }, {
        duration: 3.27 + spitDelay - suckDelay,
        animation: 'DoNotDrawChicken',
      }, {
        duration: 0.5,
        animation: 'BlackHole_SpatFly',
      }, {
        duration: fallDuration,
        animation: 'BlackHole_SpatFly',
      }, {
        duration: 0.43,
        animation: 'BlackHole_Fall',
      }],
    };
    copyChickens.push(copyChicken);

    if (index === 0) {
      targetSoundProfilesForTalent.push({
        type: 'effect',
        loop: false,
        startTime: targetTalentSegmentA.cumulativeSegmentSize + 1.33, // The startTime of a targeted chicken’s segment tSA + 1 + 1.33s
        duration: 10,
        sound: 'BlackHole_Expand',
      }, {
        type: 'effect',
        loop: false,
        startTime: targetTalentSegmentB.cumulativeSegmentSize - targetTalentSegmentB.segmentSize, // The startTime of a targeted chicken’s segment tSB
        duration: 10,
        sound: 'BlackHole_Collapse',
      });
      soundProfiles.push(...targetSoundProfilesForTalent);
    }

    log.info({
      func: 'applyBlackHole',
      raceId: raceModel.id,
      chickenId: target.id,
      talent,
      beakAccessory: target.beakAccessory,
      targetRaceProfile,
      targetSoundProfilesForTalent,
      isKillChicken,
      copyChicken,
    }, `Apply ${talent} To Target Successfully`);
  });

  const blackHole: any = {
    startTime: blackHoleStartTime,
    startPosition: undefined, // performing chicken's position
    blackHoleSlowness,
    blackHoleRadius,
  };

  const meta: any = {
    talent,
    tSA1Segment: undefined,
    blackHole,
    copyChickens,
  };

  if (sourceRaceProfile.metas?.length) {
    sourceRaceProfile.metas.push(meta);
  } else {
    sourceRaceProfile.metas = [meta];
  }
};

const getAllAdjacentSegmentsAndLock = (
  raceModel: Race,
  chickensToPerformTalent: ChickenForTalent[],
  masterSegments: MasterSegment[],
  raceProfiles: RaceProfile[],
) => {
  const adjacentSegmentList: number[][] = [];

  log.info({
    func: 'getAllAdjacentSegmentsAndLock',
    raceId: raceModel.id,
  }, 'Start Get All Adjacent Segments And Lock');

  try {
    chickensToPerformTalent.forEach((chickenForTalent) => {
      const {
        source,
        targets,
      } = chickenForTalent;

      const { talent } = source;

      switch (talent) {
        case ChickenTalent.Anvil:
          {
            // only one target for anvil
            const target = targets[0];
            const targetRaceProfile = raceProfiles.find((rp) => rp.chickenId === target?.id);

            if (!targetRaceProfile) {
              adjacentSegmentList.push([]);
              break;
            }

            const firstSegmentSizeMin = 3;
            const cumulativeSecondAndThirdSegmentSizeMin = 9;

            // need to get 3 adjacent segments based on target race profile to prevent minus segmentSize
            const adjacentSegments = getThreeAdjacentSegmentsAndLock(raceModel, masterSegments, targetRaceProfile, {
              talent,
              firstSegmentSizeMin,
              cumulativeSecondAndThirdSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.BlueRooster:
          {
            const cumulativeSegmentSizeMin = 11;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Chickenapult:
          {
            const cumulativeSegmentSizeMin = 11.5;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.CK47:
          {
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
            const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

            if (!targetRaceProfiles?.length) {
              adjacentSegmentList.push([]);
              break;
            }

            // need to get 2 adjacent segments based on min target race profile to prevent minus segmentSize
            const minRaceProfile = _.minBy([
              ...targetRaceProfiles,
              sourceRaceProfile,
            ], (rp) => rp.segments[rp.segments.length - 1].cumulativeSegmentSize);

            const cumulativeSegmentSizeMin = 11;
            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, minRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Coober:
          {
            const cumulativeSegmentSizeMin = 12;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Flight:
          {
            const cumulativeSegmentSizeMin = 11.5;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Growth:
          {
            const cumulativeSegmentSizeMin = 13;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Machete:
          {
            const cumulativeSegmentSizeMin = 13;

            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
            const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

            if (!targetRaceProfiles?.length) {
              adjacentSegmentList.push([]);
              break;
            }

            // need to get 2 adjacent segments based on min target race profile to prevent minus segmentSize
            const minRaceProfile = _.minBy([
              ...targetRaceProfiles,
              sourceRaceProfile,
            ], (rp) => rp.segments[rp.segments.length - 1].cumulativeSegmentSize);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, minRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Rollerblades:
          {
            const cumulativeSegmentSizeMin = 10;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Teleport:
          {
            const target = targets[0];
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
            const targetRaceProfile = raceProfiles.find((rp) => rp.chickenId === target?.id);

            if (!targetRaceProfile) {
              adjacentSegmentList.push([]);
              break;
            }

            const segmentSizeMin = 6.2;

            // need to get adjacent segments based on min target race profile to prevent minus segmentSize
            const minRaceProfile = _.minBy([targetRaceProfile, sourceRaceProfile], (rp) => rp.segments[rp.segments.length - 1].cumulativeSegmentSize);
            const selectedSegment = getSingleSegmentAndLock(raceModel, masterSegments, minRaceProfile, {
              talent,
              segmentSizeMin,
            });

            if (!selectedSegment) {
              adjacentSegmentList.push([]);
              break;
            }

            adjacentSegmentList.push([selectedSegment]);
          }
          break;

        case ChickenTalent.BlueEgg:
          {
            const target = targets[0];
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
            const targetRaceProfile = raceProfiles.find((rp) => rp.chickenId === target?.id);

            if (!targetRaceProfile) {
              adjacentSegmentList.push([]);
              break;
            }

            const cumulativeSegmentSizeMin = 14.5;
            const firstSegmentIndexMin = 2;
            const secondSegmentIndexMin = 2;

            // need to get adjacent segments based on min race profile to prevent minus segmentSize
            const minRaceProfile = _.minBy([targetRaceProfile, sourceRaceProfile], (rp) => rp.segments[rp.segments.length - 1].cumulativeSegmentSize);
            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, minRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
              firstSegmentIndexMin,
              secondSegmentIndexMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Dig:
          {
            const cumulativeSegmentSizeMin = 8.1;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.FanGroup:
          {
            const cumulativeSegmentSizeMin = 9;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
              firstSegmentIndexMin: 4,
              isExcludeAdjacentTalentSegments: true,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Helicopter:
          {
            const cumulativeSegmentSizeMin = 13;

            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
            const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

            if (!targetRaceProfiles?.length) {
              adjacentSegmentList.push([]);
              break;
            }

            // need to get 2 adjacent segments based on min race profile to prevent minus segmentSize
            const minRaceProfile = _.minBy([
              ...targetRaceProfiles,
              sourceRaceProfile,
            ], (rp) => rp.segments[rp.segments.length - 1].cumulativeSegmentSize);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, minRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
              isExcludeAdjacentTalentSegments: true,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Jetpack:
          {
            const cumulativeSegmentSizeMin = 12;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.ColdSnap:
          {
            const cumulativeSegmentSizeMin = 14;
            const firstSegmentSizeMin = 4;

            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
            const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

            if (!targetRaceProfiles?.length) {
              adjacentSegmentList.push([]);
              break;
            }

            // need to get 2 adjacent segments based on min race profile to prevent minus segmentSize
            const minRaceProfile = _.minBy([
              ...targetRaceProfiles,
              sourceRaceProfile,
            ], (rp) => rp.segments[rp.segments.length - 1].cumulativeSegmentSize);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, minRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
              firstSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.Devolution:
          {
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
            const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

            if (!targetRaceProfiles?.length) {
              adjacentSegmentList.push([]);
              break;
            }

            // need to get 2 adjacent segments based on min target race profile to prevent minus segmentSize
            const minRaceProfile = _.minBy([
              ...targetRaceProfiles,
              sourceRaceProfile,
            ], (rp) => rp.segments[rp.segments.length - 1].cumulativeSegmentSize);

            const cumulativeSegmentSizeMin = 13;
            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, minRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.MovingWalkway:
          {
            const cumulativeSegmentSizeMin = 11;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
              isExcludeAdjacentTalentSegments: true,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.BlackHole:
          {
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
            const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

            if (!targetRaceProfiles?.length) {
              adjacentSegmentList.push([]);
              break;
            }

            // need to get 2 adjacent segments based on min target race profile to prevent minus segmentSize
            const minRaceProfile = _.minBy([
              ...targetRaceProfiles,
              sourceRaceProfile,
            ], (rp) => rp.segments[rp.segments.length - 1].cumulativeSegmentSize);

            const cumulativeSegmentSizeMin = 12.5;
            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, minRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.RoyalProcession:
          {
            const cumulativeSegmentSizeMin = 12.2;
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.FeatherRain:
          {
            const cumulativeSegmentSizeMin = 12;

            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
            const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

            if (!targetRaceProfiles?.length) {
              adjacentSegmentList.push([]);
              break;
            }

            // need to get 2 adjacent segments based on min target race profile to prevent minus segmentSize
            const minRaceProfile = _.minBy([
              ...targetRaceProfiles,
              sourceRaceProfile,
            ], (rp) => rp.segments[rp.segments.length - 1].cumulativeSegmentSize);

            const adjacentSegments = getTwoAdjacentSegmentsAndLock(raceModel, masterSegments, minRaceProfile, {
              talent,
              cumulativeSegmentSizeMin,
            });

            adjacentSegmentList.push(adjacentSegments);
          }
          break;

        case ChickenTalent.RunicRush:
          {
            const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
            const segmentSizeMin = 7.00;

            const selectedSegment = getSingleSegmentAndLock(raceModel, masterSegments, sourceRaceProfile, {
              talent,
              segmentSizeMin,
            });

            if (!selectedSegment) {
              adjacentSegmentList.push([]);
              break;
            }

            adjacentSegmentList.push([selectedSegment]);
          }
          break;

        default:
          break;
      }
    });

    // sort chickens by talent performing order
    for (let i = 0; i < chickensToPerformTalent.length; i += 1) {
      for (let j = 0; j < i; j += 1) {
        const segmentIndexJ = adjacentSegmentList[j][0];
        if (!segmentIndexJ) {
          continue;
        }

        const segmentIndexI = adjacentSegmentList[i][0];
        const isSwap = !segmentIndexI || segmentIndexI < segmentIndexJ;

        if (isSwap) {
          const chickenTemp = chickensToPerformTalent[i];
          chickensToPerformTalent[i] = chickensToPerformTalent[j];
          chickensToPerformTalent[j] = chickenTemp;

          const segmentsTemp = adjacentSegmentList[i];
          adjacentSegmentList[i] = adjacentSegmentList[j];
          adjacentSegmentList[j] = segmentsTemp;
        }
      }
    }

    log.info({
      func: 'getAllAdjacentSegmentsAndLock',
      raceId: raceModel.id,
      adjacentSegmentList,
    }, 'End Get All Adjacent Segments And Lock');
  } catch (err) {
    log.error({
      func: 'getAllAdjacentSegmentsAndLock',
      raceId: raceModel.id,
      err,
    }, 'Get All Adjacent Segments And Lock Error');
  }

  return adjacentSegmentList;
};

export const getSegmentByTime = (segments: Segment[], elapsedTime: number) => segments.find(
  (segment) => elapsedTime >= segment.cumulativeSegmentSize - segment.segmentSize && elapsedTime < segment.cumulativeSegmentSize,
);

export const transformStartSpeedAndEndSpeed = (segments: Segment[], distance: number) => {
  // fit startSpeed and endSpeed to the race distance
  const finishTime = segments[segments.length - 1].cumulativeSegmentSize;

  const totalAvgSpeed = segments.reduce((previousValue, segment) => previousValue
    + (segment.startSpeed + segment.endSpeed) * 0.5 * (segment.segmentSize / finishTime), 0);
  const avgSpeedTransformRate = distance / finishTime / totalAvgSpeed;

  segments.forEach((segment) => {
    segment.startSpeed *= avgSpeedTransformRate;
    segment.endSpeed *= avgSpeedTransformRate;
  });

  return segments;
};

const getDevolutionMeta = ({
  possibleDelay,
}: {
  possibleDelay: number,
}) => {
  const scale = 2 / 3;
  const spawnDistance = 10;
  const fleeSpeed = 1.5;

  const segmentSize1 = 3.6 + possibleDelay;
  const segmentSize2 = 0.9;
  const segmentSize3 = 2.67;
  const segmentSize4 = 10;
  const startSpeed: number = undefined;
  const endSpeed: number = undefined;

  const segments = [{
    segmentSize: segmentSize1,
    cumulativeSegmentSize: segmentSize1,
    segmentChickenAnimation: 'Devolution_Run',
    startSpeed,
    endSpeed,
  }, {
    segmentSize: segmentSize2,
    cumulativeSegmentSize: segmentSize1 + segmentSize2,
    segmentChickenAnimation: 'Devolution_Leap',
    startSpeed,
    endSpeed,
  }, {
    segmentSize: segmentSize3,
    cumulativeSegmentSize: segmentSize1 + segmentSize2 + segmentSize3,
    segmentChickenAnimation: 'DoNotDrawChicken',
    startSpeed,
    endSpeed,
  }, {
    segmentSize: segmentSize4,
    cumulativeSegmentSize: segmentSize1 + segmentSize2 + segmentSize3 + segmentSize4,
    segmentChickenAnimation: 'Devolution_Run',
    startSpeed,
    endSpeed,
  }];

  const meta: any = {
    talent: ChickenTalent.Devolution,

    scale,
    spawnDistance,
    spawnPosition: undefined,
    fleeSpeed,
    tSA1Segment: undefined,
    tSA2Segment: undefined,

    segments,
  };

  return meta;
};

const applyDevolution = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
  const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

  if (!targetRaceProfiles?.length) {
    return;
  }

  // performing chicken
  const sourceTalentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const sourceTalentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const sourceTalentSegmentA = sourceRaceProfile.segments[sourceTalentIndexA];
  const sourceTalentSegmentB = sourceRaceProfile.segments[sourceTalentIndexB];

  const sourceOriginalSegmentSizeA = sourceTalentSegmentA.segmentSize;
  const sourceOriginalSegmentSizeB = sourceTalentSegmentB.segmentSize;
  const sourceOriginalEndSpeedA = sourceTalentSegmentA.endSpeed;

  const devolutionSpeed = sourceOriginalEndSpeedA * 1.3;
  const devolutionDuration = source.eyesType === ChickenEyesType.Lizard ? 3.73 : 3.20;

  const sourceSegmentSizeA = 1.00;
  const sourceSegmentSizeA1 = 2.00;
  const sourceSegmentSizeA2 = 1.63;
  const sourceSegmentSizeA3 = devolutionDuration;
  const sourceSegmentSizeA4 = 2.17;
  const sourceRemainderDuration = sourceOriginalSegmentSizeA + sourceOriginalSegmentSizeB
    - sourceSegmentSizeA - sourceSegmentSizeA1 - sourceSegmentSizeA2 - sourceSegmentSizeA3 - sourceSegmentSizeA4;
  const sourceSegmentSizeB = sourceRemainderDuration;

  sourceTalentSegmentA.cumulativeSegmentSize = sourceTalentSegmentA.cumulativeSegmentSize - sourceOriginalSegmentSizeA + sourceSegmentSizeA;
  sourceTalentSegmentA.segmentSize = sourceSegmentSizeA;
  sourceTalentSegmentA.endSpeed = sourceTalentSegmentA.startSpeed;

  // build segment except segment (index to mark as talent segment)
  const sourceTalentSegmentA1 = {
    segmentSize: sourceSegmentSizeA1,
    startSpeed: sourceTalentSegmentA.endSpeed,
    endSpeed: devolutionSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA.cumulativeSegmentSize + sourceSegmentSizeA1,
    segmentChickenAnimation: 'Devolution_Transform',
  };

  const sourceTalentSegmentA2 = {
    segmentSize: sourceSegmentSizeA2,
    startSpeed: sourceTalentSegmentA1.endSpeed,
    endSpeed: devolutionSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA1.cumulativeSegmentSize + sourceSegmentSizeA2,
    segmentChickenAnimation: 'Devolution_Roar',
  };

  const sourceTalentSegmentA3 = {
    segmentSize: sourceSegmentSizeA3,
    startSpeed: sourceTalentSegmentA2.endSpeed,
    endSpeed: devolutionSpeed,
    cumulativeSegmentSize: sourceTalentSegmentA2.cumulativeSegmentSize + sourceSegmentSizeA3,
    segmentChickenAnimation: 'Devolution_Run',
  };

  const sourceTalentSegmentA4 = {
    segmentSize: sourceSegmentSizeA4,
    startSpeed: sourceTalentSegmentA3.endSpeed,
    endSpeed: sourceOriginalEndSpeedA,
    cumulativeSegmentSize: sourceTalentSegmentA3.cumulativeSegmentSize + sourceSegmentSizeA4,
    segmentChickenAnimation: 'Devolution_Return',
  };

  sourceTalentSegmentB.segmentSize = sourceSegmentSizeB;
  sourceTalentSegmentB.startSpeed = sourceTalentSegmentA3.endSpeed;

  // insert talentSegmentA1, A2, A3, A4 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(
    sourceTalentIndexB,
    0,
    sourceTalentSegmentA1,
    sourceTalentSegmentA2,
    sourceTalentSegmentA3,
    sourceTalentSegmentA4,
  );

  const cutscene = {
    type: 'talent',
    // The startTime of tSA, -1.5 seconds
    startTime: Math.max((sourceTalentSegmentA.cumulativeSegmentSize - sourceTalentSegmentA.segmentSize) - 1.5, 0),
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const sourceSoundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: sourceTalentSegmentA.cumulativeSegmentSize, // The startTime of the performing chicken’s tSA + 1
    duration: 10,
    sound: 'Devolution_Transform',
  }, {
    type: 'effect',
    loop: false,
    startTime: sourceTalentSegmentA2.cumulativeSegmentSize, // The startTime of the performing chicken’s tSA + 3 segment
    duration: 10,
    sound: 'Devolution_End',
  }];

  soundProfiles.push(...sourceSoundProfilesForTalent);

  log.info({
    func: 'applyDevolution',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    sourceSoundProfilesForTalent,
  }, `Apply ${talent} To Source Successfully Before Performing Bite`);

  // target chickens
  const possibleDelays = Math.random() < 0.5 ? [0, 0.5] : [0.5, 0];

  targets.forEach((target, targetIndex) => {
    const targetRaceProfile = targetRaceProfiles.find((rp) => rp.chickenId === target.id);

    const targetTalentIndexA = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
    const targetTalentIndexB = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
    const targetTalentSegmentA = targetRaceProfile.segments[targetTalentIndexA];
    const targetTalentSegmentB = targetRaceProfile.segments[targetTalentIndexB];

    const targetOriginalSegmentSizeA = targetTalentSegmentA.segmentSize;
    const targetOriginalSegmentSizeB = targetTalentSegmentB.segmentSize;
    const targetOriginalEndSpeedA = targetTalentSegmentA.endSpeed;

    const possibleDelay = possibleDelays[targetIndex];

    const vampBonus = source.beakAccessory === ChickenBeakAccessory.Vampire ? 0.77 : 0;
    const ringBonus = target.beakAccessory === ChickenBeakAccessory.Ring ? -0.77 : 0;
    const dizzyDuration = 2.30 + vampBonus + ringBonus;
    const dizzySpeed = targetOriginalEndSpeedA * 0.8;

    const targetSegmentSizeA = 4.5 + possibleDelay;
    const targetSegmentSizeA1 = 2.67;
    const targetSegmentSizeA2 = dizzyDuration;
    const targetRemainderDuration = targetOriginalSegmentSizeA + targetOriginalSegmentSizeB
      - targetSegmentSizeA - targetSegmentSizeA1 - targetSegmentSizeA2;
    const targetSegmentSizeB = targetRemainderDuration;

    targetTalentSegmentA.cumulativeSegmentSize = targetTalentSegmentA.cumulativeSegmentSize - targetOriginalSegmentSizeA + targetSegmentSizeA;
    targetTalentSegmentA.segmentSize = targetSegmentSizeA;

    const targetTalentSegmentA1 = {
      segmentSize: targetSegmentSizeA1,
      startSpeed: targetTalentSegmentA.endSpeed,
      endSpeed: dizzySpeed,
      cumulativeSegmentSize: targetTalentSegmentA.cumulativeSegmentSize + targetSegmentSizeA1,
      segmentChickenAnimation: 'Devolution_FightCloud',
    };

    const targetTalentSegmentA2 = {
      segmentSize: targetSegmentSizeA2,
      startSpeed: targetTalentSegmentA1.endSpeed,
      endSpeed: dizzySpeed,
      cumulativeSegmentSize: targetTalentSegmentA1.cumulativeSegmentSize + targetSegmentSizeA2,
      segmentChickenAnimation: 'Dizzy_running',
    };

    targetTalentSegmentB.segmentSize = targetSegmentSizeB;
    targetTalentSegmentB.startSpeed = targetTalentSegmentA2.endSpeed;

    // insert talentSegmentA1, A2 between talentSegmentA and talentSegmentB
    targetRaceProfile.segments.splice(targetTalentIndexB, 0, targetTalentSegmentA1, targetTalentSegmentA2);

    // Mini Dinosaurs
    const meta = getDevolutionMeta({
      possibleDelay,
    });

    if (targetRaceProfile.metas?.length) {
      targetRaceProfile.metas.push(meta);
    } else {
      targetRaceProfile.metas = [meta];
    }

    log.info({
      func: 'applyDevolution',
      raceId: raceModel.id,
      chickenId: target.id,
      talent,
      beakAccessory: target.beakAccessory,
      targetRaceProfile,
    }, `Apply ${talent} To Target Successfully Before Performing Bite`);
  });

  log.info({
    func: 'applyDevolution',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    targetRaceProfiles,
    cutscene,
  }, `Apply ${talent} After Getting Meta`);
};

const applyCoober = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];
  const talentSegmentB = sourceRaceProfile.segments[talentIndexB];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalSegmentSizeB = talentSegmentB.segmentSize;
  const originalEndSpeedA = talentSegmentA.endSpeed;

  const cooberSpeed = originalEndSpeedA * 2.3;
  const terrainBonus = raceModel.terrain.name === TerrainName.Road ? 1.0 : 0;
  const robotBonus = source.baseBody === ChickenBaseBody.Robot ? 1.0 : 0;
  const cooberDuration = 3.2 + terrainBonus + robotBonus;

  const segmentSizeA1 = 2.67;
  const segmentSizeA2 = 2.4;
  const segmentSizeA3 = 0.5;
  const segmentSizeA4 = cooberDuration;
  const segmentSizeA5 = 0.01;
  const segmentSizeA6 = 1.67;
  const segmentSizeB = 0.1;
  const remainderDuration = originalSegmentSizeA + originalSegmentSizeB
    - segmentSizeA1 - segmentSizeA2 - segmentSizeA3 - segmentSizeA4 - segmentSizeA5 - segmentSizeA6 - segmentSizeB;
  const segmentSizeA = remainderDuration;

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;
  talentSegmentA.endSpeed = talentSegmentA.startSpeed;

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: talentSegmentA.endSpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: 'Coober_Call',
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: talentSegmentA1.endSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: 'Coober_GetIn',
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: cooberSpeed,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: 'Coober_Accelerate',
  };

  const talentSegmentA4 = {
    segmentSize: segmentSizeA4,
    startSpeed: talentSegmentA3.endSpeed,
    endSpeed: cooberSpeed,
    cumulativeSegmentSize: talentSegmentA3.cumulativeSegmentSize + segmentSizeA4,
    segmentChickenAnimation: 'Coober_Drive',
  };

  const talentSegmentA5 = {
    segmentSize: segmentSizeA5,
    startSpeed: talentSegmentA4.endSpeed,
    endSpeed: 0,
    cumulativeSegmentSize: talentSegmentA4.cumulativeSegmentSize + segmentSizeA5,
    segmentChickenAnimation: 'Coober_Drive',
  };

  const talentSegmentA6 = {
    segmentSize: segmentSizeA6,
    startSpeed: talentSegmentA5.endSpeed,
    endSpeed: 0,
    cumulativeSegmentSize: talentSegmentA5.cumulativeSegmentSize + segmentSizeA6,
    segmentChickenAnimation: 'Coober_GetOut',
  };

  talentSegmentB.segmentSize = segmentSizeB;
  talentSegmentB.startSpeed = talentSegmentA6.endSpeed;

  // insert talentSegmentA1, A2, A3, A4, A5, A6 between talentSegmentA and talentSegmentB
  sourceRaceProfile.segments.splice(
    talentIndexB,
    0,
    talentSegmentA1,
    talentSegmentA2,
    talentSegmentA3,
    talentSegmentA4,
    talentSegmentA5,
    talentSegmentA6,
  );

  const cutscene = {
    type: 'talent',
    startTime: Math.max(0, talentSegmentA.cumulativeSegmentSize - 2), // The startTime of tSA + 1, -2 seconds
    chickens: [source.id],
  };
  cutscenes.push(cutscene);

  const soundProfilesForTalent = [{
    type: 'effect',
    loop: false,
    startTime: talentSegmentA.cumulativeSegmentSize, // The startTime of segment tSA + 1
    duration: 10,
    sound: 'Coober_Call',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA1.cumulativeSegmentSize, // The startTime segment tSA + 2
    duration: 10,
    sound: 'Coober_Appear',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA1.cumulativeSegmentSize + 0.5, // The startTime segment tSA + 2 + 0.5 seconds
    duration: 10,
    sound: 'Coober_GetIn',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA2.cumulativeSegmentSize, // The startTime segment tSA + 3
    duration: 10,
    sound: 'Coober_Acceleration',
  }, {
    type: 'effect',
    loop: true,
    startTime: talentSegmentA3.cumulativeSegmentSize, // The startTime segment tSA + 4
    duration: cooberDuration,
    sound: 'Coober_Drive',
  }, {
    type: 'effect',
    loop: false,
    startTime: talentSegmentA4.cumulativeSegmentSize, // The startTime segment tSA + 5
    duration: 10,
    sound: 'Coober_Crash',
  }];
  soundProfiles.push(...soundProfilesForTalent);

  log.info({
    func: 'applyCoober',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
    cutscene,
    soundProfilesForTalent,
  }, `Apply ${talent} Successfully`);
};

const getFeatherRainMeta = (targetChickenIds: number[]) => {
  const meta: any = {
    talent: ChickenTalent.FeatherRain,

    startTimeOffset: 3, // +3.00 seconds after the start of tSA
    talentStartTime: undefined,
    talentEndTime: undefined,
    targetChickenIds,
  };

  return meta;
};

const applyFeatherRain = (raceModel: Race, chickenForTalent: ChickenForTalent, raceProfiles: RaceProfile[], adjacentSegments: number[], cutscenes: any[], soundProfiles: any[]) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);
  const targetRaceProfiles = raceProfiles.filter((rp) => targets.find((target) => target.id === rp.chickenId));

  if (!targetRaceProfiles?.length) {
    return;
  }

  // performing chicken
  if (sourceRaceProfile) {
    const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
    const talentIndexB = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
    const talentSegmentA = sourceRaceProfile.segments[talentIndexA];

    const originalSegmentSizeA = talentSegmentA.segmentSize;

    const segmentSizeA = 2.67;
    const segmentSizeA1 = originalSegmentSizeA - segmentSizeA;
    const originalAnimationA = talentSegmentA.segmentChickenAnimation;

    talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
    talentSegmentA.segmentSize = segmentSizeA;
    talentSegmentA.segmentChickenAnimation = 'FeatherRain_Call';

    // build segment except segment (index to mark as talent segment)
    const talentSegmentA1 = {
      segmentSize: segmentSizeA1,
      startSpeed: talentSegmentA.endSpeed,
      endSpeed: talentSegmentA.endSpeed,
      cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
      segmentChickenAnimation: originalAnimationA,
    };

    // insert talentSegmentA1 after talentSegmentA
    sourceRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1);

    const targetChickenIds = targets.map((target) => target.id);
    const meta = getFeatherRainMeta(targetChickenIds);
    if (sourceRaceProfile.metas?.length) {
      sourceRaceProfile.metas.push(meta);
    } else {
      sourceRaceProfile.metas = [meta];
    }

    log.info({
      func: 'applyFeatherRain',
      raceId: raceModel.id,
      chickenId: source.id,
      talent,
      beakAccessory: source.beakAccessory,
      eyesType: source.eyesType,
      targets: targets.map((target) => target.id),
      sourceRaceProfile,
    }, `Apply ${talent} To Source Successfully`);
  }

  // target chickens
  if (targetRaceProfiles.length > 0) {
    targets.forEach((target) => {
      const targetRaceProfile = targetRaceProfiles.find((rp) => rp.chickenId === target.id);

      const talentIndexA = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
      const talentIndexB = targetRaceProfile.segments.findIndex((segment) => adjacentSegments[1] === segment.segment);
      const talentSegmentA = targetRaceProfile.segments[talentIndexA];
      const talentSegmentB = targetRaceProfile.segments[talentIndexB];

      const originalSegmentSizeA = talentSegmentA.segmentSize;
      const originalSegmentSizeB = talentSegmentB.segmentSize;

      const randomWait = Math.random();

      const ringBonus = target.beakAccessory === ChickenBeakAccessory.Ring ? 1.0 : 0;
      const struckDuration = 6.0 - ringBonus;
      const struckSpeed = talentSegmentA.endSpeed * 0.7;

      const segmentSizeA = 3.7 + randomWait;
      const segmentSizeA1 = 0.01;
      const segmentSizeA2 = struckDuration;
      const remainderDuration = originalSegmentSizeA + originalSegmentSizeB - (segmentSizeA + segmentSizeA1 + segmentSizeA2);
      const segmentSizeB = remainderDuration;

      talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
      talentSegmentA.segmentSize = segmentSizeA;
      talentSegmentA.endSpeed = talentSegmentA.startSpeed;

      const talentSegmentA1 = {
        segmentSize: segmentSizeA1,
        startSpeed: talentSegmentA.endSpeed,
        endSpeed: struckSpeed,
        cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
        segmentChickenAnimation: talentSegmentA.segmentChickenAnimation,
      };

      const talentSegmentA2 = {
        segmentSize: segmentSizeA2,
        startSpeed: talentSegmentA1.endSpeed,
        endSpeed: struckSpeed,
        cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
        segmentChickenAnimation: 'FeatherRain_Struck',
      };

      talentSegmentB.segmentSize = segmentSizeB;
      talentSegmentB.startSpeed = talentSegmentA2.endSpeed;

      // insert talentSegmentA1, A2 between talentSegmentA and talentSegmentB
      targetRaceProfile.segments.splice(talentIndexB, 0, talentSegmentA1, talentSegmentA2);

      log.info({
        func: 'applyFeatherRain',
        raceId: raceModel.id,
        chickenId: target.id,
        talent,
        beakAccessory: target.beakAccessory,
        targetRaceProfile,
      }, `Apply ${talent} To Target Successfully`);
    });
  }
};

const applyRunicRush = (
  raceModel: Race,
  chickenForTalent: ChickenForTalent,
  raceProfiles: RaceProfile[],
  adjacentSegments: number[],
  cutscenes: any[],
  soundProfiles: any[],
) => {
  if (!adjacentSegments?.length) {
    return;
  }

  const {
    source,
    targets,
  } = chickenForTalent;

  const { talent } = source;

  const sourceRaceProfile = raceProfiles.find((rp) => rp.chickenId === source.id);

  const talentIndexA = sourceRaceProfile.segments.findIndex((segment) => adjacentSegments[0] === segment.segment);
  const talentSegmentA = sourceRaceProfile.segments[talentIndexA];

  const originalSegmentSizeA = talentSegmentA.segmentSize;
  const originalEndSpeedA = talentSegmentA.endSpeed;

  const blinkSpeed = talentSegmentA.endSpeed * 1.7;
  const segmentSizeA1 = 0.83;
  const segmentSizeA2 = 0.01;
  const segmentSizeA3 = 0.67;
  const segmentSizeA4 = 4.67;
  const segmentSizeA5 = 0.67;
  const remainderDuration = originalSegmentSizeA - segmentSizeA1 - segmentSizeA2 - segmentSizeA3 - segmentSizeA4 - segmentSizeA5;
  const segmentSizeA = remainderDuration;

  talentSegmentA.cumulativeSegmentSize = talentSegmentA.cumulativeSegmentSize - originalSegmentSizeA + segmentSizeA;
  talentSegmentA.segmentSize = segmentSizeA;
  talentSegmentA.endSpeed = talentSegmentA.startSpeed;

  // build segment except segment (index to mark as talent segment)
  const talentSegmentA1 = {
    segmentSize: segmentSizeA1,
    startSpeed: talentSegmentA.endSpeed,
    endSpeed: talentSegmentA.endSpeed,
    cumulativeSegmentSize: talentSegmentA.cumulativeSegmentSize + segmentSizeA1,
    segmentChickenAnimation: 'RunicBlink_Disappear',
  };

  const talentSegmentA2 = {
    segmentSize: segmentSizeA2,
    startSpeed: talentSegmentA1.endSpeed,
    endSpeed: blinkSpeed,
    cumulativeSegmentSize: talentSegmentA1.cumulativeSegmentSize + segmentSizeA2,
    segmentChickenAnimation: 'RunicBlink_Dash',
  };

  const talentSegmentA3 = {
    segmentSize: segmentSizeA3,
    startSpeed: talentSegmentA2.endSpeed,
    endSpeed: blinkSpeed,
    cumulativeSegmentSize: talentSegmentA2.cumulativeSegmentSize + segmentSizeA3,
    segmentChickenAnimation: 'RunicBlink_Dash',
  };

  const talentSegmentA4 = {
    segmentSize: segmentSizeA4,
    startSpeed: talentSegmentA3.endSpeed,
    endSpeed: blinkSpeed,
    cumulativeSegmentSize: talentSegmentA3.cumulativeSegmentSize + segmentSizeA4,
    segmentChickenAnimation: 'RunicBlink_Loop',
  };

  const talentSegmentA5 = {
    segmentSize: segmentSizeA5,
    startSpeed: talentSegmentA4.endSpeed,
    endSpeed: originalEndSpeedA,
    cumulativeSegmentSize: talentSegmentA4.cumulativeSegmentSize + segmentSizeA5,
    segmentChickenAnimation: 'RunicBlink_Appear',
  };

  // insert talentSegmentA1, A2, A3, A4, A5 after talentSegmentA
  sourceRaceProfile.segments.splice(talentIndexA + 1, 0, talentSegmentA1, talentSegmentA2, talentSegmentA3, talentSegmentA4, talentSegmentA5);

  log.info({
    func: 'applyRunicRush',
    raceId: raceModel.id,
    chickenId: source.id,
    talent,
    beakAccessory: source.beakAccessory,
    eyesType: source.eyesType,
    targets: targets.map((target) => target.id),
    sourceRaceProfile,
  }, `Apply ${talent} Successfully`);
};

export const applyTalents = (
  raceModel: Race,
  chickensToPerformTalent: ChickenForTalent[],
  masterSegments: MasterSegment[],
  raceProfiles: RaceProfile[],
  cutscenes: any[],
  soundProfiles: any[],
) => {
  try {
    const adjacentSegmentList = getAllAdjacentSegmentsAndLock(raceModel, chickensToPerformTalent, masterSegments, raceProfiles);

    log.info({
      func: 'applyTalents',
      raceId: raceModel.id,
      chickensToPerformTalent: chickensToPerformTalent.map((chickenForTalent) => ({
        source: {
          chickenId: chickenForTalent.source.id,
          talent: chickenForTalent.source.talent,
          beakAccessory: chickenForTalent.source.beakAccessory,
          eyesType: chickenForTalent.source.eyesType,
        },
        targets: chickenForTalent.targets.map((target) => ({
          chickenId: target.id,
          beakAccessory: target.beakAccessory,
        })),
      })),
      adjacentSegmentList,
    }, 'After Getting Adjacent Segment List');

    // apply talents to raceProfiles, cutscenes, soundProfiles
    chickensToPerformTalent.forEach((chickenForTalent, talentIndex) => {
      const {
        source,
        targets,
      } = chickenForTalent;

      const { talent } = source;
      const adjacentSegments = adjacentSegmentList[talentIndex];

      switch (talent) {
        case ChickenTalent.Anvil:
          applyAnvil(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.BlueRooster:
          applyBlueRooster(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Chickenapult:
          applyChickenapult(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.CK47:
          applyCK47(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Coober:
          applyCoober(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Flight:
          applyFlight(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Growth:
          applyGrowth(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Machete:
          applyMachete(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Rollerblades:
          applyRollerblades(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Teleport:
          applyTeleport(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.BlueEgg:
          applyBlueEgg(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Dig:
          applyDig(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.FanGroup:
          applyFanGroup(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Helicopter:
          applyHelicopter(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Jetpack:
          {
            const isLastTalent = talentIndex === chickensToPerformTalent.length - 1;
            const isR = Math.random() <= 0.5;
            const isJetpackFinishChance = isLastTalent && isR;

            applyJetpack(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles, isJetpackFinishChance);
          }
          break;

        case ChickenTalent.ColdSnap:
          applyColdSnap(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.Devolution:
          applyDevolution(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.MovingWalkway:
          applyMovingWalkway(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.BlackHole:
          {
            const isLastTalent = talentIndex === chickensToPerformTalent.length - 1;
            const sourceFinishOrder = raceProfiles.findIndex((raceProfile) => raceProfile.chickenId === source.id);
            const isSourceNotLastChicken = sourceFinishOrder < raceProfiles.length - 1;

            const vampBonus = source.beakAccessory === ChickenBeakAccessory.Vampire ? 0.3 : 0;
            const eyesBonus = source.eyesType === ChickenEyesType.Alien ? 0.3 : 0;
            const blackHoleConsumeChance = 0.2 + vampBonus + eyesBonus;
            const isBlackHoleConsume = process.env.NODE_ENV !== 'development' ? Math.random() <= blackHoleConsumeChance : 1;

            const targetChickenId = raceProfiles[raceProfiles.length - 1].chickenId;
            const target = targets.find((t) => t.id === targetChickenId);
            const isTargetNotRing = target && target.beakAccessory !== ChickenBeakAccessory.Ring;

            const isKillChicken = isLastTalent && isSourceNotLastChicken && isBlackHoleConsume && isTargetNotRing;

            applyBlackHole(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles, isKillChicken);
          }
          break;

        case ChickenTalent.RoyalProcession:
          applyRoyalProcession(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.FeatherRain:
          applyFeatherRain(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        case ChickenTalent.RunicRush:
          applyRunicRush(raceModel, chickenForTalent, raceProfiles, adjacentSegments, cutscenes, soundProfiles);
          break;

        default:
          break;
      }
    });

    log.info({
      func: 'applyTalents',
      raceId: raceModel.id,
      chickensToPerformTalent: chickensToPerformTalent.map((chickenForTalent) => ({
        source: {
          chickenId: chickenForTalent.source.id,
          talent: chickenForTalent.source.talent,
          beakAccessory: chickenForTalent.source.beakAccessory,
          eyesType: chickenForTalent.source.eyesType,
        },
        targets: chickenForTalent.targets.map((target) => ({
          chickenId: target.id,
          beakAccessory: target.beakAccessory,
        })),
      })),
    }, 'Apply Talents Successfully');
  } catch (err) {
    log.error({
      func: 'applyTalents',
      raceId: raceModel.id,
      err,
    }, 'Apply Talents Error');
  }
};

// raceProfile contains the final data applied all the talents except for meta
export const resolveTalentMetas = (raceProfiles: RaceProfile[]) => {
  raceProfiles.forEach((raceProfile) => {
    const { metas, segments } = raceProfile;
    if (!metas?.length) {
      return;
    }

    const metaIndex: {
      [talent: string]: number,
    } = {};
    const metaTargetIndex: {
      [talent: string]: Record<number, number>;
    } = {};

    TALENTS.forEach((talent) => {
      metaIndex[talent] = 0;
      metaTargetIndex[talent] = {};
    });

    metas.forEach((meta: any) => {
      const { talent, targetChickenIds } = meta;

      switch (talent) {
        case ChickenTalent.Anvil:
          {
            const sourceTSA1Index = findNthIndex(segments, (seg: Segment) => seg.segmentChickenAnimation === 'Anvil_Throw', metaIndex[talent]);
            const sourceTalentSegmentA1 = segments[sourceTSA1Index];
            const sourceTalentSegmentB = segments[sourceTSA1Index + 2];

            const targetRaceProfile = raceProfiles.find((rp) => rp.chickenId === targetChickenIds[0]);
            const targetTalentSegmentB = getSegmentByTime(
              targetRaceProfile.segments,
              sourceTalentSegmentB.cumulativeSegmentSize - sourceTalentSegmentB.segmentSize,
            );

            const targetTSB6Index = targetTalentSegmentB.segment + 6 - 1; // zero based index
            const targetTalentSegmentB6 = targetRaceProfile.segments[targetTSB6Index];

            meta.talentStartTime = sourceTalentSegmentA1.cumulativeSegmentSize - sourceTalentSegmentA1.segmentSize;
            meta.talentEndTime = targetTalentSegmentB6.cumulativeSegmentSize;

            metaIndex[talent] += 1;
          }
          break;
        case ChickenTalent.BlueRooster:
          {
            const sourceTSA1Index = findNthIndex(segments, (seg: Segment) => seg.segmentChickenAnimation === 'BlueRooster_Drink', metaIndex[talent]);
            const sourceTalentSegmentA1 = segments[sourceTSA1Index];
            const sourceTalentSegmentA3 = segments[sourceTSA1Index + 2];

            meta.talentStartTime = sourceTalentSegmentA1.cumulativeSegmentSize - sourceTalentSegmentA1.segmentSize;
            meta.talentEndTime = sourceTalentSegmentA3.cumulativeSegmentSize;

            metaIndex[talent] += 1;
          }
          break;
        case ChickenTalent.FanGroup:
          {
            const {
              fansSpawnSpeedMultiplier,
              fansSpawnDistanceOffset,
              timeWhenFansSlowDown,
            } = meta;

            const tSA1Index = findNthIndex(segments, (seg: Segment) => seg.segmentChickenAnimation === 'FanGroup_Startle', metaIndex[talent]);
            const talentSegmentA = segments[tSA1Index - 1];
            const talentSegmentA1 = segments[tSA1Index];
            const talentSegmentA2 = segments[tSA1Index + 1];

            const fansStartDuration = talentSegmentA.segmentSize;
            const fansSpawnTime = talentSegmentA.cumulativeSegmentSize - fansStartDuration;
            const avgSpeedA = (talentSegmentA.startSpeed + talentSegmentA.endSpeed) / 2;
            const fansSpawnSpeed = avgSpeedA * fansSpawnSpeedMultiplier;
            const fansSpawnEndSpeed = talentSegmentA1.startSpeed;
            const fansSpawnAvgSpeed = (fansSpawnSpeed + fansSpawnEndSpeed) / 2;
            const fansSpawnDistance = fansStartDuration * (fansSpawnAvgSpeed - avgSpeedA) + fansSpawnDistanceOffset;
            meta.fansSpawnTime = fansSpawnTime;
            meta.fansSpawnPosition = getPositionByTime(segments, fansSpawnTime) - fansSpawnDistance;
            meta.fansStartDuration = fansStartDuration;
            meta.fansSpawnDistance = fansSpawnDistance;

            const slowDownTime = talentSegmentA2.segmentSize - timeWhenFansSlowDown;
            const slowDownStartSpeed = talentSegmentA2.startSpeed
                + (talentSegmentA2.endSpeed - talentSegmentA2.startSpeed) * timeWhenFansSlowDown / talentSegmentA2.segmentSize;
            const sourceAvgSlowDownSpeed = (slowDownStartSpeed + talentSegmentA2.endSpeed) / 2;
            const sourceSlowDownDistance = sourceAvgSlowDownSpeed * slowDownTime;

            const fansSlowDownEndSpeed = 0;
            const fansAvgSlowDownSpeed = (slowDownStartSpeed + fansSlowDownEndSpeed) / 2;
            const fansSlowDownDistance = fansAvgSlowDownSpeed * slowDownTime;

            meta.disappearDistance = sourceSlowDownDistance - fansSlowDownDistance;

            meta.segments = [{
              segmentSize: fansStartDuration,
              startSpeed: fansSpawnSpeed,
              endSpeed: fansSpawnEndSpeed,
              cumulativeSegmentSize: fansStartDuration,
            }, {
              segmentSize: talentSegmentA1.segmentSize,
              startSpeed: fansSpawnEndSpeed,
              endSpeed: talentSegmentA1.endSpeed,
              cumulativeSegmentSize: fansStartDuration + talentSegmentA1.segmentSize,
            }, {
              segmentSize: timeWhenFansSlowDown,
              startSpeed: talentSegmentA2.startSpeed,
              endSpeed: slowDownStartSpeed,
              cumulativeSegmentSize: fansStartDuration + talentSegmentA1.segmentSize + timeWhenFansSlowDown,
            }, {
              segmentSize: slowDownTime,
              startSpeed: slowDownStartSpeed,
              endSpeed: fansSlowDownEndSpeed,
              cumulativeSegmentSize: fansStartDuration + talentSegmentA1.segmentSize + timeWhenFansSlowDown + slowDownTime,
            }];
            meta.tSA1Segment = tSA1Index + 1;
            meta.tSA2Segment = tSA1Index + 2;

            metaIndex[talent] += 1;
          }
          break;

        case ChickenTalent.CK47:
          {
            const { duplicateSpawnDelay, duplicateFiringDistance } = meta;
            const sourceTSA1Index = findNthIndex(segments, (seg: Segment) => seg.segmentChickenAnimation === 'CK-47_Draw', metaIndex[talent]);

            const sourceTalentSegmentA2 = segments[sourceTSA1Index + 1];
            const sourceTSA3StartTime = sourceTalentSegmentA2.cumulativeSegmentSize;
            const targetRaceProfiles = raceProfiles.filter((rp) => targetChickenIds.includes(rp.chickenId));

            let fastestTargetPosition = 0;
            let startSpeed = 0;
            const startTime = sourceTSA3StartTime + duplicateSpawnDelay;

            targetRaceProfiles.forEach((targetRaceProfile) => {
              const rpPosition = getPositionByTime(targetRaceProfile.segments, startTime);
              if (rpPosition > fastestTargetPosition) {
                fastestTargetPosition = rpPosition;
              }

              const targetSegment = getSegmentByTime(targetRaceProfile.segments, startTime);
              const maxSpeed = Math.max(targetSegment.startSpeed, targetSegment.endSpeed);
              if (maxSpeed > startSpeed) {
                startSpeed = maxSpeed;
              }
            });

            meta.segments.forEach((segment: Segment) => {
              segment.startSpeed = startSpeed;
              segment.endSpeed = startSpeed;
            });

            meta.tSA3Segment = sourceTSA1Index + 3;
            meta.startPosition = fastestTargetPosition + duplicateFiringDistance; // + 1 meter
            meta.startTime = startTime;

            metaIndex[talent] += 1;
          }
          break;

        case ChickenTalent.Devolution:
          {
            const { fleeSpeed } = meta;
            const tSA1Index = findNthIndex(segments, (seg: Segment) => seg.segmentChickenAnimation === 'Devolution_FightCloud', metaIndex[talent]);

            // a mini dinosaur spawns at tSA+2, meets and fights a target chicken at tSA+1
            const tSAIndex = tSA1Index - 1;
            const talentSegmentA = segments[tSAIndex];
            const t = talentSegmentA.segmentSize;

            // target chicken
            const startSpeedA = talentSegmentA.startSpeed;
            const endSpeedA = talentSegmentA.endSpeed;
            const targetAvgSpeed = (startSpeedA + endSpeedA) / 2; // target chicken's average speed in tSA

            // mini dinosaur
            const talentSegmentA1 = segments[tSA1Index];
            const endSpeedA2 = talentSegmentA1.startSpeed;

            /**
               * targetAvgSpeed * t + miniDinoAvgSpeed * t = spawnDistance => miniDinoAvgSpeed = (spawnDistance - targetAvgSpeed * t) / t
               * miniDinoAvgSpeed = (startSpeedA2 + endSpeedA2) / 2 => startSpeedA2 = 2 * miniDinoAvgSpeed - endSpeedA2
               * startSpeedA2 = 2 * (spawnDistance - targetAvgSpeed * t) / t - endSpeedA2
               * startSpeedA2 >= 0 => spawnDistance - targetAvgSpeed * t >= endSpeedA2 * t / 2
               *  => spawnDistance >= endSpeedA2 * t / 2 + targetAvgSpeed * t
               *
               */
            const spawnDistance = Math.max(meta.spawnDistance, endSpeedA2 * t / 2 + targetAvgSpeed * t);
            const startSpeedA2 = 2 * (spawnDistance - targetAvgSpeed * t) / t - endSpeedA2;

            const dinoSegments = meta.segments;
            const segmentSize1 = dinoSegments[0].segmentSize;
            const segmentSize2 = dinoSegments[1].segmentSize;

            // currrent speed at the end of miniDino1
            const currentSpeed = startSpeedA2 + (endSpeedA2 - startSpeedA2) * (segmentSize1 / (segmentSize1 + segmentSize2));

            dinoSegments[0].startSpeed = -startSpeedA2;
            dinoSegments[0].endSpeed = -currentSpeed;

            dinoSegments[1].startSpeed = -currentSpeed;
            dinoSegments[1].endSpeed = -endSpeedA2;

            dinoSegments[2].startSpeed = endSpeedA2;
            dinoSegments[2].endSpeed = talentSegmentA1.endSpeed;

            dinoSegments[3].startSpeed = -talentSegmentA1.endSpeed;
            dinoSegments[3].endSpeed = -fleeSpeed;

            meta.spawnTime = talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize;
            meta.spawnDistance = spawnDistance;
            meta.spawnPosition = getPositionByTime(segments, talentSegmentA.cumulativeSegmentSize - talentSegmentA.segmentSize) + spawnDistance;
            meta.tSA1Segment = tSA1Index + 1;
            meta.tSA2Segment = tSA1Index + 2;

            metaIndex[talent] += 1;
          }
          break;

        case ChickenTalent.Dig:
          {
            const tSA1Index = findNthIndex(segments, (seg: Segment) => seg.segmentChickenAnimation === 'Dig_Dive', metaIndex[talent]);
            const talentSegmentA1 = segments[tSA1Index];
            const talentSegmentA3 = segments[tSA1Index + 2];

            meta.tSA1Segment = tSA1Index + 1;

            meta.startTime = talentSegmentA1.cumulativeSegmentSize; // right after tSA+1
            meta.startPosition = getPositionByTime(segments, meta.startTime);

            // The final one spawned is Dig_Trail_11, which is spawned at the position the chicken is in at the start of tSA+3.
            // Though isn’t spawned until 0.3 seconds after the start of tSA+3
            meta.endTime = talentSegmentA3.cumulativeSegmentSize + meta.endTimeOffset;
            meta.endPosition = getPositionByTime(segments, talentSegmentA3.cumulativeSegmentSize);

            const { dirtMoundSpawnDistance } = meta;

            const dirtMoundDistance = (meta.endPosition - meta.startPosition);

            const movingAnimationsPool = ['dirt moving_3', 'dirt moving_4', 'dirt moving_5', 'dirt moving_6', 'dirt moving_7', 'dirt moving_8'];
            const numberOfMovingAnimations = Math.ceil(dirtMoundDistance / dirtMoundSpawnDistance);
            meta.movingAnimations = [];

            for (let j = 0; j < numberOfMovingAnimations; j += 1) {
              const movingAnimationIndex = Math.floor(Math.random() * movingAnimationsPool.length);
              meta.movingAnimations.push(movingAnimationsPool[movingAnimationIndex]);
            }
            meta.movingAnimations.splice(0, 1, 'Dig_Start_7');
            meta.movingAnimations.splice(meta.movingAnimations.length - 1, 1, 'Dig_Trail_11');

            metaIndex[talent] += 1;
          }
          break;

        case ChickenTalent.MovingWalkway:
          {
            const {
              startTimeOffset,
              leftTimeOffset,
              rightTimeOffset,
            } = meta;

            const tSA1Index = findNthIndex(segments, (seg: Segment) => seg.segmentChickenAnimation === 'MovingWalkway_GetOn', metaIndex[talent]);
            const talentSegmentA = segments[tSA1Index - 1];
            const talentSegmentA2 = segments[tSA1Index + 1];
            meta.startTime = talentSegmentA.cumulativeSegmentSize - startTimeOffset;

            meta.leftTime = talentSegmentA.cumulativeSegmentSize + leftTimeOffset;
            meta.leftPosition = getPositionByTime(segments, meta.leftTime);

            meta.rightTime = talentSegmentA2.cumulativeSegmentSize + rightTimeOffset;
            meta.rightPosition = getPositionByTime(segments, meta.rightTime);

            meta.initialAnimations = [
              'MovingWalkway_Start_Appear',
              'MovingWalkway_Middle_Appear',
              'MovingWalkway_End_Appear',
            ];

            meta.animations = [
              'MovingWalkway_Start',
              'MovingWalkway_StartFront',
              'MovingWalkway_Middle',
              'MovingWalkway_MiddleFront',
              'MovingWalkway_EndFron',
              'MovingWalkway_End2',
            ];

            metaIndex[talent] += 1;
          }
          break;

        case ChickenTalent.BlackHole:
          {
            const { blackHole } = meta;
            const {
              startTime,
              blackHoleSlowness,
              blackHoleRadius,
            } = blackHole;

            const segmentSizebHS1 = 1.00;
            const segmentSizebHS2 = 1.00;
            const segmentSizebHS3 = 4.00;
            const segmentSizebHS4 = 2.23;

            const startPosition = getPositionByTime(segments, startTime) + blackHoleRadius;
            // The black hole is a seperate entity that is spawned during the race.
            // It is created at the start of bh3. Its initial position is to lineup with the black hole that is spat out by the performing chicken.
            // It is to immediately start the BlackHole_Expand animation and move to be centre of the screen.
            // Vertical position is to between lanes 6 & 7, horizontal position center should be the center of the performing chicken.
            // This move should take exactly 1.00 seconds.

            const tSA1Index = findNthIndex(segments, (seg: Segment) => seg.segmentChickenAnimation === 'BlackHole_Spit', metaIndex[talent]);
            const talentSegmentA2 = segments[tSA1Index + 1];
            meta.tSA1Segment = tSA1Index + 1;

            const blackHoleCenterTime = startTime + segmentSizebHS1;
            const initialEndPosition = getPositionByTime(segments, blackHoleCenterTime);

            const initialDistance = initialEndPosition - startPosition;
            const blackHoleHSpeed = (talentSegmentA2.startSpeed + talentSegmentA2.endSpeed) / 2 * blackHoleSlowness;
            // (initialStartSpeed + blackHoleHSpeed) / 2 * segmentSizebHS1 = initialDistance
            const initialSartSpeed = initialDistance * 2 / segmentSizebHS1 - blackHoleHSpeed;

            meta.blackHole.startPosition = startPosition;
            meta.blackHole.segments = [{
              duration: segmentSizebHS1,
              startSpeed: initialSartSpeed,
              endSpeed: blackHoleHSpeed,
              animation: 'BlackHole_Expand',
            }, {
              duration: segmentSizebHS2,
              startSpeed: blackHoleHSpeed,
              endSpeed: blackHoleHSpeed,
              animation: 'BlackHole_Expand',
            }, {
              duration: segmentSizebHS3,
              startSpeed: blackHoleHSpeed,
              endSpeed: blackHoleHSpeed,
              animation: 'BlackHole_Suck',
            }, {
              duration: segmentSizebHS4,
              startSpeed: blackHoleHSpeed,
              endSpeed: blackHoleHSpeed,
              animation: 'BlackHole_Collapse',
            }];

            meta.copyChickens.forEach((copyChicken: any) => {
              const targetRaceProfile = raceProfiles.find((rp) => rp.chickenId === copyChicken.chickenId);
              copyChicken.startPosition = getPositionByTime(targetRaceProfile.segments, copyChicken.startTime);
            });

            metaIndex[talent] += 1;
          }
          break;

        case ChickenTalent.FeatherRain:
          {
            const { startTimeOffset, targetChickenIds } = meta;

            const sourceTSAIndex = findNthIndex(segments, (seg: Segment) => seg.segmentChickenAnimation === 'FeatherRain_Call', metaIndex[talent]);
            const sourceTalentSegmentA = segments[sourceTSAIndex];
            const targetRaceProfiles = raceProfiles.filter((rp) => targetChickenIds.includes(rp.chickenId));

            let lastTargetTSBStart = 0;
            for (const targetRaceProfile of targetRaceProfiles) {
              const { chickenId: targetChickenId, segments: targetSegments  } = targetRaceProfile;
              let metaTargetIndexForChicken = metaTargetIndex[talent][targetChickenId];

              if (!metaTargetIndexForChicken) {
                metaTargetIndexForChicken = 0;
              }

              const targetTSA2Index = findNthIndex(targetSegments, (seg: Segment) => seg.segmentChickenAnimation === 'FeatherRain_Struck', metaTargetIndexForChicken);
              const targetTalentSegmentA2 = targetSegments[targetTSA2Index];
              if (targetTalentSegmentA2.cumulativeSegmentSize > lastTargetTSBStart) {
                lastTargetTSBStart = targetTalentSegmentA2.cumulativeSegmentSize;
              }

              metaTargetIndex[talent][targetChickenId] = metaTargetIndexForChicken + 1;
            }

            meta.talentStartTime = sourceTalentSegmentA.cumulativeSegmentSize - sourceTalentSegmentA.segmentSize + startTimeOffset;
            meta.talentEndTime = lastTargetTSBStart;

            metaIndex[talent] += 1;
          }
          break;

        default:
          break;
      }
    });
  });
};
