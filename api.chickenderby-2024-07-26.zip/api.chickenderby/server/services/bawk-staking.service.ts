import * as moment from 'moment-timezone';
import * as express from 'express';
import { Job } from 'bull';
import Sequelize from 'sequelize';
import Fuse from 'fuse.js';

import config from '../config';
// To resolve express request
import '../middleware/parseClientInfo';

import { log, sleep, getPaginationInput } from '../utils';
import { BawkStakingContractService } from './contracts/bawkStakingContractService';
import { getSuccessfulTransactionHashAndReceipt } from './contracts/web3Service';
import { UserWallet } from '../sequelize/models/UserWallet';
import { checkBetaUserOnly, checkDeployment } from './settingService';
import { bawkStakingSchema } from '../validation';
import { BawkStakingType, BawkType } from '../types/bawk-staking';
import { BawkStakingCompany } from '../sequelize/models/BawkStakingCompany';
import { BawkStakingAssignment } from '../sequelize/models/BawkStakingAssignment';
import { AssignmentStatus } from '../types/assignments/assignmentStatus';
import { BawkEscrowContractService } from './contracts/bawk-escrow-contract.service';
import { BawkContractService } from './contracts/bawk-contract.service';
import { IBawkStakingSeason } from '../types/bawk-staking';
import { Transaction } from '../sequelize/models/Transaction';
import { BAWK_STAKING_CONTRACT } from '../abi/bawkStakingContract';
import { BAWK_ESCROW_CONTRACT } from '../abi/bawkEscrowContract';
import { TransactionType } from '../types/transactions/transactionType';
import { TransactionPaidStatus } from '../types/transactions/transactionPaidStatus';
import { TransactionCategory } from '../types/transactions/transactionCategory';

export class BawkStakingService {
  private static instance: BawkStakingService;

  constructor(
    private bawkStakingContractService: BawkStakingContractService,
    private bawkEscrowContractService: BawkEscrowContractService,
    private bawkContractService: BawkContractService,
  ) { }

  static getInstance() {
    if (!BawkStakingService.instance) {
      BawkStakingService.instance = new BawkStakingService(
        BawkStakingContractService.getInstance(),
        BawkEscrowContractService.getInstance(),
        BawkContractService.getInstance(),
      );
    }

    return BawkStakingService.instance;
  }

  private async isContractStartSuccess() {
    const startTs = await this.bawkStakingContractService.getStartTs();
    return startTs > 0;
  }

  async start(startTimestamp: number) {
    try {
      const isContractStartSuccess = await this.isContractStartSuccess();
      if (isContractStartSuccess) {
        // already started
        return;
      }

      const startDateTime = moment.unix(startTimestamp).format('YYYY-MM-DD HH:mm:ss');

      const txHashes: string[] = [];
      let transactionHash: string = null;

      await new Promise((resolve, reject) => {
        this.bawkStakingContractService.start(startTimestamp, {
          onTx: (txHash) => {
            transactionHash = txHash;
            txHashes.push(transactionHash);

            log.info({
              func: this.start.name,
              startTimestamp,
              transactionHash,
              txHashes,
            }, `start on txHash on ${startDateTime}`);
          },
          onReceipt: async (receipt) => {
            log.info({
              func: this.start.name,
              startTimestamp,
              receipt,
              transactionHash,
              txHashes,
            }, `start on receipt on ${startDateTime}`);

            resolve(receipt);
          },
          onError: async (err) => {
            await sleep(6000);

            // catch error and return undefined
            const successfulTransaction = await getSuccessfulTransactionHashAndReceipt(txHashes).catch((err2) => {
              log.error({
                func: this.start.name,
                startTimestamp,
                transactionHash,
                txHashes,
                err: err2,
              }, `start getSuccessfulTransactionHashAndReceipt Error on ${startDateTime}`);

              return null;
            });
            if (successfulTransaction?.txHash) {
              transactionHash = successfulTransaction.txHash;
            }

            // catch error and return undefined
            const isContractSuccess = await this.isContractStartSuccess().catch((err2) => {
              log.error({
                func: this.start.name,
                startTimestamp,
                transactionHash,
                txHashes,
                err: err2,
              }, `start isContractStartSuccess Error on ${startDateTime}`);
            });

            log.error({
              func: this.start.name,
              startTimestamp,
              isContractSuccess,
              transactionHash,
              txHashes,
              successfulTransaction,
              err,
            }, `start On Error on ${startDateTime}`);

            let errorMsg = err.message;

            if (isContractSuccess || successfulTransaction) {
              // edge case: we are raising new transaction if the previous one is not mined within 1000 seconds
              // sometimes the previous transaction is mined while we are generating new one
              // so new one fails with the `Signer and signature do not match` error
              // in that case, we have to mark the transaction as completed because it's actually a successful transaction
              resolve(successfulTransaction?.receipt);
              return;
            } if (errorMsg?.includes('Transaction was not mined within')) {
              resolve(null);
              return;
            }

            if (errorMsg?.includes('execution reverted: Signer and signature do not match')) {
              errorMsg += '\n This might be because your previous transaction was not minded yet. Please try again.';
            }

            reject(new Error(errorMsg));
          },
        });
      });
    } catch (err) {
      log.info({
        func: this.start.name,
        err,
      }, 'Start Error');
    }
  }

  getStakingSeasonSeconds() {
    return config.STAKING_SEASON_DAYS * 24 * 60 * 60;
  }

  getStakingSeasonOpenSeconds() {
    return Math.min(config.BAWK_STAKING_OPEN_DAYS, config.STAKING_SEASON_DAYS) * 24 * 60 * 60;
  }

  getCurrentEpoch(startTimestamp: number) {
    if (startTimestamp === 0) {
      return -1;
    }

    const stakingSeasonSeconds = this.getStakingSeasonSeconds();
    return Math.floor((moment.utc().unix() - startTimestamp) / stakingSeasonSeconds);
  }

  async getCurrentSeasonPeriod() {
    const startTimestamp = await this.bawkStakingContractService.getStartTs();
    const stakingSeasonSeconds = this.getStakingSeasonSeconds();
    const currentEpoch = this.getCurrentEpoch(startTimestamp);

    return {
      currentEpoch,
      startDate: moment.unix(startTimestamp + currentEpoch * stakingSeasonSeconds).toDate(),
      endDate: moment.unix(startTimestamp + (currentEpoch + 1) * stakingSeasonSeconds).toDate(),
    };
  }

  getCurrentSeasonEndDate(startTimestamp: number) {
    if (startTimestamp === 0) {
      return null;
    }

    const stakingSeasonSeconds = this.getStakingSeasonSeconds();
    const currentEpoch = this.getCurrentEpoch(startTimestamp);
    const endTimestamp = startTimestamp + (currentEpoch + 1) * stakingSeasonSeconds;

    return moment.unix(endTimestamp).toDate();
  }

  getCurrentSeasonStakeEndDate(startTimestamp: number) {
    if (startTimestamp === 0) {
      return null;
    }

    const stakingSeasonSeconds = this.getStakingSeasonSeconds();
    const stakingOpenSeconds = this.getStakingSeasonOpenSeconds();
    const currentEpoch = this.getCurrentEpoch(startTimestamp);
    const endTimestamp = startTimestamp + currentEpoch * stakingSeasonSeconds + stakingOpenSeconds;

    return moment.unix(endTimestamp).toDate();
  }

  getCurrentSeasonPassedSeconds(startTimestamp: number) {
    if (startTimestamp === 0) {
      return -1;
    }

    const stakingSeasonSeconds = this.getStakingSeasonSeconds();
    return (moment.utc().unix() - startTimestamp) % stakingSeasonSeconds;
  }

  async checkBawkStakingCompany(bawkStakingCompanyId: number) {
    const bawkStakingCompany = await BawkStakingCompany.findByPk(bawkStakingCompanyId);
    if (!bawkStakingCompany) {
      throw new Error('Invalid bawk staking company id');
    }
  }

  async checkBawkStakingEpoch(type: BawkStakingType, epoch: number) {
    if (epoch < 0) {
      throw new Error(`Invalid epoch - ${epoch}`);
    }

    const startTimestamp = await this.bawkStakingContractService.getStartTs();
    const currentEpoch = this.getCurrentEpoch(startTimestamp);
    if (currentEpoch === -1 || epoch > currentEpoch) {
      throw new Error('Bawk staking season is not started yet');
    }

    if ([BawkStakingType.ClaimJewel, BawkStakingType.ClaimBawk].includes(type)) {
      return;
    }

    if (epoch < currentEpoch) {
      throw new Error('Bawk staking season is expired, please refresh the page and try again');
    }

    const currentSeasonPassedSeconds = this.getCurrentSeasonPassedSeconds(startTimestamp);
    const stakingSeasonOpenSeconds = this.getStakingSeasonOpenSeconds();
    if (currentSeasonPassedSeconds >= stakingSeasonOpenSeconds) {
      throw new Error(`Bawk staking is allowed only for the first ${config.BAWK_STAKING_OPEN_DAYS} days`);
    }
  }

  async checkBawkStakingAmount(userWalletId: string, bawkStakingCompanyId: number, type: BawkStakingType, bawkType: BawkType, amount: number, epoch: number) {
    if (!Object.values(BawkStakingType).includes(type)) {
      throw new Error(`Inavlid bawk staking type - ${type}`);
    }

    if (bawkType && !Object.values(BawkType).includes(bawkType)) {
      throw new Error(`Inavlid bawk type - ${bawkType}`);
    }

    if (![BawkStakingType.ClaimJewel, BawkStakingType.ClaimBawk].includes(type)) {
      if (!amount || amount <= 0) {
        throw new Error(`Invalid bawk staking amount - ${amount}`);
      }
    }

    if (type === BawkStakingType.Stake) {
      const balance = bawkType === BawkType.Claimed
        ? await this.getUserBawkBalance(userWalletId)
        : await this.getUserEscrowBalance(userWalletId);

      if (amount > balance) {
        throw new Error(`You don't have enough BAWK(${balance}) to stake(${amount})`);
      }

      return amount;
    }

    if (type === BawkStakingType.Unstake) {
      const balance = bawkType === BawkType.Claimed
        ? await this.getUserTotalNonEscrowedStakeAmount(userWalletId, bawkStakingCompanyId)
        : await this.getUserTotalEscrowedStakeAmount(userWalletId, bawkStakingCompanyId);

      if (amount > balance) {
        throw new Error(`You don't have enough BAWK(${balance}) to unstake(${amount})`);
      }
      return amount;
    }

    if (type === BawkStakingType.ClaimJewel) {
      const unclaimedJewels = await this.getUnclaimedJewels(userWalletId, bawkStakingCompanyId, epoch);
      if (unclaimedJewels <= 0) {
        throw new Error('You have no JEWELS to claim this season');
      }

      return unclaimedJewels;
    }
  }

  generateCoupon(bawkType: BawkType, type: BawkStakingType, userWalletId: string, bawkStakingCompanyId: number, amount: number, epoch: number) {
    const cid = bawkStakingCompanyId - 1;

    if (type === BawkStakingType.ClaimJewel) {
      return this.bawkStakingContractService.generateCoupon(userWalletId, cid, null, epoch);
    }

    if (type === BawkStakingType.ClaimBawk) {
      // TODO: add coupon
      return null;
    }

    if (bawkType === BawkType.Unclaimed) {
      return this.bawkEscrowContractService.generateCoupon(userWalletId, cid, amount);
    }

    // bawkType === BawkType.Claimed
    // Stake/Unstake
    return this.bawkStakingContractService.generateCoupon(userWalletId, cid, amount);
  }

  async checkBawkStaking(req: express.Request) {
    const { id: userWalletId } = req.user as UserWallet;

    try {
      // check if deployment is in progress
      await checkDeployment();

      // check beta user enabled
      await checkBetaUserOnly(userWalletId, 'Sorry, bawk staking is currently limited to beta users.');

      const {
        epoch,
        bawkStakingCompanyId,
        amount,
        type,
        bawkType,
        gasLimit,
      } = await bawkStakingSchema.validateAsync(req.body);

      const validatedAmount = await this.checkBawkStakingAmount(userWalletId, bawkStakingCompanyId, type, bawkType, amount, epoch);

      await this.checkBawkStakingCompany(bawkStakingCompanyId);

      await this.checkBawkStakingEpoch(type, epoch);

      const numberOfPendingAssignments = await BawkStakingAssignment.count({
        where: {
          userWalletId,
          status: AssignmentStatus.Pending,
        },
      });
      if (numberOfPendingAssignments > 0) {
        throw new Error('You currently have a pending bawk staking transaction.');
      }

      if (gasLimit) {
        return {
          gasLimit,
          validatedAmount,
        };
      }

      const coupon = this.generateCoupon(bawkType, type, userWalletId, bawkStakingCompanyId, amount, epoch);

      return {
        gasLimit: config.BICONOMY_CUSTOM_GAS_LIMIT,
        validatedAmount,
        coupon,
      };
    } catch (err) {
      throw err;
    }
  }

  async isContractBawkStakingSuccess(type: BawkStakingType, userWalletId: string, bawkStakingCompanyId: number, epoch: number, previousBalance: number) {
    const currentBalance = type === BawkStakingType.ClaimJewel
      ? await this.getUnclaimedJewels(userWalletId, bawkStakingCompanyId, epoch)
      : await this.getUserTotalStakeAmountFromContract(userWalletId, bawkStakingCompanyId);
    return previousBalance !== currentBalance;
  }

  async afterProcessBawkStaking(bawkStakingAssignment: BawkStakingAssignment, {
    assignmentStatus,
    paidStatus,
    transactionHash,
    txHashes,
    err,
  }: {
    assignmentStatus: AssignmentStatus,
    paidStatus: TransactionPaidStatus;
    transactionHash: string;
    txHashes: string[];
    err?: any;
  }) {
    const {
      id: bawkStakingAssignmentId,
      userWalletId,
      type,
      bawkType,
      amount,
    } = bawkStakingAssignment;

    await BawkStakingAssignment.sequelize.transaction(async (t) => {
      await bawkStakingAssignment.update({
        status: assignmentStatus,
        transactionHash,
        txHashes,
        error: err ? { message: err.message } : null,
      }, { transaction: t });

      if (type === BawkStakingType.Stake) {
        await Transaction.create({
          fromAddress: userWalletId,
          toAddress: bawkType === BawkType.Claimed ? BAWK_STAKING_CONTRACT.address : BAWK_ESCROW_CONTRACT.address,
          type: TransactionType.In,
          transactionHash,
          status: paidStatus,
          associatedObjectType: 'bawk-staking',
          associatedObjectId: `${bawkStakingAssignmentId}`,
          amount,
          category: TransactionCategory.BawkStakingStake,
        }, { transaction: t });
      } else if (type === BawkStakingType.Unstake) {
        await Transaction.create({
          fromAddress: bawkType === BawkType.Claimed ? BAWK_STAKING_CONTRACT.address : BAWK_ESCROW_CONTRACT.address,
          toAddress: userWalletId,
          type: TransactionType.Out,
          transactionHash,
          status: paidStatus,
          associatedObjectType: 'bawk-staking',
          associatedObjectId: `${bawkStakingAssignmentId}`,
          amount,
          category: TransactionCategory.BawkStakingUnstake,
        }, { transaction: t });
      } else if (type === BawkStakingType.ClaimJewel) {
        await Transaction.create({
          fromAddress: BAWK_STAKING_CONTRACT.address,
          toAddress: userWalletId,
          type: TransactionType.Out,
          transactionHash,
          status: paidStatus,
          associatedObjectType: 'bawk-staking',
          associatedObjectId: `${bawkStakingAssignmentId}`,
          amount,
          category: TransactionCategory.BawkStakingClaim,
        }, { transaction: t });

        const userWallet = await UserWallet.findByPk(userWalletId, {
          transaction: t,
        });
        if (userWallet) {
          await userWallet.update({
            trackEarnings: userWallet.trackEarnings + amount,
          }, {
            transaction: t,
          });
        }
      }
    });
  }

  async processBawkStaking(job: Job<{
    bawkStakingAssignmentId: number;
  }>) {
    const txHashes: string[] = [];
    let transactionHash: string = null;
    let bawkStakingAssignment: BawkStakingAssignment = null;

    try {
      const { bawkStakingAssignmentId } = job.data;
      bawkStakingAssignment = await BawkStakingAssignment.findByPk(bawkStakingAssignmentId);

      const {
        userWalletId,
        epoch,
        bawkStakingCompanyId,
        amount,
        type,
        bawkType,
        signature,
        status,
        data,
      } = bawkStakingAssignment;

      log.info({
        func: `${BawkStakingService.name}/${this.processBawkStaking.name}`,
        bawkStakingAssignmentId,
        userWalletId,
        epoch,
        bawkStakingCompanyId,
        amount,
        type,
        bawkType,
        signature,
        status,
        data,
      }, 'Start Process Bawk Staking');

      await job.progress(0);

      if (status !== AssignmentStatus.Pending) {
        log.warn({
          func: `${BawkStakingService.name}/${this.processBawkStaking.name}`,
          bawkStakingAssignmentId,
          userWalletId,
          epoch,
          bawkStakingCompanyId,
          amount,
          type,
          bawkType,
          signature,
          status,
          data,
        }, 'Already Processed Bawk Staking');

        return;
      }

      const previousBalance = type === BawkStakingType.ClaimJewel
        ? await this.getUnclaimedJewels(userWalletId, bawkStakingCompanyId, epoch)
        : await this.getUserTotalStakeAmountFromContract(userWalletId, bawkStakingCompanyId);

      const contractService = (type !== BawkStakingType.ClaimJewel && bawkType === BawkType.Unclaimed)
        ? this.bawkEscrowContractService
        : this.bawkStakingContractService;

      let paidStatus = TransactionPaidStatus.Paid;

      await new Promise((resolve, reject) => {
        contractService.processBawkStaking(bawkStakingAssignment, {
          onTx: (txHash) => {
            transactionHash = txHash;
            txHashes.push(transactionHash);

            log.info({
              func: `${BawkStakingService.name}/${this.processBawkStaking.name}`,
              bawkStakingAssignmentId,
              userWalletId,
              epoch,
              bawkStakingCompanyId,
              amount,
              previousBalance,
              type,
              bawkType,
              signature,
              status,
              data,
              transactionHash,
              txHashes,
            }, 'Process Bawk Staking On txHash');
          },
          onReceipt: async (receipt) => {
            log.info({
              func: `${BawkStakingService.name}/${this.processBawkStaking.name}`,
              bawkStakingAssignmentId,
              userWalletId,
              epoch,
              bawkStakingCompanyId,
              amount,
              previousBalance,
              type,
              bawkType,
              signature,
              status,
              data,
              receipt,
              transactionHash,
              txHashes,
            }, 'Process Bawk Staking On receipt');

            resolve(receipt);
          },
          onError: async (err) => {
            await sleep(6000);
            // catch error and return undefined
            const successfulTransaction = await getSuccessfulTransactionHashAndReceipt(txHashes).catch((err2) => {
              log.error({
                func: `${BawkStakingService.name}/${this.processBawkStaking.name}`,
                bawkStakingAssignmentId,
                userWalletId,
                epoch,
                bawkStakingCompanyId,
                amount,
                previousBalance,
                type,
                bawkType,
                signature,
                status,
                data,
                transactionHash,
                txHashes,
                err: err2,
              }, 'Process Bawk Staking getSuccessfulTransactionHashAndReceipt Error');

              return null;
            });
            if (successfulTransaction?.txHash) {
              transactionHash = successfulTransaction.txHash;
            }

            // catch error and return undefined
            const isContractSuccess = await this.isContractBawkStakingSuccess(type, userWalletId, bawkStakingCompanyId, epoch, previousBalance).catch((err2) => {
              log.error({
                func: `${BawkStakingService.name}/${this.processBawkStaking.name}`,
                bawkStakingAssignmentId,
                userWalletId,
                epoch,
                bawkStakingCompanyId,
                amount,
                previousBalance,
                type,
                bawkType,
                signature,
                status,
                data,
                transactionHash,
                txHashes,
                err: err2,
              }, 'Process Bawk Staking isContractBawkStakingSuccess Error');
            });

            log.error({
              func: `${BawkStakingService.name}/${this.processBawkStaking.name}`,
              bawkStakingAssignmentId,
              userWalletId,
              epoch,
              bawkStakingCompanyId,
              amount,
              previousBalance,
              type,
              bawkType,
              signature,
              status,
              data,
              transactionHash,
              txHashes,
              successfulTransaction,
              isContractSuccess,
              err,
            }, 'Process Bawk Staking On Error');

            let errorMsg = err.message;

            if (isContractSuccess || successfulTransaction) {
              // edge case: we are raising new transaction if the previous one is not mined within 1000 seconds
              // sometimes the previous transaction is mined while we are generating new one
              // so new one fails with the `Signer and signature do not match` error
              // in that case, we have to mark the transaction as completed because it's actually a successful transaction
              paidStatus = TransactionPaidStatus.Paid;

              resolve(successfulTransaction?.receipt);
              return;
            } if (errorMsg?.includes('Transaction was not mined within')) {
              paidStatus = TransactionPaidStatus.Postponed;

              resolve(null);
              return;
            }

            if (errorMsg?.includes('execution reverted: Signer and signature do not match')) {
              errorMsg += '\n This might be because your previous transaction was not minded yet. Please try again.';
            }

            reject(new Error(errorMsg));
          },
        });
      });

      await this.afterProcessBawkStaking(bawkStakingAssignment, {
        assignmentStatus: AssignmentStatus.Success,
        paidStatus,
        transactionHash,
        txHashes,
      });

      await job.progress(100);

      log.info({
        func: `${BawkStakingService.name}/${this.processBawkStaking.name}`,
        bawkStakingAssignmentId,
        userWalletId,
        epoch,
        bawkStakingCompanyId,
        amount,
        type,
        bawkType,
        signature,
        status,
        data,
        transactionHash,
        txHashes,
      }, 'End Process Bawk Staking');
    } catch (err: any) {
      log.error({
        func: `${BawkStakingService.name}/${this.processBawkStaking.name}`,
        bawkStakingAssignmentId: job.data.bawkStakingAssignmentId,
        transactionHash,
        txHashes,
        err,
      }, 'Process Bawk Staking Error');

      if (bawkStakingAssignment) {
        await this.afterProcessBawkStaking(bawkStakingAssignment, {
          assignmentStatus: AssignmentStatus.Error,
          paidStatus: TransactionPaidStatus.Error,
          transactionHash,
          txHashes,
          err,
        });
      }

      await job.log(`Process Bawk Staking Error ${err}`);
    }
  }

  async getAllCompanies() {
    return BawkStakingCompany.findAll({
      order: [['id', 'ASC']],
    });
  }

  async getMajorityStakeInfo(epoch: number, bawkStakingCompanyId: number, totalStakeAmount: number) {
    // select userWalletId, sum(if(type = 'stake', amount, -amount)) as amounts
    // from bawkStakingAssignments
    // where status = 'success' and type in ('stake', 'unstake') and bawkStakingCompanyId = bawkStakingCompanyId
    // group by userWalletId
    // order by amounts desc
    // limit 1;
    const results = await BawkStakingAssignment.sequelize.query<{
      userWalletId: string;
      amounts: number;
    }>(
      `
        select userWalletId, sum(if(type = '${BawkStakingType.Stake}', amount, -amount)) as amounts
        from bawkStakingAssignments
        where status = '${AssignmentStatus.Success}' and type in ('${BawkStakingType.Stake}', '${BawkStakingType.Unstake}') and bawkStakingCompanyId = ${bawkStakingCompanyId}
        group by userWalletId
        order by amounts desc
        limit 1;
      `,
      {
        type: Sequelize.QueryTypes.SELECT,
        plain: false,
      },
    );

    if (!results[0]) {
      return null;
    }

    const { userWalletId, amounts } = results[0];

    const userWallet = await UserWallet.findByPk(userWalletId);
    const percentage = Number((amounts / totalStakeAmount * 100).toFixed(2));

    return {
      userWalletId,
      username: userWallet?.username || userWalletId.toUpperCase().slice(2, 8),
      amounts,
      percentage,
    };
  }

  async getUserStakeAmount(userWalletId: string, bawkStakingCompanyId: number, epoch: number) {
    // select sum(if(type = 'stake', amount, -amount)) as amounts
    // from bawkStakingAssignments
    // where status = 'success' and type in ('stake', 'unstake') and bawkStakingCompanyId = bawkStakingCompanyId and userWalletId = "userWalletId" and epoch <= epoch

    const results = await BawkStakingAssignment.sequelize.query<{
      amounts: number;
    }>(
      `
        select sum(if(type = '${BawkStakingType.Stake}', amount, -amount)) as amounts
        from bawkStakingAssignments
        where status = '${AssignmentStatus.Success}'
          and type in ('${BawkStakingType.Stake}', '${BawkStakingType.Unstake}')
          and bawkStakingCompanyId = ${bawkStakingCompanyId}
          and userWalletId = "${userWalletId}"
          and epoch <= ${epoch};
      `,
      {
        type: Sequelize.QueryTypes.SELECT,
        plain: false,
      },
    );

    if (!results[0]) {
      return 0;
    }

    return results[0].amounts;
  }

  async getTotalStakeAmount(bawkStakingCompanyId: number, epoch: number) {
    // select sum(if(type = 'stake', amount, -amount)) as amounts
    // from bawkStakingAssignments
    // where status = 'success' and type in ('stake', 'unstake') and bawkStakingCompanyId = bawkStakingCompanyId and epoch <= epoch

    const results = await BawkStakingAssignment.sequelize.query<{
      amounts: number;
    }>(
      `
        select sum(if(type = '${BawkStakingType.Stake}', amount, -amount)) as amounts
        from bawkStakingAssignments
        where status = '${AssignmentStatus.Success}'
          and type in ('${BawkStakingType.Stake}', '${BawkStakingType.Unstake}')
          and bawkStakingCompanyId = ${bawkStakingCompanyId}
          and epoch <= ${epoch};
      `,
      {
        type: Sequelize.QueryTypes.SELECT,
        plain: false,
      },
    );

    if (!results[0]) {
      return 0;
    }

    return results[0].amounts;
  }

  async getNumberOfStakers(bawkStakingCompanyId: number) {
    // select count(*) from (select userWalletId, sum(if(type = 'stake', amount, -amount)) as amounts
    // from bawkStakingAssignments
    // where status = 'success' and type in ('stake', 'unstake') and bawkStakingCompanyId = bawkStakingCompanyId
    // group by userWalletId
    // having amounts > 0) t;

    const results = await BawkStakingAssignment.sequelize.query<{
      count: number;
    }>(
      `
        select count(*) as count from
        (
          select userWalletId, sum(if(type = '${BawkStakingType.Stake}', amount, -amount)) as amounts
          from bawkStakingAssignments
          where status = '${AssignmentStatus.Success}' and type in ('${BawkStakingType.Stake}', '${BawkStakingType.Unstake}') and bawkStakingCompanyId = ${bawkStakingCompanyId}
          group by userWalletId
          having amounts > 0) t
      `,
      {
        type: Sequelize.QueryTypes.SELECT,
        plain: false,
      },
    );

    return results[0]?.count || 0;
  }

  async getUnclaimedJewels(userWalletId: string, bawkStakingCompanyId: number, epoch: number) {
    return this.bawkStakingContractService.calculateRewards(userWalletId, bawkStakingCompanyId - 1, epoch);
  }

  async getSeasonEarnings(userWalletId: string, bawkStakingCompanyId: number, epoch: number, totalStakeAmount: number) {
    const userStakeAmount = await this.getUserStakeAmount(userWalletId, bawkStakingCompanyId, epoch);
    const totalSeasonEarnings = await this.getTotalJewels(epoch, bawkStakingCompanyId);

    return totalSeasonEarnings * userStakeAmount / totalStakeAmount;
  }

  async getTotalJewels(epoch: number, bawkStakingCompanyId: number) {
    return this.bawkStakingContractService.getEarningJewels(epoch, bawkStakingCompanyId - 1);
  }

  async getUserTotalStakeAmountFromContract(userWalletId: string, bawkStakingCompanyId: number) {
    return this.bawkStakingContractService.getBalanceOfByCompanyId(userWalletId, bawkStakingCompanyId - 1);
  }

  async getUserTotalEscrowedStakeAmount(userWalletId: string, bawkStakingCompanyId: number) {
    return this.bawkStakingContractService.getEscrowedBalanceOfByCompanyId(userWalletId, bawkStakingCompanyId - 1);
  }

  async getUserTotalNonEscrowedStakeAmount(userWalletId: string, bawkStakingCompanyId: number) {
    return this.bawkStakingContractService.getNonEscrowedBalanceOfByCompanyId(userWalletId, bawkStakingCompanyId - 1);
  }

  async getUserBawkBalance(userWalletId: string) {
    return this.bawkContractService.getBalance(userWalletId);
  }

  async getUserEscrowBalance(userWalletId: string) {
    return this.bawkEscrowContractService.getTotalEscrowedAccountBalance(userWalletId);
  }

  async getCompanyStats(userWalletId?: string) {
    const startTimestamp = await this.bawkStakingContractService.getStartTs();
    const currentEpoch = this.getCurrentEpoch(startTimestamp);

    if (currentEpoch === -1) {
      return {
        seasonNumber: -1,
      };
    }

    const seasonEndDate = this.getCurrentSeasonEndDate(startTimestamp);
    const seasonStakeEndDate = this.getCurrentSeasonStakeEndDate(startTimestamp);
    const companies = await this.getAllCompanies();

    const rows = [];
    for (const company of companies) {
      const numberOfStakers = await this.getNumberOfStakers(company.id);
      const totalSeasonEarnings = await this.getTotalJewels(currentEpoch, company.id);

      const totalStakeAmount = await this.getTotalStakeAmount(company.id, currentEpoch);
      const majority = await this.getMajorityStakeInfo(currentEpoch, company.id, totalStakeAmount);

      const myStakeAmount = userWalletId ? await this.getUserStakeAmount(userWalletId, company.id, currentEpoch) : 0;
      const myStakePercentage = totalStakeAmount ? Number(((myStakeAmount / totalStakeAmount) * 100).toFixed(2)) : 0;

      const mySeasonEarnings = userWalletId ? await this.getSeasonEarnings(userWalletId, company.id, currentEpoch, totalStakeAmount) : 0;

      const myPreviousStakeAmount = (currentEpoch === 0 || !userWalletId) ? 0 : await this.getUserStakeAmount(userWalletId, company.id, currentEpoch - 1);
      const myTotalEscrowedStakeAmount = userWalletId ? await this.getUserTotalEscrowedStakeAmount(userWalletId, company.id) : 0;
      const myTotalNonEscrowedStakeAmount = userWalletId ? await this.getUserTotalNonEscrowedStakeAmount(userWalletId, company.id) : 0;

      rows.push({
        company,
        numberOfStakers,
        totalSeasonEarnings,
        majority,
        totalStakeAmount,
        myStakePercentage,
        mySeasonEarnings,
        myStakeAmount,
        myPreviousStakeAmount,
        myTotalEscrowedStakeAmount,
        myTotalNonEscrowedStakeAmount,
      });
    }

    const totalInvestedAmount = rows.reduce((prev, current) => prev + current.totalStakeAmount, 0);
    const previousSeasonInvestedAmount = rows.reduce((prev, current) => prev + current.myPreviousStakeAmount, 0);
    const currentSeasonInvestedAmount = rows.reduce((prev, current) => prev + current.myStakeAmount, 0);
    const myBawkBalance = userWalletId ? await this.getUserBawkBalance(userWalletId) : 0;
    const myEscrowBalance = userWalletId ? await this.getUserEscrowBalance(userWalletId) : 0;
    const myTotalSeasonEarnings = rows.reduce((prev, current) => prev + current.mySeasonEarnings, 0);

    return {
      seasonNumber: currentEpoch + 1,
      seasonEndDate,
      seasonStakeEndDate,
      totalInvestedAmount,
      previousSeasonInvestedAmount,
      currentSeasonInvestedAmount,
      myBawkBalance,
      myEscrowBalance,
      myTotalSeasonEarnings,
      rows,
    };
  }

  async searchSeasons(req: express.Request): Promise<{
    count: number;
    rows: IBawkStakingSeason[];
  }> {
    const { id: userWalletId } = req.user as UserWallet;

    const {
      page, limit, filter,
    } = getPaginationInput(req, { defaultSort: { field: 'id', order: 'ASC' } });

    const bawkStakingCompanyId = filter?.bawkStakingCompanyId;
    if (!bawkStakingCompanyId) {
      throw new Error('Invalid bawkStakingCompanyId');
    }
    const name = filter?.name;

    const startTimestamp = await this.bawkStakingContractService.getStartTs();
    const currentEpoch = this.getCurrentEpoch(startTimestamp);
    if (currentEpoch === -1) {
      return {
        count: 0,
        rows: [],
      };
    }

    // [currentEpoch, 0]
    const allSeasons: IBawkStakingSeason[] = [];
    for (let i = currentEpoch; i >= 0; i--) {
      allSeasons.push({
        epoch: i,
        name: `Epoch ${i + 1}`,
      });
    }

    const offset = (page - 1) * limit || 0;
    const end = offset + limit;

    let filteredSeasons: IBawkStakingSeason[] = [];
    if (!name) {
      filteredSeasons = allSeasons;
    } else {
      const fuse = new Fuse(allSeasons, {
        keys: ['name'],
      });
      const results = fuse.search(name);
      filteredSeasons = results.map((result) => result.item);
    }

    const count = filteredSeasons.length;
    const seasons = filteredSeasons.slice(offset, end);
    const epoches = seasons.map((season) => season.epoch);

    const epochesWithAvailability = await this.bawkStakingContractService.calculateRewardsForEpoches(userWalletId, bawkStakingCompanyId - 1, epoches);
    const rows = seasons.map((season, i) => ({
      ...season,
      amounts: epochesWithAvailability[i].amounts,
    }));

    return {
      count,
      rows,
    };
  }
}
