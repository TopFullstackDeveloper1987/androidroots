import { Chicken } from '../sequelize/models/Chicken';

import { ChickenPeckingOrder } from '../types/chickens/chickenPeckingOrder';
import { ChickenHeritage } from '../types/chickens/chickenHeritage';
import { ChickenStock } from '../types/chickens/chickenStock';
import { ChickenTalent } from '../types/chickens/chickenTalent';
import { ChickenLegs } from '../types/chickens/chickenLegs';
import { ChickenBaseBody } from '../types/chickens/chickenBaseBody';

// https://docs.google.com/document/d/1HNhAPt2UQc4QzbevHrpQyarAlzSCcNza4Mas_x2NOXw/

const getHeritageP = (chicken: Partial<Chicken>) => {
  // ┌──────────────────────────┬───────────┐
  // │ Fused Chicken’s heritage │ heritageP │
  // ├──────────────────────────┼───────────┤
  // │ Serama                   │ 12        │
  // ├──────────────────────────┼───────────┤
  // │ Sultan                   │ 10        │
  // ├──────────────────────────┼───────────┤
  // │ Lakenvelder              │ 8         │
  // ├──────────────────────────┼───────────┤
  // │ Dorking                  │ 6         │
  // └──────────────────────────┴───────────┘

  const heritagePs = {
    [ChickenHeritage.Serama]: 12,
    [ChickenHeritage.Sultan]: 10,
    [ChickenHeritage.Lakenvelder]: 8,
    [ChickenHeritage.Dorking]: 6,
  };

  return heritagePs[chicken.heritage] || heritagePs[ChickenHeritage.Dorking];
};

const getPerfectionP = (chicken: Partial<Chicken>) => {
  // ┌───────────────────┬────────────────────────────┐
  // │ Variable          │ Value                      │
  // ├───────────────────┼────────────────────────────┤
  // │ maximumPerfection │ 101                        │
  // ├───────────────────┼────────────────────────────┤
  // │ perfection        │ Fused Chicken’s perfection │
  // ├───────────────────┼────────────────────────────┤
  // │ power             │ -0.1                       │
  // ├───────────────────┼────────────────────────────┤
  // │ multiplier        │ 40                         │
  // └───────────────────┴────────────────────────────┘

  const maximumPerfection = 101;
  const { perfection } = chicken;
  const power = -0.1;
  const multiplier = 40;

  return ((maximumPerfection - perfection) ** power) * multiplier;
};

const getStockP = (chicken: Partial<Chicken>) => {
  // ┌───────────────────────┬────────┐
  // │ Fused Chicken’s stock │ stockP │
  // ├───────────────────────┼────────┤
  // │ Spicy                 │ 5      │
  // ├───────────────────────┼────────┤
  // │ Boss                  │ 4.5    │
  // ├───────────────────────┼────────┤
  // │ Robust                │ 4.5    │
  // ├───────────────────────┼────────┤
  // │ Fresh                 │ 3.85   │
  // ├───────────────────────┼────────┤
  // │ Crisp                 │ 3.05   │
  // ├───────────────────────┼────────┤
  // │ Tender                │ 2.10   │
  // ├───────────────────────┼────────┤
  // │ Bland                 │ 1.00   │
  // └───────────────────────┴────────┘

  const stockPs = {
    [ChickenStock.Spicy]: 5,
    [ChickenStock.Boss]: 4.5,
    [ChickenStock.Robust]: 4.5,
    [ChickenStock.Fresh]: 3.85,
    [ChickenStock.Crisp]: 3.05,
    [ChickenStock.Tender]: 2.10,
    [ChickenStock.Bland]: 1.00,
  };

  return stockPs[chicken.stock] || stockPs[ChickenStock.Bland];
};

const getTalentP = (chicken: Partial<Chicken>) => {
  // ┌────────────────────────┬─────────┐
  // │ Fused Chicken’s talent │ talentP │
  // ├────────────────────────┼─────────┤
  // │ Anvil                  │ 0.08    │
  // ├────────────────────────┼─────────┤
  // │ Blue Rooster           │ 0.074   │
  // ├────────────────────────┼─────────┤
  // │ Chickenapult           │ 0.074   │
  // ├────────────────────────┼─────────┤
  // │ CK-47                  │ 0.072   │
  // ├────────────────────────┼─────────┤
  // │ Coober                 │ 0.074   │
  // ├────────────────────────┼─────────┤
  // │ Flight?                │ 0.074   │
  // ├────────────────────────┼─────────┤
  // │ Growth                 │ 0.074   │
  // ├────────────────────────┼─────────┤
  // │ Machete                │ 0.074   │
  // ├────────────────────────┼─────────┤
  // │ Rollerblades           │ 0.039   │
  // ├────────────────────────┼─────────┤
  // │ Teleport               │ 0.08    │
  // ├────────────────────────┼─────────┤
  // │ Blue Egg               │ 0.14    │
  // ├────────────────────────┼─────────┤
  // │ Dig                    │ 0.141   │
  // ├────────────────────────┼─────────┤
  // │ Fan Group              │ 0.141   │
  // ├────────────────────────┼─────────┤
  // │ Helicopter             │ 0.141   │
  // ├────────────────────────┼─────────┤
  // │ Jetpack                │ 0.141   │
  // ├────────────────────────┼─────────┤
  // │ Cold Snap              │ 0.212   │
  // ├────────────────────────┼─────────┤
  // │ Devolution             │ 0.211   │
  // ├────────────────────────┼─────────┤
  // │ Moving Walkway         │ 0.211   │
  // ├────────────────────────┼─────────┤
  // │ Black Hole             │ 0.281   │
  // ├────────────────────────┼─────────┤
  // │ Royal Procession       │ 0.281   │
  // └────────────────────────┴─────────┘

  const talentPs = {
    [ChickenTalent.Anvil]: 0.08,
    [ChickenTalent.BlueRooster]: 0.074,
    [ChickenTalent.Chickenapult]: 0.074,
    [ChickenTalent.CK47]: 0.072,
    [ChickenTalent.Coober]: 0.074,
    [ChickenTalent.Flight]: 0.074,
    [ChickenTalent.Growth]: 0.074,
    [ChickenTalent.Machete]: 0.074,
    [ChickenTalent.Rollerblades]: 0.039,
    [ChickenTalent.Teleport]: 0.08,
    [ChickenTalent.BlueEgg]: 0.14,
    [ChickenTalent.Dig]: 0.141,
    [ChickenTalent.FanGroup]: 0.141,
    [ChickenTalent.Helicopter]: 0.141,
    [ChickenTalent.Jetpack]: 0.141,
    [ChickenTalent.ColdSnap]: 0.212,
    [ChickenTalent.Devolution]: 0.211,
    [ChickenTalent.MovingWalkway]: 0.211,
    [ChickenTalent.BlackHole]: 0.281,
    [ChickenTalent.RoyalProcession]: 0.281,
    // Just to prevent typescript error, these 2 won't be chicken.talent
    [ChickenTalent.FeatherRain]: 0,
    [ChickenTalent.RunicRush]: 0,
  };

  return talentPs[chicken.talent] || talentPs[ChickenTalent.Rollerblades];
};

const getStripesP = (chicken: Partial<Chicken>) => chicken.stripes ? 1 : 0;

const getTerrainP = (chicken: Partial<Chicken>) => chicken.terrainPreferenceStrength * 10;

const getDistanceP = (chicken: Partial<Chicken>) => chicken.distancePreferenceStrength * 6;

const getLegsP = (chicken: Partial<Chicken>) => {
  // ┌───────────────────────┬────────┐
  // │ Fused Chicken’s legs  │ legsP  │
  // ├───────────────────────┼────────┤
  // │ Blades                │ 1      │
  // ├───────────────────────┼────────┤
  // │ legsBlackHen          │ 1      │
  // ├───────────────────────┼────────┤
  // │ legsBlackRooster      │ 1      │
  // ├───────────────────────┼────────┤
  // │ Gingerbread           │ 1      │
  // ├───────────────────────┼────────┤
  // │ Hooves                │ 1      │
  // ├───────────────────────┼────────┤
  // │ legsHen               │ 0      │
  // ├───────────────────────┼────────┤
  // │ legsRooster           │ 0      │
  // └───────────────────────┴────────┘

  const legPs = {
    [ChickenLegs.Blades]: 1,
    [ChickenLegs.legsBlackHen]: 1,
    [ChickenLegs.legsBlackRooster]: 1,
    [ChickenLegs.Gingerbread]: 1,
    [ChickenLegs.Hooves]: 1,
    [ChickenLegs.legsHen]: 0,
    [ChickenLegs.legsRooster]: 0,
  };

  return legPs[chicken.legs] || legPs[ChickenLegs.legsRooster];
};

const getBodyP = (chicken: Partial<Chicken>) => {
  // ┌──────────────────────────┬────────┐
  // │ Fused Chicken’s baseBody │ bodyP  │
  // ├──────────────────────────┼────────┤
  // │ Runic                    │ 0.212  │
  // ├──────────────────────────┼────────┤
  // │ Plucked                  │ 0.212  │
  // └──────────────────────────┴────────┘

  const bodyPs = {
    [ChickenBaseBody.Runic]: 0.212,
    [ChickenBaseBody.Plucked]: 0.212,
  };

  return bodyPs[chicken.baseBody as ChickenBaseBody.Runic | ChickenBaseBody.Plucked] || 0;
};

export const getPeckingOrder = (chicken: Partial<Chicken>): ChickenPeckingOrder => {
  // ┌───────────────┬───────────────────────────────────┐
  // │ peckingOrder  │ performancePotential              │
  // ├───────────────┼───────────────────────────────────┤
  // │ X             │ performancePotential>=73          │
  // ├───────────────┼───────────────────────────────────┤
  // │ SSS+          │ performancePotential>=71          │
  // ├───────────────┼───────────────────────────────────┤
  // │ SSS           │ performancePotential>=69          │
  // ├───────────────┼───────────────────────────────────┤
  // │ SS+           │ performancePotential>=67          │
  // ├───────────────┼───────────────────────────────────┤
  // │ SS            │ performancePotential>=65          │
  // ├───────────────┼───────────────────────────────────┤
  // │ S+            │ performancePotential>=63          │
  // ├───────────────┼───────────────────────────────────┤
  // │ S             │ performancePotential>=61          │
  // ├───────────────┼───────────────────────────────────┤
  // │ A+            │ performancePotential>=59          │
  // ├───────────────┼───────────────────────────────────┤
  // │ A             │ performancePotential>=57          │
  // ├───────────────┼───────────────────────────────────┤
  // │ B+            │ performancePotential>=55          │
  // ├───────────────┼───────────────────────────────────┤
  // │ B             │ performancePotential>=53.5        │
  // ├───────────────┼───────────────────────────────────┤
  // │ C+            │ performancePotential>=52.36       │
  // ├───────────────┼───────────────────────────────────┤
  // │ C             │ performancePotential>=51.71       │
  // ├───────────────┼───────────────────────────────────┤
  // │ D+            │ performancePotential>=50.94       │
  // ├───────────────┼───────────────────────────────────┤
  // │ D             │ performancePotential>=50.2        │
  // ├───────────────┼───────────────────────────────────┤
  // │ E+            │ performancePotential>=49.74       │
  // ├───────────────┼───────────────────────────────────┤
  // │ E             │ performancePotential>=48.76       │
  // ├───────────────┼───────────────────────────────────┤
  // │ F+            │ performancePotential>=48          │
  // ├───────────────┼───────────────────────────────────┤
  // │ F             │ performancePotential>=0           │
  // └───────────────┴───────────────────────────────────┘

  const heritageP = getHeritageP(chicken);
  const perfectionP = getPerfectionP(chicken);
  const stockP = getStockP(chicken);
  const talentP = getTalentP(chicken);
  const stripesP = getStripesP(chicken);
  const terrainP = getTerrainP(chicken);
  const distanceP = getDistanceP(chicken);
  const legsP = getLegsP(chicken);
  const bodyP = getBodyP(chicken);
  const performancePotential = heritageP + perfectionP + stockP + talentP + stripesP + terrainP + distanceP + legsP + bodyP;

  const chickenPeckingOrderPairs: Record<Exclude<ChickenPeckingOrder, ChickenPeckingOrder.CHICK>, number> = {
    [ChickenPeckingOrder.X]: 73,
    [ChickenPeckingOrder.SSSp]: 71,
    [ChickenPeckingOrder.SSS]: 69,
    [ChickenPeckingOrder.SSp]: 67,
    [ChickenPeckingOrder.SS]: 65,
    [ChickenPeckingOrder.Sp]: 63,
    [ChickenPeckingOrder.S]: 61,
    [ChickenPeckingOrder.Ap]: 59,
    [ChickenPeckingOrder.A]: 57,
    [ChickenPeckingOrder.Bp]: 55,
    [ChickenPeckingOrder.B]: 53.5,
    [ChickenPeckingOrder.Cp]: 52.36,
    [ChickenPeckingOrder.C]: 51.71,
    [ChickenPeckingOrder.Dp]: 50.94,
    [ChickenPeckingOrder.D]: 50.2,
    [ChickenPeckingOrder.Ep]: 49.74,
    [ChickenPeckingOrder.E]: 48.76,
    [ChickenPeckingOrder.Fp]: 48,
    [ChickenPeckingOrder.F]: 0,
  };

  const peckingOrderPair = Object.entries(chickenPeckingOrderPairs).sort((a, b) => b[1] - a[1]).find((pair) => performancePotential >= pair[1]);
  const peckingOrder = peckingOrderPair ? peckingOrderPair[0] as ChickenPeckingOrder : ChickenPeckingOrder.F;

  return peckingOrder;
};
