import * as express from 'express';
import Sequelize from 'sequelize';
import * as _ from 'lodash';

import { Chicken } from '../sequelize/models/Chicken';
import { getPaginationInput, log } from '../utils';
import { ChickenStatsType } from '../types/race-histories/chicken-stats-type';
import { RaceHistory } from '../sequelize/models/RaceHistory';
import { Terrain } from '../sequelize/models/Terrain';
import { UserWallet } from '../sequelize/models/UserWallet';
import moment from 'moment-timezone';
import { BawkStakingService } from './bawk-staking.service';

const { Op } = Sequelize;

export class RaceHistoryService {
  private static instance: RaceHistoryService;

  static getInstace() {
    if (!RaceHistoryService.instance) {
      RaceHistoryService.instance = new RaceHistoryService();
    }

    return RaceHistoryService.instance;
  }

  mapTerrainNames(type: ChickenStatsType, raceHistory: RaceHistory, terrains: Terrain[]) {
    if (type === ChickenStatsType.Terrain) {
      return {
        ...raceHistory.toJSON(),
        terrainName: terrains.find((terrain) => terrain.id === raceHistory.terrainId)?.name,
      };
    }

    return raceHistory.toJSON();
  }

  mapTotalRaces(raceHistory: RaceHistory, totalRaceHistories: RaceHistory[]) {
    const totalRaceHistory = totalRaceHistories.find((totalHistory) => {
      const raceHistoryToCompare = _.omit(raceHistory, ['position', 'positionType', 'terrainName', 'races']);
      const totalRaceHistoryToCompare = _.omit(totalHistory.toJSON(), 'races');

      if (_.isEmpty(raceHistoryToCompare)) {
        return true;
      }

      return _.isEqual(raceHistoryToCompare, totalRaceHistoryToCompare);
    });

    return {
      ...raceHistory,
      totalRaces: totalRaceHistory?.toJSON()?.races,
    };
  }

  async getChickenStats(req: express.Request) {
    const { chickenId } = req.params;
    const type = (req.query.type as ChickenStatsType) || ChickenStatsType.All;
    const { filter } = getPaginationInput(req);

    try {
      const chicken = chickenId && await Chicken.findByPk(chickenId);
      if (!chicken) {
        throw new Error(`Invalid chicken for ${chickenId}`);
      }

      if (!Object.values(ChickenStatsType).includes(type)) {
        throw new Error(`Invalid chicken stats type - ${type}`);
      }

      const groups: string[] = [];
      if (filter?.isExpand) {
        groups.push('position');
      } else {
        groups.push('positionType');
      }

      if (type === ChickenStatsType.Terrain) {
        groups.push('terrainId');
      } else if (type === ChickenStatsType.Distance) {
        groups.push('distance');
      }

      const attributes: Sequelize.FindAttributeOptions = [
        ...groups,
        [Sequelize.fn('count', Sequelize.col('*')), 'races'],
      ];

      const where: Sequelize.WhereOptions<RaceHistory> = {
        chickenId,
      };

      if (filter?.startDate && filter?.endDate) {
        where.date = {
          [Op.between]: [filter.startDate, filter.endDate],
        };
      } else if (filter?.startDate) {
        where.date = {
          [Op.gte]: filter.startDate,
        };
      } else if (filter?.endDate) {
        where.date = {
          [Op.lte]: filter.endDate,
        };
      }

      if (filter?.distance?.length) {
        where.distance = filter.distance;
      }

      const terrains = await Terrain.findAll({});
      if (filter?.terrain?.length) {
        where.terrainId = terrains.filter((terrain) => filter.terrain.includes(terrain.name)).map(terrain => terrain.id);
      }

      if (filter?.feeMin && filter?.feeMax) {
        where.feeJEWEL = {
          [Op.gte]: Number(filter.feeMin),
          [Op.lte]: Number(filter.feeMax),
        };
      } else if (filter?.feeMin) {
        where.feeJEWEL = {
          [Op.gte]: Number(filter.feeMin),
        };
      } else if (filter?.feeMax) {
        where.feeJEWEL = {
          [Op.lte]: Number(filter.feeMax),
        };
      }

      if (filter?.capacityMin && filter?.capacityMax) {
        where.capacity = {
          [Op.gte]: Number(filter.capacityMin),
          [Op.lte]: Number(filter.capacityMax),
        };
      } else if (filter?.capacityMin) {
        where.capacity = {
          [Op.gte]: Number(filter.capacityMin),
        };
      } else if (filter?.capacityMax) {
        where.capacity = {
          [Op.lte]: Number(filter.capacityMax),
        };
      }

      if (filter?.peckingOrder?.length) {
        where.peckingOrder = filter.peckingOrder;
      }

      const raceHistories = await RaceHistory.findAll({
        where,
        attributes,
        group: groups,
      });
      const totalRaceHistories = await RaceHistory.findAll({
        where,
        attributes: attributes.filter((attr) => !['position', 'positionType'].includes(attr as string)),
        group: groups.filter((group) => !['position', 'positionType'].includes(group as string)),
      });

      const stats = raceHistories.map(
        (raceHistory) => this.mapTerrainNames(type, raceHistory, terrains),
      ).map(
        (raceHistory) => this.mapTotalRaces(raceHistory, totalRaceHistories),
      );

      return stats;
    } catch (err) {
      log.error({
        func: this.getChickenStats.name,
        chickenId,
        type,
        filter,
        err,
      }, 'Get Chicken Stats Error');

      throw err;
    }
  }

  private async getTopHistories(startDate: Date, endDate: Date, fields: Array<'chickenId' | 'userWalletId'>, limit: number) {
    const include = [];

    if (fields.includes('chickenId')) {
      include.push({
        model: Chicken,
      });
    }

    if (fields.includes('userWalletId')) {
      include.push({
        model: UserWallet,
        attributes: ['username'],
      });
    }

    return RaceHistory.findAll({
      attributes: [
        ...fields,
        [Sequelize.fn('sum', Sequelize.col('raceEarnings')), 'totalEarnings'],
      ],
      include,
      where: {
        createdAt: { [Op.between]: [startDate, endDate] },
      },
      group: fields,
      order: [['totalEarnings', 'DESC']],
      limit,
    });
  }

  async getLeaderboardStats() {
    const seasonPeriod = await BawkStakingService.getInstance().getCurrentSeasonPeriod();

    const yesterday = moment.utc().subtract(1, 'day');
    const startDate = yesterday.startOf('day').toDate();
    const endDate = yesterday.endOf('day').toDate();

    const yesterdayTopChickens = await this.getTopHistories(startDate, endDate, ['chickenId', 'userWalletId'], 3);
    const yesterdayTopUserWallets = await this.getTopHistories(startDate, endDate, ['userWalletId'], 3);

    const seasonTopChickens = await this.getTopHistories(seasonPeriod.startDate, seasonPeriod.endDate, ['chickenId'], 10);
    const seasonTopUserWallets = await this.getTopHistories(seasonPeriod.startDate, seasonPeriod.endDate, ['userWalletId'], 10);

    return {
      season: seasonPeriod.currentEpoch + 1,
      yesterdayTopChickens,
      yesterdayTopUserWallets,
      seasonTopChickens,
      seasonTopUserWallets,
    };
  }
}
