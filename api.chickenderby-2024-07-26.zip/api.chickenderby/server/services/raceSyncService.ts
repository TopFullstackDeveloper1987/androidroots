// Dependencies
import * as moment from 'moment-timezone';
import * as _ from 'lodash';
import Sequelize from 'sequelize';
import { Job } from 'bull';

const { Op } = Sequelize;

// Config
import config from '../config';

// Models
import { Race } from '../sequelize/models/Race';
import { Transaction } from '../sequelize/models/Transaction';
import { RaceAssignment } from '../sequelize/models/RaceAssignment';
import { Lane } from '../sequelize/models/Lane';

// Services
import { getRaceContractRaceInfo, getRaceContractChickenIds } from './contracts/raceContractService';
import { redisLock } from './redisLock';
import { isDeploying, isRaceSyncEnabled } from './settingService';
import { assignLane } from './raceService';
import * as chickenService from './chickenService';

// Utils
import { log } from '../utils';

// Types
import { RaceStatus } from '../types/races/raceStatus';
import { RaceAssignmentType } from '../types/races/raceAssignmentType';
import { AssignmentStatus } from '../types/assignments/assignmentStatus';
import { TransactionPaidStatus } from '../types/transactions/transactionPaidStatus';
import { ContractRace } from '../types/races/contractRace';

const isUnpaidMismatch = (race: Race, contractRace: ContractRace) => race.paidStatus === TransactionPaidStatus.Paid && !contractRace.isPaid;

// Mark as unpaid to retry payout
const syncUnpaid = async (race: Race) => Race.sequelize.transaction(async (t) => {
  await race.update({
    paidStatus: TransactionPaidStatus.Unpaid,
    syncedAt: null,
  }, { transaction: t });

  await Transaction.update({
    status: TransactionPaidStatus.Error,
  }, {
    where: {
      associatedObjectType: 'race',
      associatedObjectId: race.id,
    },
    transaction: t,
  });
});

const getUserWalletIdFromRaceAssignment = async (raceId: number, chickenId: number) => {
  const raceAssignment = await RaceAssignment.findOne({
    where: {
      raceId,
      chickenId,
      type: RaceAssignmentType.Enter,
    },
  });
  return raceAssignment?.userWalletId || chickenService.getOwnerOfChicken(chickenId);
};

const syncEnterMismatch = async (race: Race, contractChickenIds: number[], syncedAt: Date) => {
  const { id: raceId, lanes } = race;
  try {
    const raceChickenIds = lanes.filter((lane) => !!lane.chickenId).map((lane) => lane.chickenId);
    const chickenIdsToEnterDatabase = _.difference(contractChickenIds, raceChickenIds);
    const chickenIdsToEnterContract = _.difference(raceChickenIds, contractChickenIds);

    log.info({
      func: 'syncEnterMismatch',
      raceId,
      contractChickenIds,
      raceChickenIds,
      chickenIdsToEnterDatabase,
      chickenIdsToEnterContract,
    }, `Sync Enter Mismatch Start For Race ${raceId}`);

    if (chickenIdsToEnterDatabase.length === 0 && chickenIdsToEnterContract.length === 0) {
      await race.update({
        syncedAt,
      });

      return;
    }

    await Race.sequelize.transaction(async (t) => {
      for (const chickenId of chickenIdsToEnterDatabase) {
        const userWalletId = await getUserWalletIdFromRaceAssignment(raceId, chickenId);
        // Currently no way to track transaction hashes for them
        await assignLane({
          raceId, chickenId, userWalletId, transaction: t,
        });
      }

      for (const chickenId of chickenIdsToEnterContract) {
        const userWalletId = await getUserWalletIdFromRaceAssignment(raceId, chickenId);

        await RaceAssignment.update({
          status: AssignmentStatus.Error,
        }, {
          where: {
            raceId,
            chickenId,
            status: AssignmentStatus.Success,
          },
          transaction: t,
        });

        await RaceAssignment.create({
          userWalletId,
          raceId,
          chickenId,
          type: RaceAssignmentType.AutoEnter,
        }, { transaction: t });
      }
    });

    log.info({
      func: 'syncEnterMismatch',
      raceId,
      contractChickenIds,
      raceChickenIds,
      chickenIdsToEnterDatabase,
      chickenIdsToEnterContract,
    }, `Sync Enter Mismatch Finish For Race ${raceId}`);
  } catch (err) {
    log.error({
      func: 'syncEnterMismatch',
      raceId,
      err,
    }, `Sync Enter Mismatch Error For Race ${raceId}`);

    throw err;
  }
};

const isPendingRace = async (race: Race) => {
  const syncDurationMoment = moment.utc().subtract(config.RACE_SYNC_DURATION_MINUTES, 'minutes');

  await race.reload({
    include: [{
      model: Lane,
      as: 'lanes',
    }],
  });

  const { updatedAt } = race;
  if (moment.utc(updatedAt).isAfter(syncDurationMoment)) {
    return true;
  }

  const pendingRaceAssignment = await RaceAssignment.findOne({
    where: {
      raceId: race.id,
      [Op.or]: [{
        status: AssignmentStatus.Pending,
      }, {
        updatedAt: {
          [Op.gte]: syncDurationMoment.toDate(),
        },
      }],
    },
  });
  if (pendingRaceAssignment) {
    return true;
  }

  return false;
};

export const syncRace = async (job: Job) => {
  // handle all race contract calls done by admin wallet in a single place, otherwise it will get the 'execution reverted' error
  try {
    await job.progress(0);

    const isRaceSync = await isRaceSyncEnabled();
    if (!isRaceSync) {
      await job.progress(100);
      await job.log('Race sync disabled, postpone syncRace');

      log.info({
        func: 'syncRace',
      }, 'Race sync disabled, postpone syncRace');

      return;
    }

    const isDeployingSetting = await isDeploying();
    if (isDeployingSetting) {
      await job.progress(100);
      await job.log('Deployment is in progress, postpone syncRace');

      log.info({
        func: 'syncRace',
      }, 'Deployment is in progress, postpone syncRace');

      return;
    }

    const races = await Race.findAll({
      where: {
        [Op.not]: {
          syncedAt: {
            [Op.not]: null,
          },
          status: RaceStatus.Finished,
          paidStatus: TransactionPaidStatus.Paid,
        },
        prizePool: {
          [Op.gt]: 0,
        },
        status: {
          [Op.not]: RaceStatus.Canceled,
        },
        updatedAt: {
          // needs some delay because the contract status changes sometime (usually a few seconds) after getting the receipt
          [Op.lte]: moment.utc().subtract(config.RACE_SYNC_DURATION_MINUTES, 'minutes').toDate(),
        },
      },
      order: [['syncedAt', 'ASC']],
      limit: config.RACE_SYNC_LIMIT,
    });

    let numberOfRacesSynced = 0;
    for (let i = 0; i < races.length; i += 1) {
      const race = races[i];
      const { id: raceId } = race;

      try {
        numberOfRacesSynced += await redisLock(`${config.lock.assignLane}/${raceId}`, 30 * 1000, async () => {
          if (await isPendingRace(race)) {
            return 0;
          }

          const contractRace = await getRaceContractRaceInfo(raceId);
          const contractChickenIds = await getRaceContractChickenIds(raceId);

          // Need to check before and after the contract call because sometimes race starts and finishes updating during the contract call
          if (await isPendingRace(race)) {
            return 0;
          }

          const syncedAt = moment.utc().toDate();

          // Sync only unpaid mismatch because paid mismatch will be retried in payForUnpaidRaces
          if (isUnpaidMismatch(race, contractRace)) {
            await syncUnpaid(race);
            return 1;
          }

          const { fee } = race;
          if (fee === 0) {
            await race.update({
              syncedAt,
            });
            return 1;
          }

          await syncEnterMismatch(race, contractChickenIds, syncedAt);
          return 1;
        });

        await job.progress((i / races.length * 100).toFixed(2));
      } catch (err) {
        log.error({
          func: 'syncRace',
          raceId,
          err,
        }, 'syncRace Error');

        await job.log(`syncRace Error For Race ${raceId}, ${err}`);
      }
    }

    log.info({
      func: 'syncRace',
      raceIdsSynced: races.map((race) => race.id),
      numberOfRacesSynced,
    }, 'Sync Race Finish');

    await job.update({ numberOfRacesSynced });
  } catch (err) {
    log.error({
      func: 'syncRace',
      err,
    }, 'syncRace Error');

    await job.log(`syncRace Error ${err}`);
  }
};
