import config from '../config';
import { AxiosService } from './axios.service';
import { uploadObject } from './awsService';
import { exponentialBackOff } from '../utils/exponentialBackoff';
import { log, sleep } from '../utils';

export enum Narrators {
  Tom = 'Tom',
  Travis = 'Travis',
}

export class ElevenLabsService {
  private static instance: ElevenLabsService;
  private static API_BASE_URL = 'https://api.elevenlabs.io/v1/';

  private settings = {
    modelId: 'eleven_monolingual_v1',
    voiceIds: {
      [Narrators.Tom]: 'IJH6gdNupF9DgpiExmnW', // Horse Race
      [Narrators.Travis]: 'XCnAF5QgLHageg1DZ4w7', // Horse Race 2
    },
    voiceSettings: {
      'stability': 0.5,
      'similarity_boost': 0.75,
      style: 0,
      'use_speaker_boost': true,
    },
    optimizeStreamingLatency: 0,
    outputFormat: 'mp3_44100_128',
  };

  constructor(private readonly axiosService: AxiosService){}

  static getInstance() {
    if (!ElevenLabsService.instance) {
      const axiosService = AxiosService.getInstance(ElevenLabsService.API_BASE_URL, {
        'xi-api-key': config.ELEVEN_LABS_API_KEY,
      });

      ElevenLabsService.instance = new ElevenLabsService(axiosService);
    }

    return ElevenLabsService.instance;
  }

  private getVoiceId(voiceName: Narrators) {
    return this.settings.voiceIds[voiceName] || this.settings.voiceIds.Tom;
  }

  private async textToSpeech(text: string, voiceName: Narrators = Narrators.Tom, retries = 3): Promise<Buffer | null> {
    const voiceId = this.getVoiceId(voiceName);

    const {
      modelId,
      voiceSettings,
      optimizeStreamingLatency,
      outputFormat,
    } = this.settings;
    const controller = new AbortController();

    const textToSpeechFunc = async () => this.axiosService.post<any>(`text-to-speech/${voiceId}`, {
      text,
      model_id: modelId,
      voice_settings: voiceSettings,
    }, {
      params: {
        optimize_streaming_latency: optimizeStreamingLatency,
        output_format: outputFormat,
      },
      responseType: 'arraybuffer',
      headers: {
        'Connection': 'keep-alive',
      },
      signal: controller.signal,
    });

    // 5 mins timeout b/c sometimes elevenlabs doesn't return the response indefinitely
    // Usually audio generation takes about 2 mins so 5 mins will cover exponential backoff retry
    const res: any = await Promise.race([
      exponentialBackOff(textToSpeechFunc),
      sleep(5 * 60 * 1000),
    ]);

    if (retries === 0) {
      controller.abort();
      return null;
    }

    if (!res?.result?.data) {
      controller.abort();
      return this.textToSpeech(text, voiceName, retries - 1);
    }

    const body = Buffer.from(res.result.data, 'base64');
    return body;
  }

  async getAudioUrlForText(text: string, filename: string, voiceName: Narrators = Narrators.Tom) {
    try {
      log.info({
        func: this.getAudioUrlForText.name,
        text,
        filename,
        voiceName,
      }, 'Get Audio Url For Text Start');

      const audio = await this.textToSpeech(text, voiceName);

      log.info({
        func: this.getAudioUrlForText.name,
        text,
        filename,
        voiceName,
        // audio,
      }, 'Get Audio Url For Text After Text To Speech');

      const uploadResult = await uploadObject({
        bucket: config.aws.s3.chickenderby.bucket,
        key: `${config.aws.s3.chickenderby.audio.raceCommentariesDir}/${filename}.mp3`,
        body: audio,
        contentEncoding: 'base64',
        contentType: 'audio/mpeg',
      });

      const url = `${config.aws.s3.chickenderby.cloudfront}/${uploadResult.Key}`;

      log.info({
        func: this.getAudioUrlForText.name,
        text,
        filename,
        voiceName,
        url,
      }, 'Get Audio Url For Text End');

      return url;
    } catch (err) {
      log.error({
        func: this.getAudioUrlForText.name,
        text,
        filename,
        voiceName,
        err,
      }, 'Get Audio Url For Text Error');

      return null;
    }
  }
}
