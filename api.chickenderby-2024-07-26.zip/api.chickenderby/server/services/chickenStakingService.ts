import { Job } from 'bull';
import * as moment from 'moment-timezone';

import * as settingsService from './settingService';
import { log, sleep } from '../utils';
import { ChickenStakingSeason } from '../sequelize/models/ChickenStakingSeason';
import { ChickenStakingContractService } from './contracts/chickenStakingContractService';
import { getSuccessfulTransactionHashAndReceipt, toChecksumAddress } from './contracts/web3Service';
import { SeasonStatus } from '../types/seasons/seasonStatus';
import { BawkStakingService } from './bawk-staking.service';

export class ChickenStakingService {
  private static instance: ChickenStakingService;

  constructor(private chickenStakingContractService: ChickenStakingContractService, private bawkStakingService: BawkStakingService) {}

  static getInstance() {
    if (!ChickenStakingService.instance) {
      ChickenStakingService.instance = new ChickenStakingService(ChickenStakingContractService.getInstance(), BawkStakingService.getInstance());
    }

    return ChickenStakingService.instance;
  }

  private async isContractStartStakingPeriodSuccess(startTimestamp: number) {
    const periodFinish = await this.chickenStakingContractService.getPeriodFinish();
    return periodFinish > startTimestamp;
  }

  private async skipJob(job: Job, message: string) {
    await job.progress(100);
    await job.log(message);

    log.info({
      func: this.skipJob.name,
    }, message);
  }

  async startStakingPeriod(job: Job) {
    try {
      await job.progress(0);

      const isDeploymentProgress = await settingsService.isDeploying();
      if (isDeploymentProgress) {
        return this.skipJob(job, 'Deployment is in progress, postpone startStakingPeriod');
      }

      const isChickenStakingEnabled = await settingsService.isChickenStakingEnabled();
      if (!isChickenStakingEnabled) {
        return this.skipJob(job, 'Chicken staking disabled, postpone startStakingPeriod');
      }

      const liveSeason = await this.getLiveSeason();
      const pendingSeason = await ChickenStakingSeason.findOne({
        where: {
          status: SeasonStatus.Pending,
        },
        order: [['id', 'asc']],
      });

      if (!liveSeason && !pendingSeason) {
        return this.skipJob(job, 'There is no base chicken staking season');
      }

      if (liveSeason) {
        if (moment.utc(liveSeason.endsAt).isAfter(moment.utc())) {
          return this.skipJob(job, 'Current chicken staking season is in progress');
        }

        await liveSeason.update({
          status: SeasonStatus.Completed,
        });
      }

      if (!pendingSeason) {
        return this.skipJob(job, 'There is no pending chicken staking season');
      }

      const startTimestamp = moment.utc(pendingSeason.startsAt).unix();
      const startDateTime = moment.unix(startTimestamp).format('YYYY-MM-DD HH:mm:ss');

      if (!liveSeason) {
        // start the bawk staking season only once at the very first time
        await this.bawkStakingService.start(startTimestamp);

        await sleep(6000);
      }

      const txHashes: string[] = [];
      let transactionHash: string = null;

      await new Promise((resolve, reject) => {
        this.chickenStakingContractService.startStakingPeriod(startTimestamp, {
          onTx: (txHash) => {
            transactionHash = txHash;
            txHashes.push(transactionHash);

            log.info({
              func: this.startStakingPeriod.name,
              startTimestamp,
              transactionHash,
              txHashes,
            }, `startStakingPeriod on txHash on ${startDateTime}`);
          },
          onReceipt: async (receipt) => {
            log.info({
              func: this.startStakingPeriod.name,
              startTimestamp,
              receipt,
              transactionHash,
              txHashes,
            }, `startStakingPeriod on receipt on ${startDateTime}`);

            resolve(receipt);
          },
          onError: async (err) => {
            await sleep(6000);

            // catch error and return undefined
            const successfulTransaction = await getSuccessfulTransactionHashAndReceipt(txHashes).catch((err2) => {
              log.error({
                func: this.startStakingPeriod.name,
                startTimestamp,
                transactionHash,
                txHashes,
                err: err2,
              }, `startStakingPeriod getSuccessfulTransactionHashAndReceipt Error on ${startDateTime}`);

              return null;
            });
            if (successfulTransaction?.txHash) {
              transactionHash = successfulTransaction.txHash;
            }

            // catch error and return undefined
            const isContractSuccess = await this.isContractStartStakingPeriodSuccess(startTimestamp).catch((err2) => {
              log.error({
                func: this.startStakingPeriod.name,
                startTimestamp,
                transactionHash,
                txHashes,
                err: err2,
              }, `startStakingPeriod isContractEnterSuccess Error on ${startDateTime}`);
            });

            log.error({
              func: this.startStakingPeriod.name,
              startTimestamp,
              isContractSuccess,
              transactionHash,
              txHashes,
              successfulTransaction,
              err,
            }, `startStakingPeriod On Error on ${startDateTime}`);

            let errorMsg = err.message;

            if (isContractSuccess || successfulTransaction) {
            // edge case: we are raising new transaction if the previous one is not mined within 1000 seconds
            // sometimes the previous transaction is mined while we are generating new one
            // so new one fails with the `Signer and signature do not match` error
            // in that case, we have to mark the transaction as completed because it's actually a successful transaction
              resolve(successfulTransaction?.receipt);
              return;
            } if (errorMsg?.includes('Transaction was not mined within')) {
              resolve(null);
              return;
            }

            if (errorMsg?.includes('execution reverted: Signer and signature do not match')) {
              errorMsg += '\n This might be because your previous transaction was not minded yet. Please try again.';
            }

            reject(new Error(errorMsg));
          },
        });
      });

      await pendingSeason.update({
        status: SeasonStatus.Live,
      });
    } catch (err) {
      log.info({
        func: this.startStakingPeriod.name,
        err,
      }, 'Start Staking Period Error');
    }
  }

  async getChickenStaker(chickenId: number) {
    const { staker } = await this.chickenStakingContractService.getChickenIdToInfo(chickenId);
    return staker;
  }

  async isChickenStakedByUserWalletId(userWalletId: string, chickenId: number) {
    const staker = await this.getChickenStaker(chickenId);
    return toChecksumAddress(staker) === toChecksumAddress(userWalletId);
  }

  async getStakedChickenIds(userWalletId: string) {
    const userStakeInfo = await this.chickenStakingContractService.getUserStakeInfo(userWalletId);
    return userStakeInfo.chickenIdsStaked;
  }

  async getAvailableRewards(userWalletId: string) {
    const userStakeInfo = await this.chickenStakingContractService.getUserStakeInfo(userWalletId);
    return userStakeInfo.availableRewards;
  }

  async getLiveSeason() {
    return ChickenStakingSeason.findOne({
      where: {
        status: SeasonStatus.Live,
      },
      order: [['id', 'desc']],
    });
  }
}
