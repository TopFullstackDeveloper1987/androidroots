import Sequelize from 'sequelize';

// Config
import config from '../config';

// Models
import { UserWallet } from '../sequelize/models/UserWallet';
import { Coop } from '../sequelize/models/Coop';
import { ReferralService } from './referral.service';
import { PreRegisterLandService } from './pre-register-land.service';

export const createUserWallet = async (userWalletId: string, transaction?: Sequelize.Transaction) => {
  const userWallet = await UserWallet.create({
    id: userWalletId,
  }, { transaction });

  // add default coops
  for (let i = 0; i < config.COOP_LIMIT; i += 1) {
    await Coop.create({
      name: `Coop ${i + 1}`,
      userWalletId,
    }, { transaction });
  }

  return userWallet;
};

export const getPreRegisterLandInfo = async (userWalletId: string) => {
  const referralService = ReferralService.getInstance();

  const preRegistration = await PreRegisterLandService.getInstance().findOne(userWalletId);
  const defaultCount = preRegistration ? 1 : 0;

  const referrerCount = await referralService.getReferrerCount(userWalletId);
  const refereeCount = await referralService.getRefereeCount(userWalletId);

  // 1 plot by default, +1 for referrers and referee
  const lootboxCount = referrerCount + refereeCount + defaultCount;

  return {
    name: preRegistration?.name,
    lootboxCount,
    referrerCount,
    refereeCount,
  };
};
