import axios, { AxiosRequestConfig } from 'axios';
import config from '../config';
import { log } from '../utils';
import { FirebaseTopic } from '../types';

export const sendNotification = async (to: string, title: string, body: string, url: string) => {
  const axiosConfig: AxiosRequestConfig = {
    url: 'https://fcm.googleapis.com/fcm/send',
    method: 'post',
    timeout: 5000,
    headers: {
      Authorization: `Bearer ${config.FIREBASE_NOTIFICATION_TOKEN}`,
      'cache-control': 'no-cache',
      'content-type': 'application/json',
    },
    data: {
      to,
      data: {
        title,
        body,
        url,
      },
    },
  };

  try {
    await axios(axiosConfig);
  } catch (err) {
    log.error({
      func: sendNotification.name,
      axiosConfig,
      err,
    }, 'Send Firebase Push Notification Error');
  }
};

export const sendNotificationToTopic = async (topic: FirebaseTopic, title: string, body: string, url: string) => {
  const axiosConfig: AxiosRequestConfig = {
    url: 'https://fcm.googleapis.com/fcm/send',
    method: 'post',
    timeout: 5000,
    headers: {
      Authorization: `key=${config.FIREBASE_NOTIFICATION_TOKEN}`,
      'cache-control': 'no-cache',
      'content-type': 'application/json',
    },
    data: {
      to: `/topics/${topic}`,
      data: {
        title,
        body,
        url,
      },
    },
  };

  try {
    await axios(axiosConfig);
  } catch (err) {
    log.error({
      func: sendNotificationToTopic.name,
      axiosConfig,
      err,
    }, 'Send Notification To Topic Error');
  }
};
