import Sequelize from 'sequelize';

import { UserWallet } from '../sequelize/models/UserWallet';
import { PreRegistration } from '../sequelize/models/PreRegistration';
import { ICreatePreRegisterLandPayload } from '../types/pre-registrations';
import { ReferralService } from './referral.service';

export class PreRegisterLandService {
  private static instance: PreRegisterLandService;

  static getInstance() {
    if (!PreRegisterLandService.instance) {
      PreRegisterLandService.instance = new PreRegisterLandService();
    }

    return PreRegisterLandService.instance;
  }

  async createOne(userWalletId: string, payload: ICreatePreRegisterLandPayload, transaction?: Sequelize.Transaction) {
    const userWallet = await UserWallet.findByPk(userWalletId);
    if (!userWallet) {
      throw new Error('User Wallet not found');
    }

    const existingPreRegistration = await PreRegistration.findByPk(userWalletId);
    if (existingPreRegistration) {
      throw new Error('Already registered');
    }

    const preRegistrationWithName = await PreRegistration.findOne({
      where: {
        name: payload.name,
      },
    });
    if (preRegistrationWithName) {
      throw new Error('Plot name already exists');
    }

    const preRegistrationWithEmail = payload.email && await PreRegistration.findOne({
      where: {
        email: payload.email,
      },
    });
    if (preRegistrationWithEmail) {
      throw new Error('Email already exists');
    }

    if (payload.referralCode) {
      await ReferralService.getInstance().createOne(payload.referralCode, userWalletId, transaction);
    }

    return PreRegistration.create({
      id: userWalletId,
      name: payload.name,
      email: payload.email,
    }, {
      transaction,
    });
  }

  async findOne(userWalletId: string) {
    return PreRegistration.findByPk(userWalletId);
  }

  async getTotalCount() {
    return PreRegistration.count();
  }
}
