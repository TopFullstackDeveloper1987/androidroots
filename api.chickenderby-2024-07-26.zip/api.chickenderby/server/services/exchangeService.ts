import axios from 'axios';
import NP from 'number-precision';

// Config
import config from '../config';

import { exponentialBackOff } from '../utils/exponentialBackoff';
import { redisCache } from '../utils/redisCache';
import { getChainLinkEthUsdContract } from './contracts/web3Service';
import { RaceCoinType } from '../types/races/raceCoinType';

export const getCoinRate = async () => {
  const getCoinRateFunc = async () => {
    const wethId = '2396';
    const ethId = '1027';

    const getCoinMarketCappFunc = async () => axios.get('https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest', {
      headers: {
        'X-CMC_PRO_API_KEY': config.CMC_API_KEY,
      },
      params: {
        id: `${wethId},${ethId}`,
      },
    });
    const { result: response } = await exponentialBackOff(getCoinMarketCappFunc);

    const wethRate = response.data.data[wethId].quote.USD;
    const ethRate = response.data.data[ethId].quote.USD;

    const priceInfo = {
      weth: wethRate.price,
      eth: ethRate.price,
    };

    // CMC API call rate limit: 2 requests a minute

    return priceInfo;
  };

  // CMC API call rate limit: 2 requests a minute
  return redisCache(getCoinRateFunc, '__cache__getCoinRate', 30);
};

export const ethToUsdt = async () => {
  const chainLinkContract = await getChainLinkEthUsdContract();

  const ethToUsdt = async () => {
    const latestRoundDataFunc = async () => chainLinkContract.methods.latestRoundData().call();
    const { result: response } = await exponentialBackOff(latestRoundDataFunc);
    return NP.strip(response.answer / 1e8);
  };

  // every 30 seconds
  return redisCache(ethToUsdt, '__cache__ethToUsdt', 30);
};

export const ethToJewel = async () => {
  const ethPrice = await ethToUsdt();
  return NP.strip(ethPrice * config.JEWELS_MULTIPLIER);
};

export const jewelToUsdt = () => NP.strip(1 / config.JEWELS_MULTIPLIER);
export const usdtToJewel = () => NP.strip(config.JEWELS_MULTIPLIER);

export const bawkToUsdt = () => NP.strip(1 / config.BAWKS_MULTIPLIER);

export const convertCoinToJewel = async (coinType: RaceCoinType, coin: number, decimalPoints = 2) => {
  const coinPrice = coinType === RaceCoinType.WETH ? await ethToJewel() : 1;

  return Number((coin * coinPrice).toFixed(decimalPoints));
};
