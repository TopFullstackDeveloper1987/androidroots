import * as moment from 'moment-timezone';
import * as uuid from 'uuid';
import * as _ from 'lodash';

import config from '../config';
import { Nonce } from '../sequelize/models/Nonce';

const getNonceMessage = ({
  userWalletId,
  nonce,
}: {
  userWalletId: string,
  nonce: string,
}) => {
  const message = `Welcome to Chicken Derby!\n
Please Sign to authenticate your wallet.\n
This request will not trigger a blockchain transaction or cost any gas fees.\n
Your authentication status will reset after 24 hours.\n\nWallet address:\n${userWalletId}\n\nNonce:\n${nonce}`;

  return message;
};

export const findOrCreateNonce = async (userWalletId: string) => {
  const now = moment.utc();
  const defaultExpiresAt = now.clone().add(config.AUTH_TOKEN_EXPIRATION_HOURS, 'hours').toDate();
  const defaultNonce = uuid.v4();

  const defaults = {
    id: userWalletId,
    nonce: defaultNonce,
    expiresAt: defaultExpiresAt,
    message: getNonceMessage({
      userWalletId,
      nonce: defaultNonce,
    }),
  };

  const nonceRecord = await Nonce.findOrCreate({
    where: {
      id: userWalletId,
    },
    defaults,
  }).then(async ([newNonceRecord, created]) => {
    if (created) {
      return newNonceRecord;
    }

    return newNonceRecord.update(_.omit(defaults, ['id']));
  });

  return nonceRecord;
};
