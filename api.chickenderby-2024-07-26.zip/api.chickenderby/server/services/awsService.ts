import * as AWS from 'aws-sdk';
import axios from 'axios';

import config from '../config';
import { exponentialBackOff } from '../utils/exponentialBackoff';

AWS.config.update({
  accessKeyId: config.aws.accessKeyId,
  secretAccessKey: config.aws.secretAccessKey,
});

const s3 = new AWS.S3();

export const uploadObject = async ({
  bucket,
  key,
  body,
  contentEncoding,
  contentType,
}: {
  bucket: string,
  key: string,
  body: Buffer,
  contentEncoding?: string,
  contentType?: string
}) => {
  const s3UploadFunc = async () => s3.upload({
    Bucket: bucket,
    Key: key,
    Body: body,
    ContentEncoding: contentEncoding,
    ContentType: contentType,
    ACL: 'public-read',
  }).promise();
  const { result } = await exponentialBackOff(s3UploadFunc);

  return result;
};

export const deleteObject = async ({
  bucket,
  key,
}: {
  bucket: string,
  key: string,
}) => {
  const s3DeleteObjectFunc = async () => s3.deleteObject({
    Bucket: bucket,
    Key: key,
  }).promise();
  const { result } = await exponentialBackOff(s3DeleteObjectFunc);

  return result;
};

export const uploadUrlToS3 = async (url: string, {
  bucket,
  key,
  contentType,
}: {
  bucket: string,
  key: string,
  contentType?: string
}, cloudfront: string = config.aws.s3.chickenderby.cloudfront) => {
  const axiosGetFunc = async () => axios.get(url, {
    responseType: 'arraybuffer',
    headers: {
      'Connection': 'keep-alive',
    },
  });
  const { result: res } = await exponentialBackOff(axiosGetFunc);
  const body = Buffer.from(res.data, 'base64');

  const uploadResult = await uploadObject({
    bucket,
    key,
    body,
    contentEncoding: 'base64',
    contentType,
  });

  return `${cloudfront}/${uploadResult.Key}`;
};
