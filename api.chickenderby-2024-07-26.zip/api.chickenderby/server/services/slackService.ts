import axios, { AxiosRequestConfig } from 'axios';
import config from '../config';

import { sleep, log } from '../utils';
import { exponentialBackOff } from '../utils/exponentialBackoff';

export const postToSlack = async (title: string, type: 'raceAlert', {
  text,
  img,
  fields,
  slackWebhookUrl,
  actions,
  blocks,
}: {
  text: string,
  img?: string,
  fields: {
    title: string,
    value: string,
    short: boolean,
  }[],
  slackWebhookUrl?: string,
  actions?: string[],
  blocks?: string[],
}, retries = 0): Promise<any> => {
  // Select Icon
  const alertTypes = {
    raceAlert: ':exclamation:',
  };

  const typeIcon = alertTypes[type] || alertTypes.raceAlert;

  // Create Slack Message
  const slackMsg = {
    username: String(title),
    icon_emoji: typeIcon,
    text,
    blocks,
    attachments: [{
      fallback: text || fields[0]?.value,
      fields,
      actions,
      image_url: img,
    }],
  };

  const axiosConfig: AxiosRequestConfig = {
    url: slackWebhookUrl,
    method: 'post',
    timeout: 5000,
    headers: {
      'cache-control': 'no-cache',
      'content-type': 'application/json',
    },
    data: slackMsg,
  };

  try {
    // slack rate limit, one post per channel per second
    await sleep(2000);

    if (slackWebhookUrl) {
      const postToSlackAxiosFunc = async () => axios(axiosConfig);
      const { result } = await exponentialBackOff(postToSlackAxiosFunc);

      return result;
    }

    if (type === 'raceAlert') {
      axiosConfig.url = config.slack.raceAlertWebhookUrl;
      const postToSlackAxiosFunc = async () => axios(axiosConfig);
      const { result } = await exponentialBackOff(postToSlackAxiosFunc);

      return result;
    }

    return null;
  } catch (err: any) {
    log.error({
      func: 'postToSlack',
      slackMsg,
      retries,
      err,
    }, 'Post To Slack Error');

    const isTimeout = err.code === 'ECONNABORTED';
    if (isTimeout) { // don't try again on timeout
      return null;
    }

    // Retry
    if (retries < 1) {
      return postToSlack(title, type, {
        text,
        img,
        fields,
        slackWebhookUrl,
      }, retries + 1);
    }

    return null;
  }
};
