// Dependencies
import Sequelize from 'sequelize';
import axios from 'axios';
import * as _ from 'lodash';

const { Op } = Sequelize;

// Config
import config from '../config';

// Models
import { Chicken } from '../sequelize/models/Chicken';
import { UserWallet } from '../sequelize/models/UserWallet';
import { Clothing } from '../sequelize/models/Clothing';
import { ChickenClothing } from '../sequelize/models/ChickenClothing';
import { Lane } from '../sequelize/models/Lane';
import { FusionAssignment } from '../sequelize/models/FusionAssignment';

// Services
import { toChecksumAddress } from './contracts/web3Service';
import * as chickenContractService from './contracts/chickenContractService';
import { deleteObject, uploadObject } from './awsService';
import { ChickenStakingService } from './chickenStakingService';
import { getOwnersForCollection } from './contracts/alchemyService';

// Utils
import profanity from '../utils/profanity.json';
import { exponentialBackOff } from '../utils/exponentialBackoff';
import { log } from '../utils';

// Types
import { AssignmentStatus } from '../types/assignments/assignmentStatus';
import { ChickenStatus } from '../types/chickens/chickenStatus';
import { ChickenLegs } from '../types/chickens/chickenLegs';
import { ChickenSituation } from '../types/chickens/chickenSituation';
import { CHICKEN_STAKING_CONTRACT } from '../abi/chickenStakingContract';
import { CHICKEN_CONTRACT } from '../abi/chickenContract';
import { ChickenStakingStatus } from '../types/chicken-staking';

export const checkChickenOwnership = async (userWalletId: string, chickenId: number, isIncludingStaked: boolean = true) => {
  const ownerAddress = await getOwnerOfChicken(chickenId, isIncludingStaked);
  if (toChecksumAddress(ownerAddress) !== toChecksumAddress(userWalletId)) {
    throw new Error('This chicken doesn\'t belong to you');
  }
};

export const updateChickenName = async ({
  chickenId,
  userWalletId,
  name,
}: {
  chickenId: number,
  userWalletId: string,
  name: string,
}) => {
  const isProfanity = profanity.find((word) => word.toLowerCase() === name.toLowerCase());

  if (isProfanity) {
    throw new Error('We have detected profanity within this name. Please choose a different name.');
  }

  if (name.length > 20) {
    throw new Error('Your name cannot be longer than 20 characters.');
  }

  if (name.length < 3) {
    throw new Error('Your name cannot be shorter than 3 characters.');
  }

  const chickenRecord = await Chicken.findByPk(chickenId);
  if (!chickenRecord) {
    throw new Error('Chicken not found.');
  }

  if (chickenRecord.namedAt) {
    throw new Error('A chicken can only be named once, and then it can\'t be changed.');
  }

  const existingChicken = await Chicken.findOne({
    where: {
      name,
    },
  });
  if (existingChicken) {
    throw Error('This name has already been taken. Please choose another.');
  }

  await checkChickenOwnership(userWalletId, chickenId);

  return chickenRecord.update({
    name,
    namedAt: new Date(),
  });
};

export const getChickenFilter = async (filter: any) => {
  let where: Sequelize.WhereOptions<Chicken> = {};

  // Situation
  if (filter?.situation?.length) {
    where = {
      ...where,
      situation: filter.situation,
    };
  }

  // Key Traits
  // Heritage
  if (filter?.heritage?.length) {
    where = {
      ...where,
      heritage: filter.heritage,
    };
  }

  // Perfection
  if (filter?.perfectionMin && filter?.perfectionMax) {
    where = {
      ...where,
      perfection: {
        [Op.gte]: Number(filter.perfectionMin),
        [Op.lte]: Number(filter.perfectionMax),
      },
    };
  } else if (filter?.perfectionMin) {
    where = {
      ...where,
      perfection: {
        [Op.gte]: Number(filter.perfectionMin),
      },
    };
  } else if (filter?.perfectionMax) {
    where = {
      ...where,
      perfection: {
        [Op.lte]: Number(filter.perfectionMax),
      },
    };
  }

  // Stock
  if (filter?.stock?.length) {
    where = {
      ...where,
      stock: filter.stock,
    };
  }

  // Talent
  if (filter?.talent?.length) {
    where = {
      ...where,
      talent: filter.talent,
    };
  }

  if (filter?.terrainPreference?.length) {
    where = {
      ...where,
      terrainPreference: filter.terrainPreference,
    };
  }

  if (filter?.distancePreference?.length) {
    where = {
      ...where,
      distancePreference: filter.distancePreference,
    };
  }

  if (filter?.talentPreference?.length) {
    where = {
      ...where,
      talentPreference: filter.talentPreference,
    };
  }

  // Race Performances
  // Pecking Order
  if (filter?.peckingOrder?.length) {
    where = {
      ...where,
      peckingOrder: filter.peckingOrder,
    };
  }

  // Minimum Pecking Order
  if (filter?.minimumPeckingOrder?.length) {
    where = {
      ...where,
      minimumPeckingOrder: filter.minimumPeckingOrder,
    };
  }

  // Races
  if (filter?.racesMin && filter?.racesMax) {
    where = {
      ...where,
      races: {
        [Op.gte]: Number(filter.racesMin),
        [Op.lte]: Number(filter.racesMax),
      },
    };
  } else if (filter?.racesMin) {
    where = {
      ...where,
      races: {
        [Op.gte]: Number(filter.racesMin),
      },
    };
  } else if (filter?.racesMax || filter?.racesMax === 0) {
    where = {
      ...where,
      races: {
        [Op.lte]: Number(filter.racesMax),
      },
    };
  }

  // Placed
  if (filter?.placedMin && filter?.placedMax) {
    where = {
      ...where,
      placed: {
        [Op.gte]: Number(filter.placedMin),
        [Op.lte]: Number(filter.placedMax),
      },
    };
  } else if (filter?.placedMin) {
    where = {
      ...where,
      placed: {
        [Op.gte]: Number(filter.placedMin),
      },
    };
  } else if (filter?.placedMax || filter?.placedMax === 0) {
    where = {
      ...where,
      placed: {
        [Op.lte]: Number(filter.placedMax),
      },
    };
  }

  // Place Percentage
  if (filter?.placedPercentageMin && filter?.placedPercentageMax) {
    where = {
      ...where,
      placedPercentage: {
        [Op.gte]: Number(filter.placedPercentageMin),
        [Op.lte]: Number(filter.placedPercentageMax),
      },
    };
  } else if (filter?.placedPercentageMin) {
    where = {
      ...where,
      placedPercentage: {
        [Op.gte]: Number(filter.placedPercentageMin),
      },
    };
  } else if (filter?.placedPercentageMax || filter?.placedPercentageMax === 0) {
    where = {
      ...where,
      placedPercentage: {
        [Op.lte]: Number(filter.placedPercentageMax),
      },
    };
  }

  // First Place Percentage
  if (filter?.firstPlacedPercentageMin && filter?.firstPlacedPercentageMax) {
    where = {
      ...where,
      firstPlacedPercentage: {
        [Op.gte]: Number(filter.firstPlacedPercentageMin),
        [Op.lte]: Number(filter.firstPlacedPercentageMax),
      },
    };
  } else if (filter?.firstPlacedPercentageMin) {
    where = {
      ...where,
      firstPlacedPercentage: {
        [Op.gte]: Number(filter.firstPlacedPercentageMin),
      },
    };
  } else if (filter?.firstPlacedPercentageMax || filter?.firstPlacedPercentageMax === 0) {
    where = {
      ...where,
      firstPlacedPercentage: {
        [Op.lte]: Number(filter.firstPlacedPercentageMax),
      },
    };
  }

  // poPoints
  if (filter?.poPointsMin && filter?.poPointsMax) {
    where = {
      ...where,
      poPoints: {
        [Op.gte]: Number(filter.poPointsMin),
        [Op.lte]: Number(filter.poPointsMax),
      },
    };
  } else if (filter?.poPointsMin) {
    where = {
      ...where,
      poPoints: {
        [Op.gte]: Number(filter.poPointsMin),
      },
    };
  } else if (filter?.poPointsMax || filter?.poPointsMax === 0) {
    where = {
      ...where,
      poPoints: {
        [Op.lte]: Number(filter.poPointsMax),
      },
    };
  }

  // Winnings
  if (filter?.earningsMin && filter?.earningsMax) {
    where = {
      ...where,
      earnings: {
        [Op.gte]: Number(filter.earningsMin),
        [Op.lte]: Number(filter.earningsMax),
      },
    };
  } else if (filter?.earningsMin) {
    where = {
      ...where,
      earnings: {
        [Op.gte]: Number(filter.earningsMin),
      },
    };
  } else if (filter?.earningsMax || filter?.earningsMax === 0) {
    where = {
      ...where,
      earnings: {
        [Op.lte]: Number(filter.earningsMax),
      },
    };
  }

  // Appearance
  // Gender
  if (filter?.gender?.length) {
    where = {
      ...where,
      gender: filter.gender,
    };
  }

  // Color - baseBody
  if (filter?.baseBody?.length) {
    where = {
      ...where,
      baseBody: filter.baseBody,
    };
  }

  // Eyes
  if (filter?.eyesType?.length) {
    where = {
      ...where,
      eyesType: filter.eyesType,
    };
  }

  // Comb
  if (filter?.combColor?.length) {
    where = {
      ...where,
      combColor: filter.combColor,
    };
  }

  // Wattle
  if (filter?.wattleColor?.length) {
    where = {
      ...where,
      wattleColor: filter.wattleColor,
    };
  }

  // Beak
  if (filter?.beakColor?.length) {
    where = {
      ...where,
      beakColor: filter.beakColor,
    };
  }

  // Beak Accessory, pass null for None
  if (filter?.beakAccessory?.length) {
    where = {
      ...where,
      beakAccessory: filter.beakAccessory,
    };
  }

  // Background
  if (filter?.background?.length) {
    where = {
      ...where,
      background: filter.background,
    };
  }

  // Stripes, pass null for None
  if (filter?.stripes?.length) {
    if (filter?.stripes.includes(true) && filter?.stripes.includes(false)) {
      // don't need to add stripes to where criteria if it pass both true, false [true, false]
    } else if (filter?.stripes.includes(true)) {
      where = {
        ...where,
        stripes: { [Op.not]: null },
      };
    } else if (filter?.stripes.includes(false)) {
      where = {
        ...where,
        stripes: null,
      };
    }
  }

  // Legs
  if (filter?.legs?.length) {
    let chickenLegs = [];
    if (Array.isArray(filter.legs)) {
      filter.legs.forEach((leg: string) => {
        if (Object.values(ChickenLegs).includes(leg as ChickenLegs)) {
          chickenLegs.push(leg);
        } else if (leg.toLowerCase() === 'normal') {
          chickenLegs.push(ChickenLegs.legsHen, ChickenLegs.legsRooster);
        } else if (leg.toLowerCase() === 'black') {
          chickenLegs.push(ChickenLegs.legsBlackHen, ChickenLegs.legsBlackRooster);
        }
      });
    } else {
      chickenLegs = filter.legs;
    }

    where = {
      ...where,
      legs: chickenLegs,
    };
  }

  if (filter?.listed?.length) {
    if (filter?.listed.includes(true) && filter?.listed.includes(false)) {
      // don't need to add listed to where criteria if it pass both true, false [true, false]
    } else if (filter?.listed.includes(true)) {
      where = {
        ...where,
        lastActiveMarketItemId: { [Op.not]: null },
      };
    } else if (filter?.listed.includes(false)) {
      where = {
        ...where,
        lastActiveMarketItemId: null,
      };
    }
  }

  // Owner name
  if (filter?.username) {
    // TODO: need some way to avoid getting all userWalletIds at once
    const userWallets = await UserWallet.findAll({
      where: {
        username: {
          [Op.like]: `%${filter.username}%`,
        },
      },
      attributes: ['id'],
    });
    const userWalletIds = userWallets.map((userWallet) => userWallet.id);
    const chickenIdsForUserWalletIds = await chickenContractService.getChickenIdsForUserWalletIds(userWalletIds);
    const chickenIds = _.flatten(chickenIdsForUserWalletIds.map((el) => el.chickenIds));

    where = {
      ...where,
      id: chickenIds,
    };
  }

  // Chicken name
  if (filter?.name) {
    where = {
      ...where,
      name: { [Op.like]: `%${filter.name}%` },
    };
  }

  // My Chicken Only
  if (filter?.userWalletId) {
    const chickenIds = await getChickenIdsForUserWalletId(filter.userWalletId, filter.stakingStatus);

    where = {
      ...where,
      id: chickenIds,
    };
  }

  return where;
};

export const getChickenClothingImageName = (chicken: Partial<Chicken>, clothings: Clothing[]) => {
  const clothingIds = clothings.map((clothing) => clothing.id).sort();
  return `${chicken.chknId}-${clothingIds.join('-')}.png`;
};

export const generateChickenImage = async (chicken: Partial<Chicken>, clothings: Clothing[], size: number) => {
  const axiosPostFunc = async () => axios.post(`${config.IMAGE_SERVER_URL}/chickens`, {
    chicken,
    clothings,
    size,
  }, {
    responseType: 'arraybuffer',
    headers: {
      'Connection': 'keep-alive',
    },
  });

  const { result: res } = await exponentialBackOff(axiosPostFunc);
  const body = Buffer.from(res.data, 'base64');
  const key = clothings?.length > 0
    ? `${config.aws.s3.chickenderby.chickenClothingsDir}/${getChickenClothingImageName(chicken, clothings)}`
    : `${config.aws.s3.chickenderby.chickensDir}/${chicken.chknId}.png`;

  const uploadResult = await uploadObject({
    bucket: config.aws.s3.chickenderby.bucket,
    key,
    body,
    contentEncoding: 'base64',
    contentType: 'image/png',
  });

  return `${config.aws.s3.chickenderby.cloudfront}/${uploadResult.Key}`;
};

export const deleteChickenClothingImage = async (chicken: Chicken, transaction: Sequelize.Transaction) => {
  try {
    if (!chicken?.clothingImage) {
      return;
    }

    const laneWithClothingImage = await Lane.findOne({
      where: {
        clothingImage: chicken.clothingImage,
      },
      transaction,
    });
    if (laneWithClothingImage) {
      return;
    }

    const key = chicken?.clothingImage.replace(`${config.aws.s3.chickenderby.cloudfront}/`, '');
    // run in background to speed up API response time
    deleteObject({
      bucket: config.aws.s3.chickenderby.bucket,
      key,
    });

    await chicken.update({
      clothingImage: null,
    }, { transaction });
  } catch (err) {
    log.error({
      func: 'deleteChickenClothingImage',
      chickenId: chicken?.id,
      err,
    });
  }
};

export const regenerateChickenClothingImage = async (chickenId: number, transaction: Sequelize.Transaction) => {
  const chicken = chickenId && await Chicken.findByPk(chickenId, {
    include: [{
      model: ChickenClothing,
      include: [{
        model: Clothing,
      }],
    }],
    transaction,
  });

  if (!chicken) {
    return;
  }

  await deleteChickenClothingImage(chicken, transaction);

  if (chicken.chickenClothings.length > 0) {
    const clothings = chicken.chickenClothings.map((chickenClothing) => chickenClothing.clothing);
    const clothingImage = await generateChickenImage(chicken, clothings, config.CHICKEN_CLOTHING_IMAGE_SIZE);

    await chicken.update({
      clothingImage,
    }, { transaction });
  }
};

export const checkChickenStatus = async (chickenId: number, situationCheck = true) => {
  const chicken = chickenId && await Chicken.findByPk(chickenId);

  if (!chicken) {
    throw new Error(`Chicken not found with tokenId - ${chickenId}`);
  }

  if (chicken.situation !== ChickenSituation.Barn && situationCheck) {
    throw new Error(`The chicken - ${chicken.name} is in ${chicken.situation}.`);
  }

  if (chicken.status === ChickenStatus.Pending) {
    throw new Error(`The chicken - ${chicken.name} is not minted.`);
  }

  if (chicken.status === ChickenStatus.WasFused) {
    throw new Error(`The chicken - ${chicken.name} has already been fused.`);
  }

  if (chicken.status === ChickenStatus.Burned) {
    throw new Error(`The chicken - ${chicken.name} has already been burned.`);
  }

  const fusionAssignment = await FusionAssignment.findOne({
    where: {
      [Op.or]: [{
        materialChickenId1: chickenId,
        materialChickenId2: chickenId,
      }],
      status: AssignmentStatus.Pending,
    },
  });

  if (fusionAssignment) {
    throw new Error(`The chicken - ${chicken.name} is being fused.`);
  }
};

export const getStakedAndUnstakedChickenIds = async (userWalletId: string) => {
  const chickenIdsOwned = await chickenContractService.getChickenIdsForUserWalletId(userWalletId);
  const chickenIdsStaked = await ChickenStakingService.getInstance().getStakedChickenIds(userWalletId);

  return {
    stakedChickenIds: chickenIdsStaked,
    unstakedChickenIds: chickenIdsOwned,
  };
};

export const getChickenIdsForUserWalletId = async (userWalletId: string, stakingStatus: ChickenStakingStatus = ChickenStakingStatus.All) => {
  const chickenIdsOwned = stakingStatus !== ChickenStakingStatus.Staked ? await chickenContractService.getChickenIdsForUserWalletId(userWalletId) : [];
  const chickenIdsStaked = stakingStatus !== ChickenStakingStatus.Unstaked ? await ChickenStakingService.getInstance().getStakedChickenIds(userWalletId) : [];

  return [
    ...chickenIdsOwned,
    ...chickenIdsStaked,
  ];
};

export const isChickenStaked = async (chickenId: number) => {
  const ownerAddress = await chickenContractService.getOwnerOfChicken(chickenId);
  return toChecksumAddress(ownerAddress) === toChecksumAddress(CHICKEN_STAKING_CONTRACT.address);
};

export const getOwnerOfChicken = async (chickenId: number, isIncludingStaked = true) => {
  const ownerAddress = await chickenContractService.getOwnerOfChicken(chickenId);
  if (!isIncludingStaked) {
    return ownerAddress;
  }

  const isStaked = toChecksumAddress(ownerAddress) === toChecksumAddress(CHICKEN_STAKING_CONTRACT.address);
  if (isStaked) {
    return ChickenStakingService.getInstance().getChickenStaker(chickenId);
  }

  return ownerAddress;
};

export const getTotalSupply = async () => {
  return chickenContractService.getTotalSupply();
};

export const getTotalOwners = async () => {
  const owners = await getOwnersForCollection(CHICKEN_CONTRACT.address);
  return owners?.length || 0;
};

export const getTotalStaked = async () => {
  return chickenContractService.getBalance(CHICKEN_STAKING_CONTRACT.address);
};
