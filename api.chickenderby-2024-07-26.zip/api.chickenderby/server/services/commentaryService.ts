import { ChatOpenAI } from 'langchain/chat_models/openai';
import { LLMChain } from 'langchain/chains';
import { ChatPromptTemplate } from 'langchain/prompts';

import { Race } from '../sequelize/models/Race';
import { ChickenTalent } from '../types/chickens/chickenTalent';
import { RaceProfile } from '../types/races/raceProfile';
import { Segment } from '../types/races/segment';
import { talentMeta } from '../utils/constants';
import config from '../config';
import { log } from '../utils';
import { ElevenLabsService, Narrators } from './eleven-labs.service';

export interface CommentaryData {
  chickens: Chicken[];
  elapsed: number;
  type: TalentType;
  status: CommentaryStatus,
  duration: number;
  startPosition: number;
  endPosition: number;
  talent: ChickenTalent;
}

export enum TalentType {
  deploying = 'deploying',
  hitting = 'hitting',
}
export interface Chicken {
  chickenId: number;
  chickenName: string;
}

const talentByAnimations: { [name: string]: CommentaryTalent } = {
  Anvil_Throw: {
    name: ChickenTalent.Anvil,
    action: 'deploying',
  },
  BlueRooster_Drink: {
    name: ChickenTalent.BlueRooster,
    action: 'deploying',
  },
  Chickenapult_Spawn: {
    name: ChickenTalent.Chickenapult,
    action: 'deploying',
  },
  Dig_Dive: {
    name: ChickenTalent.Dig,
    action: 'deploying',
  },
  'CK-47_Draw': {
    name: ChickenTalent.CK47,
    action: 'deploying',
  },
  Coober_Call: {
    name: ChickenTalent.Coober,
    action: 'deploying',
  },
  Flight_TakeOff: {
    name: ChickenTalent.Flight,
    action: 'deploying',
  },
  Growth_Grow: {
    name: ChickenTalent.Growth,
    action: 'deploying',
  },
  Machete_Draw: {
    name: ChickenTalent.Machete,
    action: 'deploying',
  },
  Rollerblades_Spawn: {
    name: ChickenTalent.Rollerblades,
    action: 'deploying',
  },
  Teleporter_Button_Press: {
    name: ChickenTalent.Teleport,
    action: 'deploying',
  },
  BlueEgg_Launch: {
    name: ChickenTalent.BlueEgg,
    action: 'deploying',
  },
  FanGroup_Startle: {
    name: ChickenTalent.FanGroup,
    action: 'deploying',
  },
  Helicopter_Mount_Ladder: {
    name: ChickenTalent.Helicopter,
    action: 'deploying',
  },
  Jetpack_TransitionRed: {
    name: ChickenTalent.Jetpack,
    action: 'deploying',
  },
  Jetpack_Transition: {
    name: ChickenTalent.Jetpack,
    action: 'deploying',
  },
  ColdSnap_Manta: {
    name: ChickenTalent.ColdSnap,
    action: 'deploying',
  },
  Devolution_Transform: {
    name: ChickenTalent.Devolution,
    action: 'deploying',
  },
  MovingWalkway_GetOn: {
    name: ChickenTalent.MovingWalkway,
    action: 'deploying',
  },
  BlackHole_Spit: {
    name: ChickenTalent.BlackHole,
    action: 'deploying',
  },
  RoyalProcession_Appear: {
    name: ChickenTalent.RoyalProcession,
    action: 'deploying',
  },
  FeatherRain_Call: {
    name: ChickenTalent.FeatherRain,
    action: 'deploying',
  },
  RunicBlink_Disappear: {
    name: ChickenTalent.RunicRush,
    action: 'deploying',
  },
  Anvil_Lands_1: {
    name: ChickenTalent.Anvil,
    action: 'hitting',
  },
  'CK-47_Wince': {
    name: ChickenTalent.CK47,
    action: 'hitting',
  },
  Machete_Decapitate: {
    name: ChickenTalent.Machete,
    action: 'hitting',
  },
  Teleporter_Dematerialising: {
    name: ChickenTalent.Teleport,
    action: 'hitting',
  },
  ColdSnap_GotSnap: {
    name: ChickenTalent.ColdSnap,
    action: 'hitting',
  },
  Helicopter_Missile_Hit_1: {
    name: ChickenTalent.Helicopter,
    action: 'hitting',
  },
  Devolution_FightCloud: {
    name: ChickenTalent.Devolution,
    action: 'hitting',
  },
  BlueEgg_Impact_1: {
    name: ChickenTalent.BlueEgg,
    action: 'hitting',
  },
  FeatherRain_Struck: {
    name: ChickenTalent.FeatherRain,
    action: 'hitting',
  },
};

enum CommentaryChickenSpeed {
  slow = 'slow',
  medium = 'medium',
  fast = 'fast',
  veryFast = 'very fast',
}

interface CommentaryTalent {
  name: ChickenTalent;
  action: 'deploying' | 'hitting' | 'using';
}

interface CommentarySegment {
  duration: number;
  time: number;
  speed: CommentaryChickenSpeed;
  startPosition: number;
  endPosition: number;
  talent?: CommentaryTalent;
}

interface CommentaryRaceData {
  chickenId: number;
  segments: CommentarySegment[];
}

enum CommentaryStatus {
  finished = 'finished',
  starting = 'starting'
}

export class CommentaryService {
  private totalInputToken = 0;
  private chatOpenAI = new ChatOpenAI({
    openAIApiKey: config.OPEN_AI_API_KEY,
    modelName: 'gpt-3.5-turbo',
  });

  // If Tom speaks, Travis replies in 70% cases and in other 30% cases do not reply\n\
  // If Travis speaks, Tom replies in 50% cases and do not reply in other 50% cases.\n\
  private systemPrompt =
    "I want you to act as narratories of a chicken race game.\n\
    featuring 2 commentators, one is Tom and another one is Travis.\n\
    Your job is to generate very short commentary using chickens and current status.\n\
    In 60% cases, Travis speak first and in other 40% cases, Tom speaks first.\n\
    You must not include they're off or we're off in your commentaries.\n\
    You must not start with and when you speak first.\n\
    You must use a maximum of 50 characters per sentence.\n";

  private commentaryInitPrompt = ChatPromptTemplate.fromMessages([
    ['system', this.systemPrompt],
  ]);

  private totalDuration = 0;
  private chainInit = new LLMChain({
    llm: this.chatOpenAI,
    prompt: this.commentaryInitPrompt,
  });

  private get raceName() {
    return this.race.name;
  }

  private get peckingOrder() {
    return this.race.peckingOrder;
  }

  private get distance() {
    return this.race.distance;
  }

  private get terrain() {
    return this.race.terrain?.name;
  }

  private get prizePool() {
    return this.race.prizePoolJEWEL;
  }

  private get talents() {
    return this.getTalents();
  }

  private get profiles() {
    return this.getProfiles();
  }

  private get raceData() {
    return this.getRaceData();
  }

  private get times() {
    /*
    At time {elapsed}: commentator speaks like this.
    "chickenName's position has changed from {startPosition} to {endPosition}
    in {duration} seconds by using(due to) {talent}."
    */
    //data for final result
    const data: CommentaryData[] = [];
    this.raceData.map((entry) => {
      let startIndex: number = -1; // start index of deploying talent
      let duration: number = 0; // duration of item
      let elapsed: number = 0; // total elapsed time
      let talentType: TalentType;
      entry.segments.map((segment, index) => {
        let chickenName: string = '';
        this.profiles.map(lane => {
          if (lane.id === entry.chickenId)
            chickenName = lane.name;
        });
        // action starts deploying
        if (segment.talent?.action === 'deploying')
          data.push({
            chickens: [{
              chickenId: entry.chickenId,
              chickenName,
            }],
            elapsed,
            type: TalentType.deploying,
            status: CommentaryStatus.starting,
            duration: 0,
            startPosition: 0,
            endPosition: 0,
            talent: segment.talent?.name,
          });


        if (startIndex === -1 &&
          (segment.talent?.action === 'deploying' || segment.talent?.action === 'hitting'))
        // action newly starts here, deploying means active, htting means passive
        {
          startIndex = index;
          duration = segment.duration;
          talentType = segment.talent?.action === 'deploying' ? TalentType.deploying : TalentType.hitting;
        }
        if (startIndex >= 0 && segment.talent?.action === 'using') {
          // using action now
          duration += segment.duration;
        }
        if (startIndex >= 0 && !segment.talent)
        // no action, which means previous action is ended in previous segment
        {
          const startPosition = entry.segments[startIndex].startPosition;
          const endPosition = entry.segments[index].startPosition;

          if (Math.abs(startPosition - endPosition) > 0) {
            // eslint-disable-next-line @typescript-eslint/no-non-null-asserted-optional-chain
            const talent = entry.segments[startIndex].talent?.name!;
            // check if the same talent and time exists
            let isFound: boolean = false;
            for (const one of data) {
              if (Math.abs(one.elapsed - elapsed) < 0.7 && talentType == one.type
                && talent == one.talent) {
                one.chickens.push({
                  chickenId: entry.chickenId,
                  chickenName,
                });
                one.elapsed = Math.max(elapsed, one.elapsed);
                isFound = true;
              }
            }
            if (!isFound) {
              data.push(
                {
                  chickens: [{
                    chickenId: entry.chickenId,
                    chickenName,
                  }],
                  type: talentType,
                  status: CommentaryStatus.finished,
                  duration,
                  startPosition,
                  endPosition,
                  talent: talent,
                  elapsed,
                },
              );
            }
          }
          // reset variables
          startIndex = -1;

        }
        // update elapsed time, duration
        elapsed += segment.duration;
      });
      this.totalDuration = Math.max(elapsed, this.totalDuration);
      // console.log("total duration", elapsed);
    },
    );
    return data.sort((a, b) => a.elapsed - b.elapsed);
  }

  constructor(private race: Race, private raceProfiles: RaceProfile[], private commentaryIndex = 0) { }

  private getProfiles() {
    return this.race.lanes.filter(((lane) => lane.chickenId)).map((lane) => ({
      id: lane.chicken.id,
      name: lane.chicken.name,
      stock: lane.chicken.stock,
      talent: lane.chicken.talent,
      perfection: lane.chicken.perfection,
      heritage: lane.chicken.heritage,
      laneNumber: lane.laneNumber,
    }));
  }

  private getChickenById(id: number) {
    for (const profile of this.getProfiles()) {
      if (id == profile.id)
        return profile;
    }
    return null;
  }
  private getTalents() {
    return [...new Set(this.race.lanes.filter((lane) => lane.chickenId).map((lane) => lane.chicken.talent))].map(
      (talent) => talentMeta[talent],
    );
  }

  private getRaceData(): CommentaryRaceData[] {
    return this.raceProfiles.map((profile: RaceProfile, index) => ({
      chickenId: profile.chickenId,
      segments: this.parseSegments(profile),
    }));
  }

  private parseSegments(profile: RaceProfile) {
    const regularAnimations = [
      'chicken_tired',
      'chicken_run',
      'chicken_fast_run',
      'chicken_sprint_1',
    ];
    let previousTalent: CommentaryTalent | null;

    return profile.segments.map((segment: Segment, index) => {
      let speed = this.getSpeed(segment);
      let talent = this.getTalent(segment);
      let talentAction = talent?.action as 'deploying' | 'hitting' | 'using';

      if (talent) {
        if (previousTalent?.name === talent.name) {
          talentAction = 'using';

          speed =
            previousTalent.action === 'deploying'
              ? CommentaryChickenSpeed.veryFast
              : CommentaryChickenSpeed.slow;
        } else {
          talentAction = talent.action;
          previousTalent = talent;
          speed =
            talent.action === 'deploying'
              ? CommentaryChickenSpeed.veryFast
              : CommentaryChickenSpeed.slow;
        }
      } else if (previousTalent) {
        if (
          segment.segmentChickenAnimation &&
          regularAnimations.includes(segment.segmentChickenAnimation)
        ) {
          previousTalent = null;
        } else {
          speed =
            previousTalent.action === 'hitting'
              ? CommentaryChickenSpeed.slow
              : CommentaryChickenSpeed.veryFast;

          talentAction = 'using';
          talent = previousTalent;
        }
      }

      return {
        time: segment.cumulativeSegmentSize - segment.segmentSize,
        speed,
        startPosition: this.getPosition(
          profile.chickenId,
          segment.cumulativeSegmentSize - segment.segmentSize,
        ),
        endPosition: this.getPosition(
          profile.chickenId,
          segment.cumulativeSegmentSize,
        ),
        talent: talent
          ? {
            ...talent,
            action: talentAction,
          }
          : undefined,
        duration: segment.segmentSize,
      };
    });
  }

  private getPositionByTime(segments: Segment[], elapsedTime: number) {
    let position = 0; // in meters
    let segIndex = 0;

    // position until full segments
    for (let i = 0; i < segments.length; i += 1) {
      const segment = segments[i];
      const { segmentSize, cumulativeSegmentSize, startSpeed, endSpeed } =
        segment;

      if (cumulativeSegmentSize < elapsedTime) {
        const avgSpeed = (startSpeed + endSpeed) / 2;
        position += avgSpeed * segmentSize;
        segIndex = i + 1;
      }
    }

    // position for the last segment passed partially
    if (segIndex < segments.length) {
      const segment = segments[segIndex];
      const { segmentSize, cumulativeSegmentSize, startSpeed, endSpeed } =
        segment;

      const timeInSeg = segmentSize - (cumulativeSegmentSize - elapsedTime);
      const f = timeInSeg / segmentSize;
      const currentSpeed = (endSpeed - startSpeed) * f + startSpeed;
      const avgSpeed = (startSpeed + currentSpeed) / 2;
      position += avgSpeed * timeInSeg;
    }

    return position;
  }

  private getPosition(chicken: number, time: number) {
    const finishedChickens = this.raceProfiles.filter(
      ({ segments }) =>
        segments[segments.length - 1].cumulativeSegmentSize < time,
    );
    return (
      this.raceProfiles
        .filter(
          ({ segments }) =>
            segments[segments.length - 1].cumulativeSegmentSize >= time,
        )
        .map(({ chickenId, segments }) => ({
          chickenId,
          distance: this.getPositionByTime(segments, time),
        }))
        .sort((a, b) => b.distance - a.distance)
        .findIndex(({ chickenId }) => chickenId === chicken) +
      1 +
      finishedChickens.length
    );
  }

  private getSpeed(segment: Segment) {
    switch (segment.segmentChickenAnimation) {
      case 'chicken_tired':
        return CommentaryChickenSpeed.slow;
      case 'chicken_run':
        return CommentaryChickenSpeed.medium;
      case 'chicken_fast_run':
        return CommentaryChickenSpeed.fast;
      case 'chicken_sprint_1':
        return CommentaryChickenSpeed.veryFast;
      default:
        return CommentaryChickenSpeed.medium;
    }
  }

  private getTalent(segment: Segment) {
    if (!segment.segmentChickenAnimation) {
      return;
    }

    return talentByAnimations[segment.segmentChickenAnimation];
  }

  private async commentaryInit() {
    this.totalInputToken += this.systemPrompt.length;

    await this.chainInit.call({});
  }
  public async generateWinnerCommentary() {
    // find winner first
    let winner: any = null;
    let winnerId = -1;
    this.raceData.map((entry) => {
      const len = entry.segments.length;
      const position = entry.segments[len - 1].endPosition;
      if (position == 1)
        winnerId = entry.chickenId;

    });
    if (winnerId == 0)
      return null;
    winner = this.getChickenById(winnerId);
    console.log('winner', winner);

    const winner_data = {
      name: winner.name,
      heritage: winner.heritage,
      talent: winner.talent,
    };
    // comment about it
    const humanPrompt =
      'The race has ended.\n\
    The winner is : {winner}\n\
    Please congrats the winner.\n\
    Tom and Travis speaks only one sentence each and dont add emoticons.\n\
    ';

    const winnerPrompt = ChatPromptTemplate.fromMessages([
      ['system', this.systemPrompt],
      ['human', humanPrompt],
    ]);

    const chain = new LLMChain({
      llm: this.chatOpenAI,
      prompt: winnerPrompt,
    });
    const result = await chain.call({
      winner: JSON.stringify(winner_data),
    });

    const promptStr = await winnerPrompt.formatMessages({
      winner: JSON.stringify(winner_data),
    });
    //Get prompt length
    const tokens = promptStr[1].content.length;
    this.totalInputToken += tokens;

    console.log('winnerCommentary:', result.text);
    console.log('tokens:', tokens);

    return result;


  }
  public async generateRSCommentary() {
    const humanPrompt =
      'The  race has started just before.\n\
      Please comment this status with 1 sentence each.\
      ';
    const startPrompt = ChatPromptTemplate.fromMessages([
      ['system', this.systemPrompt],
      ['human', humanPrompt],
    ]);

    const chain = new LLMChain({
      llm: this.chatOpenAI,
      prompt: startPrompt,
    });
    const result = await chain.call({});

    //Get prompt length
    const promptStr = await startPrompt.formatMessages({});
    const tokens = promptStr[1].content.length;
    this.totalInputToken += tokens;

    console.log('startRaceCommentary:', result.text);
    console.log('tokens:', tokens);
    return result;

  }
  // Generate talent start commentary
  private async generateTSCommentary(data: CommentaryData) {
    console.log('data', data);
    const humanPrompt =
      'The  chicken {chicken_name} is starting to deploy {talent_name} talent now.\n\
    Please comment this status with 1 sentence each.\
    ';
    const startPrompt = ChatPromptTemplate.fromMessages([
      ['system', this.systemPrompt],
      ['human', humanPrompt],
    ]);

    const chain = new LLMChain({
      llm: this.chatOpenAI,
      prompt: startPrompt,
    });
    const result = await chain.call({
      chicken_name: data.chickens[0].chickenName,
      talent_name: data.talent,
    });

    //Get prompt length
    const promptStr = await startPrompt.formatMessages({
      chicken_name: data.chickens[0].chickenName,
      talent_name: data.talent,
    });
    const tokens = promptStr[1].content.length;
    this.totalInputToken += tokens;

    console.log('startTalentCommentary:', result.text);
    console.log('tokens:', tokens);
    return result;
  }
  //Generate talent finish commentary
  private async generateTFCommentary(data: CommentaryData) {
    console.log('data', data);
    try {
      let humanPrompt = '';
      //when the chicken has their talent
      let talentTypeExp; // explanation of the talent
      humanPrompt =
        'These are list of chickens: {chickens} \n\
          These are the current status: \n\
          Chicken race is in progress and {elapsed} seconds elapsed from the start. \n\
          Just before chickens {talentTypeExp} {talent} and position is changed from {startPosition} to {endPosition} in the last {duration} seconds.\n\
          Please comment  this status with less than 3 sentences in total';

      if (data.type === TalentType.deploying) {// chicken is deploying
        talentTypeExp = 'deployed the';
      } else {
        if (data.chickens.length == 1) // one chicken is affected
        {
          talentTypeExp = 'is hit by the';
        } else {// more than two are affected, in this case we cant mention about position change
          humanPrompt = 'These are list of chickens: {chickens} \n\
          These are the current status: \n\
          Chicken race is in progress and {elapsed} seconds elapsed from the start.\n\
          Just before chickens are hit by the {talent} and its speed is slowed down in the last {duration} seconds.\n\
          Please comment  this status with less than 3 sentences in total.';
        }
      }
      const commentaryPrompt = ChatPromptTemplate.fromMessages([
        ['system', this.systemPrompt],
        ['human', humanPrompt],
      ]);

      const chain = new LLMChain({
        llm: this.chatOpenAI,
        prompt: commentaryPrompt,
      });
      const params = {
        ...data,
        duration: Math.round(data.duration),
        chickens: JSON.stringify(data.chickens),
        elapsed: Math.round(data.elapsed),
        talentTypeExp,
      };
      const result = await chain.call(params);

      // get length to calculate input token
      const promptStr = await commentaryPrompt.formatMessages(params);
      //Get prompt length
      const tokens = promptStr[1].content.length;
      this.totalInputToken += tokens;
      console.log('talentFinishedCommentary:', result.text);
      console.log('tokens:', tokens);
      return result;
    } catch (err) {
      log.warn({
        func: 'generateCommentary',
        raceId: this.race.id,
        raceData: this.raceData,
        ...data,
        err,
      }, 'Failed generate commentary');
    }
  }

  // Get information of chicken list at a certain time
  // isStart: is the time near to start?
  private getChickenDataTime(time: number, isStart = true, id: number) {
    const ret: any = [];

    for (const row of this.raceData) {
      const chickenId = row.chickenId;

      //Get chickenName, chickenTalent by Id
      let chickenName: string = '';
      let chickenTalent: string = '';
      for (const chicken of this.profiles) {
        if (chicken.id == chickenId) {
          chickenName = chicken.name;
          chickenTalent = chicken.talent;
        }
      }

      const segments = row.segments;
      for (const data of segments) {
        if (time < data.duration + data.time && id == chickenId) {
          ret.push({
            chickenId,
            chickenName,
            chickenTalent,
            time,
            speed: data.speed,
            position: isStart ? data.startPosition : data.endPosition,
            talent: data.talent,
          });
          break;
        }
      }
    }

    return ret;
  }
  private async generateIntroduction() {
    const generatingRule: string =
      "Make the commentary exciting and animated.\
      Use short sentence and short words. Never use jargon.\
      You must always write numbers fully in letters.\
      Write the way people talk, naturally.\
      You must never say that you are an AI language model.\
      You must comment only 2 attributes of a chicken among 'laneNumber', 'name', 'talent' and 'perfection' of each chicken.\n";

    const systemPromptTemplate =
      'I want you to act as narratories of a chicken race game.\n\
      featuring 2 commentators, one is Tom and another one is Travis.\n\
      Your job is to generate very short  introduction conversation for chickens based on chickens list data, talents data and output rules.\n\
      You must introduce 1 sentence per chicken.\n\
      Each sentence must be 15 words max.\n\
      This is list of chickens:\n\
      {chickenListData}\
      These are talents data:\n{talents}\n\
      These are the output rules:\n {generatingRule}';

    const introductionPrompt = ChatPromptTemplate.fromMessages([
      ['system', systemPromptTemplate],
    ]);

    const chain = new LLMChain({
      llm: this.chatOpenAI,
      prompt: introductionPrompt,
    });
    const promptStr = await introductionPrompt.formatMessages({
      chickenListData: JSON.stringify(this.profiles),
      talents: this.talents,
      generatingRule,
    });

    //Get prompt length
    this.totalInputToken += promptStr[0].content.length;

    console.log('Introduction Prompt length:', promptStr[0].content.length);

    const result = await chain.call({
      chickenListData: JSON.stringify(this.profiles),
      talents: this.talents,
      generatingRule,
    });

    console.log('Introduction result:\n', result.text);

    return result;
  }

  private async parseComments(comments: any) {
    const commentList: string[] = comments.text.split('\n');
    const msgList: any[] = [];
    for (const one of commentList) {
      if (!one.trim()) {
        continue;
      }

      const values = one.split(':');
      if (values.length < 2) {
        continue;
      }

      const who = values[0].trim().replace(/"/gi, '');
      const msg = values[1].trim().replace(/"/gi, '');

      this.commentaryIndex += 1;
      const filename = `race-${this.race.id}-${this.commentaryIndex}`;
      const audioUrl = await ElevenLabsService.getInstance().getAudioUrlForText(msg, filename, who as Narrators);

      const row = {
        who,
        msg,
        audioUrl,
      };
      msgList.push(row);
    }
    return msgList;
  }

  public async generateRaceCommentaries() {
    try {
      await this.commentaryInit();
      const raceCommentaries: any = [];
      // add start comment
      const startResult = await this.generateRSCommentary();
      raceCommentaries.push({
        time: { elapsed: 0 },
        msgList: await this.parseComments(startResult),
      });
      // add talent finish comment
      let count = 0;
      for (const data of this.times) {
        let commentary:any;
        if (data.status == CommentaryStatus.finished) // talent finished
          commentary = await this.generateTFCommentary(data);
        else // talent start
          commentary = await this.generateTSCommentary(data);

        if (!commentary) {
          continue;
        }

        const msgList = await this.parseComments(commentary);
        if (!msgList?.length) {
          continue;
        }

        raceCommentaries.push({
          time: { elapsed: data.elapsed },
          msgList,
        });
        count += 1;
      }

      // add winner comment
      const winnerResult = await this.generateWinnerCommentary();
      if (winnerResult) {
        const msgList = await this.parseComments(winnerResult);
        if (msgList.length > 0) {
          raceCommentaries.push({
            time: { elapsed: this.totalDuration },
            msgList,
          });
        }
      }
      // some extra info
      console.log('Total', count + 2, 'comments');
      return { raceCommentaries };
    } catch (err) {
      log.warn({
        func: 'generateRaceCommentaries',
        raceId: this.race.id,
        raceData: this.raceData,
        times: this.times,
        err,
      }, 'Failed generate race commentaries');

      return null;
    }
  }
}
