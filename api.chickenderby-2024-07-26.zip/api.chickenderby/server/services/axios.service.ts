import axios, { AxiosInstance, AxiosRequestConfig, CreateAxiosDefaults } from 'axios';

export class AxiosService {
  constructor(
    private readonly axiosInstance: AxiosInstance,
    private readonly authHeader: Record<string, string> = {},
  ) {
    this.axiosInstance.interceptors.response.use((response) => response, (err) => {
      const error = err.response;

      if (error?.status === 401) {
        // TODO: unauthorized handler
      }

      throw error;
    });
  }

  static getInstance(baseURL: string, authHeader: Record<string, string>) {
    const axiosConfig: CreateAxiosDefaults = {
      baseURL,
      headers: {
        common: {
          'Content-Type': 'application/json',
        },
      },
      timeout: 30000,
    };
    const axiosInstance = axios.create(axiosConfig);

    return new AxiosService(axiosInstance, authHeader);
  }

  private getHeaders(customConfig: AxiosRequestConfig = {}) {
    const { headers } = customConfig;

    return {
      ...customConfig,
      headers: {
        ...headers,
        ...(this.authHeader || {}),
      },
    };
  }

  async get<T>(endPoint: string, customConfig: AxiosRequestConfig = {}) {
    return this.axiosInstance.get<T>(endPoint, this.getHeaders(customConfig));
  }

  async post<T>(endPoint: string, data = {}, customConfig: AxiosRequestConfig = {}) {
    return this.axiosInstance.post<T>(endPoint, data, this.getHeaders(customConfig));
  }

  async patch<T>(endPoint: string, data = {}, customConfig: AxiosRequestConfig = {}) {
    return this.axiosInstance.patch<T>(endPoint, data, this.getHeaders(customConfig));
  }

  async put<T>(endPoint: string, data = {}, customConfig: AxiosRequestConfig = {}) {
    return this.axiosInstance.put<T>(endPoint, data, this.getHeaders(customConfig));
  }

  async delete<T>(endPoint: string, customConfig: AxiosRequestConfig = {}) {
    return this.axiosInstance.delete<T>(endPoint, this.getHeaders(customConfig));
  }
}
