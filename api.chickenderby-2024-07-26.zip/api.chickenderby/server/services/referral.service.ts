import Sequelize from 'sequelize';

import { Referral } from '../sequelize/models/Referral';
import { PreRegistration } from '../sequelize/models/PreRegistration';

export class ReferralService {
  private static instance: ReferralService;

  static getInstance() {
    if (!ReferralService.instance) {
      ReferralService.instance = new ReferralService();
    }

    return ReferralService.instance;
  }

  async createOne(referralCode: string, refereeId: string, transaction?: Sequelize.Transaction) {
    const referrer = referralCode && await PreRegistration.findOne({
      where: {
        name: referralCode,
      },
    });

    if (referrer?.id === refereeId) {
      throw new Error('You couldn\'t use your referral code for yourself');
    }

    if (referrer) {
      return Referral.create({
        referrerId: referrer.id,
        refereeId,
      }, { transaction });
    }
  }

  async getReferrerCount(userWalletId: string) {
    return Referral.count({
      where: {
        referrerId: userWalletId,
      },
    });
  }

  async getRefereeCount(userWalletId: string) {
    return Referral.count({
      where: {
        refereeId: userWalletId,
      },
    });
  }
}
