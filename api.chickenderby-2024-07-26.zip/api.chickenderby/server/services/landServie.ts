import Web3 from 'web3';
import NP from 'number-precision';
import { Job } from 'bull';

import { LandMint } from '../sequelize/models/LandMint';
import { Transaction } from '../sequelize/models/Transaction';
import { log } from '../utils';
import { mintLand, getLandMintPrice } from './contracts/landContractService';
import { waitUntilBiconomyReady, getSuccessfulTransactionHashAndReceipt } from './contracts/web3Service';

export const mint = async (job: Job) => {
  const txHashes: string[] = [];
  let transactionHash: string = null;
  let landMint;
  let totalPriceEther: string = '0';

  try {
    const { landMintId } = job.data;

    landMint = landMintId && await LandMint.findByPk(landMintId);

    if (!landMint) {
      throw new Error(`Cant get landMint for ${landMintId}`);
    }

    const {
      userWalletId, signature, status, data, amount,
    } = landMint;

    log.info({
      func: 'mintLand',
      landMintId,
      userWalletId,
      signature,
      data,
      status,
      amount,
    }, `Start Minting Land ${landMintId}`);

    if (status !== 'pending') {
      log.warn({
        func: 'mintLand',
        landMintId,
        userWalletId,
        signature,
        data,
        status,
        amount,
      }, `Already Minted Land ${landMintId}`);

      return;
    }

    await waitUntilBiconomyReady();

    const price = await getLandMintPrice();
    const totalPrice = NP.strip(NP.times(price, amount));
    totalPriceEther = Web3.utils.fromWei(Web3.utils.toBN(totalPrice), 'ether');

    let paidStatus = 'paid';

    await new Promise((resolve, reject) => {
      mintLand(landMintId, userWalletId, amount, signature, data, {
        onTx: (txHash) => {
          transactionHash = txHash;
          txHashes.push(transactionHash);

          log.info({
            func: 'mintLand',
            landMintId,
            userWalletId,
            signature,
            data,
            status,
            amount,
            transactionHash,
            txHashes,
          }, `Mint Land On txHash For ${landMintId}`);
        },
        onReceipt: async (receipt) => {
          log.info({
            func: 'mintLand',
            landMintId,
            userWalletId,
            signature,
            data,
            status,
            amount,
            receipt,
            transactionHash,
            txHashes,
          }, `Mint Land On receipt For ${landMintId}`);

          resolve(receipt);
          paidStatus = 'paid';
        },
        onError: async (err) => {
          // catch error and return undefined
          const successfulTransaction = await getSuccessfulTransactionHashAndReceipt(txHashes).catch((err2) => {
            log.error({
              func: 'mintLand',
              landMintId,
              userWalletId,
              signature,
              data,
              status,
              amount,
              transactionHash,
              txHashes,
              err: err2,
            }, `Mint Land getSuccessfulTransactionHashAndReceipt Error For ${landMintId}`);

            return null;
          });
          if (successfulTransaction?.txHash) {
            transactionHash = successfulTransaction.txHash;
          }

          log.error({
            func: 'enterRace',
            landMintId,
            userWalletId,
            signature,
            data,
            status,
            amount,
            transactionHash,
            txHashes,
            successfulTransaction,
            err,
          }, `Mint Land On Error For ${landMintId}`);

          let errorMsg = err.message;

          if (successfulTransaction) {
            // edge case: we are raising new transaction if the previous one is not mined within 1000 seconds
            // sometimes the previous transaction is mined while we are generating new one
            // so new one fails with the `Signer and signature do not match` error
            // in that case, we have to mark the transaction as completed because it's actually a successful transaction
            resolve(successfulTransaction?.receipt);
            paidStatus = 'paid';

            return;
          } if (errorMsg?.includes('Transaction was not mined within')) {
            paidStatus = 'postponed';
            resolve(null);

            return;
          }

          if (errorMsg?.includes('execution reverted: Signer and signature do not match')) {
            errorMsg += '\n This might be because your previous transaction was not minded yet. Please try again.';
          }

          paidStatus = 'error';
          reject(new Error(errorMsg));
        },
      });
    });

    await landMint.update({
      status: 'success',
      transactionHash,
      txHashes,
    });

    await Transaction.create({
      userWalletId,
      type: 'in',
      transactionHash,
      status: paidStatus,
      associatedObjectType: 'landMint',
      associatedObjectId: `${landMintId}`,
      amount: totalPriceEther,
      category: 'landMintFee',
    });

    await job.progress(100);

    log.info({
      func: 'mintLand',
      landMintId,
      userWalletId,
      signature,
      data,
      status,
      amount,
      transactionHash,
      txHashes,
    }, `Finish Mint Land ${landMintId}`);
  } catch (err: any) {
    if (landMint) {
      const errorMsg = err.message;

      await landMint.update({
        status: 'error',
        transactionHash,
        txHashes,
        error: {
          message: errorMsg,
        },
      });

      await Transaction.create({
        userWalletId: landMint.userWalletId,
        type: 'in',
        transactionHash,
        status: 'error',
        associatedObjectType: 'landMint',
        associatedObjectId: `${landMint.id}`,
        amount: totalPriceEther,
        category: 'landMintFee',
      });
    }

    log.error({
      func: 'mintLand',
      landMintId: job?.data?.landMintId,
      deadline: job?.data?.deadline,
      transactionHash,
      txHashes,
      err,
    }, 'mintLand Error');

    await job.log(`mintLand Error ${err}`);
  }
};
