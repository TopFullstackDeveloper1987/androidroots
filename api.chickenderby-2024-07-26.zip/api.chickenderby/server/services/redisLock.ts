import RedLock from 'redlock';
import { redisConnect } from './redisClient';
import { log } from '../utils';

let redLock: RedLock;

export const redisLock = async <T>(resource: string | string[], ttl: number, funcPromise: () => Promise<T>) => {
  if (!redLock) {
    const redisClient = redisConnect();

    redLock = new RedLock([redisClient], {
      // retry infinitely unless ttl is expired
      retryCount: -1,
    });
  }

  let lock: RedLock.Lock;

  try {
    lock = await redLock.lock(resource, ttl);
  } catch (err) {
    // don't propagate the error but just log
    log.warn({
      func: 'redisLock',
      resource,
      err,
    }, 'Error While Locking Resource');

    return funcPromise();
  }

  try {
    return await funcPromise();
  } finally {
    // always unlock even when the actual job fails so that other acquisition could succeed immediately
    try {
      if (lock) {
        await lock.unlock();
      }
    } catch (err) {
      // don't propagate the error but just log
      // when ttl is shorter than the lock validity time the resource is expired on redis beforehand
      // so unlocking the empty resource will throw an error
      // we don't have to propagate it because it doesn't harm anything
      // https://github.com/mike-marcacci/node-redlock/issues/65

      log.warn({
        func: 'redisLock',
        resource,
        err,
      }, 'Error While Unlocking Resource');
    }
  }
};
