import { RecaptchaEnterpriseServiceClient } from '@google-cloud/recaptcha-enterprise';
import config from '../config';

const client = new RecaptchaEnterpriseServiceClient();
const projectPath = client.projectPath(config.G_RECAPTCHA_PROJECT_ID);

export async function getRecaptcaScore(token: string) {
  const request = ({
    assessment: {
      event: {
        token,
        siteKey: config.G_RECAPTCHA_SITE_KEY,
      },
    },
    parent: projectPath,
  });

  const [response] = await client.createAssessment(request);

  return response;
}
