import DiscordOauth2 from 'discord-oauth2';
import { Client, GatewayIntentBits, REST, Routes } from 'discord.js';
import Sequelize from 'sequelize';
import { Job } from 'bull';

import config from '../config';
import { log } from '../utils';
import models from '../sequelize/models';

import { DiscordRole } from '../sequelize/models/DiscordRole';
import { DiscordUserRole } from '../sequelize/models/DiscordUserRole';
import { UserWallet } from '../sequelize/models/UserWallet';
import { AssignmentStatus } from '../types/assignments/assignmentStatus';

const { Op } = Sequelize;
const discordRest = new REST({ version: '10' }).setToken(config.DISCORD.BOT_TOKEN);

const oauth = new DiscordOauth2({
  clientId: config.DISCORD.CLIENT_ID,
  clientSecret: config.DISCORD.SECRET,
  redirectUri: `${config.frontendUrl}/chickens/`,
});

const discordClient = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
  ],
});
let discordClientLoginStatus: AssignmentStatus = AssignmentStatus.Draft;

export const retrieveDiscordToken = async (code: string) => {
  try {
    const res = await oauth.tokenRequest({
      code,
      scope: ['identify', 'email'],
      grantType: 'authorization_code',
    });

    return res.access_token;
  } catch (err) {
    log.error({
      func: 'retrieveDiscordToken',
      code,
      err,
    }, 'Retrieve Discord Token Error');

    throw err;
  }
};

export const getDiscordMe = async (accessToken: string) => {
  try {
    const res = await oauth.getUser(accessToken);

    return res;
  } catch (err) {
    log.error({
      func: 'getDiscordMe',
      err,
    }, 'Get Discord Error');

    throw err;
  }
};

const getDiscordUser = async (userId: string): Promise<any> => {
  try {
    const res = await discordRest.get(Routes.guildMember(config.DISCORD.GUILD_ID, userId));

    return res;
  } catch (err) {
    log.error({
      func: 'getDiscordUser',
      err,
      userId,
    }, 'Get Discord User Error');

    return null;
  }
};

const getDiscordRoles = async (): Promise<any[]> => {
  try {
    const res = await discordRest.get(Routes.guildRoles(config.DISCORD.GUILD_ID));

    return res as any[];
  } catch (err) {
    log.error({
      func: 'getDiscordRoles',
      err,
    }, 'Get Discord Roles Error');

    throw err;
  }
};

const syncDiscordRoles = async (t: Sequelize.Transaction) => {
  try {
    const roles = await getDiscordRoles();

    for (const role of roles) {
      const discordRole = await DiscordRole.findByPk(role.id, { transaction: t });

      if (discordRole) {
        await discordRole.update({
          name: role.name,
          position: role.position,
          color: role.color,
        }, { transaction: t });
      } else {
        await DiscordRole.create({
          id: role.id,
          name: role.name,
          position: role.position,
          color: role.color,
        }, { transaction: t });
      }
    }

    // delete removed roles
    await DiscordRole.destroy({
      where: {
        id: { [Op.notIn]: roles.map((role) => role.id) },
      },
      transaction: t,
    });
  } catch (err) {
    log.error({
      func: 'syncDiscordRoles',
      err,
    }, 'Sync Discord Roles Error');

    throw err;
  }
};

const syncDiscordUserRoles = async (userWallet: UserWallet, t: Sequelize.Transaction) => {
  const { discordId, id: userWalletId } = userWallet;

  if (!discordId) {
    return;
  }

  try {
    const discordMember = await getDiscordUser(userWallet.discordId);

    if (!discordMember) {
      return;
    }

    for (const roleId of discordMember.roles) {
      const discordUserRole = await DiscordUserRole.findOne({
        where: {
          userWalletId,
          discordRoleId: roleId,
        },
        transaction: t,
      });

      if (discordUserRole) {
        continue;
      }

      await DiscordUserRole.create({
        userWalletId,
        discordRoleId: roleId,
      }, { transaction: t });
    }

    // delete removed user roles
    await DiscordUserRole.destroy({
      where: {
        userWalletId,
        discordRoleId: { [Op.notIn]: discordMember.roles },
      },
      transaction: t,
    });
  } catch (err) {
    log.error({
      func: 'syncDiscordUserRoles',
      err,
      userWalletId,
      userWalletDiscordId: userWallet.discordId,
    }, 'Sync Discord User Roles Error');

    throw err;
  }
};

export const syncUserWalletDiscordUserRoles = async (userWallet: UserWallet) => {
  try {
    await models.sequelize.transaction(async (t) => {
      await syncDiscordRoles(t);

      await syncDiscordUserRoles(userWallet, t);
    });
  } catch (err) {
    log.error({
      func: 'syncUserWalletDiscordUserRoles',
      userWalletId: userWallet.id,
      userWalletDiscordId: userWallet.discordId,
      err,
    }, 'Sync User Wallet Discord User Roles Error');

    throw err;
  }
};

export const snycAllUserWallletDiscordUserRoles = async (job: Job) => {
  const limit = 1000;
  let offset = 0;
  try {
    await job.progress(0);

    const total = await UserWallet.count({
      where: {
        discordId: { [Op.not]: null },
      },
    });

    await models.sequelize.transaction(async (t) => {
      await syncDiscordRoles(t);

      while (true) {
        const userWallets = await UserWallet.findAll({
          where: {
            discordId: { [Op.not]: null },
          },
          limit,
          offset,
          order: [['createdAt', 'ASC']],
          transaction: t,
        });

        for (const userWallet of userWallets) {
          await syncDiscordUserRoles(userWallet, t);
          offset += 1;

          await job.progress((offset / total * 100).toFixed(2));
        }

        if (userWallets.length < limit) {
          break;
        }
      }
    });

    await job.progress(100);
  } catch (err) {
    log.error({
      func: 'snycAllUserWallletDiscordUserRoles',
      err,
    }, 'Sync All User Wallets Discord User Roles Error');

    await job.log(`snycAllUserWallletDiscordUserRoles Error ${err}`);
  }
};

const loginClient = async () => {
  try {
    discordClientLoginStatus = AssignmentStatus.Pending;

    await discordClient.login(config.DISCORD.BOT_TOKEN);

    discordClientLoginStatus = AssignmentStatus.Success;
  } catch (err) {
    discordClientLoginStatus = AssignmentStatus.Error;

    log.error({
      func: '/discordService/loginClient',
      err,
    }, 'Discord Login Client Error');
  }
};

const clientCall = async<T> (func: () => Promise<T>) => {
  if (discordClientLoginStatus === AssignmentStatus.Draft) {
    await loginClient();
  }

  return func();
};

export const getNumberOfOnlineMembers = async (): Promise<any> => {
  try {
    const count = await clientCall(async () => {
      const guild = discordClient.guilds.resolve(config.DISCORD.GUILD_ID);
      // TODO: iterate until getting all the members
      const members = await guild.members.fetch({
        limit: 1000,
        force: true,
      });

      return members.filter((member) => member.presence?.status && member.presence?.status !== 'offline').size;
    });

    return count;
  } catch (err) {
    log.error({
      func: 'getNumberOfOnlineMembers',
      err,
    }, 'Get Number Of Online Members Error');

    throw err;
  }
};
