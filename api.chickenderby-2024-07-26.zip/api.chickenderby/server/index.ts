import express from 'express';
import * as bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import 'dotenv/config';

import models from './sequelize/models';
const { sequelize } = models;

import config from './config';
import { corsHandler, log } from './utils';

import { updateGitInfo } from './gitInfo';
import { waitUntilBiconomyReady } from './services/contracts/web3Service';
import { initRoutes } from './routes';
import { checkForMigrations } from './sequelize/helpers/migrations';

const app = express();

// middlewares
app.use(bodyParser.json());
app.use(cookieParser());
app.use(corsHandler);

// routes
initRoutes(app);

// Run server
const port = config.PORT;
app.listen(port, async () => {
  updateGitInfo(config.SERVER_GIT_JSON);

  log.info(`App is listing to ${port} on ${new Date()}`);

  sequelize.authenticate().then(async () => {
    const migrations = await checkForMigrations();
    if (migrations.length) {
      // eslint-disable-next-line no-console
      console.error(
        'Pending migrations need to be run:\n',
        migrations.map((migration) => migration.name).join('\n '),
        '\nUse this command to run migrations:\n "yarn sequelize db:migrate"',
      );

      process.exit(1);
    }

    log.info('Database connection has been established successfully.');
  }).catch((err) => {
    log.error({
      err,
    }, 'Unable to connect to the database');
  });

  log.info('Sequelize Database Connected');

  await waitUntilBiconomyReady().catch((err) => log.error(err));
});

// Listen to unhandled rejection events
// eslint-disable-next-line no-unused-vars
process.on('unhandledRejection', (reason: any, promise) => {
  log.error('Unhandled Promise Rejection at:', reason.stack || reason);
});

process.on('uncaughtException', (err) => {
  const ctorName = err ? Object.getPrototypeOf(err).constructor.name : 'none';

  log.error(
    `Caught exception: ${err}\n\nstack:\n${err.stack || 'no stack'}\n\ntypeof err:${typeof err}\nconstructor name:${ctorName}`,
  );

  if (ctorName === 'RestException') {
    // https://github.com/twilio/twilio-node/issues/284
    // we have a work around in the main Dockerfile for Twilio
    // verify it's workking, else you might a RestException here
    log.error('RestException might indicate that the work around for Twilio is not installed correctly.');
  }

  // Rethrowing the err for the process monitor to restart the service.
  // This cleans up allocated resources and resets the application's state.
  // See "Warning: Using uncaughtException correctly" for more info:
  // https://nodejs.org/api/process.html#process_event_uncaughtexception
  throw err;
});
