/* eslint-disable max-len */
// https://docs.google.com/spreadsheets/d/1osYq8YcXh3gIgXxJ676w2wduNJfp1hOViZTSqrkRBT0/edit#gid=1605728109

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    const tourneyOneNFTs = [{
      id: 1,
      name: 'Viking Helm',
      type: 'Head',
      clothingSet: '10k Tournament',
      image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Ftournyones%2FWITHDRAWN_6.png?alt=media&token=4c65b4b0-5a23-48b6-8d52-0b0b45517582',
      clothingId: 'HatVikingHelm',
    }, {
      id: 2,
      name: 'Sergeant Uniform',
      type: 'Body',
      clothingSet: '10k Tournament',
      image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Ftournyones%2FWITHDRAWN_5.png?alt=media&token=0e0a5653-36f0-419e-a25b-479ef08a543f',
      clothingId: 'BodySergeant',
    }, {
      id: 3,
      name: 'Fancy Monocle',
      type: 'Eyes',
      clothingSet: '10k Tournament',
      image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Ftournyones%2FWITHDRAWN_3.png?alt=media&token=b25f7b63-cbcd-483c-bf7b-98f83a4a85e0',
      clothingId: 'GlassesFancy',
    }, {
      id: 4,
      name: 'Fancy Top Hat',
      type: 'Head',
      clothingSet: '10k Tournament',
      image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Ftournyones%2FWITHDRAWN_2.png?alt=media&token=57c46f3b-f357-4121-9f44-b604e4feb74e',
      clothingId: 'HatFancy',
    }, {
      id: 5,
      name: 'Brown Boots',
      type: 'Feet',
      clothingSet: '10k Tournament',
      image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Ftournyones%2FWITHDRAWN_1.png?alt=media&token=9307dc69-5ed0-4106-9712-aee2d1c5cabc',
      clothingId: 'ShoeBrownBoots',
    }, {
      id: 6,
      name: 'Pearl Necklace',
      type: 'Neck',
      clothingSet: '10k Tournament',
      image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Ftournyones%2FWITHDRAWN_4.png?alt=media&token=f0843904-de71-4527-8cab-84b1b3012eb5',
      clothingId: 'NeckPearlNecklace',
    }];

    await queryInterface.bulkInsert('tourneyOnes', tourneyOneNFTs);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('tourneyOnes');
  },
};
