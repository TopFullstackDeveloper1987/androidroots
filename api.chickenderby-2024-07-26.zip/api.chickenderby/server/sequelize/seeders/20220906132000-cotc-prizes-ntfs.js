/* eslint-disable max-len */
// https://docs.google.com/spreadsheets/d/1osYq8YcXh3gIgXxJ676w2wduNJfp1hOViZTSqrkRBT0/edit#gid=1187515433

const clothingsCotCPrizes = [{
  id: 55,
  name: 'Creamed Corn Hat',
  type: 'Head',
  clothingSet: 'Cream of the Crop',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Fcotc%2FClothing_Head_CreamedCorn.png?alt=media&token=21d53be9-25ed-49c6-9710-988b453b791b',
  clothingId: 'HatCreamedCorn',
}];

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('clothings', clothingsCotCPrizes);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    const clothingIds = clothingsCotCPrizes.map((clothing) => clothing.id);
    await queryInterface.bulkDelete('clothings', {
      id: clothingIds,
    });
  },
};
