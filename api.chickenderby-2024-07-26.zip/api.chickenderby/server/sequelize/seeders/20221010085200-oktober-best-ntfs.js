/* eslint-disable max-len */
// https://docs.google.com/spreadsheets/d/1osYq8YcXh3gIgXxJ676w2wduNJfp1hOViZTSqrkRBT0/edit#gid=993224549

const streakingChickensCPrizes = [{
  id: 60,
  name: 'Dirndl Bonnet',
  type: 'Head',
  clothingSet: 'Oktoberbest',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Foktoberbest%2FClothing_Head_DirndlBonnet.png?alt=media&token=1c72948c-a5e9-4b31-8db0-71f59604e1eb',
  clothingId: 'HeadDirndlBonnet',
}, {
  id: 61,
  name: 'Dirndl Dress',
  type: 'Body',
  clothingSet: 'Oktoberbest',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Foktoberbest%2FClothing_Body_DirndlDress.png?alt=media&token=e59570b6-ed7d-4162-b2d1-9c819050176c',
  clothingId: 'BodyDirndlDress',
}, {
  id: 62,
  name: 'Dirndl Shoes',
  type: 'Feet',
  clothingSet: 'Oktoberbest',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Foktoberbest%2FClothing_Feet_DirndlShoes.png?alt=media&token=015da73c-929a-4094-854d-f7186cf733b8',
  clothingId: 'FeetDirndlShoes',
}, {
  id: 63,
  name: 'Lederhosen Hat',
  type: 'Head',
  clothingSet: 'Oktoberbest',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Foktoberbest%2FClothing_Head_LederhoseHat.png?alt=media&token=bcf4000d-269a-4655-bcaa-b7a5f9f6f8ce',
  clothingId: 'HeadLederhosenHat',
}, {
  id: 64,
  name: 'Lederhosen Suit',
  type: 'Body',
  clothingSet: 'Oktoberbest',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Foktoberbest%2FClothing_Body_LederhoseSuit.png?alt=media&token=ea9c296c-f11e-4614-b402-14205f74b693',
  clothingId: 'BodyLederhosenSuit',
}, {
  id: 65,
  name: 'Lederhosen Boots',
  type: 'Feet',
  clothingSet: 'Oktoberbest',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Foktoberbest%2FClothing_Feet_LederhoseShoes.png?alt=media&token=04dd2b7f-27ae-469d-b028-3794478a217c',
  clothingId: 'FeetLederhosenBoots',
}];

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('clothings', streakingChickensCPrizes);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    const clothingIds = streakingChickensCPrizes.map((clothing) => clothing.id);
    await queryInterface.bulkDelete('clothings', {
      id: clothingIds,
    });
  },
};
