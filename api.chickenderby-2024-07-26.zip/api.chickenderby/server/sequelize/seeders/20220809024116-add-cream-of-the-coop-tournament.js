const moment = require('moment-timezone');

const tournamentName = 'Cream Of The Crop';

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    const isProduction = process.env.NODE_ENV === 'production';
    const startAt = moment.utc(isProduction ? '2022-08-13' : '2022-08-09').startOf('day');
    const endAt = moment.utc(isProduction ? '2022-09-02' : '2022-08-22').endOf('day');

    const description = `In the Cream Of The Crop tournament we are determining
    which chickens are the best chickens in each Heritage & Perfection.\n
From ${startAt.format('HH:mm UTC dddd Do MMMM')} to ${endAt.format('HH:mm UTC dddd Do MMMM')},
each time your chicken beats another chicken of either the same Heritage or Perfection in a paid entry race,
it shall score 1 point. If your chicken beats a chicken of the same Heritage & Perfection, it scores 2 points.\n
At the end of the tournament, the chicken with the most points in
each Heritage & Perfection group (44 in total) shall win a prize for their owner.\n
Only the first 60 paid races per chicken during the tournament are counted.\n
There are no tie breakers. If multiple chickens tie for top, they all qualify for the prize draw.\n
For the list of prizes see our <a href="https://t.co/JD37fJ9LqK" target="_blank">discord</a>`;
    await queryInterface.bulkInsert('tournaments', [{
      name: tournamentName,
      discordUrl: 'http://discord.gg/chicken-derby',
      startAt: startAt.toDate(),
      endAt: endAt.toDate(),
      maxRaces: 60,
      groups: JSON.stringify(['heritage', 'perfection']),
      rules: JSON.stringify({
        points: {
          beats: ['heritage', 'perfection'],
        },
      }),
      description,
      url: 'cream-of-the-crop',
    }]);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('tournaments', { name: tournamentName });
  },
};
