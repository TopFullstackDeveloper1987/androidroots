module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    const isProduction = process.env.NODE_ENV === 'production';
    if (!isProduction) {
      return;
    }

    const terrainIds = {
      Dirt: 1,
      Grass: 2,
      Road: 3,
      Rock: 4,
      Sand: 5,
      Snow: 6,
      Track: 7,
    };

    const mapRaces = (raceData) => {
      const {
        terrain, type, peckingOrder, unlimitPO, ...other
      } = raceData;

      return {
        ...other,
        peckingOrder: peckingOrder.toUpperCase(),
        terrainId: terrainIds[terrain] || terrainIds.Dirt,
        type: type.toLowerCase(),
        unlimitPO: unlimitPO === 'Yes' ? 1 : 0,
      };
    };

    // eslint-disable-next-line global-require
    const basePools = require('../baseData/autoRacePoolProduction.json');
    const autoRacePools = basePools.map(mapRaces);

    // truncate the original pool
    await queryInterface.bulkDelete('autoRacePools');
    await queryInterface.bulkInsert('autoRacePools', autoRacePools);
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    const isProduction = process.env.NODE_ENV === 'production';
    if (!isProduction) {
      return;
    }

    await queryInterface.bulkDelete('autoRacePools');
  },
};
