const moment = require('moment-timezone');

const tournamentName = 'Augustus Augur';

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    const isProduction = process.env.NODE_ENV === 'production';
    const startAt = moment.utc(isProduction ? '2022-08-03' : '2022-08-01').startOf('day');
    const endAt = moment.utc(isProduction ? '2022-08-09' : '2022-08-07').endOf('day');

    const description = `It’s the month of August, named after the Roman emperor Ceaser Augustus.
He reigned for 41 years from 27BC to 14AD, so to honour the month we are giving away some emperor themed chicken clothing.\n
For each chicken that you run at least 41 times in paid entry races during the event
(from UTC ${startAt.format('HH:mm Do MMMM')} to UTC ${endAt.format('HH:mm Do MMMM')}),
you shall win an item of clothing for your chickens.\n
Additionally, each player that runs a chicken at least 41 times during the event will be entered into a draw for a
chance to win this <a href="https://www.chickenderby.com/chicken-detail/20020" target="_blank">chicken</a>.\n
You can track each of your chicken’s progress in the table below.`;

    await queryInterface.bulkInsert('tournaments', [{
      name: tournamentName,
      discordUrl: 'http://discord.gg/chicken-derby',
      startAt: startAt.toDate(),
      endAt: endAt.toDate(),
      maxRaces: 41,
      peckingOrders: null,
      rules: JSON.stringify({}),
      description,
      url: 'augustus-augur',
    }]);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('tournaments', { name: tournamentName });
  },
};
