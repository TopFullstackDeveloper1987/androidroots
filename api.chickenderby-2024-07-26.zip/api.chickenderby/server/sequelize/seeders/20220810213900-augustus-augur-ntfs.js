/* eslint-disable max-len */
// https://docs.google.com/spreadsheets/d/1osYq8YcXh3gIgXxJ676w2wduNJfp1hOViZTSqrkRBT0/edit#gid=1187515433

const clothingsAugustusAugur = [{
  id: 40,
  name: 'Regal Laurel',
  numberOfOwners: 25,
  type: 'Head',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_RegalLaurel.png?alt=media&token=d7ac2b85-807b-4a9c-82db-12323a5ad070',
  clothingId: 'HatRegalLaurel',
}, {
  id: 41,
  name: 'Legionaire Laurel',
  numberOfOwners: 65,
  type: 'Head',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_LegionaireLaurel.png?alt=media&token=07805b75-6ee6-453f-a57b-b2145ebd0317',
  clothingId: 'HatLegionaireLaurel',
}, {
  id: 42,
  name: 'Centurion Laurel',
  numberOfOwners: 65,
  type: 'Head',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_CenturionLaurel.png?alt=media&token=5e25df1d-2b82-41e2-8f3e-920de4af890e',
  clothingId: 'HatCenturionLaurel',
}, {
  id: 43,
  name: 'Velites Laurel',
  numberOfOwners: 65,
  type: 'Head',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_VelitesLaurel.png?alt=media&token=88af8245-8674-45b4-91ab-43e1f88ef388',
  clothingId: 'HatVelitesLaurel',
}, {
  id: 44,
  name: 'Tellus Mater Toga',
  numberOfOwners: 10,
  type: 'Body',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_TellusMaterToga.png?alt=media&token=07f70c39-ce72-4cb9-92a7-7f51a9011d53',
  clothingId: 'BodyTellusMaterToga',
}, {
  id: 45,
  name: 'Regal Toga',
  numberOfOwners: 25,
  type: 'Body',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_RegalToga.png?alt=media&token=db5b20e8-1bdb-43d2-800d-52b8236b5cb4',
  clothingId: 'BodyRegalToga',
}, {
  id: 46,
  name: 'Legionaire Toga',
  numberOfOwners: 65,
  type: 'Body',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_LegionaireToga.png?alt=media&token=ff1dce9a-b8e7-490d-a1be-f7470451901a',
  clothingId: 'BodyLegionaireToga',
}, {
  id: 47,
  name: 'Centurion Toga',
  numberOfOwners: 65,
  type: 'Body',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_CenturionToga.png?alt=media&token=c9fc0278-20b1-42cb-95ee-584ba815c7c3',
  clothingId: 'BodyCenturionToga',
}, {
  id: 48,
  name: 'Velites Toga',
  numberOfOwners: 65,
  type: 'Body',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_VelitesToga.png?alt=media&token=9cde09b7-7977-4bcc-b7cc-e3b439fa661d',
  clothingId: 'BodyVelitesToga',
}, {
  id: 49,
  name: 'Tellus Mater Sandals',
  numberOfOwners: 10,
  type: 'Feet',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_TellusMaterSandals.png?alt=media&token=959f802a-8ed2-49e9-a446-90753fbafe6f',
  clothingId: 'FeetTellusMaterSandals',
}, {
  id: 50,
  name: 'Regal Sandals',
  numberOfOwners: 25,
  type: 'Feet',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_RegalSandals.png?alt=media&token=8dbe8d77-6462-4b7c-816a-e0426bd8e338',
  clothingId: 'FeetRegalSandals',
}, {
  id: 51,
  name: 'Legionaire Sandals',
  numberOfOwners: 65,
  type: 'Feet',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_LegionaireSandals.png?alt=media&token=9b4cb488-74d4-4a97-bdc0-e1433dde51d7',
  clothingId: 'FeetLegionaireSandals',
}, {
  id: 52,
  name: 'Centurion Sandals',
  numberOfOwners: 65,
  type: 'Feet',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_CenturionSandals.png?alt=media&token=8ec39383-4860-496c-b7dd-ce142687c0af',
  clothingId: 'FeetCenturionSandals',
}, {
  id: 53,
  name: 'Velites Sandals',
  numberOfOwners: 65,
  type: 'Feet',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_VelitesSandals.png?alt=media&token=e4f443c7-22cd-4776-87c7-189f7b23e909',
  clothingId: 'FeetVelitesSandals',
}, {
  id: 54,
  name: 'Tellus Mater Laurel',
  numberOfOwners: 10,
  type: 'Head',
  clothingSet: 'Augustus Augur',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Faugustus-augur%2FClothing_Head_TellusMaterLaurel.png?alt=media&token=6fbc9d0f-3e0f-47c6-9ba7-28dc4407ac97',
  clothingId: 'HatTellusMaterLaurel',
}];

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('clothings', clothingsAugustusAugur);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    const clothingIds = clothingsAugustusAugur.map((clothing) => clothing.id);
    await queryInterface.bulkDelete('clothings', {
      id: clothingIds,
    });
  },
};
