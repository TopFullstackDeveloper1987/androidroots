/* eslint-disable max-len */
// https://docs.google.com/spreadsheets/d/1osYq8YcXh3gIgXxJ676w2wduNJfp1hOViZTSqrkRBT0/edit#gid=1187515433

const streakingChickensCPrizes = [{
  id: 56,
  name: 'Streaky Bacon Tie',
  type: 'Neck',
  clothingSet: 'Streaking Chickens 1',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2Fstreakybacon.png?alt=media&token=b1756800-e548-430f-afa4-92a42a750d9d',
  clothingId: 'NeckStreakyBaconTie',
}, {
  id: 57,
  name: 'Pirate Bicorn',
  type: 'Head',
  clothingSet: 'Giveaway',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Fstreaking-chickens%2FClothing_Head_PirateHat.png?alt=media&token=b4f1bc20-b0f4-44cb-bc46-56e8387b6349',
  clothingId: 'HatPirate',
}, {
  id: 58,
  name: 'Geek Specs',
  type: 'Eyes',
  clothingSet: 'Giveaway',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Fstreaking-chickens%2FClothing_Eyes_GeekGlasses.png?alt=media&token=1181ac99-22a4-48dd-804f-7a6d605b8c42',
  clothingId: 'GlassesGeek',
}, {
  id: 59,
  name: 'Gold Chain',
  type: 'Neck',
  clothingSet: 'Giveaway',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Fstreaking-chickens%2FClothing_Neck_GoldChain.png?alt=media&token=ee912abf-cecd-4067-bc77-eac7c6127f6a',
  clothingId: 'NeckGoldChain',
}];

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('clothings', streakingChickensCPrizes);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    const clothingIds = streakingChickensCPrizes.map((clothing) => clothing.id);
    await queryInterface.bulkDelete('clothings', {
      id: clothingIds,
    });
  },
};
