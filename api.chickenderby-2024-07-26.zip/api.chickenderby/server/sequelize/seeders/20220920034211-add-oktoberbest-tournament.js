/* eslint-disable max-len */
const moment = require('moment-timezone');

const tournamentName = 'Oktoberbest Tournament';

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    const isProduction = process.env.NODE_ENV === 'production';
    const startAt = moment.utc(isProduction ? '2022-09-24' : '2022-09-20').startOf('day');
    const endAt = moment.utc(isProduction ? '2022-10-07' : '2022-10-02').endOf('day');

    const description = `Guten tag meine liblingsmenschen! Von ${startAt.format('HH:mm')} UTC Samstag ${startAt.format('Do MMMM')} bis ${endAt.format('HH:mm')} UTC Freitag ${endAt.format('Do')} Oktober, es gibt der Oktoberbest Wettbewerb!\n
Or in English, from UTC ${startAt.format('HH:mm Do MMMM')} to UTC ${endAt.format('HH:mm Do MMMM')}, we are running the Oktoberbest Tournament! Each time your chicken runs in a paid entry race, it’ll earn points based on its finishing position.\n
<table>
<thead>
    <tr>
      <th><b>Pos</b></th>
      <th>1st</th>
      <th>2nd</th>
      <th>3rd</th>
      <th>4th</th>
      <th>5th</th>
      <th>6th</th>
      <th>7th</th>
      <th>8th</th>
      <th>9th</th>
      <th>10th</th>
      <th>11th</th>
      <th>12th</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><b>Pts</b></td>
      <td>25</td>
      <td>20</td>
      <td>15</td>
      <td>12</td>
      <td>10</td>
      <td>8</td>
      <td>6</td>
      <td>5</td>
      <td>4</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
There are 5 leagues (separated by Pecking Orders), and your chicken will earn points within the league for whichever Pecking Order the race was in. Only the first 30 races ran by a chicken in each league are counted.\n
The 10 chickens with the most points in each league come the end of the tournament, win!\n
<div style="text-align:left;width:fit-content;margin:auto"><b>1st</b> - Share of Tournament Fund, Land NFT, Limited Clothing NFT, CDW Statue NFT
<b>2nd</b> - Land NFT, Limited Clothing NFT, CDW Statue NFT
<b>3rd</b> - Limited Clothing NFT, CDW Statue NFT
<b>4th to 10th</b> - Limited Clothing NFT</div>
The Tournament Fund is made from 5% of all entry fees from every race that starts during the tournament. The share received varies depending on the league.\n
<table>
<thead>
    <tr>
      <th><b>Pecking Order</b></th>
      <th>S</th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><b>Share</b></td>
      <td>30%</td>
      <td>25%</td>
      <td>20%</td>
      <td>15%</td>
      <td>10%</td>
    </tr>
  </tbody>
</table>
In addition, each chicken that runs in at least 60 paid entry races during the tournament, shall win themselves a limited piece of Oktoberbest clothing.\n
<div style="display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:5px;">
<img src="https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2Foktoberbest_drindl.png?alt=media&token=548d2add-2af4-4a33-a087-76d1420d0957" width="200px" height="200px" />
<img src="https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2Foktoberbest_lederhose.png?alt=media&token=4c6dbfb5-48de-46f9-992b-cd62814fcd9a" width="200px" height="200px" />
</div>
So charge your glasses and your chickens, and lets see which chicken is the Oktoberbest. Viel Glück!
`;
    await queryInterface.bulkInsert('tournaments', [{
      name: tournamentName,
      discordUrl: 'http://discord.gg/chicken-derby',
      startAt: startAt.toDate(),
      endAt: endAt.toDate(),
      maxRaces: 30,
      groups: JSON.stringify(['peckingOrder']),
      rules: JSON.stringify({
        points: {
          positions: [25, 20, 15, 12, 10, 8, 6, 5, 4, 3, 2, 1],
        },
      }),
      description,
      url: 'oktoberbest',
    }]);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('tournaments', { name: tournamentName });
  },
};
