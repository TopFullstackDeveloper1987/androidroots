// Config
const config = require('../../config');

const freeRaceCounters = [{
  name: 'freeRaceCounterS',
  value: '0',
}, {
  name: 'freeRaceCounterA',
  value: '0',
}, {
  name: 'freeRaceCounterB',
  value: '0',
}, {
  name: 'freeRaceCounterC',
  value: '0',
}, {
  name: 'freeRaceCounterD',
  value: '0',
}, {
  name: 'freeRaceCounterLimit',
  value: config.DEFAULT_FREE_RACE_COUNTER_LIMIT,
}];

module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => queryInterface.bulkInsert('settings', freeRaceCounters),

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    const names = freeRaceCounters.map((counter) => counter.name);

    await queryInterface.bulkDelete('settings', {
      name: names,
    });
  },
};
