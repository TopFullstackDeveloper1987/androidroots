// https://docs.google.com/spreadsheets/d/1osYq8YcXh3gIgXxJ676w2wduNJfp1hOViZTSqrkRBT0/edit#gid=1605728109

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    const baseUrl = 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o';

    const tourneyOneNFTs = [{
      id: 1,
      name: 'Viking Helm',
      numberOfOwners: 5,
      type: 'Head',
      clothingSet: '10k Tournament',
      image: `${baseUrl}/clothings%2FClothing_Head_VikingHelm.png?alt=media&token=fb3bc7c9-f2f8-47a4-aa3c-8538254d523c`,
      clothingId: 'HatVikingHelm',
    }, {
      id: 2,
      name: 'Sergeant Uniform',
      numberOfOwners: 8,
      type: 'Body',
      clothingSet: '10k Tournament',
      image: `${baseUrl}/clothings%2FClothing_Body_SergeantUniform.png?alt=media&token=54fff995-a6d4-4fac-bb65-a1f92d52e0d7`,
      clothingId: 'BodySergeant',
    }, {
      id: 3,
      name: 'Fancy Monocle',
      numberOfOwners: 11,
      type: 'Eyes',
      clothingSet: '10k Tournament',
      image: `${baseUrl}/clothings%2FClothing_Eyes_FancyMonocle.png?alt=media&token=ff69204c-1a70-4e78-b8b2-9528a25e1607`,
      clothingId: 'GlassesFancy',
    }, {
      id: 4,
      name: 'Fancy Top Hat',
      numberOfOwners: 11,
      type: 'Head',
      clothingSet: '10k Tournament',
      image: `${baseUrl}/clothings%2FClothing_Head_FancyHat.png?alt=media&token=7a099f64-b6a3-456f-be27-ecfa779ed0cb`,
      clothingId: 'HatFancy',
    }, {
      id: 5,
      name: 'Brown Boots',
      numberOfOwners: 10,
      type: 'Feet',
      clothingSet: '10k Tournament',
      image: `${baseUrl}/clothings%2FClothing_Feet_BrownBoots.png?alt=media&token=a60a45dd-772d-436e-9c51-c7661ae6341d`,
      clothingId: 'ShoeBrownBoots',
    }, {
      id: 6,
      name: 'Pearl Necklace',
      numberOfOwners: 10,
      type: 'Neck',
      clothingSet: '10k Tournament',
      image: `${baseUrl}/clothings%2FClothing_Neck_PearlNecklace.png?alt=media&token=d19fc250-01d4-4f2f-bb58-3e3e7e33f9e4`,
      clothingId: 'NeckPearlNecklace',
    }];

    await queryInterface.bulkInsert('clothings', tourneyOneNFTs);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('clothings');
  },
};
