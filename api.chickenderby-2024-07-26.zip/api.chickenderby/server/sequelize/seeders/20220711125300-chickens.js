const csvToJson = require('convert-csv-to-json');
const path = require('path');
const fs = require('fs');
const _ = require('lodash');

module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    const isProduction = process.env.NODE_ENV === 'production';

    const fileName = isProduction ? 'crun-production.csv' : 'crun-staging.csv';
    const inputFilePath = path.resolve(__dirname, `../baseData/${fileName}`);
    if (!fs.existsSync(inputFilePath)) {
      throw new Error('Please get the csv file for chicken seeders');
    }

    const json = csvToJson.getJsonFromCsv(inputFilePath);
    // convert "" to null
    const chickens = JSON.parse(
      JSON.stringify(
        json.map((item) => _.omit(item, ['tokenName', 'createdAt', 'updatedAt'])),
        (key, value) => (value === '' ? null : value),
        2,
      ),
    );

    const limit = 1000;
    await queryInterface.sequelize.transaction(async (t) => {
      for (let i = 0; i < chickens.length; i += limit) {
        await queryInterface.bulkInsert('chickens', chickens.slice(i, i + limit), {
          transaction: t,
        });
      }
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('chickens');
  },
};
