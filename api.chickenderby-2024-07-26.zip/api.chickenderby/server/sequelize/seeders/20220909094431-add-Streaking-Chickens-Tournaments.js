/* eslint-disable max-len */
const moment = require('moment-timezone');

const tournamentName = 'Streaking Chickens';

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    const isProduction = process.env.NODE_ENV === 'production';
    const startAt = moment.utc(isProduction ? '2022-09-13' : '2022-09-09').startOf('day');
    const endAt = moment.utc(isProduction ? '2022-09-19' : '2022-09-15').endOf('day');

    const description = `Can your chicken hold on to a winning streak? In this challenge you want to get the best winning streak you can with your chickens in the Streaking Chickens tournament.\n
This week (UTC ${startAt.format('HH:mm Do MMMM')} to UTC ${endAt.format('HH:mm Do MMMM')}) each time your chicken finishes 1st through 8th in any paid entry race, they add 1 to their streak. Finish 9th through 12th in any paid entry race, and the streak is reset to 0.\n
After one week, prizes will be given based on the best streak that each chicken achieved throughout the event.\n
<div style="text-align:left;width:fit-content;margin:auto"><u>Best Streak prizes</u>
<b>Streak 4+</b> : Entry into a draw for Chicken and Land NFTs
<b>Streak 7+</b> : Common Clothing Item
<b>Streak 10+</b> : Streaky Bacon Tie NFT
<b>Streak 12+</b> : 50% of the Prize Fund (between all achievers)</div>
<i>Prize Fund = 5% of Entry Fees from all races that start during the tournament.</i>\n
But that isn’t all. After the tournament, each chicken with the highest active streak shall earn a Share of 50% of the Prize Fund between them.
Happy streaking everyone!\n
<img src="https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2Fstreakybacon.png?alt=media&token=b1756800-e548-430f-afa4-92a42a750d9d" width="200px" height="200px" />
`;

    await queryInterface.bulkInsert('tournaments', [{
      name: tournamentName,
      discordUrl: 'http://discord.gg/chicken-derby',
      startAt: startAt.toDate(),
      endAt: endAt.toDate(),
      maxRaces: null,
      groups: null,
      rules: JSON.stringify({
        points: {
          positions: [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
          isConsecutivePoints: true,
        },
      }),
      description,
      url: 'streaking-chickens',
    }]);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('tournaments', { name: tournamentName });
  },
};
