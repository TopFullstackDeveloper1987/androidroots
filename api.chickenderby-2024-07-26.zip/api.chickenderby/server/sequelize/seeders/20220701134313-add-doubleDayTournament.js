const moment = require('moment-timezone');

const tournamentName = 'Daily Double';
module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    const isProduction = process.env.NODE_ENV === 'production';

    const testRecord = {
      name: tournamentName,
      discordUrl: 'http://discord.gg/chicken-derby',
      startAt: moment.utc('2022-07-01').startOf('day').toDate(),
      endAt: moment.utc('2022-07-13').endOf('day').toDate(),
      maxRaces: 30,
      peckingOrders: JSON.stringify(['S', 'A', 'B', 'C', 'D']),
      rules: JSON.stringify({
        points: {
          positions: [25, 20, 15, 12, 10, 8, 6, 5, 4, 3, 2, 1],
          double: {
            by: 'day',
            data: [{
              date: '2022-07-01',
              type: 'distance',
              value: 200,
            }, {
              date: '2022-07-02',
              type: 'terrain',
              value: 'Rock',
            }, {
              date: '2022-07-03',
              type: 'distance',
              value: 180,
            }, {
              date: '2022-07-04',
              type: 'terrain',
              value: 'Track',
            }, {
              date: '2022-07-05',
              type: 'distance',
              value: 100,
            }, {
              date: '2022-07-06',
              type: 'distance',
              value: 160,
            }, {
              date: '2022-07-07',
              type: 'terrain',
              value: 'Grass',
            }, {
              date: '2022-07-08',
              type: 'terrain',
              value: 'Sand',
            }, {
              date: '2022-07-09',
              type: 'distance',
              value: 140,
            }, {
              date: '2022-07-10',
              type: 'terrain',
              value: 'Snow',
            }, {
              date: '2022-07-11',
              type: 'distance',
              value: 120,
            }, {
              date: '2022-07-12',
              type: 'terrain',
              value: 'Road',
            }, {
              date: '2022-07-13',
              type: 'terrain',
              value: 'Dirt',
            }],
          },
        },
      }),
    };

    const liveRecord = {
      name: tournamentName,
      discordUrl: 'http://discord.gg/chicken-derby',
      startAt: moment.utc('2022-07-02').startOf('day').toDate(),
      endAt: moment.utc('2022-07-14').endOf('day').toDate(),
      maxRaces: 30,
      peckingOrders: JSON.stringify(['S', 'A', 'B', 'C', 'D']),
      rules: JSON.stringify({
        points: {
          positions: [25, 20, 15, 12, 10, 8, 6, 5, 4, 3, 2, 1],
          double: {
            by: 'day',
            data: [{
              date: '2022-07-02',
              type: 'terrain',
              value: 'Rock',
            }, {
              date: '2022-07-03',
              type: 'distance',
              value: 180,
            }, {
              date: '2022-07-04',
              type: 'terrain',
              value: 'Track',
            }, {
              date: '2022-07-05',
              type: 'distance',
              value: 100,
            }, {
              date: '2022-07-06',
              type: 'distance',
              value: 160,
            }, {
              date: '2022-07-07',
              type: 'terrain',
              value: 'Grass',
            }, {
              date: '2022-07-08',
              type: 'terrain',
              value: 'Sand',
            }, {
              date: '2022-07-09',
              type: 'distance',
              value: 140,
            }, {
              date: '2022-07-10',
              type: 'terrain',
              value: 'Snow',
            }, {
              date: '2022-07-11',
              type: 'distance',
              value: 120,
            }, {
              date: '2022-07-12',
              type: 'terrain',
              value: 'Road',
            }, {
              date: '2022-07-13',
              type: 'terrain',
              value: 'Dirt',
            }, {
              date: '2022-07-14',
              type: 'distance',
              value: 200,
            }],
          },
        },
      }),
    };

    const record = isProduction ? liveRecord : testRecord;

    await queryInterface.bulkInsert('tournaments', [record]);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('tournaments', { name: tournamentName });
  },
};
