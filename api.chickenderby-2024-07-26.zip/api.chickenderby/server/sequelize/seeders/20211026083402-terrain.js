module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => queryInterface.bulkInsert('terrains', [
    {
      id: 1,
      name: 'Dirt',
      image: '/terrain/dirt_icon.png',
      createdAt: new Date(),
      updatedAt: new Date(),
    }, {
      id: 2,
      name: 'Grass',
      image: '/terrain/grass_icon.png',
      createdAt: new Date(),
      updatedAt: new Date(),
    }, {
      id: 3,
      name: 'Road',
      image: '/terrain/road_icon.png',
      createdAt: new Date(),
      updatedAt: new Date(),
    }, {
      id: 4,
      name: 'Rock',
      image: '/terrain/rock_icon.png',
      createdAt: new Date(),
      updatedAt: new Date(),
    }, {
      id: 5,
      name: 'Sand',
      image: '/terrain/sand_icon.png',
      createdAt: new Date(),
      updatedAt: new Date(),
    }, {
      id: 6,
      name: 'Snow',
      image: '/terrain/snow_icon.png',
      createdAt: new Date(),
      updatedAt: new Date(),
    }, {
      id: 7,
      name: 'Track',
      image: '/terrain/track_icon.png',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ]),

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => queryInterface.bulkDelete('terrains', null, {}),
};
