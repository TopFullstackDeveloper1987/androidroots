/* eslint-disable max-len */
// https://docs.google.com/spreadsheets/d/1osYq8YcXh3gIgXxJ676w2wduNJfp1hOViZTSqrkRBT0/edit#gid=1605728109

const clothings20K = [{
  id: 35,
  name: 'Lemon & Vanilla Double Scoop',
  numberOfOwners: 131,
  type: 'Head',
  clothingSet: 'Daily Double',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Fbirthday%2FClothing_Hat_DailyDoubleDorking.png?alt=media&token=4008429b-9ab1-4f5e-941f-c74beb6b3946',
  clothingId: 'HatIceCreamDoubleLV',
}, {
  id: 36,
  name: 'Chcoolate & Mint Double Scoop',
  numberOfOwners: 151,
  type: 'Head',
  clothingSet: 'Daily Double',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Fbirthday%2FClothing_Hat_DailyDoubleLakenvelder.png?alt=media&token=2548950e-eba2-4fa1-b4c8-e57b32102b1d',
  clothingId: 'HatIceCreamDoubleCM',
}, {
  id: 37,
  name: 'Raspberry & Ube Double Scoop',
  numberOfOwners: 121,
  type: 'Head',
  clothingSet: 'Daily Double',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Fbirthday%2FClothing_Hat_DailyDoubleSultan.png?alt=media&token=b042f79a-0c6a-4779-ba82-08eb38c30259',
  clothingId: 'HatIceCreamDoubleRU',
}, {
  id: 38,
  name: 'Bubblegum & Strawberry Double Scoop',
  numberOfOwners: 90,
  type: 'Head',
  clothingSet: 'Daily Double',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Fbirthday%2FClothing_Hat_DailyDouble_Serama.png?alt=media&token=ad290d49-f640-4e30-86b0-6f5749ce5458',
  clothingId: 'HatIceCreamDoubleBS',
}, {
  id: 39,
  name: '1st Birthday Shirt',
  numberOfOwners: 280,
  type: 'Body',
  clothingSet: '1st Birthday',
  image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/clothings%2Fbirthday%2FClothing_Body_FirstBirthdayShirt.png?alt=media&token=113f9717-8c33-4779-99d6-73c012152c54',
  clothingId: 'BodyFirstBirthday',
}];

module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('clothings', clothings20K);
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    const clothingIds = clothings20K.map((clothing) => clothing.id);
    await queryInterface.bulkDelete('clothings', {
      id: clothingIds,
    });
  },
};
