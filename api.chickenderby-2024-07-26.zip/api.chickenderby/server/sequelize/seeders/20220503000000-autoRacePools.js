module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    const terrainIds = {
      Dirt: 1,
      Grass: 2,
      Road: 3,
      Rock: 4,
      Sand: 5,
      Snow: 6,
      Track: 7,
    };

    const isProduction = process.env.NODE_ENV === 'production';
    const mapRaces = (raceData) => {
      const {
        terrain, type, peckingOrder, unlimitPO, ...other
      } = raceData;

      return {
        ...other,
        peckingOrder: peckingOrder.toUpperCase(),
        terrainId: terrainIds[terrain] || terrainIds.Dirt,
        type: type.toLowerCase(),
        unlimitPO: unlimitPO === 'Yes' ? 1 : 0,
      };
    };

    // eslint-disable-next-line global-require
    const basePools = isProduction ? require('../baseData/autoRacePoolProduction.json') : require('../baseData/autoRacePoolStaging.json');
    const autoRacePools = basePools.map(mapRaces);

    // truncate the original pool
    await queryInterface.bulkDelete('autoRacePools');
    await queryInterface.bulkInsert('autoRacePools', autoRacePools);
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('autoRacePools');
  },
};
