import { Umzug, SequelizeStorage } from 'umzug';
import Sequelize from 'sequelize';
import models from '../models';
const { sequelize } = models;

export const checkForMigrations = () => {
  const umzug = new Umzug({
    migrations: { glob: 'server/sequelize/migrations/*.js' },
    context: sequelize.getQueryInterface(),
    storage: new SequelizeStorage({ sequelize }),
    logger: console,
  });

  return umzug.pending();
};

export const performMigrations = () => {
  const umzug = new Umzug({
    migrations: {
      glob: 'server/sequelize/migrations/*.js',
      resolve: ({ name, path, context }) => {
        // adjust the migration parameters Umzug will
        // pass to migration methods, this is done because
        // Sequilize-CLI generates migrations that require
        // two parameters be passed to the up and down methods
        // but by default Umzug will only pass the first
        const migration = require(path || '');
        return {
          name,
          up: async () => migration.up(context, Sequelize),
          down: async () => migration.down(context, Sequelize),
        };
      },
    },
    context: sequelize.getQueryInterface(),
    storage: new SequelizeStorage({ sequelize }),
    logger: console,
  });

  return umzug.up();
};
