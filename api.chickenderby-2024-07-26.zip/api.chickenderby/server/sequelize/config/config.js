const path = require('path');
require('dotenv').config();

const config = {
  database: process.env.DB_NAME || 'bitapp',
  username: process.env.DB_USERNAME || 'root',
  password: process.env.DB_PASSWORD || 'root',
  host: process.env.DB_HOST || '127.0.0.1',
  port: process.env.DB_PORT || 3306,
  charset: 'utf8',
  collate: 'utf8_general_ci',
  dialect: 'mysql',
  dialectOptions: {
    decimalNumbers: true,
  },
  pool: {
    max: 100,
    min: 0,
    idle: 10000,
    acquire: 60000,
    evict: 10000,
  },
  seederStorage: 'sequelize',
  // eslint-disable-next-line no-console
  logging: process.env.DB_LOGGING === 'true' ? console.log : false,
  freezeTableName: true, // By default, sequelize will pluralize model names
  timestamps: true,
  models: [path.resolve(__dirname, '..', 'models', '!(index.*)')],
};

module.exports = config;
