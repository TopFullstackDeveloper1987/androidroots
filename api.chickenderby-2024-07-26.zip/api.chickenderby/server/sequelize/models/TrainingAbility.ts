import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  AutoIncrement,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { TrainingPartner } from './TrainingPartner';

@Table({
  tableName: 'trainingAbilities',
  name: {
    singular: 'trainingAbility',
    plural: 'trainingAbilities',
  },
})
export class TrainingAbility extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => TrainingPartner)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  trainingPartnerId!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  startStrength!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  startLevel!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  levelUp!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => TrainingPartner)
  trainingPartner!: TrainingPartner;

  // #endregion
}
