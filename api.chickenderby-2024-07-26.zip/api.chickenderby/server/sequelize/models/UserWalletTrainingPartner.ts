import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  AutoIncrement,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { UserWallet } from './UserWallet';
import { TrainingPartner } from './TrainingPartner';
import { Chicken } from './Chicken';
import { GachaPullMode } from '../../types';

@Table({
  tableName: 'userWalletTrainingPartners',
  name: {
    singular: 'userWalletTrainingPartner',
    plural: 'userWalletTrainingPartners',
  },
})
export class UserWalletTrainingPartner extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @ForeignKey(() => TrainingPartner)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  trainingPartnerId!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  chickenId!: number;

  @AllowNull(false)
  @Default(1)
  @Column(DataType.INTEGER)
  currentLevel!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  currentMaxLevel!: number;

  @AllowNull(false)
  @Default(GachaPullMode.SinglePull)
  @Column(DataType.STRING)
  mode!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  @BelongsTo(() => TrainingPartner)
  trainingPartner!: TrainingPartner;

  @BelongsTo(() => Chicken)
  chicken!: Chicken;

  // #endregion
}
