import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { AssignmentStatus } from '../../types/assignments/assignmentStatus';
import { CoinPresaleCurrency } from '../../types/bawk-staking';

import { UserWallet } from './UserWallet';

@Table({
  tableName: 'coinPresaleAssignments',
  name: {
    singular: 'coinPresaleAssignment',
    plural: 'coinPresaleAssignments',
  },
})
export class CoinPresaleAssignment extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @AllowNull(false)
  @Column(DataType.DECIMAL(20, 6))
  tokensBought!: number;

  @AllowNull(false)
  @Default(CoinPresaleCurrency.ETH)
  @Column(DataType.TINYINT.UNSIGNED)
  currency!: CoinPresaleCurrency;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  amountPaid!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER.UNSIGNED)
  timestamp!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  eventTransactionHash!: string;

  @AllowNull(false)
  @Default(AssignmentStatus.Pending)
  @Column(DataType.ENUM(AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error))
  status!: AssignmentStatus;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  signature!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  error!: any;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  transactionHash!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  txHashes!: string[];

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  data!: any;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  // #endregion
}
