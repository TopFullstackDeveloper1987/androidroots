import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  HasMany,
  AutoIncrement,
  DefaultScope,
  Default,
} from 'sequelize-typescript';
import { Op } from 'sequelize';

import { TournamentStatus } from '../../types/tournaments/tournamentStatus';
import { TournamentRanking } from './TournamentRanking';
import { Race } from './Race';

@Table({
  tableName: 'tournaments',
  name: {
    singular: 'tournament',
    plural: 'tournaments',
  },
})
@DefaultScope(() => ({
  where: {
    status: {
      [Op.not]: TournamentStatus.Disabled,
    },
  },
}))
export class Tournament extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  url!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.TEXT)
  description!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  maxRaces!: number;

  @AllowNull(false)
  @Column(DataType.DATE)
  startAt!: Date;

  @AllowNull(false)
  @Column(DataType.DATE)
  endAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  discordUrl!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  groups!: string[];

  @AllowNull(false)
  @Column(DataType.JSON)
  rules!: any;

  @AllowNull(false)
  @Default(TournamentStatus.Pending)
  @Column(DataType.ENUM(TournamentStatus.Pending, TournamentStatus.Live, TournamentStatus.Completed, TournamentStatus.Disabled))
  status!: TournamentStatus;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @HasMany(() => TournamentRanking, { foreignKey: 'tournamentId', as: 'rankings' })
  rankings!: TournamentRanking[];

  @HasMany(() => Race)
  races!: Race[];

  // #endregion
}
