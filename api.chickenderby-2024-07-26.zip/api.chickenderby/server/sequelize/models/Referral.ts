import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
} from 'sequelize-typescript';

@Table({
  tableName: 'referrals',
  name: {
    singular: 'referral',
    plural: 'referrals',
  },
})
export class Referral extends Model {
  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.STRING)
  referrerId!: string;

  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.STRING)
  refereeId!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  // #endregion
}
