import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  Default,
} from 'sequelize-typescript';

@Table({
  tableName: 'lands',
  name: {
    singular: 'land',
    plural: 'lands',
  },
})
export class Land extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  territory!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  borough!: string;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  positionX!: number;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  positionY!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  farmingPlots!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  building!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  feature!: string;

  // TODO: make it string instead of TEXT
  @AllowNull(false)
  @Column(DataType.TEXT)
  image!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;
}
