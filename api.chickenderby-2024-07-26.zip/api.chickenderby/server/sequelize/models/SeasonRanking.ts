import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  AutoIncrement,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { ChickenPeckingOrder } from '../../types/chickens/chickenPeckingOrder';
import { Season } from './Season';
import { Chicken } from './Chicken';

@Table({
  tableName: 'seasonRankings',
  name: {
    singular: 'seasonRanking',
    plural: 'seasonRankings',
  },
})
export class SeasonRanking extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => Season)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  seasonId!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  chickenId!: number;

  @AllowNull(false)
  @Default(ChickenPeckingOrder.E)
  @Column(DataType.ENUM(ChickenPeckingOrder.S, ChickenPeckingOrder.A, ChickenPeckingOrder.B, ChickenPeckingOrder.C, ChickenPeckingOrder.D, ChickenPeckingOrder.E, ChickenPeckingOrder.CHICK))
  peckingOrder!: ChickenPeckingOrder;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  position!: number;

  @AllowNull(false)
  @Default(100)
  @Column(DataType.INTEGER)
  poPoints!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  races!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  first!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  second!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  third!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  fourth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  fifth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  sixth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  seventh!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  eighth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  ninth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  tenth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  eleventh!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  twelfth!: number;

  @AllowNull(false)
  @Default(100)
  @Column(DataType.INTEGER)
  perfection!: number;

  @AllowNull(false)
  @Default(100)
  @Column(DataType.INTEGER)
  heritageOrder!: number;

  @AllowNull(false)
  @Default(100)
  @Column(DataType.INTEGER)
  stockOrder!: number;

  @AllowNull(false)
  @Default(false)
  @Column(DataType.BOOLEAN)
  isPromotionZone!: boolean;

  @AllowNull(false)
  @Default(false)
  @Column(DataType.BOOLEAN)
  isDemotionZone!: boolean;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Season)
  season!: Season;

  @BelongsTo(() => Chicken)
  chicken!: Chicken;

  // #endregion
}
