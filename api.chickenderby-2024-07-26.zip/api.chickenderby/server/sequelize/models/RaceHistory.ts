import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  Default,
  AutoIncrement,
} from 'sequelize-typescript';

import { Race } from './Race';
import { Chicken } from './Chicken';

import { ChickenPeckingOrder } from '../../types/chickens/chickenPeckingOrder';
import { PositionType } from '../../types/races/positionType';
import { WETH_CONTRACT } from '../../abi/wethContract';
import { UserWallet } from './UserWallet';

@Table({
  tableName: 'raceHistories',
  name: {
    singular: 'raceHistory',
    plural: 'raceHistories',
  },
})
export class RaceHistory extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => Race)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  raceId!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  chickenId!: number;

  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  position!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 2))
  raceEarnings!: number;

  @AllowNull(false)
  @Column(DataType.DATEONLY)
  date!: Date;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  terrainId!: number;

  @AllowNull(false)
  @Default(100)
  @Column(DataType.INTEGER.UNSIGNED)
  distance!: number;

  @AllowNull(false)
  @Default(12)
  @Column(DataType.INTEGER.UNSIGNED)
  capacity!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  peckingOrder!: ChickenPeckingOrder;

  @AllowNull(false)
  @Default(WETH_CONTRACT.address)
  @Column(DataType.STRING)
  coinContract!: string;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  feeJEWEL!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  positionType!: PositionType;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Race)
  race!: Race;

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  @BelongsTo(() => Chicken)
  chicken!: Chicken;

  // #endregion
}
