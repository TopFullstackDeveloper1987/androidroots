import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  Default,
} from 'sequelize-typescript';

import { FusionAlphaTrait } from '../../types/fusion/lockedTraits';
import { FusionBetaTrait } from '../../types/fusion/lockedTraits';
import { FusionGammaTrait } from '../../types/fusion/lockedTraits';

@Table({
  tableName: 'fusionPrices',
  name: {
    singular: 'fusionPrice',
    plural: 'fusionPrices',
  },
})
export class FusionPrice extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  trait!: FusionAlphaTrait | FusionBetaTrait | FusionGammaTrait;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  value!: string;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  serums!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;
}
