import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  Default,
} from 'sequelize-typescript';

@Table({
  tableName: 'preRegistrations',
  name: {
    singular: 'preRegistration',
    plural: 'preRegistrations',
  },
})
export class PreRegistration extends Model {
  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.STRING)
  id!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  email!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  claimedAt!: Date;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  // #endregion
}
