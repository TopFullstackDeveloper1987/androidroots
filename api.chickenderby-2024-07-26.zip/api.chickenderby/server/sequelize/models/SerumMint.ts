import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { AssignmentStatus } from '../../types/assignments/assignmentStatus';
import { TransactionPaidStatus } from '../../types/transactions/transactionPaidStatus';
import { Serum } from './Serum';
import { UserWallet } from './UserWallet';

@Table({
  tableName: 'serumMints',
  name: {
    singular: 'serumMint',
    plural: 'serumMints',
  },
})
export class SerumMint extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @ForeignKey(() => Serum)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  serumId!: number;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  amount!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  signature!: string;

  @AllowNull(false)
  @Default(AssignmentStatus.Pending)
  @Column(DataType.ENUM(AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error))
  status!: AssignmentStatus;

  @AllowNull(false)
  @Default(TransactionPaidStatus.Unpaid)
  @Column(DataType.ENUM(TransactionPaidStatus.Unpaid, TransactionPaidStatus.ReceiptNotReady, TransactionPaidStatus.Paid, TransactionPaidStatus.Error, TransactionPaidStatus.Postponed))
  paidStatus!: TransactionPaidStatus;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  error!: any;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  transactionHash!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  txHashes!: string[];

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  data!: any;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  @BelongsTo(() => Serum)
  serum!: Serum;

  // #endregion
}
