import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  Default,
  AutoIncrement,
  HasMany,
} from 'sequelize-typescript';

import { MarketItem } from './MarketItem';
import { TradeOffer } from './TradeOffer';
import { UserWallet } from './UserWallet';
import { Chicken } from './Chicken';
import { TokenTradeActivity } from './TokenTradeActivity';

@Table({
  tableName: 'tradeActivities',
  name: {
    singular: 'tradeActivity',
    plural: 'tradeActivities',
  },
})
export class TradeActivity extends Model {
  @PrimaryKey
  @AutoIncrement
  @ForeignKey(() => MarketItem)
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => TradeOffer)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  tradeOfferId!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  nftContract!: string;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  tokenId!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  seller!: string;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  buyer!: string;

  @AllowNull(false)
  @Column(DataType.DECIMAL(20, 6))
  price!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  offeredNftContract!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  tokensAttached!: string[];

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  marketFeePercent!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  timestamp!: Date;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => MarketItem)
  marketItem!: MarketItem;

  @BelongsTo(() => TradeOffer)
  tradeOffer!: TradeOffer;

  @BelongsTo(() => UserWallet, { foreignKey: 'seller', as: 'sellerUserWallet' })
  sellerUserWallet!: UserWallet;

  @BelongsTo(() => UserWallet, { foreignKey: 'buyer', as: 'buyerUserWallet' })
  buyerUserWallet!: UserWallet;

  @BelongsTo(() => Chicken, { foreignKey: 'tokenId', as: 'chicken' })
  chicken!: Chicken;

  @HasMany(() => TokenTradeActivity)
  tokenTradeActivities!: TokenTradeActivity[];
  // #endregion
}
