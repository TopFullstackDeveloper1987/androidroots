import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { UserWallet } from './UserWallet';

@Table({
  tableName: 'bawkPresaleInviteCodes',
  name: {
    singular: 'bawkPresaleInviteCode',
    plural: 'bawkPresaleInviteCodes',
  },
})
export class BawkPresaleInviteCode extends Model {
  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.STRING(8))
  id!: string;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @ForeignKey(() => UserWallet)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  claimedUserWalletId!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet, { foreignKey: 'userWalletId' })
  userWallet!: UserWallet;

  @BelongsTo(() => UserWallet, { foreignKey: 'claimedUserWalletId' })
  claimedUserWallet!: UserWallet;

  // #endregion

  static async getInviteCodes(userWalletId: string, hasChickens: boolean, hasGoldenTickets: boolean) {
    if (!hasChickens && !hasGoldenTickets) {
      return [];
    }

    const inviteCodes = await BawkPresaleInviteCode.findAll({
      where: {
        userWalletId,
      },
    });

    if (inviteCodes.length) {
      return inviteCodes.map((inviteCode) => inviteCode.id);
    }

    return this.createInviteCodes(userWalletId);
  }

  static async createInviteCodes(userWalletId: string) {
    const codes: string[] = [];

    while (true) {
      const code = await this.generateInviteCode(8);

      const inviteCode = await BawkPresaleInviteCode.findByPk(code);

      if (!inviteCode) {
        await BawkPresaleInviteCode.create({
          id: code,
          userWalletId,
        });

        codes.push(code);
      }

      if (codes.length >= 3) {
        return codes;
      }
    }
  }

  static async generateInviteCode(length: number) {
    const characters = '0123456789';
    let inviteCode = '';

    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      inviteCode += characters.charAt(randomIndex);
    }

    return inviteCode;
  }
}
