import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { TransactionPaidStatus } from '../../types/transactions/transactionPaidStatus';
import { AssignmentStatus } from '../../types/assignments/assignmentStatus';
import { RaceAssignmentType } from '../../types/races/raceAssignmentType';

import { Race } from './Race';
import { Chicken } from './Chicken';
import { UserWallet } from './UserWallet';

@Table({
  tableName: 'raceAssignments',
  name: {
    singular: 'raceAssignment',
    plural: 'raceAssignments',
  },
})
export class RaceAssignment extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => Race)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  raceId!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  chickenId!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  userWalletId!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  signature!: string;

  @AllowNull(false)
  @Default(RaceAssignmentType.Enter)
  @Column(DataType.ENUM(RaceAssignmentType.Enter, RaceAssignmentType.AutoEnter))
  type!: RaceAssignmentType;

  @AllowNull(false)
  @Default(AssignmentStatus.Pending)
  @Column(DataType.ENUM(AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error))
  status!: AssignmentStatus;

  @AllowNull(false)
  @Default(TransactionPaidStatus.Unpaid)
  @Column(DataType.ENUM(TransactionPaidStatus.Unpaid, TransactionPaidStatus.ReceiptNotReady, TransactionPaidStatus.Paid, TransactionPaidStatus.Error, TransactionPaidStatus.Postponed))
  paidStatus!: TransactionPaidStatus;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  error!: any;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  transactionHash!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  txHashes!: string[];

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  data!: any;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  @BelongsTo(() => Race)
  race!: Race;

  @BelongsTo(() => Chicken)
  chicken!: Chicken;

  // #endregion
}
