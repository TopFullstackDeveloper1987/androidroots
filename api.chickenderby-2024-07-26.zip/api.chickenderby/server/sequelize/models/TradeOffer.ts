import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  HasMany,
  Default,
  DefaultScope,
  Scopes,
} from 'sequelize-typescript';
import { Op } from 'sequelize';

import { AssignmentStatus } from '../../types/assignments/assignmentStatus';
import { MarketplaceAssignmentType } from '../../types/marketplace/marketplaceAssignmentType';
import { MarketItem } from './MarketItem';
import { UserWallet } from './UserWallet';
import { TokenTradeOffer } from './TokenTradeOffer';

@Table({
  tableName: 'tradeOffers',
  name: {
    singular: 'tradeOffer',
    plural: 'tradeOffers',
  },
})
@DefaultScope(() => ({
  where: {
    assignmentType: {
      [Op.not]: MarketplaceAssignmentType.AutoDeclineOffer,
    },
    [Op.not]: {
      assignmentType: MarketplaceAssignmentType.MakeOffer,
      assignmentStatus: [AssignmentStatus.Pending, AssignmentStatus.Error],
    },
  },
}))
@Scopes(() => ({
  active: {
    where: {
      canceledAt: null,
      declinedAt: null,
      fulfilledAt: null,
    },
  },
}))
export class TradeOffer extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => MarketItem)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  marketItemId!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  nftContract!: string;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  offerMaker!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  tokensAttached!: number[];

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  price!: number;

  @AllowNull(false)
  @Column(DataType.ENUM(
    MarketplaceAssignmentType.MakeOffer,
    MarketplaceAssignmentType.EditOffer,
    MarketplaceAssignmentType.FulfillOffer,
    MarketplaceAssignmentType.CancelOrDeclineOffer,
    MarketplaceAssignmentType.AutoDeclineOffer,
  ))
  assignmentType!: MarketplaceAssignmentType;

  @AllowNull(false)
  @Default(AssignmentStatus.Pending)
  @Column(DataType.ENUM(AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error))
  assignmentStatus!: AssignmentStatus;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  canceledAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  declinedAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  fulfilledAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  reason!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  syncedAt!: Date;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => MarketItem)
  marketItem!: MarketItem;

  @BelongsTo(() => UserWallet, { foreignKey: 'offerMaker' })
  userWallet!: UserWallet;

  @HasMany(() => TokenTradeOffer)
  tokenTradeOffers!: TokenTradeOffer[];

  // #endregion
}
