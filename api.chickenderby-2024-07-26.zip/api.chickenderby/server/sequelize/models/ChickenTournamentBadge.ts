import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  AutoIncrement,
  BelongsTo,
} from 'sequelize-typescript';

import { Chicken } from './Chicken';
import { TournamentBadge } from './TournamentBadge';

@Table({
  tableName: 'chickenTournamentBadges',
  name: {
    singular: 'chickenTournamentBadge',
    plural: 'chickenTournamentBadges',
  },
})
export class ChickenTournamentBadge extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  chickenId!: number;

  @ForeignKey(() => TournamentBadge)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  tournamentBadgeId!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Chicken)
  chicken!: Chicken;

  @BelongsTo(() => TournamentBadge)
  tournamentBadge!: TournamentBadge;

  // #endregion
}
