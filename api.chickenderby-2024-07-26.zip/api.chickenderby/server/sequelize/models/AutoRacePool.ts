import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  AutoIncrement,
  Default,
  BelongsTo,
} from 'sequelize-typescript';

import { RaceType } from '../../types/races/raceType';
import { Terrain } from './Terrain';
import { WETH_CONTRACT } from '../../abi/wethContract';
import { RaceCoinType } from '../../types/races/raceCoinType';
import { BawkStakingCompany } from './BawkStakingCompany';

@Table({
  tableName: 'autoRacePools',
  name: {
    singular: 'autoRacePool',
    plural: 'autoRacePools',
  },
})
export class AutoRacePool extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  peckingOrder!: string;

  @ForeignKey(() => Terrain)
  @AllowNull(false)
  @Column(DataType.INTEGER().UNSIGNED)
  terrainId!: number;

  @AllowNull(false)
  @Default(100)
  @Column(DataType.INTEGER().UNSIGNED)
  distance!: number;

  @AllowNull(false)
  @Default(12)
  @Column(DataType.INTEGER().UNSIGNED)
  maxCapacity!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  location!: string;

  @AllowNull(false)
  @Default(3)
  @Column(DataType.INTEGER().UNSIGNED)
  minimumStartDelay!: number;

  @AllowNull(false)
  @Default(900)
  @Column(DataType.INTEGER().UNSIGNED)
  startTime!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  fee!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  prizePool!: number;

  @AllowNull(false)
  @Default(RaceType.Manual)
  @Column(DataType.ENUM(RaceType.Manual, RaceType.Automatic))
  type!: RaceType;

  @AllowNull(false)
  @Default(1)
  @Column(DataType.INTEGER().UNSIGNED)
  group!: number;

  @AllowNull(false)
  @Default(false)
  @Column(DataType.BOOLEAN)
  unlimitPO!: boolean;

  @AllowNull(false)
  @Default(WETH_CONTRACT.address)
  @Column(DataType.STRING)
  coinContract!: string;

  @ForeignKey(() => BawkStakingCompany)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  bawkStakingCompanyId!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  @Column(DataType.VIRTUAL)
  get coinType() {
    if (this.coinContract === WETH_CONTRACT.address) {
      return RaceCoinType.WETH;
    }

    return RaceCoinType.JEWEL;
  }

  // #region Associations

  @BelongsTo(() => Terrain)
  terrain!: Terrain;
  getTerrain!: () => Promise<Terrain>;

  @BelongsTo(() => BawkStakingCompany)
  bawkStakingCompany!: BawkStakingCompany;

  // #endregion
}
