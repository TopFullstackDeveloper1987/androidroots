import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  AutoIncrement,
  PrimaryKey,
  Default,
} from 'sequelize-typescript';

import { ChickenPeckingOrder } from '../../types/chickens/chickenPeckingOrder';

@Table({
  tableName: 'seasonBadges',
  name: {
    singular: 'seasonBadge',
    plural: 'seasonBadges',
  },
})
export class SeasonBadge extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Default(ChickenPeckingOrder.E)
  @Column(DataType.ENUM(ChickenPeckingOrder.S, ChickenPeckingOrder.A, ChickenPeckingOrder.B, ChickenPeckingOrder.C, ChickenPeckingOrder.D, ChickenPeckingOrder.E, ChickenPeckingOrder.CHICK))
  peckingOrder!: ChickenPeckingOrder;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  prizePercent!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  image!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.TEXT)
  toolTip!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;
}
