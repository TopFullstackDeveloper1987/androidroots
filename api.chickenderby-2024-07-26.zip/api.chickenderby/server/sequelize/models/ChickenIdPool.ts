import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  Default,
} from 'sequelize-typescript';

import { ChickenIdPoolStatus } from '../../types/chickenIdPools/chickenIdPoolStatus';

@Table({
  tableName: 'chickenIdPools',
  name: {
    singular: 'chickenIdPool',
    plural: 'chickenIdPools',
  },
})
export class ChickenIdPool extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Default(ChickenIdPoolStatus.Pending)
  @Column(DataType.ENUM(ChickenIdPoolStatus.Pending, ChickenIdPoolStatus.Used, ChickenIdPoolStatus.Canceled))
  status!: ChickenIdPoolStatus;

  @AllowNull(false)
  @Column(DataType.DATE)
  expiresAt!: Date;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;
}
