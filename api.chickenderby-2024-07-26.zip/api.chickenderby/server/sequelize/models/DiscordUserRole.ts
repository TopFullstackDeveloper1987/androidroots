import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
} from 'sequelize-typescript';

import { UserWallet } from './UserWallet';
import { DiscordRole } from './DiscordRole';

@Table({
  tableName: 'discordUserRoles',
  name: {
    singular: 'discordUserRole',
    plural: 'discordUserRoles',
  },
})
export class DiscordUserRole extends Model {
  @PrimaryKey
  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @PrimaryKey
  @ForeignKey(() => DiscordRole)
  @AllowNull(false)
  @Column(DataType.STRING)
  discordRoleId!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  @BelongsTo(() => DiscordRole)
  discordRole!: DiscordRole;

  // #endregion
}
