import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  HasMany,
  HasOne,
  Default,
} from 'sequelize-typescript';
import * as moment from 'moment-timezone';
import NP from 'number-precision';

import { RaceType } from '../../types/races/raceType';
import { RaceStatus } from '../../types/races/raceStatus';
import { TransactionPaidStatus } from '../../types/transactions/transactionPaidStatus';
import { ChickenPeckingOrder } from '../../types/chickens/chickenPeckingOrder';
import { RaceDistanceType } from '../../types/races/raceDistanceType';

import { Terrain } from './Terrain';
import { Tournament } from './Tournament';
import { Result } from './Result';
import { RaceAssignment } from './RaceAssignment';
import { Lane } from './Lane';
import { User } from './User';
import { WETH_CONTRACT } from '../../abi/wethContract';
import { RaceCoinType } from '../../types/races/raceCoinType';
import { jewelToUsdt } from '../../services/exchangeService';
import { truncateToDecimals } from '../../utils';
import config from '../../config';
import { BawkStakingCompany } from './BawkStakingCompany';

@Table({
  tableName: 'races',
  name: {
    singular: 'race',
    plural: 'races',
  },
})
export class Race extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  peckingOrder!: ChickenPeckingOrder;

  @ForeignKey(() => Terrain)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER.UNSIGNED)
  terrainId!: number;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  distance!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  fee!: number;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  maxCapacity!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  currentCapacity!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  location!: string;

  @AllowNull(false)
  @Default(3)
  @Column(DataType.INTEGER)
  minimumStartDelay!: number;

  @AllowNull(false)
  @Default(RaceStatus.Open)
  @Column(DataType.ENUM(RaceStatus.Open, RaceStatus.Scheduled, RaceStatus.InProgress, RaceStatus.Finished, RaceStatus.Canceled))
  status!: RaceStatus;

  @AllowNull(false)
  @Default(900)
  @Column(DataType.INTEGER)
  startTime!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  prizePool!: number;

  @AllowNull(false)
  @Default(TransactionPaidStatus.Unpaid)
  @Column(DataType.ENUM(TransactionPaidStatus.Unpaid, TransactionPaidStatus.ReceiptNotReady, TransactionPaidStatus.Paid, TransactionPaidStatus.Error, TransactionPaidStatus.Postponed))
  paidStatus!: TransactionPaidStatus;

  @AllowNull(false)
  @Default(false)
  @Column(DataType.TINYINT().UNSIGNED)
  unlimitPO!: boolean;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  startsAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  endsAt!: Date;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER().UNSIGNED)
  payoutAttempts!: number;

  @AllowNull(false)
  @Default(RaceType.Manual)
  @Column(DataType.ENUM(RaceType.Manual, RaceType.Automatic))
  type!: RaceType;

  @AllowNull(false)
  @Default(1)
  @Column(DataType.INTEGER().UNSIGNED)
  group!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 2))
  feeJEWEL!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 2))
  prizePoolJEWEL!: number;

  @ForeignKey(() => Tournament)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER().UNSIGNED)
  tournamentId!: number;

  @ForeignKey(() => User)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER().UNSIGNED)
  userId!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  allowedUserWalletIds!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  allowedChickenIds!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  syncedAt!: Date;

  @AllowNull(false)
  @Default(WETH_CONTRACT.address)
  @Column(DataType.STRING)
  coinContract!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  scheduleAt!: Date;

  @ForeignKey(() => BawkStakingCompany)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  bawkStakingCompanyId!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  @Column(DataType.VIRTUAL)
  get prizePoolGN() {
    if (!this.feeJEWEL || !this.peckingOrder || !this.maxCapacity) {
      return 0;
    }

    const rake = 0.1;
    const poMultipliers: Record<ChickenPeckingOrder, number> = {
      [ChickenPeckingOrder.X]: 1.325,
      [ChickenPeckingOrder.SSSp]: 1.325,
      [ChickenPeckingOrder.SSS]: 1.325,
      [ChickenPeckingOrder.SSp]: 1.325,
      [ChickenPeckingOrder.SS]: 1.325,
      [ChickenPeckingOrder.Sp]: 1.325,
      [ChickenPeckingOrder.S]: 1.3,
      [ChickenPeckingOrder.Ap]: 1.275,
      [ChickenPeckingOrder.A]: 1.25,
      [ChickenPeckingOrder.Bp]: 1.225,
      [ChickenPeckingOrder.B]: 1.2,
      [ChickenPeckingOrder.Cp]: 1.175,
      [ChickenPeckingOrder.C]: 1.15,
      [ChickenPeckingOrder.Dp]: 1.125,
      [ChickenPeckingOrder.D]: 1.1,
      [ChickenPeckingOrder.Ep]: 1.075,
      [ChickenPeckingOrder.E]: 1.05,
      [ChickenPeckingOrder.Fp]: 1.025,
      [ChickenPeckingOrder.F]: 1,
      [ChickenPeckingOrder.CHICK]: 0,
    };
    const dollarGN = 250;

    const poMultiplier = poMultipliers[this.peckingOrder] || poMultipliers[ChickenPeckingOrder.F];
    return Math.ceil(this.feeUSD * rake * poMultiplier * dollarGN * this.maxCapacity);
  }

  @Column(DataType.VIRTUAL)
  get prizePoolCoins() {
    if (!this.feeJEWEL || !this.peckingOrder || !this.maxCapacity) {
      return 0;
    }

    const rake = 0.1;
    const poMultipliers: Record<ChickenPeckingOrder, number> = {
      [ChickenPeckingOrder.X]: 2.04,
      [ChickenPeckingOrder.SSSp]: 2.04,
      [ChickenPeckingOrder.SSS]: 2.04,
      [ChickenPeckingOrder.SSp]: 2.04,
      [ChickenPeckingOrder.SS]: 2.04,
      [ChickenPeckingOrder.Sp]: 2.04,
      [ChickenPeckingOrder.S]: 1.96,
      [ChickenPeckingOrder.Ap]: 1.88,
      [ChickenPeckingOrder.A]: 1.8,
      [ChickenPeckingOrder.Bp]: 1.72,
      [ChickenPeckingOrder.B]: 1.64,
      [ChickenPeckingOrder.Cp]: 1.56,
      [ChickenPeckingOrder.C]: 1.48,
      [ChickenPeckingOrder.Dp]: 1.4,
      [ChickenPeckingOrder.D]: 1.32,
      [ChickenPeckingOrder.Ep]: 1.24,
      [ChickenPeckingOrder.E]: 1.16,
      [ChickenPeckingOrder.Fp]: 1.08,
      [ChickenPeckingOrder.F]: 1,
      [ChickenPeckingOrder.CHICK]: 0,
    };
    const dollarCoins = 6400;

    const poMultiplier = poMultipliers[this.peckingOrder] || poMultipliers[ChickenPeckingOrder.F];
    return Math.ceil(this.feeUSD * rake * poMultiplier * dollarCoins * this.maxCapacity);
  }

  @Column(DataType.VIRTUAL)
  get coinType() {
    if (this.coinContract === WETH_CONTRACT.address) {
      return RaceCoinType.WETH;
    }

    return RaceCoinType.JEWEL;
  }

  // https://docs.google.com/document/d/1qrGgBcPblA6q8r4sOMYkm1n3rI5w22vZ2wSaOe_CT6o/edit
  @Column(DataType.VIRTUAL)
  get totalBawks() {
    // entryFee * maxCapacity * bawkPerJewel
    const bawkPerJewel = 3 / 7;
    return this.fee * this.maxCapacity * bawkPerJewel;
  }

  // https://docs.google.com/document/d/1qrGgBcPblA6q8r4sOMYkm1n3rI5w22vZ2wSaOe_CT6o/edit
  @Column(DataType.VIRTUAL)
  get bawks() {
    // this.totalBawks / numberChickensEntered
    return Number((this.totalBawks / this.currentCapacity).toFixed(2));
  }

  @Column(DataType.VIRTUAL)
  get raceTimerDuration() {
    if (!this.scheduleAt) {
      return null;
    }

    const nowUTC = moment.utc();
    return Math.max(moment.utc(this.scheduleAt).diff(nowUTC, 'seconds'), 0);
  }

  // #region Associations

  @BelongsTo(() => Terrain)
  terrain!: Terrain;

  @BelongsTo(() => Tournament)
  tournament!: Tournament;

  @HasOne(() => Result)
  result!: Result;

  @HasMany(() => RaceAssignment)
  raceAssignments!: RaceAssignment[];

  @HasMany(() => Lane)
  lanes!: Lane[];

  @BelongsTo(() => BawkStakingCompany)
  bawkStakingCompany!: BawkStakingCompany;

  // #endregion

  get distancePreferences(): RaceDistanceType[] {
    // ┌──────────────────────┬───────────┬────────────────────┬─────────────────────┬───────────┐
    // │                      │  Extremes │    Intermediate    │       Stretch       │ Extremes  │
    // │  distancePreference  ├───────────┴─────────┬──────────┴──────────┬──────────┴───────────┤
    // │                      │         Short       │       Medium        │        Long          │
    // ├──────────────────────┼───────────┬─────────┼──────────┬──────────┼──────────┬───────────┤
    // │      Distances       │    100m   │   120m  │   140m   │   160m   │   180m   │    200m   │
    // └──────────────────────┴───────────┴─────────┴──────────┴──────────┴──────────┴───────────┘

    const preferences = {
      100: [RaceDistanceType.Short, RaceDistanceType.Extremes],
      120: [RaceDistanceType.Short, RaceDistanceType.Intermediate],
      140: [RaceDistanceType.Medium, RaceDistanceType.Intermediate],
      160: [RaceDistanceType.Medium, RaceDistanceType.Stretch],
      180: [RaceDistanceType.Long, RaceDistanceType.Stretch],
      200: [RaceDistanceType.Long, RaceDistanceType.Extremes],
    };

    return preferences[this.distance as keyof typeof preferences];
  }

  get allowedUserWallets() {
    return this.allowedUserWalletIds?.split(/,\s*/g).map(userWalletId => userWalletId.toLowerCase());
  }

  get allowedChickens() {
    return this.allowedChickenIds?.split(/,\s*/g).map(chickenId => Number(chickenId));
  }

  get feeUSD() {
    const jewelPrice = jewelToUsdt();
    return Number((this.feeJEWEL * jewelPrice).toFixed(2));
  }

  get prizePoolUSD() {
    const jewelPrice = jewelToUsdt();
    return Number((this.prizePoolJEWEL * jewelPrice).toFixed(2));
  }

  get cid() {
    return this.bawkStakingCompanyId ? this.bawkStakingCompanyId - 1 : 0;
  }

  /**
   *
   * @param position - starting from 1
   * @returns
   */
  getGoldNuggets(position: number) {
    if (!this.prizePoolGN) {
      return 0;
    }

    // After the race is completed, the total prizePoolGN is first shared equally between all participants of the race.
    // Then, if there are any Gold Nuggets remaining, one each is given to each chicken, starting with the chicken in 1st place and then proceeding downwards.
    const firstShare = Math.floor(this.prizePoolGN / this.maxCapacity);
    const restGN = this.prizePoolGN - (firstShare * this.maxCapacity);
    const secondShare = position <= restGN ? 1 : 0;

    return firstShare + secondShare;
  }

  /**
   *
   * @param position - starting from 1
   * @returns
   */
  getCoins(position: number) {
    if (!this.prizePoolCoins) {
      return 0;
    }

    // After the race is completed, the total prizePoolCoins is shared between all participants depending on their finishingPosition.
    // This value is rounded up to the nearest integer.
    const finishingPositionMultiplier = [0.3, 0.2, 0.15, 0.1, 0.05, 0.05, 0.03, 0.03, 0.03, 0.02, 0.02, 0.02];
    return Math.ceil(this.prizePoolCoins * finishingPositionMultiplier[position - 1]);
  }

  getActualPrizePool() {
    return truncateToDecimals(
      NP.strip(this.fee * this.currentCapacity * config.RACE_PRIZE_POOL_PERCENT / 100),
      6,
    );
  }
}
