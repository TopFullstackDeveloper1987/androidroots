import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { AssignmentStatus } from '../../types/assignments/assignmentStatus';
import { TransactionPaidStatus } from '../../types/transactions/transactionPaidStatus';

import { UserWallet } from './UserWallet';
import { Chicken } from './Chicken';

@Table({
  tableName: 'fusionAssignments',
  name: {
    singular: 'fusionAssignment',
    plural: 'fusionAssignments',
  },
})
export class FusionAssignment extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  materialChickenId1!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  materialChickenId2!: number;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  fusedChickenId!: number;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  serums!: number;

  @AllowNull(false)
  @Default(AssignmentStatus.Draft)
  @Column(DataType.ENUM(AssignmentStatus.Draft, AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error))
  status!: AssignmentStatus;

  @AllowNull(false)
  @Default(TransactionPaidStatus.Unpaid)
  @Column(DataType.ENUM(TransactionPaidStatus.Unpaid, TransactionPaidStatus.ReceiptNotReady, TransactionPaidStatus.Paid, TransactionPaidStatus.Error, TransactionPaidStatus.Postponed))
  paidStatus!: TransactionPaidStatus;

  @AllowNull(false)
  @Column(DataType.JSON)
  chickenData!: Partial<Chicken>;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  error!: any;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  transactionHash!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  txHashes!: string[];

  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  nonce!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  data!: any;

  @Column(DataType.DATE)
  syncedAt!: Date;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  @BelongsTo(() => Chicken, { foreignKey: 'materialChickenId1', as: 'materialChicken1' })
  materialChicken1!: Chicken;

  @BelongsTo(() => Chicken, { foreignKey: 'materialChickenId2', as: 'materialChicken2' })
  materialChicken2!: Chicken;

  // #endregion
}
