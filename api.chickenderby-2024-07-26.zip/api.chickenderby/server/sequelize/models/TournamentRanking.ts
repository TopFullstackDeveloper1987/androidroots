import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  AutoIncrement,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { Tournament } from './Tournament';
import { Chicken } from './Chicken';
import { UserWallet } from './UserWallet';

@Table({
  tableName: 'tournamentRankings',
  name: {
    singular: 'tournamentRanking',
    plural: 'tournamentRankings',
  },
})
export class TournamentRanking extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => Tournament)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  tournamentId!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  chickenId!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  group!: string;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  position!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  races!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(10, 2))
  secondPoints!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  points!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  first!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  second!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  third!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  fourth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  fifth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  sixth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  seventh!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  eighth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  ninth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  tenth!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  eleventh!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  twelfth!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  data!: any;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  @BelongsTo(() => Tournament)
  tournament!: Tournament;

  @BelongsTo(() => Chicken)
  chicken!: Chicken;

  // #endregion
}
