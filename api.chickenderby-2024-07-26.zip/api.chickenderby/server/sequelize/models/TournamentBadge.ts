import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  AutoIncrement,
  PrimaryKey,
  Default,
  ForeignKey,
  BelongsTo,
} from 'sequelize-typescript';

import { Tournament } from './Tournament';

@Table({
  tableName: 'tournamentBadges',
  name: {
    singular: 'tournamentBadge',
    plural: 'tournamentBadges',
  },
})
export class TournamentBadge extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => Tournament)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  tournamentId!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  prizePosition!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  image!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.TEXT)
  toolTip!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Tournament)
  tournament!: Tournament;

  // #endregion
}
