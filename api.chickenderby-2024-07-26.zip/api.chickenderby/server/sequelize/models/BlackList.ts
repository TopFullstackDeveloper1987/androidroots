import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  AutoIncrement,
  Default,
  BelongsTo,
  Scopes,
} from 'sequelize-typescript';
import { Op } from 'sequelize';

import { Chicken } from './Chicken';
import { UserWallet } from './UserWallet';

@Table({
  tableName: 'blackLists',
  name: {
    singular: 'blackList',
    plural: 'blackLists',
  },
})
@Scopes(() => ({
  active: {
    where: {
      blackListedAt: {
        [Op.not]: null,
      },
    },
  },
}))
export class BlackList extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  nftContract!: string;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  tokenId!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  reporterUserName!: string;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  reporterUserWalletId!: string;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  stealerUserWalletId!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  blackListedAt!: Date;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet, { foreignKey: 'reporterUserWalletId', as: 'reporterUserWallet' })
  reporterUserWallet!: UserWallet;

  @BelongsTo(() => UserWallet, { foreignKey: 'stealerUserWalletId', as: 'stealerUserWallet' })
  stealerUserWallet!: UserWallet;

  @BelongsTo(() => Chicken, { foreignKey: 'tokenId', as: 'chicken' })
  chicken!: Chicken;

  // #endregion
}
