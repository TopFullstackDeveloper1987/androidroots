import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  HasMany,
  Default,
} from 'sequelize-typescript';

import { TrainingAbility } from './TrainingAbility';
import { UserWalletTrainingPartner } from './UserWalletTrainingPartner';
import { TrainingPartnerRarity, TrainingPartnerSpecialty } from '../../types';

@Table({
  tableName: 'trainingPartners',
  name: {
    singular: 'trainingPartner',
    plural: 'trainingPartners',
  },
})
export class TrainingPartner extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  imageUrl!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  skinName!: string;

  @AllowNull(false)
  @Default(TrainingPartnerRarity.S)
  @Column(DataType.STRING)
  rarity!: TrainingPartnerRarity;

  @AllowNull(false)
  @Default(TrainingPartnerSpecialty.Talent)
  @Column(DataType.STRING)
  speciality!: TrainingPartnerSpecialty;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  currentMaxLevel!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  finalMaxLevel!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  speedAppearance!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  staminaAppearance!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  cluckAppearance!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  intelligenceAppearance!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  talentAppearance!: number;

  @AllowNull(false)
  @Default(false)
  @Column(DataType.BOOLEAN)
  isHighlighted!: boolean;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @HasMany(() => TrainingAbility)
  trainingAbilities!: TrainingAbility[];

  @HasMany(() => UserWalletTrainingPartner)
  userWalletTrainingPartners!: UserWalletTrainingPartner[];

  // #endregion
}
