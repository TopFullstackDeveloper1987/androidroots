import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  Scopes,
} from 'sequelize-typescript';

import { Lane } from './Lane';
import { Clothing } from './Clothing';

@Table({
  tableName: 'laneClothings',
  name: {
    singular: 'laneClothing',
    plural: 'laneClothings',
  },
})
@Scopes(() => ({
  includesClothing: {
    attributes: ['laneId', 'clothingId'],
    include: [{
      attributes: ['type', 'clothingId'],
      model: Clothing,
    }],
  },
  includesClothingId: {
    attributes: ['clothingId'],
    include: [{
      attributes: ['clothingId'],
      model: Clothing,
    }],
  },
}))
export class LaneClothing extends Model {
  @PrimaryKey
  @ForeignKey(() => Lane)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  laneId!: number;

  @PrimaryKey
  @ForeignKey(() => Clothing)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  clothingId!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Lane)
  lane!: Lane;

  @BelongsTo(() => Clothing)
  clothing!: Clothing;

  // #endregion
}
