import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  AutoIncrement,
  Default,
  BelongsTo,
  HasMany,
  HasOne,
  Scopes,
  DefaultScope,
} from 'sequelize-typescript';
import * as moment from 'moment-timezone';

import config from '../../config';

import { TradeActivity } from './TradeActivity';
import { MarketItem } from './MarketItem';
import { TokenTradeActivity } from './TokenTradeActivity';
import { ChickenClothing } from './ChickenClothing';
import { BlackList } from './BlackList';
import { CoopChicken } from './CoopChicken';

import { chickenHiddenTraits } from '../../utils/constants';

import { RaceDistanceType } from '../../types/races/raceDistanceType';
import { ChickenPeckingOrder } from '../../types/chickens/chickenPeckingOrder';
import { ChickenSituation } from '../../types/chickens/chickenSituation';
import { ChickenAnimal } from '../../types/chickens/chickenAnimal';
import { ChickenTalentPreference } from '../../types/chickens/chickenTalentPreference';
import { ChickenHeritage } from '../../types/chickens/chickenHeritage';
import { ChickenStock } from '../../types/chickens/chickenStock';
import { ChickenTalent } from '../../types/chickens/chickenTalent';
import { ChickenGender } from '../../types/chickens/chickenGender';
import { ChickenBaseBody } from '../../types/chickens/chickenBaseBody';
import { ChickenStripes } from '../../types/chickens/chickenStripes';
import { ChickenBeakColor } from '../../types/chickens/chickenBeakColor';
import { ChickenBeakAccessory } from '../../types/chickens/chickenBeakAccessory';
import { ChickenCombColor } from '../../types/chickens/chickenCombColor';
import { ChickenWattleColor } from '../../types/chickens/chickenWattleColor';
import { ChickenLegs } from '../../types/chickens/chickenLegs';
import { ChickenBackground } from '../../types/chickens/chickenBackground';
import { TerrainName } from '../../types/terrains/terrainName';
import { ChickenEyesType } from '../../types/chickens/chickenEyesType';
import { ChickenStatus } from '../../types/chickens/chickenStatus';
import { UserWalletTrainingPartner } from './UserWalletTrainingPartner';

@Table({
  tableName: 'chickens',
  name: {
    singular: 'chicken',
    plural: 'chickens',
  },
})
@DefaultScope(() => ({
  attributes: {
    exclude: chickenHiddenTraits,
  },
}))
@Scopes(() => ({
  profile: {
    attributes: [
      'id',
      'name',
      'image',
      'poPoints',
      'situation',
      'races',
      'talent',
      'heritage',
      'perfection',
      'baseBody',
      'stripes',
      'stock',
      'beakAccessory',
      'eyesType',
      'beakColor',
      'combColor',
      'wattleColor',
      'legs',
      'background',
      'peckingOrder',
      'minimumPeckingOrder',
      'namedAt',
      'status',
      'generation',
      'flavorPreference',
      'clothingImage',
      'resetSituationAt',
      'resetSituationSeconds',
      'terrainPreference',
      'distancePreference',
      'talentPreference',
    ],
  },
  active: {
    where: {
      status: [ChickenStatus.Active, ChickenStatus.FusionResult],
    },
    attributes: {
      exclude: chickenHiddenTraits,
    },
  },
}))
export class Chicken extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  chknId!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  heritage!: ChickenHeritage;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  perfection!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  stock!: ChickenStock;

  @AllowNull(false)
  @Column(DataType.STRING)
  talent!: ChickenTalent;

  @AllowNull(false)
  @Column(DataType.STRING)
  image!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  gender!: ChickenGender;

  @AllowNull(false)
  @Default(ChickenAnimal.Chicken)
  @Column(DataType.STRING)
  animal!: ChickenAnimal;

  @AllowNull(false)
  @Column(DataType.STRING)
  baseBody!: ChickenBaseBody;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  stripes!: ChickenStripes;

  @AllowNull(false)
  @Column(DataType.STRING)
  eyesType!: ChickenEyesType;

  @AllowNull(false)
  @Column(DataType.STRING)
  beakColor!: ChickenBeakColor;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  beakAccessory!: ChickenBeakAccessory;

  @AllowNull(false)
  @Column(DataType.STRING)
  combColor!: ChickenCombColor;

  @AllowNull(false)
  @Column(DataType.STRING)
  wattleColor!: ChickenWattleColor;

  @AllowNull(false)
  @Column(DataType.STRING)
  legs!: ChickenLegs;

  @AllowNull(false)
  @Column(DataType.STRING)
  background!: ChickenBackground;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  races!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  entryFees!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  firsts!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  seconds!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  thirds!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 2))
  earnings!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 2))
  bawkGifts!: number;

  @AllowNull(false)
  @Default(ChickenSituation.Barn)
  @Column(DataType.STRING)
  situation!: ChickenSituation;

  @AllowNull(false)
  @Default(config.popOncePromoted)
  @Column(DataType.INTEGER)
  poPoints!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  fatherId!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  motherId!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  chickRaces!: number;

  // hidden traits
  @AllowNull(false)
  @Column(DataType.STRING)
  terrainPreference!: TerrainName;

  @AllowNull(false)
  @Column(DataType.DECIMAL(10, 2))
  consistency!: number;

  // new traits for Performance v3.0
  @AllowNull(false)
  @Default(0.2)
  @Column(DataType.DECIMAL(10, 2))
  terrainPreferenceStrength!: number;

  @AllowNull(false)
  @Default(RaceDistanceType.Short)
  @Column(DataType.STRING)
  distancePreference!: RaceDistanceType;

  @AllowNull(false)
  @Default(0.2)
  @Column(DataType.DECIMAL(10, 2))
  distancePreferenceStrength!: number;

  @AllowNull(false)
  @Default(ChickenTalentPreference.Magic)
  @Column(DataType.STRING)
  talentPreference!: ChickenTalentPreference;

  @AllowNull(false)
  @Default(0.2)
  @Column(DataType.DECIMAL(10, 2))
  talentPreferenceStrength!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  placed!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(5, 2))
  placedPercentage!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(5, 2))
  firstPlacedPercentage!: number;

  @ForeignKey(() => TradeActivity)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  lastTradeActivityId!: number;

  @ForeignKey(() => MarketItem)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  lastActiveMarketItemId!: number;

  @AllowNull(false)
  @Default(ChickenPeckingOrder.F)
  @Column(DataType.STRING)
  peckingOrder!: ChickenPeckingOrder;

  @AllowNull(false)
  @Default(ChickenPeckingOrder.F)
  @Column(DataType.STRING)
  minimumPeckingOrder!: ChickenPeckingOrder;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  namedAt!: Date;

  // new traits for fusion
  @AllowNull(false)
  @Default(ChickenStatus.Active)
  @Column(DataType.ENUM(ChickenStatus.Pending, ChickenStatus.Active, ChickenStatus.WasFused, ChickenStatus.FusionResult, ChickenStatus.Burned))
  status!: ChickenStatus;

  @ForeignKey(() => Chicken)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  materialChickenId1!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  materialChickenId2!: number;

  @AllowNull(false)
  @Default(1)
  @Column(DataType.INTEGER)
  generation!: number;

  @AllowNull(false)
  @Default('Sage')
  @Column(DataType.STRING)
  flavorPreference!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  clothingImage!: string;

  @AllowNull(false)
  @Default(ChickenHeritage.Dorking)
  @Column(DataType.STRING)
  recessiveHeritage!: ChickenHeritage;

  @AllowNull(false)
  @Default(ChickenTalent.Anvil)
  @Column(DataType.STRING)
  recessiveTalent!: ChickenTalent;

  @AllowNull(false)
  @Default(ChickenBaseBody.BaldChicken)
  @Column(DataType.STRING)
  recessiveBaseBody!: ChickenBaseBody;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  recessiveStripes!: ChickenStripes;

  @AllowNull(false)
  @Default(ChickenEyesType.Angry)
  @Column(DataType.STRING)
  recessiveEyesType!: ChickenEyesType;

  @AllowNull(false)
  @Default(ChickenBeakColor.Orange)
  @Column(DataType.STRING)
  recessiveBeakColor!: ChickenBeakColor;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  recessiveBeakAccessory!: ChickenBeakAccessory;

  @AllowNull(false)
  @Default(ChickenWattleColor.Orange)
  @Column(DataType.STRING)
  recessiveCombColor!: ChickenCombColor;

  @AllowNull(false)
  @Default(ChickenWattleColor.Orange)
  @Column(DataType.STRING)
  recessiveWattleColor!: ChickenWattleColor;

  @AllowNull(false)
  @Default(ChickenBackground.Amethyst)
  @Column(DataType.STRING)
  recessiveBackground!: ChickenBackground;

  @AllowNull(false)
  @Default('Sage')
  @Column(DataType.STRING)
  recessiveFlavorPreference!: string;

  @AllowNull(false)
  @Default(TerrainName.Dirt)
  @Column(DataType.STRING)
  recessiveTerrainPreference!: TerrainName;

  @AllowNull(false)
  @Default(4)
  @Column(DataType.DECIMAL(10, 2))
  recessiveConsistency!: number;

  @AllowNull(false)
  @Default(RaceDistanceType.Long)
  @Column(DataType.STRING)
  recessiveDistancePreference!: RaceDistanceType;

  @AllowNull(false)
  @Default(ChickenTalentPreference.Magic)
  @Column(DataType.STRING)
  recessiveTalentPreference!: ChickenTalentPreference;

  @AllowNull(false)
  @Default(ChickenLegs.legsHen)
  @Column(DataType.STRING)
  recessiveLegs!: ChickenLegs;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  familyPath!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  resetSituationAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  @Column(DataType.VIRTUAL)
  get resetSituationSeconds() {
    if (!this.resetSituationAt) {
      return null;
    }

    const nowUTC = moment.utc();
    return Math.max(moment.utc(this.resetSituationAt).diff(nowUTC, 'seconds'), 0);
  }

  // #region Associations

  @HasMany(() => TradeActivity)
  tradeActivities!: TradeActivity[];

  @BelongsTo(() => TradeActivity, { foreignKey: 'lastTradeActivityId', as: 'lastTradeActivity' })
  lastTradeActivity!: TradeActivity;

  @BelongsTo(() => MarketItem, { foreignKey: 'lastActiveMarketItemId', as: 'lastActiveMarketItem' })
  lastActiveMarketItem!: MarketItem;

  @HasMany(() => TokenTradeActivity)
  tokenTradeActivities!: TokenTradeActivity[];

  @HasMany(() => ChickenClothing)
  chickenClothings!: ChickenClothing[];

  @HasOne(() => CoopChicken)
  coopChicken!: CoopChicken;

  @HasMany(() => BlackList)
  blackLists!: BlackList[];

  @HasMany(() => UserWalletTrainingPartner)
  userWalletTrainingPartners!: UserWalletTrainingPartner[];

  // #endregion
}
