import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  Default,
} from 'sequelize-typescript';

@Table({
  tableName: 'goldenTickets',
  name: {
    singular: 'goldenTicket',
    plural: 'goldenTickets',
  },
})
export class GoldenTicket extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  amount!: number;

  @AllowNull(false)
  @Default(false)
  @Column(DataType.BOOLEAN)
  isOriginal!: boolean;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #endregion
}
