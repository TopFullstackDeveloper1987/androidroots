import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  Default,
  AutoIncrement,
  DefaultScope,
} from 'sequelize-typescript';

@Table({
  tableName: 'users',
  name: {
    singular: 'user',
    plural: 'users',
  },
})
@DefaultScope(() => ({
  attributes: {
    exclude: ['password', 'token', 'ipAddress'],
  },
}))
export class User extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  email!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  password!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  nickname!: string;

  @AllowNull(false)
  @Default('admin')
  @Column(DataType.STRING)
  role!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  token!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  ipAddress!: string;

  get roles() {
    return this.role.split(/,\s*/g);
  }

  get isPartner() {
    return this.roles.includes('partner');
  }

  get isAdmin() {
    return this.roles.includes('admin');
  }
}
