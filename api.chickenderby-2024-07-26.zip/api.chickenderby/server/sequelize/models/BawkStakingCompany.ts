import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  Default,
} from 'sequelize-typescript';

@Table({
  tableName: 'bawkStakingCompanies',
  name: {
    singular: 'bawkStakingCompany',
    plural: 'bawkStakingCompanies',
  },
})
export class BawkStakingCompany extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  imageUrl!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  // #endregion

  @Column(DataType.VIRTUAL)
  get cid() {
    return this.id - 1;
  }
}
