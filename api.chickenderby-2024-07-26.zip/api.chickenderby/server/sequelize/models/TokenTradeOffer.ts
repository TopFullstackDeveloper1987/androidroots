import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
} from 'sequelize-typescript';

import { Chicken } from './Chicken';
import { TradeOffer } from './TradeOffer';

// Only used to include Chicken for tokensAttached in TradeOffer
@Table({
  tableName: 'tokenTradeOffers',
  name: {
    singular: 'tokenTradeOffer',
    plural: 'tokenTradeOffers',
  },
})
export class TokenTradeOffer extends Model {
  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.STRING)
  nftContract!: string;

  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.INTEGER)
  tokenId!: number;

  @PrimaryKey
  @ForeignKey(() => TradeOffer)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  tradeOfferId!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Chicken, { foreignKey: 'tokenId', foreignKeyConstraint: false, constraints: false })
  chicken!: Chicken;

  @BelongsTo(() => TradeOffer)
  tradeOffer!: TradeOffer;

  // #endregion
}
