import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  Default,
  DefaultScope,
  BelongsToMany,
  HasMany,
} from 'sequelize-typescript';

import { Coop } from './Coop';
import { DiscordUserRole } from './DiscordUserRole';
import { DiscordRole } from './DiscordRole';
import { UserWalletTrainingPartner } from './UserWalletTrainingPartner';

@Table({
  tableName: 'userWallets',
  name: {
    singular: 'userWallet',
    plural: 'userWallets',
  },
})
@DefaultScope(() => ({
  attributes: {
    exclude: ['password', 'token'],
  },
}))
export class UserWallet extends Model {
  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.STRING)
  id!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  username!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  email!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  password!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  firstName!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  lastName!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  token!: string;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  raceEntries!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  entryFees!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  winnings!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 2))
  winningsJEWEL!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 2))
  bawkGifts!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  firsts!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  seconds!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  thirds!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  firebaseToken!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  discordId!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  discordInfo!: any;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  betaUserAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  confirmedTosAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  ipAddress!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  ipCountry!: string;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  coins!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  goldNuggets!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 2))
  trackEarnings!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @HasMany(() => Coop)
  coops!: Coop[];

  @HasMany(() => DiscordUserRole, {
    foreignKey: 'userWalletId',
    onDelete: 'CASCADE',
  })
  discordUserRoles!: DiscordUserRole[];

  @BelongsToMany(() => DiscordRole, () => DiscordUserRole)
  discordRoles!: DiscordRole[];

  @HasMany(() => UserWalletTrainingPartner)
  userWalletTrainingPartners!: UserWalletTrainingPartner[];

  // #endregion
}
