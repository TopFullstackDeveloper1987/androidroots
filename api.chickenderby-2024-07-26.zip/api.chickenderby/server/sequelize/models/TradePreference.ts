import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  Default,
  AutoIncrement,
} from 'sequelize-typescript';

import { UserWallet } from './UserWallet';
import { Chicken } from './Chicken';

@Table({
  tableName: 'tradePreferences',
  name: {
    singular: 'tradePreference',
    plural: 'tradePreferences',
  },
})
export class TradePreference extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  userWalletId!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  nftContract!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  tokenId!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  preference!: any;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  @BelongsTo(() => Chicken, { foreignKey: 'tokenId', as: 'chicken' })
  chicken!: Chicken;

  // #endregion
}
