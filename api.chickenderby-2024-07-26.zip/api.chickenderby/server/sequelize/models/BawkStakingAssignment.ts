import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { AssignmentStatus } from '../../types/assignments/assignmentStatus';
import { BawkStakingType, BawkType } from '../../types/bawk-staking';

import { UserWallet } from './UserWallet';
import { BawkStakingCompany } from './BawkStakingCompany';

@Table({
  tableName: 'bawkStakingAssignments',
  name: {
    singular: 'bawkStakingAssignment',
    plural: 'bawkStakingAssignments',
  },
})
export class BawkStakingAssignment extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  epoch!: number;

  @ForeignKey(() => BawkStakingCompany)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  bawkStakingCompanyId!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @AllowNull(false)
  @Column(DataType.DECIMAL(20, 6))
  amount!: number;

  @AllowNull(false)
  @Default(BawkStakingType.Stake)
  @Column(DataType.ENUM(BawkStakingType.Stake, BawkStakingType.Unstake, BawkStakingType.ClaimJewel, BawkStakingType.ClaimBawk))
  type!: BawkStakingType;

  @AllowNull(false)
  @Default(BawkType.Unclaimed)
  @Column(DataType.ENUM(BawkType.Unclaimed, BawkType.Claimed))
  bawkType!: BawkType;

  @AllowNull(false)
  @Default(AssignmentStatus.Pending)
  @Column(DataType.ENUM(AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error))
  status!: AssignmentStatus;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  signature!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  error!: any;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  transactionHash!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  txHashes!: string[];

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  data!: any;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => BawkStakingCompany)
  bawkStakingCompany!: BawkStakingCompany;

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  // #endregion
}
