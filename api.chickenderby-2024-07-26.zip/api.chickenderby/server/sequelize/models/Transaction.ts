import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  Default,
  ForeignKey,
} from 'sequelize-typescript';

import { TransactionPaidStatus } from '../../types/transactions/transactionPaidStatus';
import { TransactionType } from '../../types/transactions/transactionType';
import { TransactionCategory } from '../../types/transactions/transactionCategory';

import { UserWallet } from './UserWallet';

@Table({
  tableName: 'transactions',
  name: {
    singular: 'transaction',
    plural: 'transactions',
  },
})
export class Transaction extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  userWalletId!: string;

  @AllowNull(false)
  @Default(TransactionType.In)
  @Column(DataType.ENUM(TransactionType.In, TransactionType.Out))
  type!: TransactionType;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  transactionHash!: string;

  @AllowNull(false)
  @Column(DataType.DECIMAL(20, 6))
  amount!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  associatedObjectType!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  associatedObjectId!: string;

  @AllowNull(false)
  @Default(TransactionPaidStatus.Paid)
  @Column(DataType.ENUM(TransactionPaidStatus.Unpaid, TransactionPaidStatus.ReceiptNotReady, TransactionPaidStatus.Paid, TransactionPaidStatus.Error, TransactionPaidStatus.Postponed))
  status!: TransactionPaidStatus;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  tokenId!: number;

  @AllowNull(false)
  @Default(TransactionCategory.RaceEnter)
  @Column(DataType.STRING)
  category!: TransactionCategory;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  fromAddress!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  toAddress!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;
}
