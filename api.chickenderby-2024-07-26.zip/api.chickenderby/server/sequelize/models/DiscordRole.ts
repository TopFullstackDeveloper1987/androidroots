import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  HasMany,
  Default,
} from 'sequelize-typescript';

import { DiscordUserRole } from './DiscordUserRole';

@Table({
  tableName: 'discordRoles',
  name: {
    singular: 'discordRole',
    plural: 'discordRoles',
  },
})
export class DiscordRole extends Model {
  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.STRING)
  id!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  position!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  color!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @HasMany(() => DiscordUserRole, { foreignKey: 'discordRoleId', onDelete: 'CASCADE' })
  discordUserRoles!: DiscordUserRole[];

  // #endregion
}
