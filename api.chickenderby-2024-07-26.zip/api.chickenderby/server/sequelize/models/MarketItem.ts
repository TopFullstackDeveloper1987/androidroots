import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  HasMany,
  Default,
  DefaultScope,
  Scopes,
} from 'sequelize-typescript';
import { Op } from 'sequelize';

import { MarketplaceTradeType } from '../../types/marketplace/marketplaceTradeType';
import { MarketplaceAssignmentType } from '../../types/marketplace/marketplaceAssignmentType';
import { AssignmentStatus } from '../../types/assignments/assignmentStatus';

import { UserWallet } from './UserWallet';
import { Chicken } from './Chicken';
import { TradeOffer } from './TradeOffer';
import { TradePreference } from './TradePreference';

@Table({
  tableName: 'marketItems',
  name: {
    singular: 'marketItem',
    plural: 'marketItems',
  },
})
@DefaultScope(() => ({
  where: {
    assignmentType: {
      [Op.not]: MarketplaceAssignmentType.AutoCancelMarketItem,
    },
    [Op.not]: {
      assignmentType: MarketplaceAssignmentType.CreateMarketItem,
      assignmentStatus: [AssignmentStatus.Pending, AssignmentStatus.Error],
    },
  },
}))
@Scopes(() => ({
  active: {
    where: {
      canceledAt: null,
      soldAt: null,
    },
  },
}))
export class MarketItem extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  nftContract!: string;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  tokenId!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  seller!: string;

  @ForeignKey(() => UserWallet)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  buyer!: string;

  @AllowNull(false)
  @Column(DataType.DECIMAL(20, 6))
  price!: number;

  @AllowNull(false)
  @Default(MarketplaceTradeType.NoTrade)
  @Column(DataType.INTEGER)
  tradeType!: MarketplaceTradeType;

  @ForeignKey(() => TradePreference)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  tradePreferenceId!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  minimum!: number;

  @AllowNull(false)
  @Column(DataType.ENUM(
    MarketplaceAssignmentType.CreateMarketItem,
    MarketplaceAssignmentType.EditMarketItem,
    MarketplaceAssignmentType.CancelMarketItem,
    MarketplaceAssignmentType.PurchaseMarketItem,
    MarketplaceAssignmentType.AutoCancelMarketItem,
  ))
  assignmentType!: MarketplaceAssignmentType;

  @AllowNull(false)
  @Default(AssignmentStatus.Pending)
  @Column(DataType.ENUM(AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error))
  assignmentStatus!: AssignmentStatus;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  soldAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  canceledAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  syncedAt!: Date;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet, { foreignKey: 'seller', as: 'sellerUserWallet' })
  sellerUserWallet!: UserWallet;

  @BelongsTo(() => UserWallet, { foreignKey: 'buyer', as: 'buyerUserWallet' })
  buyerUserWallet!: UserWallet;

  @BelongsTo(() => Chicken, { foreignKey: 'tokenId', as: 'chicken' })
  chicken!: Chicken;

  @HasMany(() => TradeOffer)
  tradeOffers!: TradeOffer[];

  @BelongsTo(() => TradePreference)
  tradePreference!: TradePreference;

  // #endregion
}
