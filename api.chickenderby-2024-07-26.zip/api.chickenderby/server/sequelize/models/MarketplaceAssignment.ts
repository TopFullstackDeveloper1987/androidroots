import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { AssignmentStatus } from '../../types/assignments/assignmentStatus';
import { TransactionPaidStatus } from '../../types/transactions/transactionPaidStatus';
import { MarketplaceAssignmentType } from '../../types/marketplace/marketplaceAssignmentType';
import { MarketplaceTradeType } from '../../types/marketplace/marketplaceTradeType';

import { UserWallet } from './UserWallet';
import { MarketItem } from './MarketItem';
import { TradeOffer } from './TradeOffer';

@Table({
  tableName: 'marketplaceAssignments',
  name: {
    singular: 'marketplaceAssignment',
    plural: 'marketplaceAssignments',
  },
})
export class MarketplaceAssignment extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @AllowNull(false)
  @Column(DataType.ENUM(
    MarketplaceAssignmentType.CreateMarketItem,
    MarketplaceAssignmentType.EditMarketItem,
    MarketplaceAssignmentType.CancelMarketItem,
    MarketplaceAssignmentType.PurchaseMarketItem,
    MarketplaceAssignmentType.AutoCancelMarketItem,

    MarketplaceAssignmentType.MakeOffer,
    MarketplaceAssignmentType.EditOffer,
    MarketplaceAssignmentType.FulfillOffer,
    MarketplaceAssignmentType.CancelOrDeclineOffer,
    MarketplaceAssignmentType.AutoDeclineOffer,

    MarketplaceAssignmentType.Transfer,
  ))
  type!: MarketplaceAssignmentType;

  @ForeignKey(() => MarketItem)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  marketItemId!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  nftContract!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  tokenId!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DECIMAL(20, 6))
  price!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DECIMAL(20, 6))
  minimum!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  tradeType!: MarketplaceTradeType;

  @ForeignKey(() => TradeOffer)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  tradeOfferId!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  tokensAttached!: number[];

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  signature!: string;

  @AllowNull(false)
  @Default(AssignmentStatus.Pending)
  @Column(DataType.ENUM(AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error))
  status!: AssignmentStatus;

  @AllowNull(false)
  @Default(TransactionPaidStatus.Unpaid)
  @Column(DataType.ENUM(TransactionPaidStatus.Unpaid, TransactionPaidStatus.ReceiptNotReady, TransactionPaidStatus.Paid, TransactionPaidStatus.Error, TransactionPaidStatus.Postponed))
  paidStatus!: TransactionPaidStatus;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  error!: any;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  transactionHash!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  txHashes!: string[];

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  data!: any;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  nonce!: number;

  @AllowNull(false)
  @Default(1)
  @Column(DataType.INTEGER)
  quantity!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  @BelongsTo(() => MarketItem)
  marketItem!: MarketItem;

  @BelongsTo(() => TradeOffer)
  tradeOffer!: TradeOffer;

  // #endregion
}
