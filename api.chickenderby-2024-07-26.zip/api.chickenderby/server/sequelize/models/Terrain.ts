import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
} from 'sequelize-typescript';

import { TerrainName } from '../../types/terrains/terrainName';

@Table({
  tableName: 'terrains',
  name: {
    singular: 'terrain',
    plural: 'terrains',
  },
})
export class Terrain extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  name!: TerrainName;

  @AllowNull(false)
  @Column(DataType.STRING)
  image!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;
}
