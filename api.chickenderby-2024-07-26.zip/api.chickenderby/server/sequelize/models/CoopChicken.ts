import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  AutoIncrement,
  BelongsTo,
} from 'sequelize-typescript';

import { Coop } from './Coop';
import { Chicken } from './Chicken';

@Table({
  tableName: 'coopChickens',
  name: {
    singular: 'coopChicken',
    plural: 'coopChickens',
  },
})
export class CoopChicken extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => Coop)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  coopId!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  chickenId!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Coop)
  coop!: Coop;

  @BelongsTo(() => Chicken)
  chicken!: Chicken;

  // #endregion
}
