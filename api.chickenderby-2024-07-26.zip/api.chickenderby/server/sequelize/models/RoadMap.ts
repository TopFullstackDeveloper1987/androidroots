import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  Default,
} from 'sequelize-typescript';

@Table({
  tableName: 'roadMaps',
  name: {
    singular: 'roadMap',
    plural: 'roadMaps',
  },
})
export class RoadMap extends Model {
  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.STRING)
  id!: string;

  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  order!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  timeline!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  title!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  headline!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  link!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.TEXT)
  summary!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  imageUrl!: string;

  @AllowNull(false)
  @Default(true)
  @Column(DataType.BOOLEAN)
  isLocked!: boolean;

  @AllowNull(false)
  @Default(false)
  @Column(DataType.BOOLEAN)
  isDisabled!: boolean;

  @AllowNull(false)
  @Default(true)
  @Column(DataType.BOOLEAN)
  isNewTab!: boolean;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;
  // #endregion
}
