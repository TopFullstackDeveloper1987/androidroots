import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  AutoIncrement,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  Default,
} from 'sequelize-typescript';

import { Race } from './Race';

@Table({
  tableName: 'results',
  name: {
    singular: 'result',
    plural: 'results',
  },
})
export class Result extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => Race)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  raceId!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  raceProfiles!: any[];

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  cutscenes!: any[];

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  commentaries!: any;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.JSON)
  soundProfiles!: any[];

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Race)
  race!: Race;

  // #endregion
}
