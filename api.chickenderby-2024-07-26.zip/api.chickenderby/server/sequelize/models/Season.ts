import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  AutoIncrement,
  PrimaryKey,
  Default,
  DefaultScope,
  HasMany,
} from 'sequelize-typescript';
import { Op } from 'sequelize';

import config from '../../config';
import { SeasonStatus } from '../../types/seasons/seasonStatus';
import { SeasonRanking } from './SeasonRanking';

@Table({
  tableName: 'seasons',
  name: {
    singular: 'season',
    plural: 'seasons',
  },
})
@DefaultScope(() => ({
  where: {
    status: {
      [Op.not]: SeasonStatus.Disabled,
    },
  },
}))
export class Season extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(false)
  @Default(config.SEASON_INITIAL_POP)
  @Column(DataType.INTEGER)
  initialPoPoints!: number;

  @AllowNull(false)
  @Default(15)
  @Column(DataType.INTEGER)
  promotionPercent!: number;

  @AllowNull(false)
  @Default(15)
  @Column(DataType.INTEGER)
  demotionPercent!: number;

  @AllowNull(false)
  @Column(DataType.DATE)
  startsAt!: Date;

  @AllowNull(false)
  @Column(DataType.DATE)
  endsAt!: Date;

  @AllowNull(false)
  @Default(SeasonStatus.Pending)
  @Column(DataType.ENUM(SeasonStatus.Pending, SeasonStatus.Live, SeasonStatus.Completed, SeasonStatus.Disabled))
  status!: SeasonStatus;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.TEXT)
  description!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @HasMany(() => SeasonRanking)
  seasonRankings!: SeasonRanking[];

  // #endregion
}
