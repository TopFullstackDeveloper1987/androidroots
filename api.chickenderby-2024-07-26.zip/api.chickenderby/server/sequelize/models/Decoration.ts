import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  Default,
} from 'sequelize-typescript';

@Table({
  tableName: 'decorations',
  name: {
    singular: 'decoration',
    plural: 'decorations',
  },
})
export class Decoration extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  name!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  image!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  type!: string;

  @AllowNull(false)
  @Column(DataType.STRING)
  decorationSet!: string;

  @AllowNull(false)
  @Default(1)
  @Column(DataType.INTEGER)
  width!: number;

  @AllowNull(false)
  @Default(1)
  @Column(DataType.INTEGER)
  length!: number;

  @AllowNull(false)
  @Default(1)
  @Column(DataType.INTEGER)
  area!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  reference!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;
}
