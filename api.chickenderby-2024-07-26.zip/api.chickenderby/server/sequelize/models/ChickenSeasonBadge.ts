import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  AutoIncrement,
  BelongsTo,
} from 'sequelize-typescript';

import { Season } from './Season';
import { Chicken } from './Chicken';
import { SeasonBadge } from './SeasonBadge';

@Table({
  tableName: 'chickenSeasonBadges',
  name: {
    singular: 'chickenSeasonBadge',
    plural: 'chickenSeasonBadges',
  },
})
export class ChickenSeasonBadge extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => Season)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  seasonId!: number;

  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  chickenId!: number;

  @ForeignKey(() => SeasonBadge)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  seasonBadgeId!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Season)
  season!: Season;

  @BelongsTo(() => Chicken)
  chicken!: Chicken;

  @BelongsTo(() => SeasonBadge)
  seasonBadge!: SeasonBadge;

  // #endregion
}
