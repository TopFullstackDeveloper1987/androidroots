import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  Default,
} from 'sequelize-typescript';

@Table({
  tableName: 'bawkPresales',
  name: {
    singular: 'bawkPresale',
    plural: 'bawkPresales',
  },
})
export class BawkPresale extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  amount!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  chickenHolderSales!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  goldenTicketSales!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  publicSales!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  chickens!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  goldenTickets!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  raffles!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  won!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  lost!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.INTEGER)
  refunds!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 6))
  bawks!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  salesSyncedAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  rafflesSyncedAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  refundsSyncedAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  airdroppedAt!: Date;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  transactionHash!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #endregion
}
