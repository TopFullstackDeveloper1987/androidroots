import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
} from 'sequelize-typescript';

import { Chicken } from './Chicken';
import { TradeActivity } from './TradeActivity';

// Only used to include Chicken for tokensAttached in TradeActivity
@Table({
  tableName: 'tokenTradeActivities',
  name: {
    singular: 'tokenTradeActivity',
    plural: 'tokenTradeActivities',
  },
})
export class TokenTradeActivity extends Model {
  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.STRING)
  nftContract!: string;

  @ForeignKey(() => Chicken)
  @PrimaryKey
  @AllowNull(false)
  @Column(DataType.INTEGER)
  tokenId!: number;

  @PrimaryKey
  @ForeignKey(() => TradeActivity)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  tradeActivityId!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Chicken, { foreignKey: 'tokenId', foreignKeyConstraint: false, constraints: false })
  chicken!: Chicken;

  @BelongsTo(() => TradeActivity)
  tradeActivity!: TradeActivity;

  // #endregion
}
