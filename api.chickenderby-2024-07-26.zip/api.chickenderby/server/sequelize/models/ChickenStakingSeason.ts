import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
} from 'sequelize-typescript';

import { SeasonStatus } from '../../types/seasons/seasonStatus';

@Table({
  tableName: 'chickenStakingSeasons',
  name: {
    singular: 'chickenStakingSeason',
    plural: 'chickenStakingSeasons',
  },
})
export class ChickenStakingSeason extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @AllowNull(false)
  @Column(DataType.DATE)
  startsAt!: Date;

  @AllowNull(false)
  @Column(DataType.DATE)
  endsAt!: Date;

  @AllowNull(false)
  @Column(DataType.STRING)
  status!: SeasonStatus;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  // #endregion

  @Column(DataType.VIRTUAL)
  get epoch() {
    return this.id - 1;
  }
}
