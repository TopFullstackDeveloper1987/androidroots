import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  Scopes,
} from 'sequelize-typescript';

import { Chicken } from './Chicken';
import { Clothing } from './Clothing';
import { UserWallet } from './UserWallet';

@Table({
  tableName: 'chickenClothings',
  name: {
    singular: 'chickenClothing',
    plural: 'chickenClothings',
  },
})
@Scopes(() => ({
  includesClothing: {
    attributes: ['chickenId', 'clothingId', 'userWalletId'],
    include: [{
      attributes: ['id', 'type', 'name', 'image', 'clothingId'],
      model: Clothing,
    }],
  },
  includesClothingId: {
    attributes: ['clothingId'],
    include: [{
      attributes: ['clothingId'],
      model: Clothing,
    }],
  },
}))
export class ChickenClothing extends Model {
  @PrimaryKey
  @ForeignKey(() => Chicken)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  chickenId!: number;

  @PrimaryKey
  @ForeignKey(() => Clothing)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  clothingId!: number;

  @PrimaryKey
  @ForeignKey(() => UserWallet)
  @AllowNull(false)
  @Column(DataType.STRING)
  userWalletId!: string;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Chicken)
  chicken!: Chicken;

  @BelongsTo(() => Clothing)
  clothing!: Clothing;

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  // #endregion
}
