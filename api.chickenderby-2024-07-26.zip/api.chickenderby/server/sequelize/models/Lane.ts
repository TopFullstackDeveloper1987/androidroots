import {
  Table,
  Column,
  Model,
  DataType,
  AllowNull,
  PrimaryKey,
  AutoIncrement,
  ForeignKey,
  BelongsTo,
  HasMany,
  Default,
} from 'sequelize-typescript';

import { Race } from './Race';
import { Chicken } from './Chicken';
import { UserWallet } from './UserWallet';
import { LaneClothing } from './LaneClothing';
import { Tournament } from './Tournament';

@Table({
  tableName: 'lanes',
  name: {
    singular: 'lane',
    plural: 'lanes',
  },
})
export class Lane extends Model {
  @PrimaryKey
  @AutoIncrement
  @AllowNull(false)
  @Column(DataType.INTEGER.UNSIGNED)
  id!: number;

  @ForeignKey(() => Race)
  @AllowNull(false)
  @Column(DataType.INTEGER)
  raceId!: number;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  laneNumber!: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE)
  assignedAt!: Date;

  @ForeignKey(() => Chicken)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  chickenId!: number;

  @ForeignKey(() => UserWallet)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  userWalletId!: string;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER)
  position!: number;

  @AllowNull(false)
  @Default(0)
  @Column(DataType.DECIMAL(20, 2))
  raceEarnings!: number;

  @AllowNull(false)
  @Default(false)
  @Column(DataType.BOOLEAN)
  bonusBawk!: boolean;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.STRING)
  clothingImage!: string;

  @ForeignKey(() => Tournament)
  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER().UNSIGNED)
  tournamentId!: number;

  @Column(DataType.DATE)
  createdAt!: Date;

  @Column(DataType.DATE)
  updatedAt!: Date;

  // #region Associations

  @BelongsTo(() => Race)
  race!: Race;

  @BelongsTo(() => UserWallet)
  userWallet!: UserWallet;

  @BelongsTo(() => Chicken)
  chicken!: Chicken;

  @HasMany(() => LaneClothing)
  laneClothings!: LaneClothing[];

  // #endregion
}
