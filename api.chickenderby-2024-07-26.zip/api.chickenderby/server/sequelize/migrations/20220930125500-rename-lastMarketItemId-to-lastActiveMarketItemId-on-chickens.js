/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.renameColumn('chickens', 'lastMarketItemId', 'lastActiveMarketItemId');
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.renameColumn('chickens', 'lastActiveMarketItemId', 'lastMarketItemId');
  },
};
