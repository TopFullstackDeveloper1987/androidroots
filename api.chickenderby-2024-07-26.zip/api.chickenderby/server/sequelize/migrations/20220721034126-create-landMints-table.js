/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('landMints', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      userWalletId: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      amount: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      coupon: {
        type: Sequelize.JSON,
        allowNull: true,
        defaultValue: null,
      },
      signature: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      status: {
        allowNull: false,
        defaultValue: 'pending',
        type: Sequelize.ENUM('pending', 'success', 'error'),
      },
      error: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      transactionHash: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.STRING,
      },
      txHashes: {
        allowNull: true,
        type: Sequelize.JSON,
        defaultValue: null,
      },
      data: {
        allowNull: true,
        type: Sequelize.JSON,
        defaultValue: null,
      },
      landIds: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('landMints', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'landMintsUserWalletIds',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('landMints');
  },
};
