/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.addColumn('races', 'unlimitPO', {
    allowNull: false,
    type: Sequelize.TINYINT(1).UNSIGNED,
    defaultValue: 0,
  }, { logging: console.log }),

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => queryInterface.removeColumn('races', 'unlimitPO'),
};
