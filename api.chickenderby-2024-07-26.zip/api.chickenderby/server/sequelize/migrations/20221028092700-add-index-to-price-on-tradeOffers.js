/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addIndex('tradeOffers', ['price'], {
      name: 'idx_tradeOffers_price',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeIndex('tradeOffers', 'idx_tradeOffers_price');
  },
};
