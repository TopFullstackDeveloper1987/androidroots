/* eslint-disable no-console */

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('laneClothings', {
      laneId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      clothingId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    }, {
      logging: console.log,
    });

    await queryInterface.addConstraint('laneClothings', {
      type: 'foreign key',
      fields: ['laneId'],
      name: 'laneClothings_laneId',
      references: {
        table: 'lanes',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.addConstraint('laneClothings', {
      type: 'foreign key',
      fields: ['clothingId'],
      name: 'laneClothings_clothingId',
      references: {
        table: 'clothings',
        field: 'id',
      },
    }, {
      logging: console.log,
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('laneClothings');
  },
};
