/* eslint-disable no-console */
const TransactionType = require('../../types/transactions/transactionType');
const TransactionCategory = require('../../types/transactions/transactionCategory');

module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeConstraint('transactions', 'transactions_userWalletId');
    await queryInterface.removeIndex('transactions', 'transactions_userWalletId');

    await queryInterface.addColumn('transactions', 'fromAddress', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.addIndex('transactions', ['fromAddress'], {
      name: 'idx_transactions_fromAddress',
    });

    await queryInterface.addColumn('transactions', 'toAddress', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.addIndex('transactions', ['toAddress'], {
      name: 'idx_transactions_toAddress',
    });

    await queryInterface.addIndex('transactions', ['associatedObjectType'], {
      name: 'idx_transactions_associatedObjectType',
    });

    await queryInterface.changeColumn('transactions', 'type', {
      type: Sequelize.ENUM(TransactionType.In, TransactionType.Out),
      allowNull: false,
      defaultValue: TransactionType.In,
    }, { logging: console.log });

    await queryInterface.changeColumn('transactions', 'category', {
      type: Sequelize.ENUM(
        TransactionCategory.EntryFee,
        TransactionCategory.Payout,

        TransactionCategory.RaceEnter,
        TransactionCategory.RacePayout,
        TransactionCategory.RacePayoutFee,

        TransactionCategory.LandMintFee,

        TransactionCategory.MarketplacePurchase,
        TransactionCategory.MarketplacePurchaseFee,
        TransactionCategory.MarketplaceFulfillOffer,
        TransactionCategory.MarketplaceFulfillOfferFee,
      ),
      allowNull: false,
      defaultValue: TransactionCategory.RaceEnter,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.addConstraint('transactions', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'transactions_userWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.removeColumn('transactions', 'fromAddress');
    await queryInterface.removeColumn('transactions', 'toAddress');

    await queryInterface.removeIndex('transactions', 'idx_transactions_associatedObjectType');

    await queryInterface.changeColumn('transactions', 'type', {
      type: Sequelize.STRING,
      allowNull: false,
    }, { logging: console.log });

    await queryInterface.changeColumn('transactions', 'category', {
      type: Sequelize.ENUM(
        TransactionCategory.EntryFee,
        TransactionCategory.Payout,
      ),
      allowNull: false,
      defaultValue: TransactionCategory.EntryFee,
    }, { logging: console.log });
  },
};
