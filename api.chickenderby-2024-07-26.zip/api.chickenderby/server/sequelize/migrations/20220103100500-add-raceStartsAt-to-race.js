/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.addColumn('races', 'raceStartsAt', {
    allowNull: true,
    defaultValue: null,
    type: Sequelize.DATE,
  }, { logging: console.log }),

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => queryInterface.removeColumn('races', 'raceStartsAt'),
};
