/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('tokenTradeActivities', {
      nftContract: {
        primaryKey: true,
        type: Sequelize.STRING,
        allowNull: false,
      },
      tokenId: {
        primaryKey: true,
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      tradeActivityId: {
        primaryKey: true,
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('tokenTradeActivities', {
      type: 'foreign key',
      fields: ['tradeActivityId'],
      name: 'tokenTradeActivitiesTradeActivityId',
      references: {
        table: 'tradeActivities',
        field: 'id',
      },
    }, { logging: console.log });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('tokenTradeActivities');
  },
};
