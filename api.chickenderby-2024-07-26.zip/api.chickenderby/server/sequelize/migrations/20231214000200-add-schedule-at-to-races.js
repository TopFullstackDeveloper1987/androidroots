/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('races', 'scheduleAt', {
      type: Sequelize.DATE,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addIndex('races', ['scheduleAt'], {
      name: 'idx_races_scheduleAt',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('races', 'scheduleAt');
  },
};
