/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('landMints', 'coupon');
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('landMints', 'coupon', {
      allowNull: true,
      defaultValue: null,
      type: Sequelize.JSON,
    }, { logging: console.log });
  },
};
