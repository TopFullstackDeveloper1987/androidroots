/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('seasonRankings', 'chickenId', {
      type: Sequelize.INTEGER,
      allowNull: false,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('seasonRankings', 'chickenId', {
      type: Sequelize.STRING,
      allowNull: false,
    }, { logging: console.log });
  },
};
