/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('lanes', 'tournamentId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addConstraint('lanes', {
      type: 'foreign key',
      fields: ['tournamentId'],
      name: 'laneTournamentId',
      references: {
        table: 'tournaments',
        field: 'id',
      },
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('lanes', 'tournamentId');
  },
};
