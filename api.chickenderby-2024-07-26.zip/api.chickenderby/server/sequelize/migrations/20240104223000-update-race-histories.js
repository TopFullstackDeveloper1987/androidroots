/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('raceHistories');

    await queryInterface.createTable('raceHistories', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER.UNSIGNED,
      },
      raceId: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      chickenId: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      position: {
        type: Sequelize.INTEGER.UNSIGNED,
        allowNull: false,
      },
      raceEarnings: {
        allowNull: false,
        type: Sequelize.DECIMAL(10, 2),
        defaultValue: 0,
      },
      date: {
        type: Sequelize.DATEONLY,
        allowNull: false,
      },
      terrainId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      distance: {
        type: Sequelize.INTEGER.UNSIGNED,
        allowNull: false,
        defaultValue: 100,
      },
      capacity: {
        type: Sequelize.INTEGER.UNSIGNED,
        allowNull: false,
        defaultValue: 12,
      },
      peckingOrder: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      coinContract: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619', // WETH
      },
      feeJEWEL: {
        type: Sequelize.DECIMAL(10, 6),
        allowNull: false,
        defaultValue: 0,
      },
      positionType: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('raceHistories', {
      type: 'foreign key',
      fields: ['raceId'],
      name: 'raceHistoriesRaceId',
      references: {
        table: 'races',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.addConstraint('raceHistories', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'raceHistoriesChickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    for (const column of [
      'position',
      'raceEarnings',
      'date',
      'terrainId',
      'distance',
      'capacity',
      'peckingOrder',
      'coinContract',
      'feeJEWEL',
      'positionType',
    ]) {
      await queryInterface.addIndex('raceHistories', [column], {
        name: `idx_raceHistories_${column}`,
      });
    }
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('raceHistories', {
      raceId: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      chickenId: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      earnings: {
        allowNull: false,
        type: Sequelize.DECIMAL(10, 2),
        defaultValue: 0,
      },
      place: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.INTEGER,
      },
      poPoints: {
        allowNull: false,
        defaultValue: 0,
        type: Sequelize.INTEGER,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('raceHistories', {
      type: 'foreign key',
      fields: ['raceId'],
      name: 'raceHistoriesRaceId',
      references: {
        table: 'races',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.addConstraint('raceHistories', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'raceHistoriesChickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, {
      logging: console.log,
    });
  },
};
