/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('bawkPresales', 'bawks', {
      type: Sequelize.DECIMAL(20, 6),
      allowNull: false,
      defaultValue: 0,
    }, {
      logging: console.log,
    });

    await queryInterface.addColumn('bawkPresales', 'transactionHash', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('bawkPresales', 'userWalletId');
    await queryInterface.removeColumn('bawkPresales', 'transactionHash');
  },
};
