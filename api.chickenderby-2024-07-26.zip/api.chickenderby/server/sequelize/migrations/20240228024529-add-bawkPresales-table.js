/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('bawkPresales', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      userWalletId: {
        type: 'varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci',
        allowNull: false,
      },
      amount: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      chickenHolderSales: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      goldenTicketSales: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      publicSales: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      raffles: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      won: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      lost: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      refunds: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      salesSyncedAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      rafflesSyncedAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      refundsSyncedAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      airdroppedAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('bawkPresales');
  },
};
