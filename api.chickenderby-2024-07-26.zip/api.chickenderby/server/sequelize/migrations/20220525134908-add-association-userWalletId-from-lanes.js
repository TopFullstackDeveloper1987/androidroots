/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  async up(queryInterface, Sequelize) {
    await queryInterface.addConstraint('lanes', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'laneUserWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  async down(queryInterface, Sequelize) {
    await queryInterface.removeConstraint('lanes', 'laneUserWalletId');
  },
};
