/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('lanes', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      raceId: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      laneNumber: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      assignedAt: {
        allowNull: true,
        type: Sequelize.DATE,
        defaultValue: null,
      },
      tokenId: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      userWalletId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('lanes', {
      type: 'foreign key',
      fields: ['raceId'],
      name: 'lanesRaceId',
      references: {
        table: 'races',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('lanes', ['assignedAt'], {
      name: 'idx_lanes_assignedAt',
    });
    await queryInterface.addIndex('lanes', ['tokenId'], {
      name: 'idx_lanes_tokenId',
    });
    await queryInterface.addIndex('lanes', ['userWalletId'], {
      name: 'idx_lanes_userWalletId',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('lanes');
  },
};
