/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('lanes', 'position', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.addColumn('lanes', 'raceEarnings', {
      type: Sequelize.DECIMAL(10, 2),
      allowNull: false,
      defaultValue: 0,
    }, { logging: console.log });
    await queryInterface.addColumn('lanes', 'bonusBawk', {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('lanes', 'position');
    await queryInterface.removeColumn('lanes', 'raceEarnings');
    await queryInterface.removeColumn('lanes', 'bonusBawk');
  },
};
