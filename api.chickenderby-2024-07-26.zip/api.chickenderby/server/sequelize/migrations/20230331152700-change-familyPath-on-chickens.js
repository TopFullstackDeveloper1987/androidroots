/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeIndex('chickens', 'idx_chickens_familyPath');
    await queryInterface.changeColumn('chickens', 'familyPath', {
      type: Sequelize.TEXT('2048'),
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('chickens', 'familyPath', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.addIndex('chickens', ['familyPath'], {
      name: 'idx_chickens_familyPath',
    });
  },
};
