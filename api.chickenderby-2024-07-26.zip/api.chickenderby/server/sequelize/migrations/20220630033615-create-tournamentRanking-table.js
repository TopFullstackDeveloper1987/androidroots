/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('tournamentRankings', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      tournamentId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      tokenId: {
        type: Sequelize.STRING,
        allowNull: false,
        index: true,
      },
      userWalletId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      peckingOrder: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
        index: true,
      },
      position: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      points: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      races: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      first: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      second: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      third: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      fourth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      fifth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      sixth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      seventh: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      eighth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      ninth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      tenth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      eleventh: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      twelfth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('tournamentRankings', {
      type: 'foreign key',
      fields: ['tournamentId'],
      name: 'tournamentRakingTournamentId',
      references: {
        table: 'tournaments',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('tournamentRankings', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'tournamentRankingsUserWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('tournamentRankings', ['tokenId'], {
      name: 'idx_tournamentRankings_tokenId',
    });

    await queryInterface.addIndex('tournamentRankings', ['peckingOrder'], {
      name: 'idx_tournamentRankings_peckingOrder',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('tournamentRankings');
  },
};
