/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('autoRacePools', 'coinContract', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619', // WETH
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('autoRacePools', 'coinContract');
  },
};
