/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('tokenTradeOffers', {
      nftContract: {
        primaryKey: true,
        type: Sequelize.STRING,
        allowNull: false,
      },
      tokenId: {
        primaryKey: true,
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      tradeOfferId: {
        primaryKey: true,
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('tokenTradeOffers', {
      type: 'foreign key',
      fields: ['tradeOfferId'],
      name: 'tokenTradeOffersTradeOfferId',
      references: {
        table: 'tradeOffers',
        field: 'id',
      },
    }, { logging: console.log });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('tokenTradeOffers');
  },
};
