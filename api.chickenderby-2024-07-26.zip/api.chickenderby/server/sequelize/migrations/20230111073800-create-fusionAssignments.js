/* eslint-disable no-console */

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('fusionAssignments', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      userWalletId: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      materialChickenId1: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      materialChickenId2: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      fusedChickenId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      serums: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      status: {
        allowNull: false,
        defaultValue: 'pending',
        type: Sequelize.ENUM('pending', 'success', 'error'),
      },
      paidStatus: {
        allowNull: false,
        defaultValue: 'unpaid',
        type: Sequelize.ENUM('unpaid', 'receiptNotReady', 'paid', 'error', 'postponed'),
      },
      chickenData: {
        allowNull: false,
        type: Sequelize.JSON,
      },
      error: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      transactionHash: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      txHashes: {
        type: Sequelize.JSON,
        allowNull: true,
        defaultValue: null,
      },
      nonce: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      data: {
        type: Sequelize.JSON,
        allowNull: true,
        defaultValue: null,
      },
      syncedAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('fusionAssignments', {
      type: 'foreign key',
      fields: ['materialChickenId1'],
      name: 'fusionAssignmentsMaterialChickenId1',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, { logging: console.log });
    await queryInterface.addConstraint('fusionAssignments', {
      type: 'foreign key',
      fields: ['materialChickenId2'],
      name: 'fusionAssignmentsMaterialChickenId2',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('fusionAssignments', ['userWalletId'], {
      name: 'idx_fusionAssignments_userWalletId',
    });
    await queryInterface.addIndex('fusionAssignments', ['status'], {
      name: 'idx_fusionAssignments_status',
    });
    await queryInterface.addIndex('fusionAssignments', ['paidStatus'], {
      name: 'idx_fusionAssignments_paidStatus',
    });
    await queryInterface.addIndex('fusionAssignments', ['syncedAt'], {
      name: 'idx_fusionAssignments_syncedAt',
    });
    await queryInterface.addIndex('fusionAssignments', ['updatedAt'], {
      name: 'idx_fusionAssignments_updatedAt',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('fusionAssignments');
  },
};
