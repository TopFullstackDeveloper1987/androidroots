module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('races', 'prizePool', {
      allowNull: false,
      type: Sequelize.DECIMAL(10, 2),
      defaultValue: 0,
    // eslint-disable-next-line no-console
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('races', 'prizePool');
  },
};
