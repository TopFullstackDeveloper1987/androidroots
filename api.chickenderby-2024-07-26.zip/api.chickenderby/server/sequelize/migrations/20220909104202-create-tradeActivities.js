/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('tradeActivities', {
      id: { // The same as marketItemId
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      tradeOfferId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      nftContract: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      tokenId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      seller: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      buyer: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      price: {
        type: Sequelize.DECIMAL(10, 6),
        allowNull: false,
      },
      offeredNftContract: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      tokensAttached: {
        type: Sequelize.JSON,
        allowNull: true,
        defaultValue: null,
      },
      marketFeePercent: {
        type: Sequelize.DECIMAL(10, 6),
        allowNull: false,
        defaultValue: 0,
      },
      timestamp: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('tradeActivities', {
      type: 'foreign key',
      fields: ['id'],
      name: 'tradeActivitiesMarketItemId',
      references: {
        table: 'marketItems',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('tradeActivities', {
      type: 'foreign key',
      fields: ['tradeOfferId'],
      name: 'tradeActivitiesTradeOfferId',
      references: {
        table: 'tradeOffers',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('tradeActivities', {
      type: 'foreign key',
      fields: ['seller'],
      name: 'tradeActivitiesSeller',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('tradeActivities', {
      type: 'foreign key',
      fields: ['buyer'],
      name: 'tradeActivitiesBuyer',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('tradeActivities', ['nftContract'], {
      name: 'idx_tradeActivities_nftContract',
    });
    await queryInterface.addIndex('tradeActivities', ['tokenId'], {
      name: 'idx_tradeActivities_tokenId',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('tradeActivities');
  },
};
