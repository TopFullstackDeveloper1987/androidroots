/* eslint-disable no-console */
const MarketplaceAssignmentType = require('../../types/marketplace/marketplaceAssignmentType');

module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('marketplaceAssignments', 'type', {
      type: Sequelize.ENUM(
        MarketplaceAssignmentType.CreateMarketItem,
        MarketplaceAssignmentType.EditMarketItem,
        MarketplaceAssignmentType.CancelMarketItem,
        MarketplaceAssignmentType.PurchaseMarketItem,

        MarketplaceAssignmentType.MakeOffer,
        MarketplaceAssignmentType.EditOffer,
        MarketplaceAssignmentType.FulfillOffer,
        MarketplaceAssignmentType.CancelOrDeclineOffer,
        MarketplaceAssignmentType.AutoDeclineOffer,
        MarketplaceAssignmentType.AutoCancelMarketItem,

        MarketplaceAssignmentType.Transfer,
      ),
      allowNull: false,
    }, { logging: console.log });

    await queryInterface.changeColumn('marketItems', 'assignmentType', {
      type: Sequelize.ENUM(
        MarketplaceAssignmentType.CreateMarketItem,
        MarketplaceAssignmentType.EditMarketItem,
        MarketplaceAssignmentType.CancelMarketItem,
        MarketplaceAssignmentType.PurchaseMarketItem,
        MarketplaceAssignmentType.AutoCancelMarketItem,
      ),
      allowNull: false,
    }, { logging: console.log });

    await queryInterface.addIndex('marketplaceAssignments', ['transactionHash'], {
      name: 'idx_marketplaceAssignments_transactionHash',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('marketplaceAssignments', 'type', {
      type: Sequelize.ENUM(
        MarketplaceAssignmentType.CreateMarketItem,
        MarketplaceAssignmentType.EditMarketItem,
        MarketplaceAssignmentType.CancelMarketItem,
        MarketplaceAssignmentType.PurchaseMarketItem,

        MarketplaceAssignmentType.MakeOffer,
        MarketplaceAssignmentType.EditOffer,
        MarketplaceAssignmentType.FulfillOffer,
        MarketplaceAssignmentType.CancelOrDeclineOffer,
        MarketplaceAssignmentType.AutoDeclineOffer,
      ),
      allowNull: false,
    }, { logging: console.log });

    await queryInterface.changeColumn('marketItems', 'assignmentType', {
      type: Sequelize.ENUM(
        MarketplaceAssignmentType.CreateMarketItem,
        MarketplaceAssignmentType.EditMarketItem,
        MarketplaceAssignmentType.CancelMarketItem,
        MarketplaceAssignmentType.PurchaseMarketItem,
      ),
      allowNull: false,
    }, { logging: console.log });

    await queryInterface.removeIndex('marketplaceAssignments', 'idx_marketplaceAssignments_transactionHash');
  },
};
