module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addConstraint('results', {
      type: 'foreign key',
      fields: ['raceId'],
      name: 'resultsRaceId',
      references: {
        table: 'races',
        field: 'id',
      },
    });

    await queryInterface.addConstraint('coops', {
      type: 'foreign key',
      fields: ['userId'],
      name: 'coopsUserId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    });

    await queryInterface.addIndex('races', ['raceType'], {
      name: 'idx_races_raceType',
    });
    await queryInterface.addIndex('races', ['raceCapacity'], {
      name: 'idx_races_raceCapacity',
    });
    await queryInterface.addIndex('races', ['currentCapacity'], {
      name: 'idx_races_currentCapacity',
    });
    await queryInterface.addIndex('races', ['raceStartsAt'], {
      name: 'idx_races_raceStartsAt',
    });
    await queryInterface.addIndex('races', ['paidStatus'], {
      name: 'idx_races_paidStatus',
    });
    await queryInterface.addIndex('races', ['prizePool'], {
      name: 'idx_races_prizePool',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeConstraint('results', 'resultsRaceId');
    await queryInterface.removeConstraint('coops', 'coopsUserId');

    await queryInterface.removeIndex('races', 'idx_races_raceType');
    await queryInterface.removeIndex('races', 'idx_races_raceCapacity');
    await queryInterface.removeIndex('races', 'idx_races_currentCapacity');
    await queryInterface.removeIndex('races', 'idx_races_raceStartsAt');
    await queryInterface.removeIndex('races', 'idx_races_paidStatus');
    await queryInterface.removeIndex('races', 'idx_races_prizePool');
  },
};
