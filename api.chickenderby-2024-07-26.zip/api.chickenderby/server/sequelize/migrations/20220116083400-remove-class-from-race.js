/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('races', 'class');
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('races', 'class', {
      allowNull: true,
      defaultValue: null,
      type: Sequelize.STRING,
    }, { logging: console.log });
  },
};
