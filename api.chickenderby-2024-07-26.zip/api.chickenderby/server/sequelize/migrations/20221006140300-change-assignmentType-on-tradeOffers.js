/* eslint-disable no-console */
const MarketplaceAssignmentType = require('../../types/marketplace/marketplaceAssignmentType');

module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('tradeOffers', 'assignmentType', {
      type: Sequelize.ENUM(
        MarketplaceAssignmentType.MakeOffer,
        MarketplaceAssignmentType.EditOffer,
        MarketplaceAssignmentType.FulfillOffer,
        MarketplaceAssignmentType.CancelOrDeclineOffer,
        MarketplaceAssignmentType.AutoDeclineOffer,
      ),
      allowNull: false,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('tradeOffers', 'assignmentType', {
      type: Sequelize.ENUM(
        MarketplaceAssignmentType.MakeOffer,
        MarketplaceAssignmentType.EditOffer,
        MarketplaceAssignmentType.FulfillOffer,
        MarketplaceAssignmentType.CancelOrDeclineOffer,
      ),
      allowNull: false,
    }, { logging: console.log });
  },
};
