/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('autoRacePools', 'fee', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('autoRacePools', 'prizePool', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('chickens', 'entryFees', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('chickens', 'earnings', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 2),
    }, { logging: console.log });
    await queryInterface.changeColumn('chickens', 'bawkGifts', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 2),
    }, { logging: console.log });

    await queryInterface.changeColumn('lanes', 'raceEarnings', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 2),
    }, { logging: console.log });

    await queryInterface.changeColumn('marketItems', 'price', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('marketItems', 'minimum', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('marketplaceAssignments', 'price', {
      allowNull: true,
      defaultValue: null,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('marketplaceAssignments', 'minimum', {
      allowNull: true,
      defaultValue: null,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('races', 'fee', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('races', 'prizePool', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('races', 'feeJEWEL', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 2),
    }, { logging: console.log });
    await queryInterface.changeColumn('races', 'prizePoolJEWEL', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 2),
    }, { logging: console.log });

    await queryInterface.changeColumn('raceHistories', 'raceEarnings', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 2),
    }, { logging: console.log });
    await queryInterface.changeColumn('raceHistories', 'feeJEWEL', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('tradeActivities', 'price', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('tradeActivities', 'marketFeePercent', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('tradeOffers', 'price', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('transactions', 'amount', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('userWallets', 'entryFees', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('userWallets', 'winnings', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('userWallets', 'winningsJEWEL', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 2),
    }, { logging: console.log });
    await queryInterface.changeColumn('userWallets', 'bawkGifts', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 2),
    }, { logging: console.log });
    await queryInterface.changeColumn('userWallets', 'trackEarnings', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 2),
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('autoRacePools', 'fee', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('autoRacePools', 'prizePool', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('chickens', 'entryFees', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('chickens', 'earnings', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 2),
    }, { logging: console.log });
    await queryInterface.changeColumn('chickens', 'bawkGifts', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 2),
    }, { logging: console.log });

    await queryInterface.changeColumn('lanes', 'raceEarnings', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 2),
    }, { logging: console.log });

    await queryInterface.changeColumn('marketItems', 'price', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('marketItems', 'minimum', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('marketplaceAssignments', 'price', {
      allowNull: true,
      defaultValue: null,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('marketplaceAssignments', 'minimum', {
      allowNull: true,
      defaultValue: null,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('races', 'fee', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('races', 'prizePool', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('races', 'feeJEWEL', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 2),
    }, { logging: console.log });
    await queryInterface.changeColumn('races', 'prizePoolJEWEL', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 2),
    }, { logging: console.log });

    await queryInterface.changeColumn('raceHistories', 'raceEarnings', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 2),
    }, { logging: console.log });
    await queryInterface.changeColumn('raceHistories', 'feeJEWEL', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('tradeActivities', 'price', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('tradeActivities', 'marketFeePercent', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('tradeOffers', 'price', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('transactions', 'amount', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('userWallets', 'entryFees', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('userWallets', 'winnings', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 6),
    }, { logging: console.log });
    await queryInterface.changeColumn('userWallets', 'winningsJEWEL', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 2),
    }, { logging: console.log });
    await queryInterface.changeColumn('userWallets', 'bawkGifts', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 2),
    }, { logging: console.log });
    await queryInterface.changeColumn('userWallets', 'trackEarnings', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 2),
    }, { logging: console.log });
  },
};
