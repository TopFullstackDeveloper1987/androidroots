/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'fee', {
      allowNull: false,
      type: Sequelize.DECIMAL(10, 6),
      defaultValue: 0,
    }, { logging: console.log });

    await queryInterface.changeColumn('races', 'prizePool', {
      allowNull: false,
      type: Sequelize.DECIMAL(10, 6),
      defaultValue: 0,
    }, { logging: console.log });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'fee', {
      allowNull: false,
      type: Sequelize.DECIMAL(10, 2),
      defaultValue: 0,
    }, { logging: console.log });

    await queryInterface.changeColumn('races', 'prizePool', {
      allowNull: false,
      type: Sequelize.DECIMAL(10, 2),
      defaultValue: 0,
    }, { logging: console.log });
  },
};
