/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('races', 'allowedUserWalletIds', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('races', 'allowedChickenIds', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addIndex('races', ['allowedUserWalletIds'], {
      name: 'idx_races_allowedUserWalletIds',
    });
    await queryInterface.addIndex('races', ['allowedChickenIds'], {
      name: 'idx_races_allowedChickenIds',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('races', 'allowedUserWalletIds');
    await queryInterface.removeColumn('races', 'allowedChickenIds');
  },
};
