/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('trainingPartners', 'skinName', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
      after: 'name',
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('trainingPartners', 'skinName');
  },
};
