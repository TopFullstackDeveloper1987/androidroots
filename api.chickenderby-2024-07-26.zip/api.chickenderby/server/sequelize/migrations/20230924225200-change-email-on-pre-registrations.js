/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('preRegistrations', 'email', {
      type: Sequelize.STRING,
      allowNull: false,
      unique: true,
    }, { logging: console.log });

    await queryInterface.addIndex('preRegistrations', ['email'], {
      name: 'idx_preRegistrations_email',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('preRegistrations', 'email', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },
};
