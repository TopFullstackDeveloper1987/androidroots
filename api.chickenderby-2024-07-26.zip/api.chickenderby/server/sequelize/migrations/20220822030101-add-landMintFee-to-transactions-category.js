/* eslint-disable no-console */

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.changeColumn('transactions', 'category', {
      allowNull: false,
      type: Sequelize.ENUM('entryFee', 'payout', 'landMintFee'),
    }, { logging: console.log });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.changeColumn('transactions', 'category', {
      allowNull: false,
      type: Sequelize.ENUM('entryFee', 'payout'),
    }, { logging: console.log });
  },
};
