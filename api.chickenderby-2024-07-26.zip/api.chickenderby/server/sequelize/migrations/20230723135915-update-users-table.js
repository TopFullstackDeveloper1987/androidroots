/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('users', 'reset');
    await queryInterface.removeColumn('users', 'isVerified');
    await queryInterface.removeColumn('users', 'status');

    await queryInterface.changeColumn('users', 'role', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'admin',
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('users', 'reset', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('users', 'isVerified', {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    }, { logging: console.log });

    await queryInterface.addColumn('users', 'status', {
      type: Sequelize.INTEGER,
    }, { logging: console.log });

    await queryInterface.changeColumn('users', 'role', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 0,
    }, { logging: console.log });
  },
};
