/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('coopChickens', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      coopId: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      tokenId: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('coopChickens', {
      type: 'foreign key',
      fields: ['coopId'],
      name: 'coopChickens_coopId',
      references: {
        table: 'coops',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('coopChickens', ['tokenId'], {
      name: 'idx_coopChickens_tokenId',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('coopChickens');
  },
};
