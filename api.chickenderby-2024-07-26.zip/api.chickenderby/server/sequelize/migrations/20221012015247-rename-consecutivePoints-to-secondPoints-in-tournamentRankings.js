module.exports = {
  up: async (queryInterface) => {
    await queryInterface.renameColumn('tournamentRankings', 'consecutivePoints', 'secondPoints');
  },

  down: async (queryInterface) => {
    await queryInterface.renameColumn('tournamentRankings', 'secondPoints', 'consecutivePoints');
  },
};
