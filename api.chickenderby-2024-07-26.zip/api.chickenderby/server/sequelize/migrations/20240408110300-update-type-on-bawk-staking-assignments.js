/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('bawkStakingAssignments', 'type', {
      allowNull: false,
      defaultValue: 'stake',
      type: Sequelize.ENUM('stake', 'unstake', 'claim'),
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('bawkStakingAssignments', 'type', {
      allowNull: false,
      defaultValue: 'stake',
      type: Sequelize.ENUM('stake', 'unstake'),
    }, { logging: console.log });
  },
};
