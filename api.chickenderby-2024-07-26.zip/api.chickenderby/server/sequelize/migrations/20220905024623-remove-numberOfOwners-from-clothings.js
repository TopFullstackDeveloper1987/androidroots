/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('clothings', 'numberOfOwners');
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('clothings', 'numberOfOwners', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 5,
    }, { logging: console.log });
  },
};
