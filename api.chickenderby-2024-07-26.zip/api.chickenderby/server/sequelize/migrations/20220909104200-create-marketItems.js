/* eslint-disable no-console */
const MarketplaceTradeType = require('../../types/marketplace/marketplaceTradeType');
const AssignmentStatus = require('../../types/assignments/assignmentStatus');
const MarketplaceAssignmentType = require('../../types/marketplace/marketplaceAssignmentType');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('marketItems', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      nftContract: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      tokenId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      seller: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      buyer: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      price: {
        type: Sequelize.DECIMAL(10, 6),
        allowNull: false,
      },
      tradeType: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: MarketplaceTradeType.NoTrade,
      },
      tradePreferenceId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      minimum: {
        type: Sequelize.DECIMAL(10, 6),
        allowNull: false,
        defaultValue: 0,
      },
      assignmentType: {
        type: Sequelize.ENUM(
          MarketplaceAssignmentType.CreateMarketItem,
          MarketplaceAssignmentType.EditMarketItem,
          MarketplaceAssignmentType.CancelMarketItem,
          MarketplaceAssignmentType.PurchaseMarketItem,
        ),
        allowNull: false,
      },
      assignmentStatus: {
        type: Sequelize.ENUM(AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error),
        allowNull: false,
        defaultValue: AssignmentStatus.Pending,
      },
      soldAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      canceledAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      syncedAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('marketItems', {
      type: 'foreign key',
      fields: ['seller'],
      name: 'marketItemsSeller',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('marketItems', {
      type: 'foreign key',
      fields: ['buyer'],
      name: 'marketItemsBuyer',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('marketItems', {
      type: 'foreign key',
      fields: ['tradePreferenceId'],
      name: 'marketItemstradePreferenceId',
      references: {
        table: 'tradePreferences',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('marketItems', ['nftContract'], {
      name: 'idx_marketItems_nftContract',
    });
    await queryInterface.addIndex('marketItems', ['tokenId'], {
      name: 'idx_marketItems_tokenId',
    });
    await queryInterface.addIndex('marketItems', ['assignmentType'], {
      name: 'idx_marketItems_assignmentType',
    });
    await queryInterface.addIndex('marketItems', ['assignmentStatus'], {
      name: 'idx_marketItems_assignmentStatus',
    });
    await queryInterface.addIndex('marketItems', ['updatedAt'], {
      name: 'idx_marketItems_updatedAt',
    });
    await queryInterface.addIndex('marketItems', ['soldAt'], {
      name: 'idx_marketItems_soldAt',
    });
    await queryInterface.addIndex('marketItems', ['canceledAt'], {
      name: 'idx_marketItems_canceledAt',
    });
    await queryInterface.addIndex('marketItems', ['syncedAt'], {
      name: 'idx_marketItems_syncedAt',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('marketItems');
  },
};
