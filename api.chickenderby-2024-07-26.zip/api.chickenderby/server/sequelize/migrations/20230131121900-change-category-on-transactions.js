/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('transactions', 'category', {
      type: Sequelize.ENUM(
        'entryFee',
        'payout',
        'raceEnter',
        'racePayout',
        'racePayoutFee',
        'landMintFee',
        'marketplacePurchase',
        'marketplacePurchaseFee',
        'marketplaceFulfillOffer',
        'marketplaceFulfillOfferFee',
        'fuse',
        'breed',
      ),
      allowNull: false,
      defaultValue: 'raceEnter',
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('transactions', {
      category: ['fuse', 'breed'],
    });
    await queryInterface.changeColumn('transactions', 'category', {
      type: Sequelize.ENUM(
        'entryFee',
        'payout',
        'raceEnter',
        'racePayout',
        'racePayoutFee',
        'landMintFee',
        'marketplacePurchase',
        'marketplacePurchaseFee',
        'marketplaceFulfillOffer',
        'marketplaceFulfillOfferFee',
      ),
      allowNull: false,
      defaultValue: 'raceEnter',
    }, { logging: console.log });
  },
};
