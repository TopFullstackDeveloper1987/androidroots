/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('raceAssignments', 'signature', {
      allowNull: false,
      type: Sequelize.TEXT,
    }, { logging: console.log });
    await queryInterface.changeColumn('marketplaceAssignments', 'signature', {
      type: Sequelize.TEXT,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('raceAssignments', 'signature', {
      allowNull: false,
      type: Sequelize.STRING,
    }, { logging: console.log });
    await queryInterface.changeColumn('marketplaceAssignments', 'signature', {
      allowNull: false,
      type: Sequelize.STRING,
    }, { logging: console.log });
  },
};
