/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('seasonRankings', 'perfection', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 100,
    }, { logging: console.log });
    await queryInterface.addIndex('seasonRankings', ['perfection'], {
      name: 'idx_seasonRankings_perfection',
    });

    await queryInterface.addColumn('seasonRankings', 'heritageOrder', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 100,
    }, { logging: console.log });
    await queryInterface.addIndex('seasonRankings', ['heritageOrder'], {
      name: 'idx_seasonRankings_heritageOrder',
    });

    await queryInterface.addColumn('seasonRankings', 'stockOrder', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 100,
    }, { logging: console.log });
    await queryInterface.addIndex('seasonRankings', ['stockOrder'], {
      name: 'idx_seasonRankings_stockOrder',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('seasonRankings', 'perfection');
    await queryInterface.removeColumn('seasonRankings', 'heritageOrder');
    await queryInterface.removeColumn('seasonRankings', 'stockOrder');
  },
};
