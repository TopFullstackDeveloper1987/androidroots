/* eslint-disable no-console */
module.exports = {
  // 'value "9223372036854778000" is out of range for type bigint'
  up: async (queryInterface, Sequelize) => queryInterface.changeColumn('raceHistories', 'earnings', {
    allowNull: false,
    type: Sequelize.DECIMAL(10, 2),
    defaultValue: 0,
  }, { logging: console.log }),

  down: async (queryInterface, Sequelize) => queryInterface.changeColumn('raceHistories', 'earnings', {
    allowNull: false,
    type: Sequelize.BIGINT,
  }, { logging: console.log }),
};
