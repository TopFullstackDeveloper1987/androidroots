/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('nonces', {
      id: {
        type: Sequelize.STRING,
        allowNull: false,
        primaryKey: true,
      },
      nonce: {
        type: Sequelize.UUID,
        allowNull: false,
        defaultValue: Sequelize.UUIDV4,
      },
      expiresAt: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      message: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addIndex('nonces', ['nonce'], {
      name: 'idx_nonces_nonce',
    });
    await queryInterface.addIndex('nonces', ['expiresAt'], {
      name: 'idx_nonces_expiresAt',
    });

    await queryInterface.removeColumn('userWallets', 'nonce');
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('nonces');

    await queryInterface.addColumn('userWallets', 'nonce', {
      type: Sequelize.INTEGER.UNSIGNED,
      allowNull: false,
      defaultValue: () => Math.floor(Math.random() * 1000000), // Initialize with a random nonce
    }, { logging: console.log });
  },
};
