/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('trainingPartners', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      imageUrl: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      rarity: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: 'S',
      },
      speciality: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: 'Talent',
      },
      currentMaxLevel: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      finalMaxLevel: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      speedAppearance: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      staminaAppearance: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      cluckAppearance: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      intelligenceAppearance: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      talentAppearance: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      isHighlighted: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('trainingPartners');
  },
};
