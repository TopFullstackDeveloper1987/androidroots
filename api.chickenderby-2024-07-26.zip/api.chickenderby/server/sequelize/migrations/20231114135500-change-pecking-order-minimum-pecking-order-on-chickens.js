/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('chickens', 'peckingOrder', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'F',
    }, { logging: console.log });

    await queryInterface.changeColumn('chickens', 'minimumPeckingOrder', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'F',
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('chickens', 'peckingOrder', {
      type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'E', 'CHICK'),
      allowNull: false,
      defaultValue: 'E',
    }, { logging: console.log });

    await queryInterface.changeColumn('chickens', 'minimumPeckingOrder', {
      type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'E', 'CHICK'),
      allowNull: false,
      defaultValue: 'E',
    }, { logging: console.log });
  },
};
