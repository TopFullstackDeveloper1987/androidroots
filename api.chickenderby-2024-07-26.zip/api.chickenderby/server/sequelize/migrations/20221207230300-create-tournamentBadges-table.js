/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('tournamentBadges', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      tournamentId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      prizePosition: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      image: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      toolTip: {
        type: Sequelize.TEXT,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('tournamentBadges', {
      type: 'foreign key',
      fields: ['tournamentId'],
      name: 'tournamentBadgesTournamentId',
      references: {
        table: 'tournaments',
        field: 'id',
      },
    }, { logging: console.log });
    await queryInterface.addIndex('tournamentBadges', ['prizePosition'], {
      name: 'idx_tournamentBadges_prizePosition',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('tournamentBadges');
  },
};
