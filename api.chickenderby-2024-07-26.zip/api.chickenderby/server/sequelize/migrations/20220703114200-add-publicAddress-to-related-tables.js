/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    // in MySQL transaction doesn't work with column changes, it works only for updating records
    // Postgres works though
    // coops
    await queryInterface.addColumn('coops', 'publicAddress', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });

    // lanes
    await queryInterface.addColumn('lanes', 'publicAddress', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });

    // raceAssignments
    await queryInterface.addColumn('raceAssignments', 'publicAddress', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });

    // transactions
    await queryInterface.addColumn('transactions', 'publicAddress', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });

    // tournamentRankings
    await queryInterface.addColumn('tournamentRankings', 'publicAddress', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });

    // userWallets
    await queryInterface.addIndex('userWallets', ['token'], {
      name: 'idx_userWallets_token',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    // coops
    await queryInterface.removeColumn('coops', 'publicAddress');

    // lanes
    await queryInterface.removeColumn('lanes', 'publicAddress');

    // raceAssignments
    await queryInterface.removeColumn('raceAssignments', 'publicAddress');

    // transactions
    await queryInterface.removeColumn('transactions', 'publicAddress');

    // tournamentRankings
    await queryInterface.removeColumn('tournamentRankings', 'publicAddress');

    // userWallets
    await queryInterface.removeIndex('userWallets', 'idx_userWallets_token');
  },
};
