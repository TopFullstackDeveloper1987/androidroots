/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('coinPresaleAssignments', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      userWalletId: {
        allowNull: false,
        type: 'varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci',
      },
      tokensBought: {
        allowNull: false,
        type: Sequelize.DECIMAL(20, 6),
      },
      currency: {
        allowNull: false,
        defaultValue: 0,
        type: Sequelize.TINYINT(1).UNSIGNED,
      },
      amountPaid: {
        allowNull: false,
        type: Sequelize.DECIMAL(20, 6),
      },
      timestamp: {
        allowNull: false,
        type: Sequelize.INTEGER.UNSIGNED,
      },
      eventTransactionHash: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      status: {
        allowNull: false,
        defaultValue: 'pending',
        type: Sequelize.ENUM('pending', 'success', 'error'),
      },
      signature: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.STRING,
      },
      error: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      transactionHash: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.STRING,
      },
      txHashes: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      data: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('coinPresaleAssignments', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'coinPresaleAssignmentsUserWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    for (const index of ['tokensBought', 'currency', 'amountPaid', 'timestamp', 'eventTransactionHash', 'status']) {
      await queryInterface.addIndex('coinPresaleAssignments', [index], {
        name: `idx_coinPresaleAssignments_${index}`,
      });
    }
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('coinPresaleAssignments');
  },
};
