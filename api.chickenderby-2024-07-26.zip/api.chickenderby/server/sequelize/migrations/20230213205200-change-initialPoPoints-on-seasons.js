/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('seasons', 'initialPoPoints', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 1000,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('seasons', 'initialPoPoints', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 100,
    }, { logging: console.log });
  },
};
