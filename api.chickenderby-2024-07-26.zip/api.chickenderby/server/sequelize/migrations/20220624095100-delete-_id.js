/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('coops', '_id');
    await queryInterface.removeColumn('races', '_id');
    await queryInterface.removeColumn('settings', '_id');
    await queryInterface.removeColumn('users', '_id');
    await queryInterface.removeColumn('userWallets', '_id');
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('coops', '_id', {
      type: Sequelize.UUID,
      defaultValue: Sequelize.UUIDV4,
    }, { logging: console.log });
    await queryInterface.addColumn('races', '_id', {
      type: Sequelize.UUID,
      defaultValue: Sequelize.UUIDV4,
    }, { logging: console.log });
    await queryInterface.addColumn('settings', '_id', {
      type: Sequelize.UUID,
      defaultValue: Sequelize.UUIDV4,
    }, { logging: console.log });
    await queryInterface.addColumn('users', '_id', {
      type: Sequelize.UUID,
      defaultValue: Sequelize.UUIDV4,
    }, { logging: console.log });
    await queryInterface.addColumn('userWallets', '_id', {
      type: Sequelize.UUID,
      defaultValue: Sequelize.UUIDV4,
    }, { logging: console.log });
  },
};
