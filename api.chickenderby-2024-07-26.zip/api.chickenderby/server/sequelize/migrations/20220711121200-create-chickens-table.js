module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('chickens', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      chknId: {
        type: Sequelize.STRING,
        unique: true,
        allowNull: false,
      },
      heritage: { // nft
        type: Sequelize.STRING,
        allowNull: false,
      },
      perfection: { // nft
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      stock: { // nft
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      talent: { // nft
        type: Sequelize.STRING,
        allowNull: false,
      },
      image: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      gender: { // nft
        type: Sequelize.STRING,
        allowNull: false,
      },
      animal: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: 'Chicken',
      },
      baseBody: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      stripes: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      eyesType: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      beakColor: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      beakAccessory: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      combColor: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      wattleColor: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      legs: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      background: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      races: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      firsts: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      seconds: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      thirds: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      earnings: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0,
      },
      situation: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: 'Barn',
      },
      poPoints: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 10,
      },
      hair: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      necklace: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      glasses: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      jacket: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      shoes: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      // -- Hidden ---
      fatherID: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      motherID: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      name: {
        type: 'varchar(255) CHARACTER SET utf8mb4', // hack to enable emoji
        allowNull: true,
        defaultValue: null,
      },
      chickRaces: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },

      // hidden traits
      terrainPreference: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      consistency: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false,
      },

      // new traits for Performance v3.0
      terrainPreferenceStrength: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0.2,
      },
      distancePreference: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: 'Short',
      },
      distancePreferenceStrength: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0.2,
      },
      talentPreference: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: 'Magic',
      },
      talentPreferenceStrength: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0.2,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('chickens');
  },
};
