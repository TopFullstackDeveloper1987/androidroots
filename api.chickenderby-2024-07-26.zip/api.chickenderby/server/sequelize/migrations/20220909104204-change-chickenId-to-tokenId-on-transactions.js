/* eslint-disable no-unused-vars */

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.renameColumn('transactions', 'chickenId', 'tokenId');
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.renameColumn('transactions', 'tokenId', 'chickenId');
  },
};
