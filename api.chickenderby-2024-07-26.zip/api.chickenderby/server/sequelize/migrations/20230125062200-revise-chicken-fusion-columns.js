/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('chickens', 'fusedChickenId');
    await queryInterface.addColumn('chickens', 'materialChickenId1', {
      allowNull: true,
      type: Sequelize.INTEGER,
      defaultValue: null,
    // eslint-disable-next-line no-console
    }, { logging: console.log });
    await queryInterface.addColumn('chickens', 'materialChickenId2', {
      allowNull: true,
      type: Sequelize.INTEGER,
      defaultValue: null,
    // eslint-disable-next-line no-console
    }, { logging: console.log });

    await queryInterface.renameColumn('chickens', 'fatherID', 'fatherId');
    await queryInterface.renameColumn('chickens', 'motherID', 'motherId');

    await queryInterface.addColumn('chickens', 'familyPath', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    // eslint-disable-next-line no-console
    }, { logging: console.log });

    await queryInterface.addConstraint('chickens', {
      type: 'foreign key',
      fields: ['materialChickenId1'],
      name: 'chickensMaterialChickenId1',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('chickens', {
      type: 'foreign key',
      fields: ['materialChickenId2'],
      name: 'chickensMaterialChickenId2',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('chickens', {
      type: 'foreign key',
      fields: ['fatherId'],
      name: 'chickensFatherId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('chickens', {
      type: 'foreign key',
      fields: ['motherId'],
      name: 'chickensMotherId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('chickens', ['familyPath'], {
      name: 'idx_chickens_familyPath',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('chickens', 'fusedChickenId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.removeColumn('chickens', 'materialChickenId1');
    await queryInterface.removeColumn('chickens', 'materialChickenId2');

    await queryInterface.removeConstraint('chickens', 'chickensFatherId');
    await queryInterface.removeConstraint('chickens', 'chickensMotherId');
    await queryInterface.renameColumn('chickens', 'fatherId', 'fatherID');
    await queryInterface.renameColumn('chickens', 'motherId', 'motherID');

    await queryInterface.removeColumn('chickens', 'familyPath');
  },
};
