/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('races', 'status', {
      allowNull: false,
      type: Sequelize.ENUM('open', 'scheduled', 'in_progress', 'finished', 'canceled'),
      defaultValue: 'open',
    }, { logging: console.log });

    await queryInterface.addIndex('races', ['status'], {
      name: 'idx_races_status',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('races', 'status');
  },
};
