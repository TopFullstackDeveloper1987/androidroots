/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('userWalletTrainingPartners', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      userWalletId: {
        type: 'varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci',
        allowNull: false,
      },
      trainingPartnerId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      chickenId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      currentLevel: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 1,
      },
      currentMaxLevel: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      mode: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: 'single-pull',
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('userWalletTrainingPartners', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'userWalletTrainingPartnersUserWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('userWalletTrainingPartners', {
      type: 'foreign key',
      fields: ['trainingPartnerId'],
      name: 'userWalletTrainingPartnersTrainingPartnerId',
      references: {
        table: 'trainingPartners',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('userWalletTrainingPartners', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'userWalletTrainingPartnersChickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('userWalletTrainingPartners', ['mode'], {
      name: 'idx_userWalletTrainingPartners_mode',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('userWalletTrainingPartners');
  },
};
