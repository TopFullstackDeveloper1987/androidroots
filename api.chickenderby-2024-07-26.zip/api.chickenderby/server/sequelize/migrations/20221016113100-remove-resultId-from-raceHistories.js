/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('raceHistories', 'resultId');
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('raceHistories', 'resultId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },
};
