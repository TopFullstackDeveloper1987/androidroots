/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('chickenTournamentBadges', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      chickenId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      tournamentBadgeId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('chickenTournamentBadges', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'chickenTournamentBadgesChickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, { logging: console.log });
    await queryInterface.addConstraint('chickenTournamentBadges', {
      type: 'foreign key',
      fields: ['tournamentBadgeId'],
      name: 'chickenTournamentBadgesTournamentBadgeId',
      references: {
        table: 'tournamentBadges',
        field: 'id',
      },
    }, { logging: console.log });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('chickenTournamentBadges');
  },
};
