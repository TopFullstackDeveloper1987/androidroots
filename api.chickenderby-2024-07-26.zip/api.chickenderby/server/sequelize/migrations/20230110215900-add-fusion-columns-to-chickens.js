/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('chickens', 'fusion', {
      type: Sequelize.ENUM('Was Fused', 'Fusion Result'),
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'fusedChickenId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'generation', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 1,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'flavorPreference', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Sage',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveHeritage', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Dorking',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveTalent', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Anvil',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveBaseBody', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Bald Chicken',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveStripes', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveEyesType', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Angry',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveBeakColor', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Orange',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveBeakAccessory', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveCombColor', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Orange',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveWattleColor', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Orange',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveBackground', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Amethyst',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveFlavorPreference', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Sage',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveTerrainPreference', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Dirt',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveConsistency', {
      type: Sequelize.DECIMAL(10, 2),
      allowNull: false,
      defaultValue: 4,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveDistancePreference', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Long',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveTalentPreference', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'Magic',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'recessiveLegs', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'legsHen',
    }, { logging: console.log });

    await queryInterface.addConstraint('chickens', {
      type: 'foreign key',
      fields: ['fusedChickenId'],
      name: 'chickensFusedChickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('chickens', 'fusion');
    await queryInterface.removeColumn('chickens', 'fusedChickenId');
    await queryInterface.removeColumn('chickens', 'generation');
    await queryInterface.removeColumn('chickens', 'flavorPreference');
    await queryInterface.removeColumn('chickens', 'recessiveHeritage');
    await queryInterface.removeColumn('chickens', 'recessiveTalent');
    await queryInterface.removeColumn('chickens', 'recessiveBaseBody');
    await queryInterface.removeColumn('chickens', 'recessiveStripes');
    await queryInterface.removeColumn('chickens', 'recessiveEyesType');
    await queryInterface.removeColumn('chickens', 'recessiveBeakColor');
    await queryInterface.removeColumn('chickens', 'recessiveBeakAccessory');
    await queryInterface.removeColumn('chickens', 'recessiveCombColor');
    await queryInterface.removeColumn('chickens', 'recessiveWattleColor');
    await queryInterface.removeColumn('chickens', 'recessiveBackground');
    await queryInterface.removeColumn('chickens', 'recessiveFlavorPreference');
    await queryInterface.removeColumn('chickens', 'recessiveTerrainPreference');
    await queryInterface.removeColumn('chickens', 'recessiveConsistency');
    await queryInterface.removeColumn('chickens', 'recessiveDistancePreference');
    await queryInterface.removeColumn('chickens', 'recessiveTalentPreference');
    await queryInterface.removeColumn('chickens', 'recessiveLegs');
  },
};
