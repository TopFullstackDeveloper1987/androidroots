/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeIndex('races', 'idx_races_allowedUserWalletIds');
    await queryInterface.removeIndex('races', 'idx_races_allowedChickenIds');

    await queryInterface.changeColumn('races', 'allowedUserWalletIds', {
      type: Sequelize.TEXT,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.changeColumn('races', 'allowedChickenIds', {
      type: Sequelize.TEXT,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'allowedUserWalletIds', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.changeColumn('races', 'allowedChickenIds', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addIndex('races', ['allowedUserWalletIds'], {
      name: 'idx_races_allowedUserWalletIds',
    });
    await queryInterface.addIndex('races', ['allowedChickenIds'], {
      name: 'idx_races_allowedChickenIds',
    });
  },
};
