/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('races', 'myArrayField');
    await queryInterface.removeColumn('races', 'lane');
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('races', 'myArrayField', {
      allowNull: true,
      defaultValue: null,
      type: Sequelize.JSON,
    }, { logging: console.log });

    await queryInterface.addColumn('races', 'lane', {
      allowNull: true,
      defaultValue: null,
      type: Sequelize.JSON,
    }, { logging: console.log });
  },
};
