/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.renameColumn('races', 'feeUSD', 'feeJEWEL');
    await queryInterface.renameColumn('races', 'prizePoolUSD', 'prizePoolJEWEL');

    await queryInterface.renameColumn('userWallets', 'winningsUSD', 'winningsJEWEL');
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.renameColumn('races', 'feeJEWEL', 'feeUSD');
    await queryInterface.renameColumn('races', 'prizePoolJEWEL', 'prizePoolUSD');

    await queryInterface.renameColumn('userWallets', 'winningsJEWEL', 'winningsUSD');
  },
};
