module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.changeColumn('races', 'fee', {
    allowNull: false,
    type: Sequelize.DECIMAL(10, 2),
    defaultValue: 0,
  // eslint-disable-next-line no-console
  }, { logging: console.log }),

  down: async (queryInterface, Sequelize) => queryInterface.changeColumn('races', 'fee', {
    allowNull: false,
    type: Sequelize.INTEGER,
  // eslint-disable-next-line no-console
  }, { logging: console.log }),
};
