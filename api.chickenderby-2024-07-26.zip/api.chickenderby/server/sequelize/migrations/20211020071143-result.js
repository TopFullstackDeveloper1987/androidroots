module.exports = {
  up: async (queryInterface, DataTypes) => {
    await queryInterface.createTable('results', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER,
      },
      gameInfo: {
        type: DataTypes.TEXT,
        get() {
          return JSON.parse(this.getDataValue('gameInfo'));
        },
        set(val) {
          return this.setDataValue('gameInfo', JSON.stringify(val));
        },
      },
      raceId: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE,
      },
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, DataTypes) => {
    await queryInterface.dropTable('results');
  },
};
