/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('roadMaps', 'isNewTab', {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('roadMaps', 'isNewTab');
  },
};
