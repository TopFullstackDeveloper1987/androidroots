/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('transactions', 'transactionHash', {
      allowNull: true,
      type: Sequelize.STRING,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('transactions', 'status', {
      allowNull: false,
      type: Sequelize.STRING,
      defaultValue: 'success',
    }, { logging: console.log });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('transactions', 'transactionHash', {
      allowNull: false,
      type: Sequelize.STRING,
    }, { logging: console.log });

    await queryInterface.removeColumn('transactions', 'status');
  },
};
