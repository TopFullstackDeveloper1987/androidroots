/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('marketplaceAssignments', 'tokenId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('marketplaceAssignments', 'tokenId', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },
};
