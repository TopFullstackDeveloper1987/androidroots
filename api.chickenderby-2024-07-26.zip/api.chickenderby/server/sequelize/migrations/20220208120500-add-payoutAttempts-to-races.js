/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('races', 'payoutAttempts', {
      type: Sequelize.INTEGER(11).UNSIGNED,
      allowNull: false,
      defaultValue: 0,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('races', 'payoutAttempts');
  },
};
