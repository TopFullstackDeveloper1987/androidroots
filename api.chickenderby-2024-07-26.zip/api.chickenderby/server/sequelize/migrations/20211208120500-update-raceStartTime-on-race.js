/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'raceStartTime', {
      allowNull: false,
      type: Sequelize.INTEGER,
      defaultValue: 900,
    }, { logging: console.log });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'raceStartTime', {
      allowNull: false,
      type: Sequelize.STRING,
      defaultValue: '00:00:00',
    }, { logging: console.log });
  },
};
