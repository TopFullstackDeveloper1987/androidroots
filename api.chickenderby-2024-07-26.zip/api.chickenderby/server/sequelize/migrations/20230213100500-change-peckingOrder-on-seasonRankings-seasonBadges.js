/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('seasonRankings', 'peckingOrder', {
      type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'E', 'CHICK'),
      allowNull: false,
      defaultValue: 'E',
    }, { logging: console.log });

    await queryInterface.changeColumn('seasonBadges', 'peckingOrder', {
      type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'E', 'CHICK'),
      allowNull: false,
      defaultValue: 'E',
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('seasonRankings', 'peckingOrder', {
      type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'CHICK'),
      allowNull: false,
      defaultValue: 'CHICK',
    }, { logging: console.log });

    await queryInterface.changeColumn('seasonBadges', 'peckingOrder', {
      type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'CHICK'),
      allowNull: false,
      defaultValue: 'CHICK',
    }, { logging: console.log });
  },
};
