/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'currentCapacity', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 0,
    }, { logging: console.log });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'currentCapacity', {
      type: Sequelize.INTEGER,
      allowNull: false,
    }, { logging: console.log });
  },
};
