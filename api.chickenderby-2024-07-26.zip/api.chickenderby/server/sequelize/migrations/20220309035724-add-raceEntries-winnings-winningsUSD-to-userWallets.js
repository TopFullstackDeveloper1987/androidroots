/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('userWallets', 'raceEntries', {
      allowNull: false,
      type: Sequelize.INTEGER,
      defaultValue: 0,
    }, { logging: console.log });

    await queryInterface.addColumn('userWallets', 'winnings', {
      allowNull: false,
      type: Sequelize.DECIMAL(10, 6),
      defaultValue: 0,
    }, { logging: console.log });

    await queryInterface.addColumn('userWallets', 'winningsUSD', {
      allowNull: false,
      type: Sequelize.DECIMAL(10, 2),
      defaultValue: 0,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('userWallets', 'raceEntries');
    await queryInterface.removeColumn('userWallets', 'winnings');
    await queryInterface.removeColumn('userWallets', 'winningsUSD');
  },
};
