/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('userWallets', 'firsts', {
      type: Sequelize.INTEGER.UNSIGNED,
      allowNull: false,
      defaultValue: 0,
    }, { logging: console.log });

    await queryInterface.addColumn('userWallets', 'seconds', {
      type: Sequelize.INTEGER.UNSIGNED,
      allowNull: false,
      defaultValue: 0,
    }, { logging: console.log });

    await queryInterface.addColumn('userWallets', 'thirds', {
      type: Sequelize.INTEGER.UNSIGNED,
      allowNull: false,
      defaultValue: 0,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('userWallets', 'firsts');
    await queryInterface.removeColumn('userWallets', 'seconds');
    await queryInterface.removeColumn('userWallets', 'thirds');
  },
};
