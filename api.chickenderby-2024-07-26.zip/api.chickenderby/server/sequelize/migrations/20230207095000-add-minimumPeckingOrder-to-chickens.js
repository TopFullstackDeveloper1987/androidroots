/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('chickens', 'minimumPeckingOrder', {
      type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'E', 'CHICK'),
      allowNull: false,
      defaultValue: 'E',
    }, { logging: console.log });

    await queryInterface.changeColumn('chickens', 'peckingOrder', {
      type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'E', 'CHICK'),
      allowNull: false,
      defaultValue: 'E',
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('chickens', 'minimumPeckingOrder');

    await queryInterface.changeColumn('chickens', 'peckingOrder', {
      type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'CHICK'),
      allowNull: false,
      defaultValue: 'D',
    }, { logging: console.log });
  },
};
