/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('userWallets', 'betaUserAt', {
      type: Sequelize.DATE,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addIndex('userWallets', ['betaUserAt'], {
      name: 'idx_userWallets_betaUserAt',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('userWallets', 'betaUserAt');
  },
};
