/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('coinPresaleAssignments', 'amountPaid', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('coinPresaleAssignments', 'timestamp', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.INTEGER.UNSIGNED,
    }, { logging: console.log });

    await queryInterface.changeColumn('coinPresaleAssignments', 'eventTransactionHash', {
      allowNull: true,
      defaultValue: null,
      type: Sequelize.STRING,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('coinPresaleAssignments', 'amountPaid', {
      allowNull: false,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });

    await queryInterface.changeColumn('coinPresaleAssignments', 'timestamp', {
      allowNull: false,
      type: Sequelize.INTEGER.UNSIGNED,
    }, { logging: console.log });

    await queryInterface.changeColumn('coinPresaleAssignments', 'eventTransactionHash', {
      allowNull: false,
      type: Sequelize.STRING,
    }, { logging: console.log });
  },
};
