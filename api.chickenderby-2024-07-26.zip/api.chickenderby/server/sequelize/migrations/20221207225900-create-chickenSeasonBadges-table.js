/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('chickenSeasonBadges', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      seasonId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      chickenId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      seasonBadgeId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('chickenSeasonBadges', {
      type: 'foreign key',
      fields: ['seasonId'],
      name: 'chickenSeasonBadgesSeasonId',
      references: {
        table: 'seasons',
        field: 'id',
      },
    }, { logging: console.log });
    await queryInterface.addConstraint('chickenSeasonBadges', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'chickenSeasonBadgesChickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, { logging: console.log });
    await queryInterface.addConstraint('chickenSeasonBadges', {
      type: 'foreign key',
      fields: ['seasonBadgeId'],
      name: 'chickenSeasonBadgesSeasonBadgeId',
      references: {
        table: 'seasonBadges',
        field: 'id',
      },
    }, { logging: console.log });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('chickenSeasonBadges');
  },
};
