module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addIndex('raceAssignments', ['updatedAt'], {
      name: 'idx_raceAssignments_updatedAt',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeIndex('raceAssignments', 'idx_raceAssignments_updatedAt');
  },
};
