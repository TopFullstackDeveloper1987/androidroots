/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('chickens', 'isPromotionZone');
    await queryInterface.removeColumn('chickens', 'isDemotionZone');
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('chickens', 'isPromotionZone', {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'isDemotionZone', {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    }, { logging: console.log });
  },
};
