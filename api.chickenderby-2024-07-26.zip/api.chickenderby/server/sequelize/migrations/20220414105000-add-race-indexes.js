module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addIndex('races', ['name'], {
      name: 'idx_races_name',
    });
    await queryInterface.addIndex('races', ['peckingOrder'], {
      name: 'idx_races_peckingOrder',
    });
    await queryInterface.addIndex('races', ['distance'], {
      name: 'idx_races_distance',
    });
    await queryInterface.addIndex('races', ['unlimitPO'], {
      name: 'idx_races_unlimitPO',
    });

    await queryInterface.addIndex('terrains', ['name'], {
      name: 'idx_terrains_name',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeIndex('races', 'idx_races_name');
    await queryInterface.removeIndex('races', 'idx_races_peckingOrder');
    await queryInterface.removeIndex('races', 'idx_races_distance');
    await queryInterface.removeIndex('races', 'idx_races_unlimitPO');

    await queryInterface.removeIndex('terrains', 'idx_terrains_name');
  },
};
