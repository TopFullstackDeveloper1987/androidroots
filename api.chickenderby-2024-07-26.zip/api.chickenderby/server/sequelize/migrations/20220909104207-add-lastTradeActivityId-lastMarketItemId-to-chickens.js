/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('chickens', 'lastTradeActivityId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.addColumn('chickens', 'lastMarketItemId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addConstraint('chickens', {
      type: 'foreign key',
      fields: ['lastTradeActivityId'],
      name: 'chickensLastTradeActivityId',
      references: {
        table: 'tradeActivities',
        field: 'id',
      },
    }, { logging: console.log });
    await queryInterface.addConstraint('chickens', {
      type: 'foreign key',
      fields: ['lastMarketItemId'],
      name: 'chickensLastMarketItemId',
      references: {
        table: 'marketItems',
        field: 'id',
      },
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('chickens', 'lastTradeActivityId');
    await queryInterface.removeColumn('chickens', 'lastMarketItemId');
  },
};
