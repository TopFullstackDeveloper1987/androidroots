/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    const chickens = await queryInterface.rawSelect('chickens', {
      plain: false,
      limit: 10,
    }, []);
    if (chickens.length === 0) {
      throw new Error('Please run the seeders for chickens first');
    }

    await queryInterface.renameColumn('coopChickens', 'tokenId', 'chickenId');
    await queryInterface.changeColumn('coopChickens', 'chickenId', {
      type: Sequelize.INTEGER,
      allowNull: false,
    }, { logging: console.log });
    await queryInterface.addConstraint('coopChickens', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'coopChickens_chickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('lanes', 'tokenId', 'chickenId');
    await queryInterface.changeColumn('lanes', 'chickenId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.addConstraint('lanes', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'lanes_chickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('raceAssignments', 'tokenId', 'chickenId');
    await queryInterface.changeColumn('raceAssignments', 'chickenId', {
      type: Sequelize.INTEGER,
      allowNull: false,
    }, { logging: console.log });
    await queryInterface.addConstraint('raceAssignments', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'raceAssignments_chickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('raceHistories', 'tokenId', 'chickenId');
    await queryInterface.changeColumn('raceHistories', 'chickenId', {
      type: Sequelize.INTEGER,
      allowNull: false,
    }, { logging: console.log });
    await queryInterface.addConstraint('raceHistories', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'raceHistories_chickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('tournamentRankings', 'tokenId', 'chickenId');
    await queryInterface.changeColumn('tournamentRankings', 'chickenId', {
      type: Sequelize.INTEGER,
      allowNull: false,
    }, { logging: console.log });
    await queryInterface.addConstraint('tournamentRankings', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'tournamentRankings_chickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('transactions', 'tokenId', 'chickenId');
    await queryInterface.changeColumn('transactions', 'chickenId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.addConstraint('transactions', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'transactions_chickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, {
      logging: console.log,
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeConstraint('coopChickens', 'coopChickens_chickenId');
    await queryInterface.changeColumn('coopChickens', 'chickenId', {
      type: Sequelize.STRING,
      allowNull: false,
    }, { logging: console.log });
    await queryInterface.renameColumn('coopChickens', 'chickenId', 'tokenId');

    await queryInterface.removeConstraint('lanes', 'lanes_chickenId');
    await queryInterface.changeColumn('lanes', 'chickenId', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.renameColumn('lanes', 'chickenId', 'tokenId');

    await queryInterface.removeConstraint('raceAssignments', 'raceAssignments_chickenId');
    await queryInterface.changeColumn('raceAssignments', 'chickenId', {
      type: Sequelize.STRING,
      allowNull: false,
    }, { logging: console.log });
    await queryInterface.renameColumn('raceAssignments', 'chickenId', 'tokenId');

    await queryInterface.removeConstraint('raceHistories', 'raceHistories_chickenId');
    await queryInterface.changeColumn('raceHistories', 'chickenId', {
      type: Sequelize.STRING,
      allowNull: false,
    }, { logging: console.log });
    await queryInterface.renameColumn('raceHistories', 'chickenId', 'tokenId');

    await queryInterface.removeConstraint('tournamentRankings', 'tournamentRankings_chickenId');
    await queryInterface.changeColumn('tournamentRankings', 'chickenId', {
      type: Sequelize.STRING,
      allowNull: false,
    }, { logging: console.log });
    await queryInterface.renameColumn('tournamentRankings', 'chickenId', 'tokenId');

    await queryInterface.removeConstraint('transactions', 'transactions_chickenId');
    await queryInterface.changeColumn('transactions', 'chickenId', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.renameColumn('transactions', 'chickenId', 'tokenId');
  },
};
