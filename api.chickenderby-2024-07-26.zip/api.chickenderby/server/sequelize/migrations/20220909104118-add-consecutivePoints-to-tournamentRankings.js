/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('tournamentRankings', 'consecutivePoints', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 0,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('tournamentRankings', 'consecutivePoints');
  },
};
