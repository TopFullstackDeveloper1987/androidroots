/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'createdAt', {
      allowNull: false,
      type: Sequelize.DATE,
      defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
    }, { logging: console.log });

    await queryInterface.changeColumn('races', 'updatedAt', {
      allowNull: false,
      type: Sequelize.DATE,
      defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
    }, { logging: console.log });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'createdAt', {
      allowNull: false,
      type: Sequelize.DATE,
    }, { logging: console.log });

    await queryInterface.changeColumn('races', 'updatedAt', {
      allowNull: false,
      type: Sequelize.DATE,
    }, { logging: console.log });
  },
};
