module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addIndex('races', ['feeUSD'], {
      name: 'idx_races_feeUSD',
    });
    await queryInterface.addIndex('races', ['prizePoolUSD'], {
      name: 'idx_races_prizePoolUSD',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeIndex('races', 'idx_races_feeUSD');
    await queryInterface.removeIndex('races', 'idx_races_prizePoolUSD');
  },
};
