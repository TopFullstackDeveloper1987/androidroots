/* eslint-disable no-console */
const AssignmentStatus = require('../../types/assignments/assignmentStatus');
const MarketplaceAssignmentType = require('../../types/marketplace/marketplaceAssignmentType');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('tradeOffers', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      marketItemId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      nftContract: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      offerMaker: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      tokensAttached: {
        type: Sequelize.JSON,
        allowNull: true,
        defaultValue: null,
      },
      price: {
        type: Sequelize.DECIMAL(10, 6),
        allowNull: false,
        defaultValue: 0,
      },
      assignmentType: {
        type: Sequelize.ENUM(
          MarketplaceAssignmentType.MakeOffer,
          MarketplaceAssignmentType.EditOffer,
          MarketplaceAssignmentType.FulfillOffer,
          MarketplaceAssignmentType.CancelOrDeclineOffer,
        ),
        allowNull: false,
      },
      assignmentStatus: {
        type: Sequelize.ENUM(AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error),
        allowNull: false,
        defaultValue: AssignmentStatus.Pending,
      },
      canceledAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      declinedAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      fulfilledAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      syncedAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      reason: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('tradeOffers', {
      type: 'foreign key',
      fields: ['marketItemId'],
      name: 'tradeOffersMarketItemId',
      references: {
        table: 'marketItems',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('tradeOffers', {
      type: 'foreign key',
      fields: ['offerMaker'],
      name: 'tradeOffersOfferMaker',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('tradeOffers', ['nftContract'], {
      name: 'idx_tradeOffers_nftContract',
    });
    await queryInterface.addIndex('tradeOffers', ['assignmentType'], {
      name: 'idx_tradeOffers_assignmentType',
    });
    await queryInterface.addIndex('tradeOffers', ['assignmentStatus'], {
      name: 'idx_tradeOffers_assignmentStatus',
    });
    await queryInterface.addIndex('tradeOffers', ['updatedAt'], {
      name: 'idx_tradeOffers_updatedAt',
    });
    await queryInterface.addIndex('tradeOffers', ['canceledAt'], {
      name: 'idx_tradeOffers_canceledAt',
    });
    await queryInterface.addIndex('tradeOffers', ['declinedAt'], {
      name: 'idx_tradeOffers_declinedAt',
    });
    await queryInterface.addIndex('tradeOffers', ['fulfilledAt'], {
      name: 'idx_tradeOffers_fulfilledAt',
    });
    await queryInterface.addIndex('tradeOffers', ['syncedAt'], {
      name: 'idx_tradeOffers_syncedAt',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('tradeOffers');
  },
};
