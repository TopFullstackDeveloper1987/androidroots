module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('raceHistories', {
      raceId: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      resultId: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      tokenId: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.STRING,
      },
      earnings: {
        allowNull: false,
        defaultValue: 0,
        type: Sequelize.BIGINT,
      },
      place: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.INTEGER,
      },
      poPoints: {
        allowNull: false,
        defaultValue: 0,
        type: Sequelize.INTEGER,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('raceHistories', {
      type: 'foreign key',
      fields: ['raceId'],
      name: 'raceHistoriesRaceId',
      references: {
        table: 'races',
        field: 'id',
      },
    });

    await queryInterface.addConstraint('raceHistories', {
      type: 'foreign key',
      fields: ['resultId'],
      name: 'raceHistoriesResultId',
      references: {
        table: 'results',
        field: 'id',
      },
    });

    await queryInterface.addIndex('raceHistories', ['tokenId'], {
      name: 'idx_raceHistories_tokenId',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('raceHistories');
  },
};
