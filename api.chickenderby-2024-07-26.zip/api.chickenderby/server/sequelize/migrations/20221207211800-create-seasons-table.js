module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('seasons', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      initialPoPoints: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 100,
      },
      promotionPercent: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 20,
      },
      demotionPercent: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 20,
      },
      startsAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      endsAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      status: {
        type: Sequelize.ENUM('pending', 'live', 'completed', 'disabled'),
        allowNull: false,
        defaultValue: 'pending',
      },
      description: {
        type: Sequelize.TEXT,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addIndex('seasons', ['startsAt'], {
      name: 'idx_seasons_startsAt',
    });
    await queryInterface.addIndex('seasons', ['endsAt'], {
      name: 'idx_seasons_endsAt',
    });
    await queryInterface.addIndex('seasons', ['status'], {
      name: 'idx_seasons_status',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('seasons');
  },
};
