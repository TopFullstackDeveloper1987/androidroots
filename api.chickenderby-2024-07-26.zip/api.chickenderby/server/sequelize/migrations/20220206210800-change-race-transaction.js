/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('races', 'raceType');

    await queryInterface.removeColumn('races', 'chickenId');

    await queryInterface.changeColumn('transactions', 'status', {
      allowNull: false,
      type: Sequelize.ENUM('unpaid', 'receiptNotReady', 'paid', 'error', 'postponed'),
      defaultValue: 'paid',
    }, { logging: console.log });

    await queryInterface.changeColumn('races', 'paidStatus', {
      allowNull: false,
      // add '0', '1', '2', '3', '4' to migrate from the old database
      type: Sequelize.ENUM('unpaid', 'receiptNotReady', 'paid', 'error', 'postponed', '0', '1', '2', '3', '4'),
      defaultValue: 'unpaid',
    }, { logging: console.log });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('races', 'raceType', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 1,
    }, { logging: console.log });

    await queryInterface.addColumn('races', 'chickenId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.changeColumn('transactions', 'status', {
      allowNull: false,
      // add 'success' to migrate from the old database
      type: Sequelize.ENUM('unpaid', 'receiptNotReady', 'paid', 'error', 'postponed', 'success'),
      defaultValue: 'paid',
    }, { logging: console.log });

    await queryInterface.changeColumn('races', 'paidStatus', {
      allowNull: false,
      type: Sequelize.TINYINT(1).UNSIGNED,
      defaultValue: 0,
    }, { logging: console.log });
  },
};
