module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('autoRacePools', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11).UNSIGNED,
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      peckingOrder: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      terrainId: {
        type: Sequelize.INTEGER(11).UNSIGNED,
        allowNull: true,
        defaultValue: null,
      },
      distance: {
        type: Sequelize.INTEGER(11).UNSIGNED,
        allowNull: false,
        defaultValue: 100,
      },
      maxCapacity: {
        type: Sequelize.INTEGER(11).UNSIGNED,
        allowNull: false,
        defaultValue: 12,
      },
      location: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      minimumStartDelay: {
        type: Sequelize.INTEGER(11).UNSIGNED,
        defaultValue: 3,
      },
      startTime: {
        type: Sequelize.INTEGER(11).UNSIGNED,
        defaultValue: 900,
      },
      fee: {
        type: Sequelize.DECIMAL(10, 6),
        allowNull: false,
        defaultValue: 0,
      },
      prizePool: {
        type: Sequelize.DECIMAL(10, 6),
        allowNull: false,
        defaultValue: 0,
      },
      type: {
        allowNull: false,
        type: Sequelize.ENUM('manual', 'automatic'),
        defaultValue: 'manual',
      },
      group: {
        allowNull: false,
        type: Sequelize.INTEGER(11).UNSIGNED,
        defaultValue: 1,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('autoRacePools');
  },
};
