/* eslint-disable no-console */

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('chickenClothings', {
      clothingId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      chickenId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      userWalletId: {
        type: Sequelize.STRING,
        allowNull: false,
        primaryKey: true,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    }, {
      logging: console.log,
    });

    await queryInterface.addConstraint('chickenClothings', {
      type: 'foreign key',
      fields: ['chickenId'],
      name: 'chickenClothings_chickenId',
      references: {
        table: 'chickens',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.addConstraint('chickenClothings', {
      type: 'foreign key',
      fields: ['clothingId'],
      name: 'chickenClothings_clothingId',
      references: {
        table: 'clothings',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.addConstraint('chickenClothings', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'chickenClothings_userWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, {
      logging: console.log,
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('chickenClothings');
  },
};
