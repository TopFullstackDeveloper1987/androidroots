module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('tourneyOnes', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true,
      },
      type: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      clothingSet: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      image: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      clothingId: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addIndex('tourneyOnes', ['name'], {
      name: 'idx_tourneyOnes_name',
    });
    await queryInterface.addIndex('tourneyOnes', ['type'], {
      name: 'idx_tourneyOnes_type',
    });
    await queryInterface.addIndex('tourneyOnes', ['clothingSet'], {
      name: 'idx_tourneyOnes_clothingSet',
    });
    await queryInterface.addIndex('tourneyOnes', ['clothingId'], {
      name: 'idx_tourneyOnes_clothingId',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('tourneyOnes');
  },
};
