/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('raceAssignments', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      raceId: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      tokenId: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      userWalletId: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      signature: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      status: {
        allowNull: false,
        defaultValue: 'pending',
        type: Sequelize.ENUM('pending', 'success', 'error'),
      },
      paidStatus: {
        allowNull: false,
        defaultValue: 'unpaid',
        type: Sequelize.ENUM('unpaid', 'receiptNotReady', 'paid', 'error', 'postponed'),
      },
      error: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('raceAssignments', {
      type: 'foreign key',
      fields: ['raceId'],
      name: 'raceAssignmentsRaceId',
      references: {
        table: 'races',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('raceAssignments', ['userWalletId'], {
      name: 'idx_raceAssignments_userWalletId',
    });
    await queryInterface.addIndex('raceAssignments', ['status'], {
      name: 'idx_raceAssignments_status',
    });
    await queryInterface.addIndex('raceAssignments', ['paidStatus'], {
      name: 'idx_raceAssignments_paidStatus',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('raceAssignments');
  },
};
