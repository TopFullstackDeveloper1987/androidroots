module.exports = {
  up: async (queryInterface, DataTypes) => {
    await queryInterface.createTable('races', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER,
      },
      _id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notNull: { message: 'Race Name is Required' },
          notEmpty: { message: 'Race Name is Required' },
        },
      },
      peckingOrder: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notNull: { message: 'peckingOrder is Required' },
          notEmpty: { message: 'peckingOrder is Required' },
        },
      },
      raceCapacity: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          notNull: { message: 'raceCapacity is Required' },
          notEmpty: { message: 'raceCapacity is Required' },
        },
      },
      currentCapacity: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          notNull: { message: 'currentCapacity is Required' },
          notEmpty: { message: 'currentCapacity is Required' },
        },
      },
      distance: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          notNull: { message: 'Distance is Required' },
          notEmpty: { message: 'Distance is Required' },
        },
      },
      fee: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          notNull: { message: 'Fee is Required' },
          notEmpty: { message: 'Fee is Required' },
        },
      },
      location: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notNull: { message: 'Location is Required' },
          notEmpty: { message: 'Location is Required' },
        },
      },
      minimumStartDelay: {
        type: DataTypes.INTEGER,
        defaultValue: 3,
      },
      raceStartTime: {
        type: DataTypes.STRING,
        defaultValue: '00:00:00',
      },
      class: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notNull: { message: 'class is Required' },
          notEmpty: { message: 'class is Required' },
        },
      },
      terraince: {
        type: DataTypes.INTEGER,
      },
      laneId: {
        type: DataTypes.INTEGER,
      },
      raceType: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 1,
        validate: {
          notNull: { message: 'Race Type is Required' },
          notEmpty: { message: 'Race Type Required' },
        },
      },
      myArrayField: {
        type: DataTypes.STRING,
        get() {
          return JSON.parse(this.getDataValue('myArrayField'));
        },
        set(val) {
          return this.setDataValue('myArrayField', JSON.stringify(val));
        },
      },
      lane: {
        type: DataTypes.STRING(1234),
        get() {
          return JSON.parse(this.getDataValue('lane'));
        },
        set(val) {
          return this.setDataValue('lane', JSON.stringify(val));
        },
      },
      chickenId: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE,
      },
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, DataTypes) => {
    await queryInterface.dropTable('races');
  },
};
