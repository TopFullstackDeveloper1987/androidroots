/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'paidStatus', {
      allowNull: false,
      type: Sequelize.ENUM('unpaid', 'receiptNotReady', 'paid', 'error', 'postponed'),
      defaultValue: 'unpaid',
    }, { logging: console.log });

    await queryInterface.addColumn('races', 'type', {
      allowNull: false,
      type: Sequelize.ENUM('manual', 'automatic'),
      defaultValue: 'manual',
    }, { logging: console.log });

    await queryInterface.addIndex('races', ['type'], {
      name: 'idx_races_type',
    });

    await queryInterface.addColumn('races', 'group', {
      allowNull: false,
      type: Sequelize.INTEGER(11).UNSIGNED,
      defaultValue: 1,
    }, { logging: console.log });

    await queryInterface.addIndex('races', ['group'], {
      name: 'idx_races_group',
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('races', 'paidStatus', {
      allowNull: false,
      // add '0', '1', '2', '3', '4' to migrate from the old database
      type: Sequelize.ENUM('unpaid', 'receiptNotReady', 'paid', 'error', 'postponed', '0', '1', '2', '3', '4'),
      defaultValue: 'unpaid',
    }, { logging: console.log });

    await queryInterface.removeColumn('races', 'type');

    await queryInterface.removeColumn('races', 'group');
  },
};
