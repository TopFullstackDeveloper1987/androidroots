module.exports = {
  up: async (queryInterface, DataTypes) => {
    await queryInterface.createTable('betaUsers', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER,
      },
      _id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
      publicAddress: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          isLowercase: true,
          notNull: { message: 'Wallet address is required' },
          notEmpty: { message: 'Wallet address is required' },
        },
        unique: true,
      },
      nonce: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
        defaultValue: () => Math.floor(Math.random() * 1000000), // Initialize with a random nonce
      },
      username: {
        type: DataTypes.STRING,
        unique: true,
      },
      email: {
        type: DataTypes.STRING,
        unique: true,
      },
      password: {
        type: DataTypes.STRING,
      },
      first_name: {
        type: DataTypes.STRING,
      },
      last_name: {
        type: DataTypes.STRING,
      },
      token: {
        type: DataTypes.STRING,
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE,
      },
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('betaUsers');
  },
};
