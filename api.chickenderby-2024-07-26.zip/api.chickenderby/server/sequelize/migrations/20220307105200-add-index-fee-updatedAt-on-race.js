module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addIndex('races', ['fee'], {
      name: 'idx_races_fee',
    });
    await queryInterface.addIndex('races', ['updatedAt'], {
      name: 'idx_races_updatedAt',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeIndex('races', 'idx_races_fee');
    await queryInterface.removeIndex('races', 'idx_races_updatedAt');
  },
};
