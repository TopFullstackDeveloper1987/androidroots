module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.renameColumn('userWallets', 'first_name', 'firstName');
    await queryInterface.renameColumn('userWallets', 'last_name', 'lastName');
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.renameColumn('userWallets', 'firstName', 'first_name');
    await queryInterface.renameColumn('userWallets', 'lastName', 'last_name');
  },
};
