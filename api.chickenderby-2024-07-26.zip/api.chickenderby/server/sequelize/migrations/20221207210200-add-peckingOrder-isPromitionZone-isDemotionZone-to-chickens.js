/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('chickens', 'peckingOrder', {
      type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'CHICK'),
      allowNull: false,
      defaultValue: 'CHICK',
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'isPromotionZone', {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'isDemotionZone', {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('chickens', 'peckingOrder');
    await queryInterface.removeColumn('chickens', 'isPromotionZone');
    await queryInterface.removeColumn('chickens', 'isDemotionZone');
  },
};
