/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('bawkPresaleInviteCodes', {
      id: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.STRING(8),
      },
      userWalletId: {
        type: 'varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci',
        allowNull: false,
      },
      claimedUserWalletId: {
        type: 'varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci',
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('bawkPresaleInviteCodes', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'bawkPresaleInviteCodesUserWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('bawkPresaleInviteCodes', {
      type: 'foreign key',
      fields: ['claimedUserWalletId'],
      name: 'bawkPresaleInviteCodesClaimedUserWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('bawkPresaleInviteCodes');
  },
};
