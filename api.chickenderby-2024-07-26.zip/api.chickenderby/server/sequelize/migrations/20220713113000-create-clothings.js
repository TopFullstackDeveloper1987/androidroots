module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('clothings', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true,
      },
      numberOfOwners: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 5,
      },
      type: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      clothingSet: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      image: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      clothingId: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addIndex('clothings', ['name'], {
      name: 'idx_clothings_name',
    });
    await queryInterface.addIndex('clothings', ['type'], {
      name: 'idx_clothings_type',
    });
    await queryInterface.addIndex('clothings', ['clothingSet'], {
      name: 'idx_clothings_clothingSet',
    });
    await queryInterface.addIndex('clothings', ['clothingId'], {
      name: 'idx_clothings_clothingId',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('clothings');
  },
};
