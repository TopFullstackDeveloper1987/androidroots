/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('userWallets', 'referralCode', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addIndex('userWallets', ['referralCode'], {
      name: 'idx_userWallets_referralCode',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('userWallets', 'referralCode');
  },
};
