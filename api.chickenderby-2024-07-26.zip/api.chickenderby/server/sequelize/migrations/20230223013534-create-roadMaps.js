module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('roadMaps', {
      id: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.STRING,
      },
      order: {
        type: Sequelize.INTEGER.UNSIGNED,
        allowNull: false,
      },
      timeline: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      title: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      headline: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      link: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      summary: {
        type: Sequelize.TEXT,
        allowNull: true,
        defaultValue: null,
      },
      isLocked: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      isDisabled: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('roadMaps');
  },
};
