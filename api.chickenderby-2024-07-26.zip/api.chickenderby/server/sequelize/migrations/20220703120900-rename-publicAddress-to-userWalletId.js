/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('coops', 'userId');
    await queryInterface.removeColumn('lanes', 'userWalletId');
    await queryInterface.removeColumn('raceAssignments', 'userWalletId');
    await queryInterface.removeColumn('transactions', 'userWalletId');
    await queryInterface.removeColumn('tournamentRankings', 'userWalletId');

    await queryInterface.removeColumn('userWallets', 'id');
    await queryInterface.renameColumn('userWallets', 'publicAddress', 'id');
    await queryInterface.removeConstraint('userWallets', 'publicAddress');
    await queryInterface.addConstraint('userWallets', {
      type: 'primary key',
      fields: ['id'],
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('coops', 'publicAddress', 'userWalletId');
    await queryInterface.addConstraint('coops', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'coops_userWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('lanes', 'publicAddress', 'userWalletId');
    await queryInterface.addConstraint('lanes', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'lanes_userWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('raceAssignments', 'publicAddress', 'userWalletId');
    await queryInterface.addConstraint('raceAssignments', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'raceAssignments_userWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('transactions', 'publicAddress', 'userWalletId');
    await queryInterface.addConstraint('transactions', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'transactions_userWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('tournamentRankings', 'publicAddress', 'userWalletId');
    await queryInterface.addConstraint('tournamentRankings', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'tournamentRankings_userWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, {
      logging: console.log,
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeConstraint('coops', 'coops_userWalletId');
    await queryInterface.removeConstraint('lanes', 'lanes_userWalletId');
    await queryInterface.removeConstraint('raceAssignments', 'raceAssignments_userWalletId');
    await queryInterface.removeConstraint('transactions', 'transactions_userWalletId');
    await queryInterface.removeConstraint('tournamentRankings', 'tournamentRankings_userWalletId');

    await queryInterface.removeConstraint('userWallets', 'PRIMARY');
    await queryInterface.renameColumn('userWallets', 'id', 'publicAddress');
    await queryInterface.addColumn('userWallets', 'id', {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: Sequelize.INTEGER,
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('coops', 'userWalletId', 'publicAddress');
    await queryInterface.addColumn('coops', 'userId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('lanes', 'userWalletId', 'publicAddress');
    await queryInterface.addColumn('lanes', 'userWalletId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('raceAssignments', 'userWalletId', 'publicAddress');
    await queryInterface.addColumn('raceAssignments', 'userWalletId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('transactions', 'userWalletId', 'publicAddress');
    await queryInterface.addColumn('transactions', 'userWalletId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });

    await queryInterface.renameColumn('tournamentRankings', 'userWalletId', 'publicAddress');
    await queryInterface.addColumn('tournamentRankings', 'userWalletId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, {
      logging: console.log,
    });
  },
};
