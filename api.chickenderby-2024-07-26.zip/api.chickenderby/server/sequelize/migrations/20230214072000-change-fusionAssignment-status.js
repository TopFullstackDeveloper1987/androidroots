/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('fusionAssignments', 'status', {
      type: Sequelize.ENUM('draft', 'pending', 'success', 'error'),
      allowNull: false,
      defaultValue: 'draft',
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('fusionAssignments', 'status', {
      type: Sequelize.ENUM('pending', 'success', 'error'),
      allowNull: false,
      defaultValue: 'pending',
    }, { logging: console.log });
  },
};
