module.exports = {
  up: async (queryInterface, DataTypes) => {
    await queryInterface.createTable('Lanes', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER,
      },
      race_id: {
        type: DataTypes.INTEGER,
      },
      lane: {
        type: DataTypes.STRING(1234),
        get() {
          return JSON.parse(this.getDataValue('lane'));
        },
        set(val) {
          return this.setDataValue('lane', JSON.stringify(val));
        },
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE,
      },
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, DataTypes) => {
    await queryInterface.dropTable('Lanes');
  },
};
