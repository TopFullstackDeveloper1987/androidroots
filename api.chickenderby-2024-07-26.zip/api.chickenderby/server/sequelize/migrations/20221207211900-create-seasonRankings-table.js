/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('seasonRankings', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      seasonId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      chickenId: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      peckingOrder: {
        type: Sequelize.ENUM('S', 'A', 'B', 'C', 'D', 'CHICK'),
        allowNull: false,
        defaultValue: 'CHICK',
      },
      position: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      poPoints: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 100,
      },
      races: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      first: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      second: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      third: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      fourth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      fifth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      sixth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      seventh: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      eighth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      ninth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      tenth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      eleventh: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      twelfth: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('seasonRankings', {
      type: 'foreign key',
      fields: ['seasonId'],
      name: 'seasonRankingsSeasonId',
      references: {
        table: 'seasons',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('seasonRankings', ['chickenId'], {
      name: 'idx_seasonRankings_chickenId',
    });
    await queryInterface.addIndex('seasonRankings', ['peckingOrder'], {
      name: 'idx_seasonRankings_peckingOrder',
    });
    await queryInterface.addIndex('seasonRankings', ['position'], {
      name: 'idx_seasonRankings_position',
    });
    await queryInterface.addIndex('seasonRankings', ['poPoints'], {
      name: 'idx_seasonRankings_poPoints',
    });
    await queryInterface.addIndex('seasonRankings', ['races'], {
      name: 'idx_seasonRankings_races',
    });

    const ordinals = ['first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth', 'eleventh', 'twelfth'];
    for (const ordinal of ordinals) {
      await queryInterface.addIndex('seasonRankings', [`${ordinal}`], {
        name: `idx_seasonRankings_${ordinal}`,
      });
    }
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('seasonRankings');
  },
};
