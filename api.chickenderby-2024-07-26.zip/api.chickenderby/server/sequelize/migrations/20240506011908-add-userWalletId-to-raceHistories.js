/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('raceHistories', 'userWalletId', {
      type: 'varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci',
      allowNull: true,
      defaultValue: null,
      after: 'raceId',
    }, {
      logging: console.log,
    });

    await queryInterface.addConstraint('raceHistories', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'raceHistories_userWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, {
      logging: console.log,
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('raceHistories', 'userWalletId');
  },
};
