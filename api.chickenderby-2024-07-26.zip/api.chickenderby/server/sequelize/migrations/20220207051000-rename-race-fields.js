module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.renameColumn('races', 'raceCapacity', 'maxCapacity');
    await queryInterface.renameColumn('races', 'raceStartTime', 'startTime');
    await queryInterface.renameColumn('races', 'terraince', 'terrainId');
    await queryInterface.renameColumn('races', 'raceStartsAt', 'startsAt');
    await queryInterface.renameColumn('races', 'raceEndsAt', 'endsAt');
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.renameColumn('races', 'maxCapacity', 'raceCapacity');
    await queryInterface.renameColumn('races', 'startTime', 'raceStartTime');
    await queryInterface.renameColumn('races', 'terrainId', 'terraince');
    await queryInterface.renameColumn('races', 'startsAt', 'raceStartsAt');
    await queryInterface.renameColumn('races', 'endsAt', 'raceEndsAt');
  },
};
