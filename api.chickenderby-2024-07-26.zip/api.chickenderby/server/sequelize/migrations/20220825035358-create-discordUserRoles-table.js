/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('discordUserRoles', {
      userWalletId: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.STRING,
      },
      discordRoleId: {
        type: Sequelize.STRING,
        allowNull: false,
        primaryKey: true,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('discordUserRoles', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'discordUserRoleUserWalletId',
      onDelete: 'CASCADE',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('discordUserRoles', {
      type: 'foreign key',
      fields: ['discordRoleId'],
      name: 'discordUserRoleDiscordRoleId',
      onDelete: 'CASCADE',
      references: {
        table: 'discordRoles',
        field: 'id',
      },
    }, { logging: console.log });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('discordUserRoles');
  },
};
