/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('bawkStakingAssignments', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      epoch: {
        allowNull: false,
        defaultValue: 0,
        type: Sequelize.INTEGER,
      },
      bawkStakingCompanyId: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      userWalletId: {
        allowNull: false,
        type: 'varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci',
      },
      amount: {
        allowNull: false,
        type: Sequelize.DECIMAL(10, 2),
      },
      type: {
        allowNull: false,
        defaultValue: 'stake',
        type: Sequelize.ENUM('stake', 'unstake'),
      },
      bawkType: {
        allowNull: false,
        defaultValue: 'unclaimed',
        type: Sequelize.ENUM('unclaimed', 'claimed'),
      },
      status: {
        allowNull: false,
        defaultValue: 'pending',
        type: Sequelize.ENUM('pending', 'success', 'error'),
      },
      signature: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.STRING,
      },
      error: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      transactionHash: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.STRING,
      },
      txHashes: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      data: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('bawkStakingAssignments', {
      type: 'foreign key',
      fields: ['bawkStakingCompanyId'],
      name: 'bawkStakingAssignmentsCompanyId',
      references: {
        table: 'bawkStakingCompanies',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('bawkStakingAssignments', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'bawkStakingAssignmentsUserWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    for (const index of ['epoch', 'type', 'bawkType', 'status']) {
      await queryInterface.addIndex('bawkStakingAssignments', [index], {
        name: `idx_bawkStakingAssignments_${index}`,
      });
    }
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('bawkStakingAssignments');
  },
};
