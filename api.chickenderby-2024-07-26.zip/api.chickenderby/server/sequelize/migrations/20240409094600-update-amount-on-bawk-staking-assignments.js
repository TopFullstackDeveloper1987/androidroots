/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('bawkStakingAssignments', 'amount', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(20, 6),
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('bawkStakingAssignments', 'amount', {
      allowNull: false,
      defaultValue: 0,
      type: Sequelize.DECIMAL(10, 2),
    }, { logging: console.log });
  },
};
