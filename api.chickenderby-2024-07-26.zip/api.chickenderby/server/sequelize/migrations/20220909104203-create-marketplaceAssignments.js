/* eslint-disable no-console */

const AssignmentStatus = require('../../types/assignments/assignmentStatus');
const PaidStatus = require('../../types/transactions/transactionPaidStatus');
const MarketplaceAssignmentType = require('../../types/marketplace/marketplaceAssignmentType');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('marketplaceAssignments', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      userWalletId: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      type: {
        type: Sequelize.ENUM(
          MarketplaceAssignmentType.CreateMarketItem,
          MarketplaceAssignmentType.EditMarketItem,
          MarketplaceAssignmentType.CancelMarketItem,
          MarketplaceAssignmentType.PurchaseMarketItem,

          MarketplaceAssignmentType.MakeOffer,
          MarketplaceAssignmentType.EditOffer,
          MarketplaceAssignmentType.FulfillOffer,
          MarketplaceAssignmentType.CancelOrDeclineOffer,
        ),
        allowNull: false,
      },
      marketItemId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      nftContract: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      tokenId: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      price: {
        type: Sequelize.DECIMAL(10, 6),
        allowNull: true,
        defaultValue: null,
      },
      minimum: {
        type: Sequelize.DECIMAL(10, 6),
        allowNull: true,
        defaultValue: null,
      },
      tradeType: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      tradeOfferId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      tokensAttached: {
        type: Sequelize.JSON,
        allowNull: true,
        defaultValue: null,
      },
      signature: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      status: {
        allowNull: false,
        defaultValue: AssignmentStatus.Pending,
        type: Sequelize.ENUM(AssignmentStatus.Pending, AssignmentStatus.Success, AssignmentStatus.Error),
      },
      paidStatus: {
        allowNull: false,
        defaultValue: PaidStatus.Unpaid,
        type: Sequelize.ENUM(PaidStatus.Unpaid, PaidStatus.ReceiptNotReady, PaidStatus.Paid, PaidStatus.Error, PaidStatus.Postponed),
      },
      error: {
        allowNull: true,
        defaultValue: null,
        type: Sequelize.JSON,
      },
      transactionHash: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      txHashes: {
        type: Sequelize.JSON,
        allowNull: true,
        defaultValue: null,
      },
      data: {
        type: Sequelize.JSON,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addIndex('marketplaceAssignments', ['nftContract'], {
      name: 'idx_marketplaceAssignments_nftContract',
    });
    await queryInterface.addIndex('marketplaceAssignments', ['userWalletId'], {
      name: 'idx_marketplaceAssignments_userWalletId',
    });
    await queryInterface.addIndex('marketplaceAssignments', ['type'], {
      name: 'idx_marketplaceAssignments_type',
    });
    await queryInterface.addIndex('marketplaceAssignments', ['status'], {
      name: 'idx_marketplaceAssignments_status',
    });
    await queryInterface.addIndex('marketplaceAssignments', ['paidStatus'], {
      name: 'idx_marketplaceAssignments_paidStatus',
    });
    await queryInterface.addIndex('marketplaceAssignments', ['updatedAt'], {
      name: 'idx_marketplaceAssignments_updatedAt',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('marketplaceAssignments');
  },
};
