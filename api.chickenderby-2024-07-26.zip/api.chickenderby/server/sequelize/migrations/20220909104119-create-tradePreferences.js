/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('tradePreferences', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      userWalletId: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      nftContract: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      tokenId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      preference: {
        type: Sequelize.JSON,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('tradePreferences', {
      type: 'foreign key',
      fields: ['userWalletId'],
      name: 'tradePreferencesUserWalletId',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('tradePreferences', ['nftContract'], {
      name: 'idx_tradePreferences_nftContract',
    });

    await queryInterface.addIndex('tradePreferences', ['tokenId'], {
      name: 'idx_tradePreferences_tokenId',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('tradePreferences');
  },
};
