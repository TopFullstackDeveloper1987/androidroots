/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('results', 'cutscenes', {
      type: Sequelize.JSON,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.addColumn('results', 'soundProfiles', {
      type: Sequelize.JSON,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('results', 'cutscenes');
    await queryInterface.removeColumn('results', 'soundProfiles');
  },
};
