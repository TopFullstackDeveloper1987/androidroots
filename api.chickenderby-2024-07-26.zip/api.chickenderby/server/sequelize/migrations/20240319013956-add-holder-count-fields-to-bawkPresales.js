/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('bawkPresales', 'chickens', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 0,
      after: 'publicSales',
    }, { logging: console.log });

    await queryInterface.addColumn('bawkPresales', 'goldenTickets', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 0,
      after: 'publicSales',
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('bawkPresales', 'chickens');
    await queryInterface.removeColumn('bawkPresales', 'goldenTickets');
  },
};
