/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('results', 'gameInfo');
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('results', 'gameInfo', {
      allowNull: true,
      defaultValue: null,
      type: Sequelize.JSON,
    }, { logging: console.log });
  },
};
