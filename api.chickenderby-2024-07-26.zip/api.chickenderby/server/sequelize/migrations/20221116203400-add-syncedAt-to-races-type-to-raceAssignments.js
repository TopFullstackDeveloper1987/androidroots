/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('races', 'syncedAt', {
      type: Sequelize.DATE,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
    await queryInterface.addIndex('races', ['syncedAt'], {
      name: 'idx_races_syncedAt',
    });

    // use the hard-coded enum in migrations
    await queryInterface.addColumn('raceAssignments', 'type', {
      type: Sequelize.ENUM(
        'enter',
        'autoEnter',
      ),
      allowNull: false,
      defaultValue: 'enter',
    }, { logging: console.log });
    await queryInterface.addIndex('raceAssignments', ['type'], {
      name: 'idx_raceAssignments_type',
    });

    await queryInterface.changeColumn('raceAssignments', 'signature', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('races', 'syncedAt');
    await queryInterface.removeColumn('raceAssignments', 'type');
    await queryInterface.changeColumn('raceAssignments', 'signature', {
      type: Sequelize.STRING,
      allowNull: false,
    }, { logging: console.log });
  },
};
