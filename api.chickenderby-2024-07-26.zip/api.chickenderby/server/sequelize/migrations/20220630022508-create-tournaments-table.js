module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('tournaments', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      maxRaces: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null,
      },
      startAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      endAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      discordUrl: {
        allowNull: true,
        type: Sequelize.STRING,
        defaultValue: null,
      },
      peckingOrders: {
        allowNull: true,
        type: Sequelize.JSON,
        defaultValue: null,
      },
      rules: {
        allowNull: false,
        type: Sequelize.JSON,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('tournaments');
  },
};
