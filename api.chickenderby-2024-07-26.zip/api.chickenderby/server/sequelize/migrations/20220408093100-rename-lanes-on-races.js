module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.renameColumn('races', 'lanes', 'Lanes');
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.renameColumn('races', 'Lanes', 'lanes');
  },
};
