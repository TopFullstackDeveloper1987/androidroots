/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('transactions', 'status', {
      allowNull: false,
      // add 'success' to migrate from the old database
      type: Sequelize.ENUM('unpaid', 'receiptNotReady', 'paid', 'error', 'postponed', 'success'),
      defaultValue: 'paid',
    }, { logging: console.log });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('transactions', 'status', {
      allowNull: false,
      type: Sequelize.STRING,
      defaultValue: 'success',
    }, { logging: console.log });
  },
};
