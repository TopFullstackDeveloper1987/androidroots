/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('chickens', 'resetSituationAt', {
      type: Sequelize.DATE,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addIndex('chickens', ['resetSituationAt'], {
      name: 'idx_chickens_resetSituationAt',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('chickens', 'resetSituationAt');
  },
};
