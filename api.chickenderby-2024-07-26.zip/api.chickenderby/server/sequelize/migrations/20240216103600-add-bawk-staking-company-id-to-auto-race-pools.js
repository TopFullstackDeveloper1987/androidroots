/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('autoRacePools', 'bawkStakingCompanyId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addConstraint('autoRacePools', {
      type: 'foreign key',
      fields: ['bawkStakingCompanyId'],
      name: 'autoRacePoolsBawkStakingCompanyId',
      references: {
        table: 'bawkStakingCompanies',
        field: 'id',
      },
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('autoRacePools', 'bawkStakingCompanyId');
  },
};
