/* eslint-disable no-console */
module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('chickens', 'hair');
    await queryInterface.removeColumn('chickens', 'necklace');
    await queryInterface.removeColumn('chickens', 'glasses');
    await queryInterface.removeColumn('chickens', 'jacket');
    await queryInterface.removeColumn('chickens', 'shoes');
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('chickens', 'hair', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'necklace', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'glasses', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'jacket', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addColumn('chickens', 'shoes', {
      type: Sequelize.STRING,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },
};
