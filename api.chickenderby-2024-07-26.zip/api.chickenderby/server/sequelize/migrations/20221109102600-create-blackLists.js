/* eslint-disable no-console */

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('blackLists', {
      id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      nftContract: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      tokenId: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      reporterUserName: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      reporterUserWalletId: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      stealerUserWalletId: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null,
      },
      blackListedAt: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    await queryInterface.addConstraint('blackLists', {
      type: 'foreign key',
      fields: ['reporterUserWalletId'],
      name: 'blackListsReporter',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('blackLists', {
      type: 'foreign key',
      fields: ['stealerUserWalletId'],
      name: 'blackListsStealer',
      references: {
        table: 'userWallets',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addIndex('blackLists', ['nftContract'], {
      name: 'idx_blackLists_nftContract',
    });
    await queryInterface.addIndex('blackLists', ['tokenId'], {
      name: 'idx_blackLists_tokenId',
    });
    await queryInterface.addIndex('blackLists', ['reporterUserName'], {
      name: 'idx_blackLists_reporterUserName',
    });
    await queryInterface.addIndex('blackLists', ['blackListedAt'], {
      name: 'idx_blackLists_blackListedAt',
    });
  },
  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('blackLists');
  },
};
