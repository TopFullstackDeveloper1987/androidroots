/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('goldenTickets', 'isOriginal', {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('goldenTickets', 'isOriginal');
  },
};
