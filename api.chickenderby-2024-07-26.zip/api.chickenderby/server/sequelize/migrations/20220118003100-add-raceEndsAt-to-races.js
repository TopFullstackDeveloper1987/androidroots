/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('races', 'raceEndsAt', {
      allowNull: true,
      type: Sequelize.DATE,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addIndex('races', ['raceEndsAt'], {
      name: 'idx_races_raceEndsAt',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('races', 'raceEndsAt');
  },
};
