/* eslint-disable no-console */
const MarketplaceAssignmentType = require('../../types/marketplace/marketplaceAssignmentType');

module.exports = {
  // eslint-disable-next-line no-unused-vars
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('marketplaceAssignments', 'type', {
      type: Sequelize.ENUM(
        MarketplaceAssignmentType.CreateMarketItem,
        MarketplaceAssignmentType.EditMarketItem,
        MarketplaceAssignmentType.CancelMarketItem,
        MarketplaceAssignmentType.PurchaseMarketItem,

        MarketplaceAssignmentType.MakeOffer,
        MarketplaceAssignmentType.EditOffer,
        MarketplaceAssignmentType.FulfillOffer,
        MarketplaceAssignmentType.CancelOrDeclineOffer,
        MarketplaceAssignmentType.AutoDeclineOffer,
      ),
      allowNull: false,
    }, { logging: console.log });

    await queryInterface.addConstraint('marketplaceAssignments', {
      type: 'foreign key',
      fields: ['marketItemId'],
      name: 'marketplaceAssignmentsMarketItemId',
      references: {
        table: 'marketItems',
        field: 'id',
      },
    }, { logging: console.log });

    await queryInterface.addConstraint('marketplaceAssignments', {
      type: 'foreign key',
      fields: ['tradeOfferId'],
      name: 'marketplaceAssignmentsTradeOfferId',
      references: {
        table: 'tradeOffers',
        field: 'id',
      },
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('marketplaceAssignments', 'type', {
      type: Sequelize.ENUM(
        MarketplaceAssignmentType.CreateMarketItem,
        MarketplaceAssignmentType.EditMarketItem,
        MarketplaceAssignmentType.CancelMarketItem,
        MarketplaceAssignmentType.PurchaseMarketItem,

        MarketplaceAssignmentType.MakeOffer,
        MarketplaceAssignmentType.EditOffer,
        MarketplaceAssignmentType.FulfillOffer,
        MarketplaceAssignmentType.CancelOrDeclineOffer,
      ),
      allowNull: false,
    }, { logging: console.log });

    await queryInterface.removeConstraint('marketplaceAssignments', 'marketplaceAssignmentsMarketItemId');
    await queryInterface.removeIndex('marketplaceAssignments', 'marketplaceAssignmentsMarketItemId');
    await queryInterface.removeConstraint('marketplaceAssignments', 'marketplaceAssignmentsTradeOfferId');
    await queryInterface.removeIndex('marketplaceAssignments', 'marketplaceAssignmentsTradeOfferId');
  },
};
