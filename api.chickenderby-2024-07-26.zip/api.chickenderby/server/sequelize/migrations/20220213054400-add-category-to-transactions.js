/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('transactions', 'category', {
      allowNull: false,
      type: Sequelize.ENUM('entryFee', 'payout'),
      defaultValue: 'entryFee',
    }, { logging: console.log });

    await queryInterface.sequelize.query('UPDATE transactions SET category=\'payout\' WHERE type=\'out\'');
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('transactions', 'category');
  },
};
