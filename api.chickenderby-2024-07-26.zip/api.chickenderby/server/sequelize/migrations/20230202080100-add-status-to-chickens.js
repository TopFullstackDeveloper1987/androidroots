/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('chickens', 'status', {
      type: Sequelize.ENUM('Pending', 'Active', 'Was Fused', 'Fusion Result', 'Burned'),
      allowNull: false,
      defaultValue: 'Active',
    }, { logging: console.log });

    await queryInterface.addIndex('chickens', ['status'], {
      name: 'idx_chickens_status',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('chickens', 'status');
  },
};
