/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('marketplaceAssignments', 'nonce', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });

    await queryInterface.addIndex('marketplaceAssignments', ['nonce'], {
      name: 'idx_marketplaceAssignments_nonce',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('marketplaceAssignments', 'nonce');
  },
};
