/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('chickens', 'fusion');
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('chickens', 'fusion', {
      type: Sequelize.ENUM('Was Fused', 'Fusion Result'),
      allowNull: true,
      defaultValue: null,
    }, { logging: console.log });
  },
};
