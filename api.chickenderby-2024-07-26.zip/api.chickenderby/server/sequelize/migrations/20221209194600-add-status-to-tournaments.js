/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('tournaments', 'status', {
      type: Sequelize.ENUM('pending', 'live', 'completed', 'disabled'),
      allowNull: false,
      defaultValue: 'pending',
    }, { logging: console.log });
    await queryInterface.addIndex('tournaments', ['status'], {
      name: 'idx_tournaments_status',
    });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('tournaments', 'status');
  },
};
