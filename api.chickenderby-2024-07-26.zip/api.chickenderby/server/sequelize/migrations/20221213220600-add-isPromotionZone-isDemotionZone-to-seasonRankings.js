/* eslint-disable no-console */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('seasonRankings', 'isPromotionZone', {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    }, { logging: console.log });

    await queryInterface.addColumn('seasonRankings', 'isDemotionZone', {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    }, { logging: console.log });
  },

  // eslint-disable-next-line no-unused-vars
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('seasonRankings', 'isPromotionZone');
    await queryInterface.removeColumn('seasonRankings', 'isDemotionZone');
  },
};
