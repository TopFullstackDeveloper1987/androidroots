// !Important: Do not import this file in any place of the project, it runs as an independent process
import IoRedis from 'ioredis';

require('dotenv').config();

import config from '../config';

import { waitUntilBiconomyReady } from '../services/contracts/web3Service';

import models from '../sequelize/models';
import { updateGitInfo } from '../gitInfo';

import { log } from '../utils';
import { checkForMigrations } from '../sequelize/helpers/migrations';
import { FusionService } from '../services/fusions/fusionService';
import { syncFusions } from '../services/fusions/fusionSyncService';
import { SerumMintService } from '../services/fusions/serumMintService';
import { fusionSyncWorker, fusionWorker, serumMintWorker } from '../queues/fusionQueues';

// health check
const redis = new IoRedis(config.redis);

redis.ping(async (err: any) => {
  if (err) {
    log.error({
      func: 'fusionJobs',
      err,
    }, 'Redis Error On Fusion Jobs');

    return;
  }

  models.sequelize.authenticate().then(async () => {
    const migrations = await checkForMigrations();
    if (migrations.length) {
      // eslint-disable-next-line no-console
      console.error(
        'Pending migrations need to be run:\n',
        migrations.map((migration) => migration.name).join('\n '),
        '\nUse this command to run migrations:\n "yarn sequelize db:migrate"',
      );

      process.exit(1);
    }

    log.info('Database connection has been established successfully.');
  }).catch((err2) => {
    log.error({
      func: 'fusionJobs',
      err: err2,
    }, 'Unable to connect to the database');

    process.exit(1);
  });

  updateGitInfo(config.FUSION_JOBS_GIT_JSON);

  await waitUntilBiconomyReady().catch((err2) => log.error(err2));

  log.info(`Fusion Jobs HealthCheck is OK on ${new Date()}`);
});

// Jobs
// ---------------------------------------------
fusionWorker.process(config.MAX_CONCURRENT_WORKERS_FOR_FUSION, async (job) => FusionService.handleFusionAssignment(job));

// ---------------------------------------------
fusionSyncWorker.process(async (job) => syncFusions(job));

fusionSyncWorker.clean(0, 'delayed');
fusionSyncWorker.add({}, {
  // every minute
  repeat: { cron: `*/${config.FUSION_SYNC_DURATION_MINUTES} * * * *` },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60 / config.FUSION_SYNC_DURATION_MINUTES,
  removeOnFail: config.bull.historyTTLInHours * 60 / config.FUSION_SYNC_DURATION_MINUTES,
});

// ---------------------------------------------
serumMintWorker.process(config.MAX_CONCURRENT_WORKERS_FOR_SERUM_MINT, async (job) => SerumMintService.handleSerumMint(job));

FusionService.subscribeFusionPendingTransactions();

log.info(`ChickenDerby Fusion Jobs Started On ${new Date()}`);
