// !Important: Do not import this file in any place of the project, it runs as an independent process
import IoRedis from 'ioredis';

import 'dotenv/config';

import config from '../config';

import { waitUntilBiconomyReady } from '../services/contracts/web3Service';

import models from '../sequelize/models';
import { updateGitInfo } from '../gitInfo';

import { log } from '../utils';
import { checkForMigrations } from '../sequelize/helpers/migrations';
import { CoinPresaleService } from '../services/coin-presale/coin-presale.service';
import { coinPresaleAdminWorker } from '../queues/coin-presale-queues';

// health check
const redis = new IoRedis(config.redis);

redis.ping(async (err: any) => {
  if (err) {
    log.error({
      func: 'coin-presale-jobs',
      err,
    }, 'Redis Error On Coin Presale Jobs');

    return;
  }

  models.sequelize.authenticate().then(async () => {
    const migrations = await checkForMigrations();
    if (migrations.length) {
      // eslint-disable-next-line no-console
      console.error(
        'Pending migrations need to be run:\n',
        migrations.map((migration) => migration.name).join('\n '),
        '\nUse this command to run migrations:\n "yarn sequelize db:migrate"',
      );

      process.exit(1);
    }

    log.info('Database connection has been established successfully.');
  }).catch((err2) => {
    log.error({
      func: 'coin-presale-jobs',
      err: err2,
    }, 'Unable to connect to the database');

    process.exit(1);
  });

  updateGitInfo(config.COIN_PRESALE_JOBS_GIT_JSON);

  await waitUntilBiconomyReady().catch((err2) => log.error(err2));

  log.info(`Coin Presale Jobs HealthCheck is OK on ${new Date()}`);
});

// Jobs
// ---------------------------------------------
CoinPresaleService.subscribeCoinPresaleLogs();

// ---------------------------------------------
coinPresaleAdminWorker.process(async (job) => CoinPresaleService.getInstance().handleCoinPresaleAdminJobs(job));

coinPresaleAdminWorker.clean(0, 'delayed');
coinPresaleAdminWorker.add({}, {
  // every minute
  repeat: { cron: '* * * * *' },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60,
  removeOnFail: config.bull.historyTTLInHours * 60,
});

log.info(`ChickenDerby Coin Presale Jobs Started On ${new Date()}`);
