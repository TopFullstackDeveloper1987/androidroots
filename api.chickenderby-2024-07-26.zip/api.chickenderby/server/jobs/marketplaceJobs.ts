// !Important: Do not import this file in any place of the project, it runs as an independent process
import IoRedis from 'ioredis';

import 'dotenv/config';

import config from '../config';

import { waitUntilBiconomyReady } from '../services/contracts/web3Service';

import models from '../sequelize/models';
import { updateGitInfo } from '../gitInfo';

import { log } from '../utils';
import { handleMarketplaceAssignments, handleMarketplaceAdminJobs, subscribeMarketplacePendingTransactions } from '../services/marketplace/marketplaceService';
import { MarketplaceChickenSyncService } from '../services/marketplace/marketplaceChickenSyncService';
import { MarketplaceClothingSyncService } from '../services/marketplace/marketplaceClothingSyncService';
import { checkForMigrations } from '../sequelize/helpers/migrations';
import { marketplaceAdminWorker, marketplaceChickenSyncWorker, marketplaceClothingSyncWorker, marketplaceWorker } from '../queues/marketplaceQueues';

// health check
const redis = new IoRedis(config.redis);

redis.ping(async (err: any) => {
  if (err) {
    log.error({
      func: 'marketplaceJobs',
      err,
    }, 'Redis Error On Marketplace Jobs');

    return;
  }

  models.sequelize.authenticate().then(async () => {
    const migrations = await checkForMigrations();
    if (migrations.length) {
      // eslint-disable-next-line no-console
      console.error(
        'Pending migrations need to be run:\n',
        migrations.map((migration) => migration.name).join('\n '),
        '\nUse this command to run migrations:\n "yarn sequelize db:migrate"',
      );

      process.exit(1);
    }

    log.info('Database connection has been established successfully.');
  }).catch((err2) => {
    log.error({
      func: 'marketplaceJobs',
      err: err2,
    }, 'Unable to connect to the database');

    process.exit(1);
  });

  updateGitInfo(config.MARKETPLACE_JOBS_GIT_JSON);

  await waitUntilBiconomyReady().catch((err2) => log.error(err2));

  log.info(`Marketplace Jobs HealthCheck is OK on ${new Date()}`);
});

// Jobs
// ---------------------------------------------
marketplaceWorker.process(config.MAX_CONCURRENT_WORKERS_FOR_MARKETPLACE, async (job) => handleMarketplaceAssignments(job));

// ---------------------------------------------
marketplaceAdminWorker.process(async (job) => handleMarketplaceAdminJobs(job));

marketplaceAdminWorker.clean(0, 'delayed');
marketplaceAdminWorker.add({}, {
  // every minute
  repeat: { cron: '* * * * *' },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60,
  removeOnFail: config.bull.historyTTLInHours * 60,
});

// ---------------------------------------------
marketplaceChickenSyncWorker.process(async (job) => MarketplaceChickenSyncService.sharedInstance().syncMarketplace(job));

marketplaceChickenSyncWorker.clean(0, 'delayed');
marketplaceChickenSyncWorker.add({}, {
  // every minute
  repeat: { cron: `*/${config.MARKETPLACE_SYNC_DURATION_MINUTES} * * * *` },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60 / config.MARKETPLACE_SYNC_DURATION_MINUTES,
  removeOnFail: config.bull.historyTTLInHours * 60 / config.MARKETPLACE_SYNC_DURATION_MINUTES,
});

// ---------------------------------------------
marketplaceClothingSyncWorker.process(async (job) => MarketplaceClothingSyncService.sharedInstance().syncMarketplace(job));

marketplaceClothingSyncWorker.clean(0, 'delayed');
marketplaceClothingSyncWorker.add({}, {
  // every minute
  repeat: { cron: `*/${config.MARKETPLACE_SYNC_DURATION_MINUTES} * * * *` },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60 / config.MARKETPLACE_SYNC_DURATION_MINUTES,
  removeOnFail: config.bull.historyTTLInHours * 60 / config.MARKETPLACE_SYNC_DURATION_MINUTES,
});

subscribeMarketplacePendingTransactions();

log.info(`ChickenDerby Marketplace Jobs Started On ${new Date()}`);
