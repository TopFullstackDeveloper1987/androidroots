// !Important: Do not import this file in any place of the project, it runs as an independent process

import IoRedis from 'ioredis';

import 'dotenv/config';

import config from '../config';

import {
  scheduleRaces,
  countDownScheduledRaces,
  finishScheduledRaces,
  enterRace,
  handleRaceAdminJobs,
  alertFailedRaces,
  performRace,
  setRaceScheduleAt,
  resetChickenSituation,
} from '../services/raceService';
import { waitUntilBiconomyReady } from '../services/contracts/web3Service';
import { syncRace } from '../services/raceSyncService';
import { updateTournamentStatus } from '../services/tournaments/tournamentService';

import models from '../sequelize/models';
import { updateGitInfo } from '../gitInfo';

import { log } from '../utils';
import { mint } from '../services/landServie';
import { snycAllUserWallletDiscordUserRoles } from '../services/discordService';
import { checkForMigrations } from '../sequelize/helpers/migrations';
import { ChickenStakingService } from '../services/chickenStakingService';
import {
  mintLandWorker,
  performRaceWorker,
  raceAdminWorker,
  raceAlertWorker,
  raceEnterWorker,
  raceFinishWorker,
  raceScheduler,
  raceSyncWorker,
  raceScheduleTimer,
  syncDiscordRolesWorker,
  tournamentStatusWorker,
  raceTimeLimitMonitor,
  resetChickenSituationWorker,
  chickenStakingSeasonWorker,
  bawkStakingWorker,
} from '../queues/raceQueues';
import { BawkStakingService } from '../services/bawk-staking.service';

// health check
const redis = new IoRedis(config.redis);

redis.ping(async (err) => {
  if (err) {
    log.error({
      func: 'raceJobs',
      err,
    }, 'Redis Error On Race Jobs');

    return;
  }

  models.sequelize.authenticate().then(async () => {
    const migrations = await checkForMigrations();
    if (migrations.length) {
      // eslint-disable-next-line no-console
      console.error(
        'Pending migrations need to be run:\n',
        migrations.map((migration) => migration.name).join('\n '),
        '\nUse this command to run migrations:\n "yarn sequelize db:migrate"',
      );

      process.exit(1);
    }

    log.info('Database connection has been established successfully.');
  }).catch((err2) => {
    log.error({
      func: 'raceJobs',
      err: err2,
    }, 'Unable to connect to the database');

    process.exit(1);
  });

  updateGitInfo(config.RACE_JOBS_GIT_JSON);

  await waitUntilBiconomyReady().catch((err2) => log.error(err2));

  log.info(`Race Jobs HealthCheck is OK on ${new Date()}`);
});

// Jobs
// ---------------------------------------------
raceScheduler.process(async (job) => scheduleRaces(job));

raceScheduler.clean(0, 'delayed');
raceScheduler.add({}, {
  // every 5 seconds
  repeat: { every: 5000 },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60 * 12,
  removeOnFail: config.bull.historyTTLInHours * 60 * 12,
});

// ---------------------------------------------
raceScheduleTimer.process(async (job) => countDownScheduledRaces(job));

raceScheduleTimer.clean(0, 'delayed');
raceScheduleTimer.add({}, {
  // every 10 seconds
  repeat: { every: 10000 },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60 * 6,
  removeOnFail: config.bull.historyTTLInHours * 60 * 6,
});

// ---------------------------------------------
performRaceWorker.process(config.MAX_CONCURRENT_WORKERS_FOR_PERFORM_RACE, async (job) => performRace(job));

// ---------------------------------------------
raceFinishWorker.process(async (job) => finishScheduledRaces(job));

raceFinishWorker.clean(0, 'delayed');
raceFinishWorker.add({}, {
  // every 10 seconds
  repeat: { every: 10000 },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60 * 6,
  removeOnFail: config.bull.historyTTLInHours * 60 * 6,
});

// ---------------------------------------------
raceAdminWorker.process(async (job) => handleRaceAdminJobs(job));

raceAdminWorker.clean(0, 'delayed');
raceAdminWorker.add({}, {
  // every minute
  repeat: { cron: '* * * * *' },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60,
  removeOnFail: config.bull.historyTTLInHours * 60,
});

// ---------------------------------------------
raceEnterWorker.process(config.MAX_CONCURRENT_WORKERS_FOR_ENTER, async (job) => enterRace(job));

// ---------------------------------------------
raceAlertWorker.process(async (job) => alertFailedRaces(job));

raceAlertWorker.clean(0, 'delayed');
raceAlertWorker.add({}, {
  // every 5 minutes
  repeat: { cron: '*/5 * * * *' },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 12,
  removeOnFail: config.bull.historyTTLInHours * 12,
});

// ---------------------------------------------
mintLandWorker.process(config.MAX_CONCURRENT_WORKERS_FOR_MINT_LAND, async (job) => mint(job));

// ---------------------------------------------
syncDiscordRolesWorker.process(async (job) => snycAllUserWallletDiscordUserRoles(job));

syncDiscordRolesWorker.clean(0, 'delayed');
syncDiscordRolesWorker.add({}, {
  // every 10 minutes
  repeat: { cron: '*/10 * * * *' },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 6,
  removeOnFail: config.bull.historyTTLInHours * 6,
});

// ---------------------------------------------
raceSyncWorker.process(async (job) => syncRace(job));

raceSyncWorker.clean(0, 'delayed');
raceSyncWorker.add({}, {
  // every minute
  repeat: { cron: `*/${config.RACE_SYNC_DURATION_MINUTES} * * * *` },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60 / config.RACE_SYNC_DURATION_MINUTES,
  removeOnFail: config.bull.historyTTLInHours * 60 / config.RACE_SYNC_DURATION_MINUTES,
});

// ---------------------------------------------
tournamentStatusWorker.process(async (job) => updateTournamentStatus(job));

tournamentStatusWorker.clean(0, 'delayed');
tournamentStatusWorker.add({}, {
  // every minute
  repeat: { cron: '* * * * *' },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60,
  removeOnFail: config.bull.historyTTLInHours * 60,
});

// ---------------------------------------------
raceTimeLimitMonitor.process(async (job) => setRaceScheduleAt(job));

raceTimeLimitMonitor.clean(0, 'delayed');
raceTimeLimitMonitor.add({}, {
  // every 10 seconds
  repeat: { every: 10000 },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60 * 6,
  removeOnFail: config.bull.historyTTLInHours * 60 * 6,
});

// ---------------------------------------------
resetChickenSituationWorker.process(async (job) => resetChickenSituation(job));

resetChickenSituationWorker.clean(0, 'delayed');
resetChickenSituationWorker.add({}, {
  // every minute
  repeat: { cron: '* * * * *' },

  // keep the history for a week
  removeOnComplete: config.bull.historyTTLInHours * 60,
  removeOnFail: config.bull.historyTTLInHours * 60,
});

// ---------------------------------------------
chickenStakingSeasonWorker.process(async (job) => ChickenStakingService.getInstance().startStakingPeriod(job));

chickenStakingSeasonWorker.clean(0, 'delayed');
chickenStakingSeasonWorker.add({}, {
  // every hour
  repeat: { cron: '0 * * * *' },
});

// ---------------------------------------------
bawkStakingWorker.process(config.MAX_CONCURRENT_WORKERS_FOR_ENTER, async (job) => BawkStakingService.getInstance().processBawkStaking(job));

log.info(`ChickenDerby Race Jobs Started On ${new Date()}`);
