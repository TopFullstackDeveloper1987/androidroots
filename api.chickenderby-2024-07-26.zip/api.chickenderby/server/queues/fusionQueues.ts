import Queue from 'bull';
import config from '../config';

export const fusionWorker = new Queue('fusion-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const fusionSyncWorker = new Queue('fusion-sync-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const serumMintWorker = new Queue('serum-mint-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

