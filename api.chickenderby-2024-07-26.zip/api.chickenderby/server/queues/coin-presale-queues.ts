import Queue from 'bull';
import config from '../config';

export const coinPresaleAdminWorker = new Queue('coin-presale-admin-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});
