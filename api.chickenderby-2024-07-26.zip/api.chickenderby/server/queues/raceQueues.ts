import Queue from 'bull';
import config from '../config';

export const raceScheduleTimer = new Queue('race-schedule-timer', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const performRaceWorker = new Queue('perform-race-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const raceEnterWorker = new Queue('Race Enter Worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const raceFinishWorker = new Queue('Race Finish Worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const raceAdminWorker = new Queue('race-admin-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const raceAlertWorker = new Queue('Race Alert Worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const mintLandWorker = new Queue('Mint Land Worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const syncDiscordRolesWorker = new Queue('Sync Discord Roles Worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const raceSyncWorker = new Queue('race-sync-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const tournamentStatusWorker = new Queue('tournament-status-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const raceScheduler = new Queue('Race Scheduler', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const raceTimeLimitMonitor = new Queue('race-time-limit-monitor', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const resetChickenSituationWorker = new Queue('reset-chicken-situation-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});
export const chickenStakingSeasonWorker = new Queue('chicken-staking-season-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const bawkStakingWorker = new Queue<{
  bawkStakingAssignmentId: number;
}>('bawk-staking-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});
