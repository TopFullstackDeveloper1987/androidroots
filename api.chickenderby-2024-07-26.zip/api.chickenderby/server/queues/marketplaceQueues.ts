import Queue from 'bull';
import config from '../config';

export const marketplaceWorker = new Queue('marketplace-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const marketplaceAdminWorker = new Queue('marketplace-admin-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const marketplaceChickenSyncWorker = new Queue('marketplace-chicken-sync-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});

export const marketplaceClothingSyncWorker = new Queue('marketplace-clothing-sync-worker', {
  redis: config.redis,
  defaultJobOptions: config.defaultJobOptions,
});
