// node server/scripts/migrateTokenIdForMarketplaceAssignments

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for marketplaceAssignment.tokenId');

  const marketplaceAssignments = await models.MarketplaceAssignment.findAll({
    where: {
      tokenId: null,
    },
  });

  for (const marketplaceAssignment of marketplaceAssignments) {
    const { marketItemId, tradeOfferId } = marketplaceAssignment;
    let tokenId = null;

    if (marketItemId) {
      const marketItem = await models.MarketItem.findByPk(marketItemId);
      tokenId = marketItem.tokenId;
    } else if (tradeOfferId) {
      const tradeOffer = await models.TradeOffer.findByPk(tradeOfferId, {
        include: [{
          model: models.MarketItem,
        }],
      });
      tokenId = tradeOffer.marketItem.tokenId;
    }

    await marketplaceAssignment.update({
      tokenId,
    });
  }

  log.info('end migration for marketplaceAssignment.tokenId');

  process.exit(0);
})();
