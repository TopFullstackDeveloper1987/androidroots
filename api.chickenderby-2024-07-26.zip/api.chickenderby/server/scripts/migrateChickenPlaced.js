// node server/scripts/migrateChickenPlaced
const { Op } = require('sequelize');

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for chicken placed and placedPercentage');

  const limit = 10000;
  let count = 0;

  const where = {
    races: {
      [Op.gt]: 0,
    },
  };

  const total = await models.Chicken.count({
    where,
  });

  while (count < total) {
    const chickens = await models.Chicken.findAll({
      where,
      offset: count,
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      const {
        races, firsts, seconds, thirds,
      } = chicken;
      const placed = firsts + seconds + thirds;
      const placedPercentage = placed / races * 100;

      await chicken.update({
        placed,
        placedPercentage,
      });

      count += 1;
    }

    log.info(`progress => current: ${count} / total: ${total} (${(count / total * 100).toFixed(2)}%)`);
  }

  log.info('end migration for chicken placed and placedPercentage');

  process.exit(0);
})();
