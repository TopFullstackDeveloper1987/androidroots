// node server/scripts/createCoops.js

const { COOP_LIMIT } = require('../config');
const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for create coops');

  const userWallets = await models.userWallet.findAll();

  for (const userWallet of userWallets) {
    for (let i = 0; i < COOP_LIMIT; i += 1) {
      await models.coop.create({
        name: `Coop ${i + 1}`,
        userId: userWallet.id,
      });
    }
  }

  log.info('end migration for create coops');

  process.exit(0);
})();
