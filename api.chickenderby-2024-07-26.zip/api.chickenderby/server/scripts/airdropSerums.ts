// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/airdropSerums
import 'dotenv/config';
import { AbiItem } from 'web3-utils';

import config from '../config';
import { getFusionAdminSignerAddress, getPolygonWeb3, getGasPrice } from '../services/contracts/web3Service';
import { sleep } from '../utils';

(async () => {
  const limit = 100;

  try {
    const polygonWeb3 = getPolygonWeb3();
    const fusionContract = new polygonWeb3.eth.Contract(config.FUSION_CONTRACT.abi as AbiItem[], config.FUSION_CONTRACT.address);
    const fusionAdmin = getFusionAdminSignerAddress();
    const gasPrice = await getGasPrice(polygonWeb3);

    console.log('Starting Airdrop', config.FUSION_CONTRACT.address);

    const airdrops: {
      userWalletId: string,
      quantity: number,
    }[] = [
      {
        userWalletId: '0x7a7a38a3bc38e7fab3e8dffe513d9bf6f60fda31',
        quantity: 7,
      },
      {
        userWalletId: '0x7b61505e579cf7c52b95cd242612e03ab9a26b28',
        quantity: 7,
      },
      {
        userWalletId: '0xab76c8a0a8fb2fb2b4a9a7f0df541173ca6504bb',
        quantity: 5,
      },
      {
        userWalletId: '0xfecc129cb601b754813936f238a7c56086982f4c',
        quantity: 5,
      },
      {
        userWalletId: '0x7e03d22777bfb569a62e1a04da24546d925f44d1',
        quantity: 5,
      },
      {
        userWalletId: '0xc227ae10e4b78268018e57a4319a605725dfd830',
        quantity: 1,
      },
      {
        userWalletId: '0x83dd5a88915a4e065a52930a8270c656905eb5c8',
        quantity: 1,
      },
      {
        userWalletId: '0x58c5a30e228a26aa2e982bc50f8e2f2ae226caa5',
        quantity: 1,
      },
      {
        userWalletId: '0x958cc2bd6d6c902a0d0c363cce7cb8fddfd65373',
        quantity: 1,
      },
      {
        userWalletId: '0xc227ae10e4b78268018e57a4319a605725dfd830',
        quantity: 1,
      },
      {
        userWalletId: '0xe1474922e5dba2c0947192713c05d4e4540bad9f',
        quantity: 1,
      },
    ];

    while (airdrops.length > 0) {
      const splicedAirdrops = airdrops.splice(0, limit);
      const gasLimit = config.BICONOMY_CUSTOM_GAS_LIMIT + config.BICONOMY_CUSTOM_GAS_LIMIT * (splicedAirdrops.length - 1) * 0.1;

      const userWalletIds = splicedAirdrops.map((airdrop) => airdrop.userWalletId);
      const quantities = splicedAirdrops.map((airdrop) => airdrop.quantity);
      await fusionContract.methods.mintBatch(1, userWalletIds, quantities).send({
        from: fusionAdmin.publicAddress,
        gas: gasLimit,
        gasPrice,
      });

      console.log('splicedAirdrops', splicedAirdrops, 'Sub Mint Success');
      await sleep(500);
    }

    console.log('Mint success');
  } catch (err) {
    console.log('Mint error', err);
    process.exit(1);
  }

  process.exit(0);
})();
