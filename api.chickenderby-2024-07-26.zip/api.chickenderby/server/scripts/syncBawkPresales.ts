// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/syncBawkPresales.ts
require('dotenv').config();

import '../sequelize/models';
import { UserWallet } from '../sequelize/models/UserWallet';
import { GoldenTicket } from '../sequelize/models/GoldenTicket';
import { BawkPresale } from '../sequelize/models/BawkPresale';

import { createUserWallet } from '../services/userWalletService';
import { redisConnect, redisGetAsync } from '../services/redisClient';
import { getChickenIdsForUserWalletId } from '../services/contracts/chickenContractService';
import { getBawkPresaleUsers, getBawkPresaleUsersCount, getUserTotalReserved } from '../services/contracts/bawkPresaleContractService';

import { log } from '../utils';

const limit = 100;
const redisKey = 'sync_bawk_presales';

const syncBawkPresalesByUser = async (userWalletId: string) => {
  await UserWallet.sequelize?.transaction(async (t) => {
    let userWallet = await UserWallet.findByPk(userWalletId, { transaction: t });

    if (!userWallet) {
      userWallet = await createUserWallet(userWalletId, t);
    }

    const usersTotalReserved = await getUserTotalReserved(userWallet.id);
    const chickenIds = await getChickenIdsForUserWalletId(userWallet.id);
    const goldenTicket = await GoldenTicket.findOne({
      where: {
        userWalletId: userWallet.id,
      },
      transaction: t,
    });

    const bawkPresale = await BawkPresale.findOne({
      where: {
        userWalletId: userWallet.id,
      },
      transaction: t,
    });

    const chickens = chickenIds.length;
    const goldenTickets = goldenTicket?.amount || 0;
    const chickenHolderSales = Math.min(usersTotalReserved, chickens);
    const goldenTicketSales = Math.max(Math.min(usersTotalReserved - chickens, goldenTickets), 0);
    const publicSales = Math.max(usersTotalReserved - chickenHolderSales - goldenTicketSales, 0);

    if (bawkPresale) {
      return bawkPresale.update({
        amount: usersTotalReserved,
        chickenHolderSales,
        goldenTicketSales,
        publicSales,
        chickens,
        goldenTickets,
        salesSyncedAt: new Date(),
      }, { transaction: t });
    }

    return BawkPresale.create({
      amount: usersTotalReserved,
      chickenHolderSales,
      goldenTicketSales,
      publicSales,
      chickens,
      goldenTickets,
      salesSyncedAt: new Date(),
      userWalletId: userWallet.id,
    }, { transaction: t });
  });
};

const syncBakePresales = async () => {
  const redisClient = redisConnect();
  const initialOffset = await redisGetAsync(redisKey);
  let offset = initialOffset ? parseInt(initialOffset, 10) : 0;
  const total = await getBawkPresaleUsersCount();

  log.info(`sync presales start at ${offset}`);

  while (true) {
    const start = offset;
    const end = (offset + limit) - 1;
    const userWalletIds = await getBawkPresaleUsers(start, end);

    for (const userWalletId of userWalletIds) {
      await syncBawkPresalesByUser(userWalletId);

      offset += 1;
      redisClient.set(redisKey, offset.toString());
    }

    log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);

    if (userWalletIds.length < limit) {
      break;
    }
  }

  log.info('sync presales ended');
  redisClient.del(redisKey);
};

(async () => {
  await syncBakePresales();
  process.exit(0);
})();
