// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateUsdToJewelForOpenRaces.ts
import '../sequelize/models';
import { Race } from '../sequelize/models/Race';

import { convertCoinToJewel } from '../services/exchangeService';
import { RaceStatus } from '../types/races/raceStatus';

const migrateOpenRaces = async () => {
  console.log('Start migrating open races');

  const races = await Race.findAll({
    where: {
      status: RaceStatus.Open,
    },
  });

  for (const race of races) {
    const feeJEWEL = await convertCoinToJewel(race.coinType, race.fee);
    const prizePoolJEWEL = await convertCoinToJewel(race.coinType, race.prizePool);

    await race.update({
      feeJEWEL,
      prizePoolJEWEL,
    });
  }

  console.log('End migrating open races');
};

(async () => {
  await migrateOpenRaces();
})();
