// node server/scripts/migrateResultEarnings.js

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for chicken.info.race_earnings');

  const results = await models.result.findAll();
  for (const result of results) {
    const { chickens } = result.gameInfo;
    for (const chicken of chickens) {
      if (chicken.info.race_earnings === 'NaN') {
        chicken.info.race_earnings = undefined;
      }
    }

    result.gameInfo = {
      ...result.gameInfo,
      chickens,
    };

    await result.save();
  }

  log.info('end migration for chicken.info.race_earnings');

  process.exit(0);
})();
