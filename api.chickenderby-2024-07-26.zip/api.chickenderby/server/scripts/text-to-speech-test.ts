// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/text-to-speech-test.ts
import 'dotenv/config';

import { ElevenLabsService, Narrators } from '../services/eleven-labs.service';

(async () => {
  console.log('Start');

  const text = 'The chickens are off and running,<break time="1.0s" /> what a start!';
  const filename = 'race-test-01';
  const voiceName = Narrators.Tom;

  const url = await ElevenLabsService.getInstance().getAudioUrlForText(text, filename, voiceName);

  console.log('End url', url);
})();
