// node server/scripts/approveMarketplace
// Test script to approve chickens for marketplace contract on backend

require('dotenv').config();

const { log } = require('../utils');
const { CHICKEN_CONTRACT } = require('../abi/chickenContract');
const {
  getChickenOwnerAccount,
} = require('../services/contracts/chickenContractService');
const {
  fetchMarketItemById,
  fetchTradeOfferById,
  getMarketFeePercent,
  getMarketFeeRecipient,
  setApprovalForAllForMarketplace,
  isAllTokensApprovedForMarketplace,
  fetchActiveMarketItems,
  fetchActiveTradeOffers,
} = require('../services/contracts/marketplaceContractService');

(async () => {
  log.info('start approving marketplace contract for chickens');

  const { TEST_CHICKEN_OWNER_PRIVATE_KEY } = process.env;
  if (!TEST_CHICKEN_OWNER_PRIVATE_KEY) {
    log.error('Chicken owner private key not found');
    process.exit(0);
  }

  const chickenOwnerAccount = await getChickenOwnerAccount(TEST_CHICKEN_OWNER_PRIVATE_KEY);
  let isApproved = await isAllTokensApprovedForMarketplace(chickenOwnerAccount.address, CHICKEN_CONTRACT.address);

  log.info({
    chickenOwnerAccount,
    isApproved,
  }, 'Before setApprovalForAll');

  if (!isApproved) {
    await setApprovalForAllForMarketplace(chickenOwnerAccount.address, CHICKEN_CONTRACT.address, true);
    isApproved = await isAllTokensApprovedForMarketplace(chickenOwnerAccount.address, CHICKEN_CONTRACT.address);

    log.info({
      chickenOwnerAccount,
      isApproved,
    }, 'After setApprovalForAll');
  }

  const marketFeePercent = await getMarketFeePercent();
  const marketFeeRecipient = await getMarketFeeRecipient();

  const {
    count: totalActiveMarketItems, rows: activeMarketItems,
  } = await fetchActiveMarketItems(0, 100);

  const {
    count: totalActiveTradeOffers, rows: activeTradeOffers,
  } = await fetchActiveTradeOffers(0, 100);

  const marketItemId = activeMarketItems[0]?.id || 1;
  const marketItem = await fetchMarketItemById(marketItemId);

  const tradeOfferId = activeTradeOffers[0]?.id || 1;
  const tradeOffer = await fetchTradeOfferById(tradeOfferId);

  log.info({
    marketFeePercent,
    marketFeeRecipient,
    marketItemId: marketItem.id,
    marketItem,
    tradeOfferId: tradeOffer.id,
    tradeOffer,
    tokensAttached: tradeOffer.tokensAttached,
  }, 'Fetch Market Item By Id');

  log.info({
    totalActiveMarketItems,
    activeMarketItems,
    seller: activeMarketItems[0]?.seller,
    totalActiveTradeOffers,
    activeTradeOffers,
    offerMaker: activeTradeOffers[0]?.offerMaker,
  }, 'Fetch Active items with pagination');

  log.info('end approving marketplace contract for chickens');

  process.exit(0);
})();
