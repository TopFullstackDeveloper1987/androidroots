// node server/scripts/migrateBetaUserAt

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('Start migration to add betaUserAt');

  const betaUsers = await models.betaUser.findAll();

  for (const betaUser of betaUsers) {
    await models.userWallet.update({
      betaUserAt: new Date(),
    }, {
      where: {
        publicAddress: betaUser.publicAddress,
      },
    });
  }

  log.info(`End migration to add betaUserAt for ${betaUsers.length}`);

  process.exit(0);
})();
