// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateChickenFamilyPath

import Sequelize from 'sequelize';

import models from '../sequelize/models';
import { log, sleep } from '../utils';

const migrateChickenFamilyPath = async () => {
  log.info('start migration for chicken familyPath');

  const limit = 10000;
  let offset = 0;

  const where: Sequelize.WhereOptions = {
    familyPath: null,
  };
  const total = await models.Chicken.count({
    where,
  });

  while (offset < total) {
    const chickens = await models.Chicken.findAll({
      where,
      offset,
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      await chicken.update({
        familyPath: `${chicken.id}.`,
      });
    }

    await sleep(1000);

    offset += chickens.length;

    log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);
  }

  log.info('end migration for chicken familyPath');
};

(async () => {
  await migrateChickenFamilyPath();

  process.exit(0);
})();
