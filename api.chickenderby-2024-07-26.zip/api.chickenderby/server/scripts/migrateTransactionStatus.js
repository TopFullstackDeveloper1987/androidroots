// node server/scripts/migrateTransactionStatus.js

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for transaction.status');

  await models.sequelize.query('UPDATE transactions SET status = "paid" where status = "success"');

  log.info('end migration for transaction.status');

  process.exit(0);
})();
