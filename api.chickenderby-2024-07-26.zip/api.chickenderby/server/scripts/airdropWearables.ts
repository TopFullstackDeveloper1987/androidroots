// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/airdropWearables.ts
const csvToJson = require('convert-csv-to-json');
import * as path from 'path';
import * as fs from 'fs';
import 'dotenv/config';

import config from '../config';
import { getWearablesOwnerAddress, getPolygonWeb3, getGasPrice, getClothingContract } from '../services/contracts/web3Service';
import { sleep } from '../utils';

// set maxType on contract
// download the CSV, remove the first row with Private and Public, and then remove all the other columns except for nft_id, Wallet, NumberOfOwners
const readCSV = () => {
  const csvFiles = [
    'Elves.csv',
  ];

  const mappings: {
    id: number;
    userWalletIds: string[];
    maxNumberOfOwners: number;
  }[] = [];

  for (const csvFile of csvFiles) {
    const inputFilePath = path.resolve(__dirname, `./${csvFile}`);
    if (!fs.existsSync(inputFilePath)) {
      throw new Error('Please get the csv file for chicken seeders');
    }

    const json = csvToJson.fieldDelimiter(',').getJsonFromCsv(inputFilePath);
    // convert "" to null
    const nfts: {
      nft_id: string;
      Wallet: string;
      NumberOfOwners: string;
    }[] = JSON.parse(
      JSON.stringify(
        json,
        (key, value) => (value === '' ? null : value),
        2,
      ),
    );

    for (const nft of nfts) {
      const mapping = mappings.find((m) => m.id === Number(nft.nft_id));
      if (!mapping) {
        mappings.push({
          id: Number(nft.nft_id),
          userWalletIds: [nft.Wallet.replace(/ /g, '')],
          maxNumberOfOwners: Number(nft.NumberOfOwners),
        });
      } else {
        mapping.userWalletIds.push(nft.Wallet.replace(/ /g, ''));
      }
    }
  }

  return mappings;
};

(async () => {
  let lastMintId = 0;
  const limit = 100;

  try {
    const clothingContract = await getClothingContract();
    const wearablesOwner = getWearablesOwnerAddress();
    const polygonWeb3 = getPolygonWeb3();
    const gasPrice = await getGasPrice(polygonWeb3);

    console.log('Starting Airdrop');

    const mappings = readCSV();

    for (const mapping of mappings) {
      const { id, userWalletIds, maxNumberOfOwners } = mapping;

      console.log('Before setMaxNumber For', id, 'maxNumberOfOwners', maxNumberOfOwners);

      await clothingContract.methods.setMaxNumber(id, maxNumberOfOwners).send({
        from: wearablesOwner.publicAddress,
        gas: config.BICONOMY_CUSTOM_GAS_LIMIT,
        gasPrice,
      });

      console.log('After setMaxNumber For', id);

      while (userWalletIds.length > 0) {
        const splicedUserWalletIds = userWalletIds.splice(0, limit);
        const gasLimit = config.BICONOMY_CUSTOM_GAS_LIMIT + config.BICONOMY_CUSTOM_GAS_LIMIT * (splicedUserWalletIds.length - 1) * 0.1;

        await clothingContract.methods.mint(id, splicedUserWalletIds).send({
          from: wearablesOwner.publicAddress,
          gas: gasLimit,
          gasPrice,
        });

        console.log('id', id, 'splicedUserWalletIds', splicedUserWalletIds, 'Sub Mint Success');
        await sleep(500);
      }

      lastMintId = id;
      console.log('lastMintId', lastMintId, 'Mint success');
    }
  } catch (err) {
    console.log('lastMintId', lastMintId, 'Mint error', err);
    process.exit(1);
  }

  process.exit(0);
})();
