// node server/scripts/migrateRacePaidStatus.js

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for race.paidStatus');

  const races = await models.race.findAll();
  for (const race of races) {
    let paidStatus = 'unpaid';

    if (race.paidStatus === '1') {
      paidStatus = 'paid';
    } else if (race.paidStatus === '2') {
      paidStatus = 'error';
    } else if (race.paidStatus === '3') {
      paidStatus = 'postponed';
    } else if (race.paidStatus === '4') {
      paidStatus = 'receiptNotReady';
    }

    await race.update({
      paidStatus,
    });
  }

  log.info('end migration for race.paidStatus');

  process.exit(0);
})();
