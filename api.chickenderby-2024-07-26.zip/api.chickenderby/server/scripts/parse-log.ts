// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/parse-log.ts
import { CoinPresaleService } from '../services/coin-presale/coin-presale.service';

const run = () => {
  const topics = [
    '0x135cbd296cd849f586e6880a2a9c9d92a2561aa418d1ff418328683b0a58cfb5',
    '0x0000000000000000000000000741993ce0930614dd67ec4af36cf77d688f5610',
    '0x00000000000000000000000000000000000000000000000000000000000428de',
    '0x0000000000000000000000000000000000000000000000000000000000000001',
  ];
  const data = '0x00000000000000000000000000000000000000000000000000000000513e2ff000000000000000000000000000000000000000000000000000000000665f0f7b';

  const result = CoinPresaleService.parseLog(data, topics);

  console.log('result', result);
};

(async () => {
  run();
})();
