// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/raffleBawkPresales.ts
require('dotenv').config();

import Sequelize from 'sequelize';
import '../sequelize/models';
import { BawkPresale } from '../sequelize/models/BawkPresale';

import { log, shuffleArray } from '../utils';

const { Op } = Sequelize;

type RaffleTarget = 'chickenHolderSales' | 'goldenTicketSales' | 'publicSales'
type RaffleResult = { [address: string]: number }

const raffleBakePresales = async () => {
  const totalSales = await BawkPresale.sum('amount');
  const chickenHolderSales = await BawkPresale.sum('chickenHolderSales');
  const goldenTicketSales = await BawkPresale.sum('goldenTicketSales');
  const publicSales = await BawkPresale.sum('publicSales');
  const max = Math.min(totalSales, 20000);

  let raffleTarget: RaffleTarget;
  let raffleCount: number;

  if (chickenHolderSales >= max) {
    raffleTarget = 'chickenHolderSales';
    raffleCount = max;
  } else if (chickenHolderSales + goldenTicketSales > max) {
    raffleTarget = 'goldenTicketSales';
    raffleCount = max - chickenHolderSales;
  } else {
    raffleTarget = 'publicSales';
    raffleCount = max - chickenHolderSales - goldenTicketSales;
  }

  log.info(`raffle target: ${raffleTarget}, raffle count: ${raffleCount} => total: ${totalSales}, chicken holder sales: ${chickenHolderSales}, golden ticket sales: ${goldenTicketSales}, public sales: ${publicSales}`);

  await BawkPresale.sequelize?.transaction(async (t) => {
    let updateValues: Sequelize.Attributes<BawkPresale>;
    if (raffleTarget === 'chickenHolderSales') {
      updateValues = {
        lost: Sequelize.literal('goldenTicketSales + publicSales'),
      };
    } else if (raffleTarget === 'goldenTicketSales') {
      updateValues = {
        won: Sequelize.literal('chickenHolderSales'),
        lost: Sequelize.literal('publicSales'),
      };
    } else {
      updateValues = {
        won: Sequelize.literal('chickenHolderSales + goldenTicketSales'),
        lost: 0,
      };
    }

    await BawkPresale.update(updateValues, {
      where: {},
      transaction: t,
    });

    const raffleSales = await BawkPresale.findAll({
      attributes: ['userWalletId', raffleTarget],
      where: {
        [raffleTarget]: { [Op.gt]: 0 },
      },
      transaction: t,
    });

    const userWalletIds: string[] = [];

    for (const raffleSale of raffleSales) {
      const sales = raffleSale[raffleTarget];
      for (let i = 0; i < sales; i += 1) {
        userWalletIds.push(raffleSale.userWalletId);
      }
    }

    const shuffledUserWalletIds = shuffleArray(userWalletIds);
    const raffleWonAddresses = shuffledUserWalletIds.slice(0, raffleCount);
    const raffleResult = raffleWonAddresses.reduce<RaffleResult>((obj, address) => ({
      ...obj,
      [address]: (obj[address] || 0) + 1,
    }), {});

    log.info(`won ${raffleWonAddresses.length} in ${shuffledUserWalletIds.length} from ${raffleTarget}`);
    const total = await BawkPresale.count();
    const limit = 1000;
    let offset = 0;

    while (true) {
      const bawkPresales = await BawkPresale.findAll({
        offset,
        limit,
        order: [['createdAt', 'ASC']],
        transaction: t,
      });

      for (const bawkPresale of bawkPresales) {
        const targetSales = bawkPresale[raffleTarget];
        const won = raffleResult[bawkPresale.userWalletId] || 0;
        const lost = targetSales - won;

        await bawkPresale.update({
          won: bawkPresale.won + won,
          lost: bawkPresale.lost + lost,
          raffles: won,
          rafflesSyncedAt: new Date(),
        }, {
          transaction: t,
        });

        offset += 1;
      }

      log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);

      if (bawkPresales.length < limit) {
        break;
      }
    }

    log.info('done');
  });
};

(async () => {
  await raffleBakePresales();
  process.exit(0);
})();
