// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/commentaryBaseData.ts
import '../sequelize/models';
import { Chicken } from '../sequelize/models/Chicken';
import { Lane } from '../sequelize/models/Lane';
import { Race } from '../sequelize/models/Race';
import { Result } from '../sequelize/models/Result';
import { Terrain } from '../sequelize/models/Terrain';
import { CommentaryService } from '../services/commentaryService';

(async () => {
  // Please check the last mint id on the database before running the script!
  const raceId = 3005074;

  const raceModel = await Race.findOne({
    where: {
      id: raceId,
    },
    include: [
      {
        model: Terrain,
        attributes: ['name', 'image'],
      },
      {
        model: Lane,
        include: [Chicken],
        as: 'lanes',
      },
    ],
  });

  const resultModel = await Result.findOne({ where: { raceId } });

  if (!raceModel || !resultModel) {
    return;
  }

  const race = {
    id: raceModel.id,
    name: raceModel.name,
    peckingOrder: raceModel.peckingOrder,
    distance: raceModel.distance,
    fee: raceModel.fee,
    feeJEWEL: raceModel.feeJEWEL,
    prizePool: raceModel.prizePool,
    prizePoolJEWEL: raceModel.prizePoolJEWEL,
    maxCapacity: raceModel.maxCapacity,
    location: raceModel.location,
    terrain: {
      name: raceModel.terrain.name,
      image: raceModel.terrain.image,
    },
    lanes: raceModel.lanes.map((lane) => ({
      id: lane.id,
      laneNumber: lane.laneNumber,
      chicken: {
        id: lane.chicken.id,
        name: lane.chicken.name,
        heritage: lane.chicken.heritage,
        perfection: lane.chicken.perfection,
        stock: lane.chicken.stock,
        talent: lane.chicken.talent,
        image: lane.chicken.image,
        gender: lane.chicken.gender,
        animal: lane.chicken.animal,
        baseBody: lane.chicken.baseBody,
        stripes: lane.chicken.stripes,
        eyesType: lane.chicken.eyesType,
        beakColor: lane.chicken.beakColor,
        beakAccessory: lane.chicken.beakAccessory,
        combColor: lane.chicken.combColor,
        wattleColor: lane.chicken.wattleColor,
        legs: lane.chicken.legs,
        background: lane.chicken.background,
        races: lane.chicken.races,
        firsts: lane.chicken.firsts,
        seconds: lane.chicken.seconds,
        thirds: lane.chicken.thirds,
        earnings: lane.chicken.earnings,
      },
    })),
  };

  const d = new CommentaryService(raceModel, resultModel.raceProfiles);
  const comment = await d.generateRaceCommentaries();
  console.log('============');
  console.log(JSON.stringify(comment));

  // console.log('race========');
  // console.log(JSON.stringify(race));
  // console.log('race profiles ==========');
  // console.log(JSON.stringify(resultModel.raceProfiles));
})();
