// node server/scripts/migrateResultsToLanes
const { Op } = require('sequelize');

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for result.chickens');
  const limit = 1000;
  let count = 0;

  const where = {
    chickens: {
      [Op.not]: null,
    },
  };

  const total = await models.Result.count({ where });

  while (count < total) {
    const results = await models.Result.findAll({
      where,
      limit,
      order: [['id', 'ASC']],
    });

    for (const result of results) {
      await models.sequelize.transaction(async (t) => {
        const { raceId, chickens } = result.toJSON();

        for (let i = 0; i < chickens.length; i += 1) {
          const chicken = chickens[i];
          await models.Lane.update({
            position: i + 1,
            raceEarnings: chicken.raceEarnings || 0,
            bonusBawk: chicken.bonusBawk,
          }, {
            where: {
              raceId,
              chickenId: chicken.id,
            },
            transaction: t,
          });
        }

        await result.update({
          chickens: null,
        }, {
          transaction: t,
        });
      });

      count += 1;
    }

    log.info(`progress => current: ${count} / total: ${total} (${(count / total * 100).toFixed(2)}%)`);
  }

  log.info('end migration for result.chickens');

  process.exit(0);
})();
