// node server/scripts/migrateChickensForPerformance3.js
require('../sequelize/models');
const { updateTokens } = require('../services/chickenService');
const { redisConnect, redisGetAsync } = require('../services/redisClient');
const { sleep } = require('../utils');
const allChickens = require('./chickensPerformance3.json');
const { log } = require('../utils');

let offset = 0;
const limit = 100;
let redisClient;

const getChickens = () => allChickens.slice(offset, offset + limit).map((chicken) => ({
  tokenId: chicken.tokenId,
  consistency: Number(chicken.consistency),
  terrainPreference: chicken.terrainPreference,
  terrainPreferenceStrength: Number(chicken.terrainPreferenceStrength),
  distancePreference: chicken.distancePreference,
  distancePreferenceStrength: Number(chicken.distancePreferenceStrength),
  talentPreference: chicken.talentPreference,
  talentPreferenceStrength: Number(chicken.talentPreferenceStrength),
}));

const migrateChickens = async () => {
  const total = allChickens.length;

  log.info('start migration of chickens for performance v3.0');
  log.info(`starting from ${offset} records`);

  while (offset < total) {
    const chickens = getChickens();
    // console.log('chickens', chickens);
    await updateTokens(chickens);

    offset += chickens.length;
    redisClient.set('migrateChickensForPerformance3', `${offset}`, 'EX', 24 * 3600); // 24 hours

    log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);

    await sleep(100);
  }

  log.info('end migration of chickens for performance v3.0');
};

(async () => {
  try {
    redisClient = redisConnect();

    const initialOffset = await redisGetAsync('migrateChickensForPerformance3');

    offset = initialOffset ? parseInt(initialOffset, 10) : 0;

    await migrateChickens();

    redisClient.del('migrateChickensForPerformance3');

    log.info('DONE');
  } catch (err) {
    log.info({
      func: 'migrateChickensForPerformance3',
      err,
    });
  }

  process.exit(0);
})();
