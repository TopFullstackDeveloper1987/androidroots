// node server/scripts/migrateLanes.js

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for lanes');

  const races = await models.race.findAll();
  for (const raceModel of races) {
    for (const lane of raceModel.Lanes) {
      // For old races, we just put assignedAt as startsAt. Couldn't use raceAssignment.createdAt for free races
      const assignedAt = lane.assigned ? (raceModel.startsAt || new Date()) : null;

      await models.lane.create({
        raceId: raceModel.id,
        laneNumber: lane.lane,
        assignedAt,
        tokenId: lane.chickenId,
        userWalletId: lane.userWalletId,
      });
    }
  }

  log.info('end migration for lanes');

  process.exit(0);
})();
