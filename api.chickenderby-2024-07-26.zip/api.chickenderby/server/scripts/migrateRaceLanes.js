// node server/scripts/migrateRaceLanes.js

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for race.lanes');

  const races = await models.race.findAll({
    where: {
      lanes: null,
    },
    include: [{
      model: models.Lane,
      required: true,
    }],
  });

  for (const raceModel of races) {
    await raceModel.update({
      lanes: raceModel.Lane.lane,
    });
  }

  log.info('end migration for race.lanes');

  process.exit(0);
})();
