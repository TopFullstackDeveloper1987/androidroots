// node server/scripts/migrateChickenBonusPoPoints

const models = require('../sequelize/models');
const { updateTokens, getTokens } = require('../services/chickenService');
const { redisConnect, redisGetAsync } = require('../services/redisClient');
const { sleep } = require('../utils');
const allChickens = require('./chickensPerformance3.json');
const { log } = require('../utils');

let offset = 0;
const limit = 100;
let redisClient;

const getChickRaces = async (tokenId) => models.race.count({
  distinct: true,
  where: {
    peckingOrder: 'CHICK',
    status: 'finished',
  },
  include: [{
    model: models.lane,
    where: {
      tokenId,
    },
  }],
});

const getChickens = async () => {
  const chickens = allChickens.slice(offset, offset + limit);

  const bonusPoPointList = {
    Serama: [35, 30, 20, 20, 20, 10, 10, 10, 10, 10, 10],
    Sultan: [30, 20, 10, 10, 10, 10, 0, 0, 0, 0, 0],
    Lakenvelder: [20, 10, 10, 0, 0, 0, 0, 0, 0, 0, 0],
    Dorking: [20, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  };

  const tokenIds = chickens.map((chicken) => chicken.tokenId);
  const tokens = await getTokens(tokenIds);

  const updatedChickens = [];
  for (const chicken of chickens) {
    const {
      tokenId,
      perfection,
      heritage,
    } = chicken;

    const poPointIndex = 100 - Number(perfection);
    const bonusPoPoints = bonusPoPointList[heritage][poPointIndex];

    const token = tokens.find((t) => t.tokenId === tokenId);
    const chickRaces = await getChickRaces(tokenId);

    updatedChickens.push({
      tokenId,
      poPoints: Math.min(token.info.poPoints + bonusPoPoints, 110),
      chickRaces,
    });
  }

  return updatedChickens;
};

const migrateChickens = async () => {
  const total = allChickens.length;

  log.info('start migrating bonus poPoints');
  log.info(`starting from ${offset} records`);

  while (offset < total) {
    const chickens = await getChickens();
    // console.log('chickens', chickens);
    await updateTokens(chickens);

    offset += limit;
    redisClient.set('migrateChickenBonusPoPoints', `${offset}`, 'EX', 24 * 3600); // 24 hours

    log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);

    await sleep(100);
  }

  log.info('end migrating bonus poPoints');
};

(async () => {
  try {
    redisClient = redisConnect();

    const initialOffset = await redisGetAsync('migrateChickenBonusPoPoints');

    offset = initialOffset ? parseInt(initialOffset, 10) : 0;

    await migrateChickens();

    redisClient.del('migrateChickenBonusPoPoints');

    log.info('DONE');
  } catch (err) {
    log.info({
      func: 'migrateChickenBonusPoPoints',
      err,
    });
  }

  process.exit(0);
})();
