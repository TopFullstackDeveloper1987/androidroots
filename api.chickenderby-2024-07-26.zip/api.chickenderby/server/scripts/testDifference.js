// node server/scripts/testDifference

require('dotenv').config();
const _ = require('lodash');

const models = require('../sequelize/models');
const { log } = require('../utils');

const { getRaceContractChickenIds } = require('../services/contracts/raceContractService');

(async () => {
  const raceId = 1931;
  const contractChickenIds = await getRaceContractChickenIds(raceId);
  const race = await models.Race.findByPk(raceId, {
    include: [{
      model: models.Lane,
      as: 'lanes',
    }],
  });
  const { lanes } = race;

  const raceChickenIds = lanes.filter((lane) => !!lane.chickenId).map((lane) => lane.chickenId);
  const chickenIdsToEnterDatabase = _.difference(contractChickenIds, raceChickenIds);
  const chickenIdsToEnterContract = _.difference(raceChickenIds, contractChickenIds);

  log.info({
    contractChickenIds,
    raceChickenIds,
    chickenIdsToEnterDatabase,
    chickenIdsToEnterContract,
  });

  process.exit(0);
})();
