// node server/scripts/migrateResultChickensAndRaceProfiles
const _ = require('lodash');

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for result.chickens and raceProfiles');

  const results = await models.Result.findAll();
  await models.sequelize.transaction(async (t) => {
    for (const resultModel of results) {
      const { chickens, raceProfiles } = resultModel.toJSON();

      resultModel.chickens = chickens.map((chicken) => {
        const { info } = chicken;
        info.id = Number(info.tokenId);

        return _.pick(info, [
          'id',
          'owner',
          'bonusBawk',
          'raceEarnings',
        ]);
      });
      resultModel.raceProfiles = raceProfiles.map((raceProfile) => {
        raceProfile.chickenId = Number(raceProfile.tokenId);
        delete raceProfile.tokenId;

        if (raceProfile.metas) {
          raceProfile.metas = raceProfile.metas.map((meta) => {
            if (meta.targetTokenIds) {
              meta.targetChickenIds = meta.targetTokenIds.map((targetTokenId) => Number(targetTokenId));
              delete meta.targetTokenIds;
            }

            if (meta.copyChickens) {
              meta.copyChickens = meta.copyChickens.map((copyChicken) => {
                copyChicken.chickenId = Number(copyChicken.tokenId);
                delete copyChicken.tokenId;

                return copyChicken;
              });
            }

            return meta;
          });
        }

        return raceProfile;
      });

      await resultModel.save({
        transaction: t,
      });
    }
  });

  log.info('end migration for result.chickens and raceProfiles');

  process.exit(0);
})();
