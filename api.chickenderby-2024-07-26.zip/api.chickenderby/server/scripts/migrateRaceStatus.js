// node server/scripts/migrateRaceStatus.js

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for race.status');

  const races = await models.race.findAll();
  for (const race of races) {
    let status = 'open';
    if (race.raceType === 2) {
      status = 'scheduled';
    } else if (race.raceType === 3) {
      status = 'finished';
    }

    await race.update({
      status,
    });
  }

  log.info('end migration for race.status');

  process.exit(0);
})();
