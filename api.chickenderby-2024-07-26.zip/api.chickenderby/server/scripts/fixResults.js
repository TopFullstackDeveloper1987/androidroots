// node server/scripts/fixResults
const models = require('../sequelize/models');
const { performRace } = require('../services/raceService');

(async () => {
  const races = await models.Race.findAll({
    where: {
      id: [73564, 73568],
      // id: [1001022],
    },
  });

  for (const race of races) {
    await performRace(race);
  }

  process.exit(0);
})();
