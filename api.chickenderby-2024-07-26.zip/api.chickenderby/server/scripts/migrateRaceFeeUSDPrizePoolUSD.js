// node server/scripts/migrateRaceFeeUSDPrizePoolUSD.js

const models = require('../sequelize/models');
const { getCoinRate } = require('../services/exchangeService');
const { log } = require('../utils');

(async () => {
  log.info('start migration for race.feeUSD and prizePoolUSD');

  const coinRate = await getCoinRate();
  const races = await models.race.findAll({
    where: {
      status: 'finished',
    },
  });

  for (const raceModel of races) {
    const result = await models.result.findOne({
      where: {
        raceId: raceModel.id,
      },
    });

    if (!result) {
      continue;
    }

    const feeUSD = Number((Number(result.gameInfo.race_stats.feeUSD) || (raceModel.fee * coinRate.weth)).toFixed(2));
    const prizePoolUSD = Number((Number(result.gameInfo.race_stats.prizePoolUSD) || (raceModel.prizePool * coinRate.weth)).toFixed(2));

    await raceModel.update({
      feeUSD,
      prizePoolUSD,
    });
  }

  log.info('end migration for race.feeUSD and prizePoolUSD');

  process.exit(0);
})();
