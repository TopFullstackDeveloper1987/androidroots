// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateRaceHistories.ts
import Sequelize from 'sequelize';
import * as moment from 'moment-timezone';

const { Op } = Sequelize;

import 'dotenv/config';

import models from '../sequelize/models';
import { redisConnect, redisGetAsync } from '../services/redisClient';
import { getPositionType } from '../services/raceService';

const redisKey = 'migrate-race-histories-date';

const getFirstDate = async () => {
  const firstRace = await models.Race.findOne({
    where: {
      endsAt: {
        [Op.not]: null,
      },
    },
    order: [['endsAt', 'ASC']],
  });

  return moment.utc(firstRace?.endsAt).format('YYYY-MM-DD');
};

const executeRecordChanges = async (date: string) => {
  const lanes = await models.Lane.findAll({
    where: {
      chickenId: {
        [Op.not]: null,
      },
    },
    include: [{
      model: models.Race,
      where: {
        endsAt: {
          [Op.between]: [
            moment.utc(date).startOf('day').toDate(),
            moment.utc(date).endOf('day').toDate(),
          ],
        },
      },
    }],
  });

  await models.sequelize.transaction(async (t) => {
    for (const lane of lanes) {
      const {
        raceId,
        chickenId,
        userWalletId,
        raceEarnings,
        position,
      } = lane;

      const {
        terrainId,
        distance,
        currentCapacity,
        peckingOrder,
        coinContract,
        feeJEWEL,
        endsAt,
      } = lane.race;

      const positionType = getPositionType(position);

      await models.RaceHistory.create({
        raceId,
        userWalletId,
        chickenId,
        position,
        raceEarnings,
        date,
        terrainId,
        distance,
        capacity: currentCapacity,
        peckingOrder,
        coinContract,
        feeJEWEL,
        createdAt: endsAt,
        positionType,
      }, {
        transaction: t,
      });
    }
  });

  console.log(`${date}: migrated ${lanes.length} race histories`);
};

const run = async () => {
  const redisClient = redisConnect();

  const today = moment.utc().format('YYYY-MM-DD');
  let date = await redisGetAsync(redisKey);
  if (!date) {
    date = await getFirstDate();
  }

  while (date <= today) {
    await executeRecordChanges(date);

    date = moment.utc(date).add(1, 'day').format('YYYY-MM-DD');
    redisClient.set(redisKey, date, 'EX', 2 * 24 * 60 * 60); // expiration of 2 days
  }
};

(async () => {
  console.log('Start migration race histories');

  await run();

  console.log('End migrating race histories');

  process.exit(0);
})();
