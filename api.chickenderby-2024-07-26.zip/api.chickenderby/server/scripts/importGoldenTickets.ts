// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/importGoldenTickets.ts


const csvToJson = require('convert-csv-to-json');
import * as path from 'path';
import 'dotenv/config';

import '../sequelize/models';
import { GoldenTicket } from '../sequelize/models/GoldenTicket';

const readCSV = () => {
  const inputFilePath = path.resolve(__dirname, './goldenTickets.csv');

  const json = csvToJson.fieldDelimiter(',').getJsonFromCsv(inputFilePath);


  return json;
};

const importGoldenTicket = async (userWalletId: string) => {
  const goldenTicket = await GoldenTicket.findOne({
    where: {
      userWalletId,
    },
  });

  if (goldenTicket) {
    return goldenTicket.update({
      amount: goldenTicket.amount + 1,
      isOriginal: true,
    });
  }


  return GoldenTicket.create({
    userWalletId,
    amount: 1,
    isOriginal: true,
  });
};

(async () => {
  try {
    console.log('start importing golden tickets');
    const mappings = readCSV();

    for (const item of mappings) {
      if (!item.userWalletId) {
        continue;
      }

      let userWalletId: string = item.userWalletId;

      if (!userWalletId.startsWith('0x')) {
        userWalletId = `0x${userWalletId}`;
      }

      await importGoldenTicket(userWalletId);
    }

    console.log('ended importing golden tickets');
  } catch (err) {
    process.exit(1);
  }
})();
