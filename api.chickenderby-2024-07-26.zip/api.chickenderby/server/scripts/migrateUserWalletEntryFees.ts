// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateUserWalletEntryFees.ts

import Sequelize from 'sequelize';

import models from '../sequelize/models';
import { log, sleep } from '../utils';

const migrateUserWalletEntryFees = async () => {
  log.info('start migration for userWallet entryFees');

  const limit = 10000;
  let offset = 0;

  const where: Sequelize.WhereOptions = {};
  const total = await models.UserWallet.count({
    where,
  });

  while (offset < total) {
    const userWallets = await models.UserWallet.findAll({
      where,
      offset,
      limit,
      order: [['id', 'ASC']],
    });

    for (const userWallet of userWallets) {
      const record: { entryFees: number }[] = await models.sequelize.query(
        `SELECT SUM(feeJEWEL) AS entryFees FROM races, lanes where races.id = lanes.raceId AND lanes.userWalletId="${userWallet.id}";`,
        {
          type: Sequelize.QueryTypes.SELECT,
          plain: false,
        },
      );
      const firsts = await models.Lane.count({
        where: {
          userWalletId: userWallet.id,
          position: 1,
        },
      });

      const seconds = await models.Lane.count({
        where: {
          userWalletId: userWallet.id,
          position: 2,
        },
      });

      const thirds = await models.Lane.count({
        where: {
          userWalletId: userWallet.id,
          position: 3,
        },
      });

      const { entryFees } = record[0];

      await userWallet.update({
        entryFees: entryFees || 0,
        firsts,
        seconds,
        thirds,
      });
    }

    await sleep(1000);

    offset += userWallets.length;

    log.info(
      `progress => current: ${offset} / total: ${total} (${(
        (offset / total) *
        100
      ).toFixed(2)}%)`,
    );
  }

  log.info('end migration for userWallet entryFees');
};

(async () => {
  await migrateUserWalletEntryFees();

  process.exit(0);
})();
