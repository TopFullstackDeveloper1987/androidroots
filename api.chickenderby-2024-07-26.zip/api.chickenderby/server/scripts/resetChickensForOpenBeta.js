// node server/scripts/resetChickensForOpenBeta.js

require('../sequelize/models');
const { updateTokens } = require('../services/chickenService');
const { redisConnect, redisGetAsync } = require('../services/redisClient');
const { sleep } = require('../utils');
const allChickens = require('./chickensPerformance3.json');
const { log } = require('../utils');

let offset = 0;
const limit = 100;
let redisClient;

const getChickens = () => allChickens.slice(offset, offset + limit).map((chicken) => {
  const poPointList = {
    Serama: [60, 60, 60, 60, 55, 55, 55, 50, 50, 40, 30],
    Sultan: [60, 60, 60, 55, 55, 55, 50, 50, 40, 30, 30],
    Lakenvelder: [60, 60, 55, 55, 55, 50, 50, 40, 30, 30, 25],
    Dorking: [60, 55, 55, 55, 50, 50, 40, 30, 25, 25, 20],
  };

  const poPointIndex = 100 - Number(chicken.perfection);
  const poPoints = poPointList[chicken.heritage][poPointIndex];

  const resetChicken = {
    tokenId: chicken.tokenId,
    races: 0,
    firsts: 0,
    seconds: 0,
    thirds: 0,
    earnings: 0,
    poPoints,
  };

  return resetChicken;
});

const migrateChickens = async () => {
  const total = allChickens.length;

  log.info('start reset chickens for open beta');
  log.info(`starting from ${offset} records`);

  while (offset < total) {
    const chickens = getChickens();
    // console.log('chickens', chickens);
    await updateTokens(chickens);

    offset += chickens.length;
    redisClient.set('resetChickensForOpenBeta', `${offset}`, 'EX', 24 * 3600); // 24 hours

    log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);

    await sleep(100);
  }

  log.info('end reset chickens for open beta');
};

(async () => {
  try {
    redisClient = redisConnect();

    const initialOffset = await redisGetAsync('resetChickensForOpenBeta');

    offset = initialOffset ? parseInt(initialOffset, 10) : 0;

    await migrateChickens();

    redisClient.del('resetChickensForOpenBeta');

    log.info('DONE');
  } catch (err) {
    log.error({
      func: 'resetChickensForOpenBeta',
      err,
    });
  }

  process.exit(0);
})();
