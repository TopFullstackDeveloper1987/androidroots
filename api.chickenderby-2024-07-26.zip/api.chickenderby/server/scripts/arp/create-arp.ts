// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/arp/create-arp.ts
import NP from 'number-precision';

import config from '../../config';
import '../../sequelize/models';
import { AutoRacePool } from '../../sequelize/models/AutoRacePool';
import { BawkStakingCompany } from '../../sequelize/models/BawkStakingCompany';
import { Terrain } from '../../sequelize/models/Terrain';
import { RaceNames } from './race-names';
import { log } from '../../utils';
import { ChickenPeckingOrder } from '../../types/chickens/chickenPeckingOrder';
import { RaceType } from '../../types/races/raceType';
import { JEWEL_CONTRACT } from '../../abi/jewelContract';

const run = async () => {
  log.info('Start creating auto race pools');

  // 5
  const companies = await BawkStakingCompany.findAll({
    order: [['id', 'asc']],
  });
  // 7
  const terrains = await Terrain.findAll({
    order: [['id', 'asc']],
  });
  // 6
  const distances = [
    100,
    120,
    140,
    160,
    180,
    200,
  ];
  const fees = [
    [4620, 5280, 6600, 7920, 9240],
    [2640, 2904, 3168, 3432, 3960],
    [1056, 1188, 1320, 1584, 1848],
    [528, 580, 660, 740, 792],
    [236, 276, 316, 356, 396],
  ];
  const startTimes = [3600, 600, 60, 60, 60];

  let nameIndex = 0;
  const peckingOrder = Object.values(ChickenPeckingOrder).filter(po => po !== ChickenPeckingOrder.CHICK).join(',');

  await AutoRacePool.sequelize?.transaction(async (t) => {
    await AutoRacePool.destroy({
      truncate: true,
      transaction: t,
    });

    // 5 x 7 x 6 = 210
    for (let companyIndex = 0; companyIndex < companies.length; companyIndex += 1) {
      for (const terrain of terrains) {
        for (let distanceIndex = 0; distanceIndex < distances.length; distanceIndex += 1) {
          const distance = distances[distanceIndex];
          const name = RaceNames[nameIndex++];
          const maxCapacity = 12;
          const fee = fees[companyIndex][distanceIndex % fees.length];
          const company = companies[distanceIndex % companies.length];

          const autoRacePool: Partial<AutoRacePool> = {
            name,
            peckingOrder,
            terrainId: terrain.id,
            distance: Number(distance),
            maxCapacity,
            location: name, // location is no longer used
            minimumStartDelay: 3,
            startTime: startTimes[companyIndex],
            fee,
            prizePool: NP.strip(fee * maxCapacity * config.RACE_PRIZE_POOL_PERCENT / 100),
            type: RaceType.Automatic,
            group: companyIndex + 1,
            unlimitPO: false,
            coinContract: JEWEL_CONTRACT.address,
            bawkStakingCompanyId: company.id,
          };

          try {
            await AutoRacePool.create(autoRacePool, { transaction: t });
          } catch (err) {
            log.error({
              func: 'create-arp',
              nameIndex,
              distanceIndex,
              distances,
              autoRacePool,
            });

            throw err;
          }
        }
      }
    }
  });

  log.info('End creating auto race pools');
};

(async () => {
  await run();

  process.exit(0);
})();
