// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/arp/create-races-from-arp.ts

import * as _ from 'lodash';

import '../../sequelize/models';
import { log } from '../../utils';
import { AutoRacePool } from '../../sequelize/models/AutoRacePool';
import { ChickenPeckingOrder } from '../../types/chickens/chickenPeckingOrder';
import { convertCoinToJewel } from '../../services/exchangeService';
import { Race } from '../../sequelize/models/Race';
import { Lane } from '../../sequelize/models/Lane';

const run = async () => {
  log.info('Start creating inital races from auto race pools');

  // 210
  const autoRacePools = await AutoRacePool.findAll({
    order: [['group', 'ASC']],
  });

  const allPeckingOrders = _.reverse(Object.values(ChickenPeckingOrder).filter(po => po !== ChickenPeckingOrder.CHICK));

  // group x terrain x distance = 5 x 7 x 6 = 210
  for (let i = 0; i < autoRacePools.length; i += 1) {
    const autoRacePool = autoRacePools[i];
    const peckingOrderIndex = i % allPeckingOrders.length;
    const peckingOrder = allPeckingOrders[peckingOrderIndex];

    const feeJEWEL = await convertCoinToJewel(autoRacePool.coinType, autoRacePool.fee);
    const prizePoolJEWEL = await convertCoinToJewel(autoRacePool.coinType, autoRacePool.prizePool);

    await Race.sequelize?.transaction(async (t) => {
      const race = await Race.create({
        ..._.omit(autoRacePool.toJSON(), ['id', 'createdAt', 'updatedAt', 'coinType']),
        peckingOrder,
        feeJEWEL,
        prizePoolJEWEL,
      }, {
        transaction: t,
      });

      for (let j = 0; j < race.maxCapacity; j += 1) {
        await Lane.create({
          raceId: race.id,
          laneNumber: j + 1,
        }, { transaction: t });
      }
    });
  }

  log.info('End creating inital races from auto race pools');
};

(async () => {
  await run();

  process.exit(0);
})();
