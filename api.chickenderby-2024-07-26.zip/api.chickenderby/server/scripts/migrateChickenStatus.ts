// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateChickenStatus
import Sequelize from 'sequelize';
import * as _ from 'lodash';
const { Op } = Sequelize;

import 'dotenv/config';

import config from '../config';
import models from '../sequelize/models';
import { log } from '../utils';
import { getChickenIdsForUserWalletIds } from '../services/contracts/chickenContractService';
import { ChickenStatus } from '../types/chickens/chickenStatus';

const migrateChickenStatus = async () => {
  const isProduction = process.env.NODE_ENV === 'production';
  if (isProduction) {
    throw new Error('Not needed to run this script on the production');
  }

  log.info('start migration for chicken status');

  // mark all as pending
  await models.Chicken.update({
    status: ChickenStatus.Pending,
  }, {
    where: {
      status: ChickenStatus.Active,
    },
  });

  const chickenIdsForUserWalletIds = await getChickenIdsForUserWalletIds(Object.values(config.DEV_USER_WALLET_IDS));
  const chickenIds = _.flatten(chickenIdsForUserWalletIds.map((el) => el.chickenIds));

  const where: Sequelize.WhereOptions = {
    [Op.or]: [{
      id: chickenIds,
    }, {
      status: ChickenStatus.FusionResult,
    }],
  };

  const chickens = await models.Chicken.findAll({
    where,
  });

  for (const chicken of chickens) {
    if (chickenIds.includes(chicken.id)) {
      await chicken.update({
        status: chicken.status === ChickenStatus.FusionResult ? ChickenStatus.FusionResult : ChickenStatus.Active,
      });
    } else {
      await chicken.update({
        status: ChickenStatus.Burned,
      });
    }
  }

  log.info('end migration for chicken status');
};

(async () => {
  await migrateChickenStatus();

  process.exit(0);
})();
