// node server/scripts/migratePublicAddress
const fs = require('fs');
const path = require('path');
const { Op } = require('sequelize');
const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for publicAddress');

  await models.sequelize.transaction(async (t) => {
    // dump original userWalletId => publicAddress mappings for backup
    const userWallets = await models.userWallet.findAll();
    const mappings = userWallets.map((userWalletModel) => ({
      id: userWalletModel.id,
      publicAddress: userWalletModel.publicAddress,
    }));

    const filePath = path.resolve(__dirname, 'userWalletId_publicAddress.json');
    const fileContents = JSON.stringify(mappings, null, 2);

    fs.writeFileSync(filePath, fileContents);

    // coops
    const coops = await models.coop.findAll();
    for (const coopModel of coops) {
      const userWalletModel = await models.userWallet.findByPk(coopModel.userId);
      await coopModel.update({
        publicAddress: userWalletModel.publicAddress,
      }, {
        transaction: t,
      });
    }
    log.info(`migrated ${coops.length} coops`);

    // lanes
    const lanes = await models.lane.findAll({
      where: {
        userWalletId: {
          [Op.not]: null,
        },
      },
    });
    for (const laneModel of lanes) {
      const userWalletModel = await models.userWallet.findByPk(laneModel.userWalletId);
      await laneModel.update({
        publicAddress: userWalletModel.publicAddress,
      }, {
        transaction: t,
      });
    }
    log.info(`migrated ${lanes.length} lanes`);

    // raceAssignments
    const raceAssignments = await models.raceAssignment.findAll();
    for (const raceAssignmentModel of raceAssignments) {
      const userWalletModel = await models.userWallet.findByPk(raceAssignmentModel.userWalletId);
      await raceAssignmentModel.update({
        publicAddress: userWalletModel.publicAddress,
      }, {
        transaction: t,
      });
    }
    log.info(`migrated ${raceAssignments.length} raceAssignments`);

    // transactions
    const transactions = await models.transaction.findAll();
    for (const transactionModel of transactions) {
      const userWalletModel = await models.userWallet.findByPk(transactionModel.userWalletId);
      await transactionModel.update({
        publicAddress: userWalletModel.publicAddress,
      }, {
        transaction: t,
      });
    }
    log.info(`migrated ${transactions.length} transactions`);

    // tournamentRankings
    const tournamentRankings = await models.tournamentRanking.findAll();
    for (const tournamentRankingModel of tournamentRankings) {
      const userWalletModel = await models.userWallet.findByPk(tournamentRankingModel.userWalletId);
      await tournamentRankingModel.update({
        publicAddress: userWalletModel.publicAddress,
      }, {
        transaction: t,
      });
    }
    log.info(`migrated ${tournamentRankings.length} tournamentRankings`);
  });

  log.info('end migration for publicAddress');

  process.exit(0);
})();
