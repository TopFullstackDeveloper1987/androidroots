// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/testCoupon.ts

require('dotenv').config();

import { BawkStakingContractService } from '../services/contracts/bawkStakingContractService';

(async () => {
  const userWalletChickenIds = [
    {
      userWalletId: '0x45EFf28AAf3C6Feb4AA10bAB9f3eB191D0Aa6508',
      cid: 4,
      epoch: 71,
    },
  ];

  const coupons: any = [];

  for (const { userWalletId, cid, epoch } of userWalletChickenIds) {
    const coupon = BawkStakingContractService.getInstance().generateCoupon(userWalletId, cid, null, epoch);
    coupons.push({
      userWalletId,
      cid,
      epoch,
      coupon,
    });
  }

  console.log('coupons', coupons);

  process.exit(0);
})();
