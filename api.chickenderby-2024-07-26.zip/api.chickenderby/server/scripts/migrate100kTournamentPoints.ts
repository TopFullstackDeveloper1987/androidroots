// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrate100kTournamentPoints

import '../sequelize/models';
import Sequelize from 'sequelize';

import { Lane } from '../sequelize/models/Lane';
import { Race } from '../sequelize/models/Race';
import { Tournament } from '../sequelize/models/Tournament';
import { TournamentRanking } from '../sequelize/models/TournamentRanking';

import { log } from '../utils';

const pointMap = [25, 20, 15, 12, 10, 8, 6, 5, 4, 3, 2, 1];

const migrate100kTournamentPoints = async () => {
  log.info('start migration for 100k tournament points');

  const tournament = await Tournament.findOne({
    where: {
      url: '100k-tournament',
    },
  });

  if (!tournament) {
    throw new Error('Cant find 100k tournament');
  }

  await tournament.sequelize.transaction(async (t: Sequelize.Transaction) => {
    const tournamentRankings = await TournamentRanking.findAll({
      where: {
        tournamentId: tournament.id,
      },
      transaction: t,
    });

    for (const tournamentRanking of tournamentRankings) {
      const top50Lanes = await Lane.findAll({
        where: {
          chickenId: tournamentRanking.chickenId,
          userWalletId: tournamentRanking.userWalletId,
        },
        include: [{
          model: Race,
          where: {
            tournamentId: tournament.id,
            peckingOrder: tournamentRanking.group, // was issue in here. we wasn't get pecking orders 50 top races before
          },
        }],
        limit: 50,
        order: [['position', 'ASC']],
        transaction: t,
      });

      const points = top50Lanes.reduce((total, lane) => {
        return total + pointMap[lane.position - 1];
      }, 0);

      await tournamentRanking.update({
        points,
      }, { transaction: t } );
    }

    // Re-calculate position
    const tournamentRankingGroup = await TournamentRanking.findAll({
      attributes: ['group'],
      where: {
        tournamentId: tournament.id,
      },
      group: ['group'],
      transaction: t,
    });

    for (const { group } of tournamentRankingGroup) {
      const tournamentRankingRecords = await TournamentRanking.findAll({
        where: {
          tournamentId: tournament.id,
          group,
        },
        order: [
          ['points', 'desc'],
          ['first', 'desc'],
          ['second', 'desc'],
          ['third', 'desc'],
          ['fourth', 'desc'],
          ['fifth', 'desc'],
          ['sixth', 'desc'],
          ['seventh', 'desc'],
          ['eighth', 'desc'],
          ['ninth', 'desc'],
          ['tenth', 'desc'],
          ['eleventh', 'desc'],
          ['twelfth', 'desc'],
        ],
        transaction: t,
      });

      for (let i = 0; i < tournamentRankingRecords.length; i += 1) {
        const record = tournamentRankingRecords[i];

        await record.update({
          position: i + 1,
        }, { transaction: t });
      }
    }
  });

  log.info('end migration for chicken pecking orders');
};

(async () => {
  await migrate100kTournamentPoints();

  process.exit(0);
})();
