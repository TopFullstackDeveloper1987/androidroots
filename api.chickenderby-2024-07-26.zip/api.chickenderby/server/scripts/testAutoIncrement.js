// node server/scripts/testAutoIncrement

require('dotenv').config();

require('../sequelize/models');
const { log } = require('../utils');

const { getLastMarketItemId, getLastTradeOfferId } = require('../services/marketplace/marketplaceService');

(async () => {
  const lastMarketItemId = await getLastMarketItemId();
  const lastTradeOfferId = await getLastTradeOfferId();

  log.info({
    lastMarketItemId,
    lastTradeOfferId,
  });

  process.exit(0);
})();
