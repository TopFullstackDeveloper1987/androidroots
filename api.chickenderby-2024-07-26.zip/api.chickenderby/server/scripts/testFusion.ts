// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/testFusion
// TODO: We have to switch into unit tests

require('dotenv').config();

import { getChickenIdsForUserWalletId, getOwnerOfChicken } from '../services/contracts/chickenContractService';
import { toChecksumAddress, isZeroAddress, isEaterAddress } from '../services/contracts/web3Service';
import { EATER_ADDRESS, ZERO_ADDRESS } from '../utils/constants';

(async () => {
  const ownerAddress = await getOwnerOfChicken(40000);
  console.log('ownerAddress', ownerAddress);

  console.log(toChecksumAddress(ZERO_ADDRESS) !== toChecksumAddress(EATER_ADDRESS));
  console.log(isZeroAddress(ownerAddress), isEaterAddress(EATER_ADDRESS));

  const chickenIdsForEater = await getChickenIdsForUserWalletId(EATER_ADDRESS);
  console.log('chickenIdsForEater', chickenIdsForEater);

  const chickenIdsForZero = await getChickenIdsForUserWalletId(ZERO_ADDRESS);
  console.log('chickenIdsForZero', chickenIdsForZero);
})();
