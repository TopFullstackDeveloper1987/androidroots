// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateChickenEntryFees.ts

import Sequelize from 'sequelize';

import models from '../sequelize/models';
import { log, sleep } from '../utils';

const migrateChickenEntryFees = async () => {
  log.info('start migration for chicken entryFees');

  const limit = 10000;
  let offset = 0;

  const where: Sequelize.WhereOptions = {};
  const total = await models.Chicken.count({
    where,
  });

  while (offset < total) {
    const chickens = await models.Chicken.findAll({
      where,
      offset,
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      const record: { entryFees: number }[] = await models.sequelize.query(
        `SELECT SUM(feeJEWEL) AS entryFees FROM races, lanes where races.id = lanes.raceId AND lanes.chickenId=${chicken.id};`,
        {
          type: Sequelize.QueryTypes.SELECT,
          plain: false,
        },
      );
      const { entryFees } = record[0];

      if (!entryFees) {
        continue;
      }

      await chicken.update({
        entryFees,
      });
    }

    await sleep(1000);

    offset += chickens.length;

    log.info(
      `progress => current: ${offset} / total: ${total} (${(
        (offset / total) *
        100
      ).toFixed(2)}%)`,
    );
  }

  log.info('end migration for chicken entryFees');
};

(async () => {
  await migrateChickenEntryFees();

  process.exit(0);
})();
