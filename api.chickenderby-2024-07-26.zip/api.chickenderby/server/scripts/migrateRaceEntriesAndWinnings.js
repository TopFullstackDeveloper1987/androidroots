// node server/scripts/migrateRaceEntriesAndWinnings.js

const { Op } = require('sequelize');
const models = require('../sequelize/models');
const {
  increaseRaceEntries,
  recordUserWinnings,
} = require('../services/raceService');
const { log } = require('../utils');

(async () => {
  log.info('start migration to add raceEntries and winnings');

  await models.userWallet.update({
    raceEntries: 0,
    winnings: 0,
    winningsUSD: 0,
  }, {
    where: {},
  });

  const races = await models.race.findAll({
    include: [{
      model: models.lane,
      where: {
        userWallet: {
          [Op.not]: null,
        },
      },
    }],
  });

  for (const race of races) {
    for (const laneModel of race.lanes) {
      if (laneModel.userWalletId) {
        await increaseRaceEntries(laneModel.userWalletId);
      }
    }

    if (race.status !== 'finished') {
      continue;
    }

    const result = await models.result.findOne({
      where: {
        raceId: race.id,
      },
    });

    if (!result) {
      continue;
    }

    race.result = result;

    await recordUserWinnings(race);
  }

  log.info('end migration to add raceEntries and winnings');

  process.exit(0);
})();
