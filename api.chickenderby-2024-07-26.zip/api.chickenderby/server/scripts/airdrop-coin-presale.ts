// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/airdrop-coin-presale.ts
import 'dotenv/config';
import { log } from '../utils';
import { CoinPresaleContractService } from '../services/contracts/coin-presale-contract.service';
import { CoinPresaleService } from '../services/coin-presale/coin-presale.service';
import '../sequelize/models';

const run = async () => {
  const coinPresaleContractService = CoinPresaleContractService.getInstance();

  const numberOfUsers = await coinPresaleContractService.getPresaleUsersCount();
  const userWalletIds = await coinPresaleContractService.getPresaleUsers(0, numberOfUsers);

  log.info({
    func: 'airdrop-coin-presale',
    numberOfUsers,
    userWalletIds,
  }, 'After Getting Presale Users');

  for (const userWalletId of userWalletIds) {
    const tokensBought = await coinPresaleContractService.getUserDeposits(userWalletId);

    log.info({
      func: 'airdrop-coin-presale',
      userWalletId,
      tokensBought,
    }, 'User Deposits');

    await CoinPresaleService.createAssignment({
      userWalletId,
      tokensBought,
    });
  }
};

(async () => {
  log.info('Start Airdrop Coin Presale');

  await run();

  log.info('End Airdrop Coin Presale');

  process.exit(0);
})();
