/* eslint-disable max-len */
// node server/scripts/testVerifySignature

const ethUtil = require('ethereumjs-util');

const { log } = require('../utils');

(async () => {
  const userWalletId = '0x166a229cf67e1327d4f7d0a5cc370607da8493a7';
  const signature = '0x90d3a5f9a323c06662fa4fe41beab72f3e4032529d1e304940b87baef22db3ff28d1b5727dd52062b3c639885efb859288e9762895c9cbd7b4dfc240802387751b';
  const nonce = '66c2eaa0-7215-4172-a7a1-4015f87231b0';

  try {
    const nonceMessage = `Welcome to Chicken Derby!\n
Please Sign to authenticate your wallet.\n
This request will not trigger a blockchain transaction or cost any gas fees.\n
Your authentication status will reset after 24 hours.\n\nWallet address:\n${userWalletId}\n\nNonce:\n${nonce}`;

    const msgHex = ethUtil.bufferToHex(Buffer.from(nonceMessage));
    const msgBuffer = ethUtil.toBuffer(msgHex);
    const msgHash = ethUtil.hashPersonalMessage(msgBuffer);

    const signatureBuffer = ethUtil.toBuffer(signature);
    const signatureParams = ethUtil.fromRpcSig(signatureBuffer);
    const publicKey = ethUtil.ecrecover(
      msgHash,
      signatureParams.v,
      signatureParams.r,
      signatureParams.s,
    );
    const addresBuffer = ethUtil.publicToAddress(publicKey);
    const publicAddress = ethUtil.bufferToHex(addresBuffer);

    if (publicAddress?.toLowerCase() === userWalletId?.toLowerCase()) {
      log.info({
        func: 'verifySignature',
        userWalletId,
        signature,
        publicAddress,
      }, 'Verify Signature Success');
    } else {
      log.error({
        func: 'verifySignature',
        userWalletId,
        signature,
        publicAddress,
      }, 'Verify Signature Error');
    }
  } catch (err) {
    log.error({
      func: 'verifySignature',
      userWalletId,
      signature,
      err,
    }, 'Verify Signature Error');
  }
})();
