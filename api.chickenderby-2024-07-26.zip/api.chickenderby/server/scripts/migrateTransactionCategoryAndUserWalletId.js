// node server/scripts/migrateTransactionCategoryAndUserWalletId
const NP = require('number-precision');

const models = require('../sequelize/models');
const { log } = require('../utils');
const TransactionCategory = require('../types/transactions/transactionCategory');
const { getRaceContractAddress, getRaceContractFeeAddress, getRaceContractPrizePercent } = require('../services/contracts/raceContractService');
const TransactionType = require('../types/transactions/transactionType');

(async () => {
  log.info('start migration for transaction category, fromAddress, and toAddress');

  const limit = 10000;
  let count = 0;

  const where = {
    category: [TransactionCategory.EntryFee, TransactionCategory.Payout],
  };

  const raceContractAddress = await getRaceContractAddress();
  const raceContractFeeAddress = await getRaceContractFeeAddress();
  const racePrizePercent = await getRaceContractPrizePercent();

  const total = await models.Transaction.count({
    where,
  });

  while (count < total) {
    const transactions = await models.Transaction.findAll({
      where,
      limit,
      order: [['id', 'ASC']],
    });

    for (const transaction of transactions) {
      const {
        category, userWalletId, type, associatedObjectId, transactionHash, status,
      } = transaction;
      const newCategory = category === TransactionCategory.EntryFee ? TransactionCategory.RaceEnter : TransactionCategory.RacePayout;

      if (type === TransactionType.In) {
        await transaction.update({
          category: newCategory,
          fromAddress: userWalletId,
          toAddress: raceContractAddress,
        });
      } else {
        const race = await models.Race.findByPk(associatedObjectId);

        await models.sequelize.transaction(async (t) => {
          await transaction.update({
            category: newCategory,
            fromAddress: raceContractAddress,
            toAddress: userWalletId,
          }, {
            transaction: t,
          });

          if (race?.fee > 0) {
            const feeTransaction = await models.Transaction.findOne({
              where: {
                associatedObjectType: 'race',
                associatedObjectId: `${race.id}`,
                category: TransactionCategory.RacePayoutFee,
              },
            });
            if (!feeTransaction) {
              await models.Transaction.create({
                fromAddress: raceContractAddress,
                toAddress: raceContractFeeAddress,
                type: TransactionType.Out,
                transactionHash,
                status,
                associatedObjectType: 'race',
                associatedObjectId: `${race.id}`,
                amount: NP.strip(race.prizePool * (100 - racePrizePercent) / 100),
                category: TransactionCategory.RacePayoutFee,
              }, {
                transaction: t,
              });
            }
          }
        });
      }

      count += 1;
    }

    log.info(`progress => current: ${count} / total: ${total} (${(count / total * 100).toFixed(2)}%)`);
  }

  log.info('end migration for transaction category, fromAddress, and toAddress');

  process.exit(0);
})();
