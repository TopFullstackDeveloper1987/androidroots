// node server/scripts/migrateCoopsToUserWallet.js
const { Op } = require('sequelize');
const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for coops');
  const coops = await models.coop.findAll({
    where: {
      name: {
        [Op.not]: 'My Coop',
      },
    },
  });
  for (const coop of coops) {
    const userWallet = await models.userWallet.findByPk(coop.userId);
    if (userWallet) {
      userWallet.username = coop.name;
      await userWallet.save();
    }
  }

  await models.coop.destroy({ where: {}, truncate: true });

  log.info('end migration for lanes');

  process.exit(0);
})();
