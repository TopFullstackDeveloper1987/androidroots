// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateClothingImages
import Sequelize from 'sequelize';

require('dotenv').config();

import config from '../config';
import models from '../sequelize/models';
import { log, sleep } from '../utils';
import { generateChickenImage, getChickenClothingImageName, regenerateChickenClothingImage } from '../services/chickenService';

const migrateLaneClothingImages = async () => {
  log.info('start migration for lane clothing images');

  const limit = 100;
  let offset = 0;

  const where: Sequelize.WhereOptions = {
    clothingImage: null,
  };
  const laneClothingInclude: Sequelize.Includeable[] = [{
    model: models.Chicken,
    required: true,
  }, {
    model: models.LaneClothing,
    required: true,
    include: [{
      model: models.Clothing,
    }],
  }];

  const total = await models.Lane.count({
    where,
    include: laneClothingInclude,
    distinct: true,
  });
  const clothingImages: Record<string, string> = {};

  while (offset < total) {
    const lanes = await models.Lane.findAll({
      where,
      include: laneClothingInclude,
      limit,
      order: [['id', 'ASC']],
    });

    for (const lane of lanes) {
      const clothings = lane.laneClothings.map((laneClothing) => laneClothing.clothing);
      await models.sequelize.transaction(async (t) => {
        const clothingImageName = getChickenClothingImageName(lane.chicken, clothings);
        const clothingImage = clothingImages[clothingImageName] || await generateChickenImage(lane.chicken, clothings, config.CHICKEN_CLOTHING_IMAGE_SIZE);
        if (!clothingImages[clothingImageName]) {
          clothingImages[clothingImageName] = clothingImage;
        }

        await lane.update({
          clothingImage,
        }, { transaction: t });
      });
    }

    await sleep(1000);

    offset += lanes.length;
    log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);
  }

  log.info(`end migration for ${Object.keys(clothingImages).length} lane clothing images`);
};

const migrateChickenClothingImages = async () => {
  log.info('start migration for chicken clothing images');

  if (process.env.NODE_ENV !== 'production') {
    const numberOfDestroied = await models.ChickenClothing.destroy({
      where: {},
      truncate: true,
    });

    log.info(`end migration for ${numberOfDestroied} chicken clothing images`);

    return;
  }

  const limit = 100;
  let offset = 0;

  const where: Sequelize.WhereOptions = {
    clothingImage: null,
  };
  const chickenClothingInclude: Sequelize.Includeable[] = [{
    model: models.ChickenClothing,
    required: true,
    include: [{
      model: models.Clothing,
    }],
  }];

  const total = await models.Chicken.count({
    where,
    include: chickenClothingInclude,
    distinct: true,
  });

  while (offset < total) {
    const chickens = await models.Chicken.findAll({
      where,
      include: chickenClothingInclude,
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      await models.sequelize.transaction(async (t) => regenerateChickenClothingImage(chicken.id, t));
    }

    await sleep(1000);

    offset += chickens.length;

    log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);
  }

  log.info('end migration for chicken clothing images');
};

(async () => {
  await migrateLaneClothingImages();
  await migrateChickenClothingImages();

  process.exit(0);
})();
