// node server/scripts/migrateResultFeeUsd.js

const models = require('../sequelize/models');
const { getCoinRate } = require('../services/exchangeService');
const { log } = require('../utils');

(async () => {
  log.info('start migration for gameInfo.race_stats.feeUSD');

  const results = await models.result.findAll();
  const coinRate = await getCoinRate();

  for (const result of results) {
    const { race_stats: raceStats } = result.toJSON().gameInfo;
    const feeRate = raceStats.prizePoolUSD && raceStats.prizePool ? Number(raceStats.prizePoolUSD) / Number(raceStats.prizePool) : coinRate.weth;
    raceStats.feeUSD = (Number(raceStats.fee) * feeRate).toFixed(2);

    result.gameInfo = {
      ...result.gameInfo,
      race_stats: raceStats,
    };

    await result.save();
  }

  log.info('end migration for gameInfo.race_stats.feeUSD');

  process.exit(0);
})();
