// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateImagesToS3_2

import * as _ from 'lodash';
import Sequelize from 'sequelize';
const { Op } = Sequelize;

import config from '../config';
import models from '../sequelize/models';
import { log, sleep } from '../utils';

const migrateChickenImages = async () => {
  log.info('start migration for chicken images');

  const limit = 10000;
  let offset = 0;

  const where: Sequelize.WhereOptions = {
    image: {
      [Op.notLike]: `${config.aws.s3.chickenderby.cloudfront}%`,
    },
  };

  const total = await models.Chicken.count({
    where,
  });

  while (offset < total) {
    const chickens = await models.Chicken.findAll({
      where,
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      const { chknId } = chicken;
      const s3Url = `${config.aws.s3.chickenderby.cloudfront}/chickens/${chknId}.png`;

      await chicken.update({
        image: s3Url,
      });
    }

    await sleep(1000);

    offset += chickens.length;

    log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);
  }

  log.info('end migration for chicken images');
};

const migrateSeasonBadges = async () => {
  log.info('start migration for season badges');

  const seasonBadges = await models.SeasonBadge.findAll({
    where: {
      image: {
        [Op.notLike]: `${config.aws.s3.chickenderby.cloudfront}%`,
      },
    },
  });
  for (const seasonBadge of seasonBadges) {
    const { toolTip } = seasonBadge;
    const filename = _.snakeCase(toolTip);
    const s3Url = `${config.aws.s3.chickenderby.cloudfront}/badges/seasons/${filename}.png`;

    await seasonBadge.update({
      image: s3Url,
    });
  }

  log.info('end migration for season badges');
};

const migrateTournamentBadges = async () => {
  log.info('start migration for tournament badges');

  const tournamentBadges = await models.TournamentBadge.findAll({
    where: {
      image: {
        [Op.notLike]: `${config.aws.s3.chickenderby.cloudfront}%`,
      },
    },
  });
  for (const tournamentBadge of tournamentBadges) {
    const { toolTip } = tournamentBadge;
    const filename = _.snakeCase(toolTip);
    const s3Url = `${config.aws.s3.chickenderby.cloudfront}/badges/tournaments/${filename}.png`;

    await tournamentBadge.update({
      image: s3Url,
    });
  }

  log.info('end migration for tournament badges');
};

const migrateClothings = async () => {
  log.info('start migration for clothings');

  const clothings = await models.Clothing.findAll({
    where: {
      image: {
        [Op.notLike]: `${config.aws.s3.chickenderby.cloudfront}%`,
      },
    },
  });

  for (const clothing of clothings) {
    const { name, type, clothingSet } = clothing;

    const dir = _.kebabCase(clothingSet);
    const filename = _.snakeCase(`${type} ${name}`);
    const s3Url = `${config.aws.s3.chickenderby.cloudfront}/clothings/${dir}/${filename}.png`;

    await clothing.update({
      image: s3Url,
    });
  }

  log.info('end migration for clothings');
};

const migrateTourneyOnesClothings = async () => {
  log.info('start migration for tourney ones clothings');

  const clothings = await models.TourneyOne.findAll({
    where: {
      image: {
        [Op.notLike]: `${config.aws.s3.chickenderby.cloudfront}%`,
      },
    },
  });

  for (const clothing of clothings) {
    const { name, type, clothingSet } = clothing;

    const dir = _.kebabCase(clothingSet);
    const filename = _.snakeCase(`${type} ${name}`);
    const s3Url = `${config.aws.s3.chickenderby.cloudfront}/tourney-ones/${dir}/${filename}.png`;

    await clothing.update({
      image: s3Url,
    });
  }

  log.info('end migration for tourney ones clothings');
};

const migrateDecorations = async () => {
  log.info('start migration for decorations');

  const decorations = await models.Decoration.findAll({
    where: {
      image: {
        [Op.notLike]: `${config.aws.s3.chickenderby.cloudfront}%`,
      },
    },
  });
  for (const decoration of decorations) {
    const { name, type } = decoration;
    const filename = _.snakeCase(`${type} ${name}`);
    const s3Url = `${config.aws.s3.chickenderby.cloudfront}/decorations/${filename}.png`;

    await decoration.update({
      image: s3Url,
    });
  }

  log.info('end migration for decorations');
};

const migrateFusionSerum = async () => {
  log.info('start migration for fusion serum');

  const serum = await models.Serum.findOne({
    where: {
      image: {
        [Op.notLike]: `${config.aws.s3.chickenderby.cloudfront}%`,
      },
    },
  });
  if (serum) {
    const s3Url = `${config.aws.s3.chickenderby.cloudfront}/fusion/fusion_serum.png`;

    await serum.update({
      image: s3Url,
    });
  }

  log.info('end migration for fusion serum');
};

(async () => {
  await migrateChickenImages();
  await migrateSeasonBadges();
  await migrateTournamentBadges();
  await migrateClothings();
  await migrateTourneyOnesClothings();
  await migrateDecorations();
  await migrateFusionSerum();

  process.exit(0);
})();
