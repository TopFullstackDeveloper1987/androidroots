// node server/scripts/migrateChickenName

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for chicken name');

  const limit = 10000;
  let count = 0;

  const total = await models.Chicken.count();

  while (count < total) {
    const chickens = await models.Chicken.findAll({
      offset: count,
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      const { name, chknId } = chicken;

      if (name) {
        await chicken.update({
          namedAt: new Date(),
        });
      } else {
        await chicken.update({
          name: `Chicken ${chknId.replace('chkn', '')}`,
        });
      }
    }

    count += chickens.length;

    log.info(`progress => current: ${count} / total: ${total} (${(count / total * 100).toFixed(2)}%)`);
  }

  log.info('end migration for chicken name');

  process.exit(0);
})();
