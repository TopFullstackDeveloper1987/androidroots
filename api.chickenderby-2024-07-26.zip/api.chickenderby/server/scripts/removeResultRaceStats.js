// node server/scripts/removeResultRaceStats.js

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration to remove gameInfo.race_stats');

  const results = await models.result.findAll();

  for (const result of results) {
    const { gameInfo } = result.toJSON();

    delete gameInfo.race_stats;

    result.gameInfo = gameInfo;

    await result.save();
  }

  log.info('end migration to remove gameInfo.race_stats');

  process.exit(0);
})();
