// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/getRacesToRefund.ts

import { Op } from 'sequelize';

import '../sequelize/models';
import { Race } from '../sequelize/models/Race';
import { Lane } from '../sequelize/models/Lane';
import { log } from '../utils';
import { RaceStatus } from '../types/races/raceStatus';
import { UserWallet } from '../sequelize/models/UserWallet';

(async () => {
  const races = await Race.findAll({
    where: {
      status: RaceStatus.Canceled,
      currentCapacity: {
        [Op.gt]: 0,
      },
      fee: {
        [Op.gt]: 0,
      },
    },
    include: [{
      model: Lane,
      include: [{
        model: UserWallet,
        required: true,
      }],
    }],
  });

  const racesToRefund: any[] = [];
  races.forEach((raceModel) => {
    const {
      id, name, fee, currentCapacity, lanes,
    } = raceModel;

    const userWallets = lanes.map((lane) => ({
      name: lane.userWallet.username,
      userWalletId: lane.userWalletId,
    }));

    racesToRefund.push({
      id,
      name,
      url: `https://www.chickenderby.com/race-detail/${id}`,
      fee,
      currentCapacity,
      userWallets,
    });
  });

  log.info({
    racesToRefund,
  });

  process.exit(0);
})();
