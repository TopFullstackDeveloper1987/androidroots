// node server/scripts/migrateResultChickens
const _ = require('lodash');

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for result.chickens');

  const results = await models.Result.findAll();
  await models.sequelize.transaction(async (t) => {
    for (const resultModel of results) {
      const { chickens } = resultModel.toJSON();

      resultModel.chickens = chickens.map(
        (chicken) => _.pick(chicken, [
          'id',
          'owner',
          'bonusBawk',
          'raceEarnings',
        ]),
      );

      await resultModel.save({
        transaction: t,
      });
    }
  });

  log.info('end migration for result.chickens');

  process.exit(0);
})();
