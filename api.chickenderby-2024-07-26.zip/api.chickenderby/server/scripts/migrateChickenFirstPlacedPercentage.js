// node server/scripts/migrateChickenFirstPlacedPercentage
const { Op } = require('sequelize');

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  log.info('start migration for chicken firstPlacedPercentage');

  const limit = 10000;
  let count = 0;

  const where = {
    races: {
      [Op.gt]: 0,
    },
  };

  const total = await models.Chicken.count({
    where,
  });

  while (count < total) {
    const chickens = await models.Chicken.findAll({
      where,
      offset: count,
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      const {
        races, firsts,
      } = chicken;
      const firstPlacedPercentage = firsts / races * 100;

      await chicken.update({
        firstPlacedPercentage,
      });

      count += 1;
    }

    log.info(`progress => current: ${count} / total: ${total} (${(count / total * 100).toFixed(2)}%)`);
  }

  log.info('end migration for chicken firstPlacedPercentage');

  process.exit(0);
})();
