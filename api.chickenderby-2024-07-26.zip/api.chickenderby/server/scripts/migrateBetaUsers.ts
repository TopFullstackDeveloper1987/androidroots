// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateBetaUsers

import '../sequelize/models';
import { log } from '../utils';
import { Race } from '../sequelize/models/Race';
import { Terrain } from '../sequelize/models/Terrain';
import { Lane } from '../sequelize/models/Lane';
import { Chicken } from '../sequelize/models/Chicken';
import { Result } from '../sequelize/models/Result';
import { CommentaryService } from '../services/commentaryService';
const raceId = 122127;
const migrateBetaUsers = async () => {
  const race = await Race.findByPk(raceId, {
    include: [Terrain],
  });

  const lanes = await Lane.findAll({
    where: {
      raceId,
    },
    include: [Chicken],
  });

  const result = await Result.findOne({
    where: {
      raceId,
    },
  });

  if (!race || !lanes || !result) {
    return;
  }

  const commentaryService = new CommentaryService(race, lanes, result);

  const d = commentaryService.getCommentaryProfile();
  console.log(JSON.stringify(d));
  log.info('end migration for beta users');
};

(async () => {
  await migrateBetaUsers();

  process.exit(0);
})();
