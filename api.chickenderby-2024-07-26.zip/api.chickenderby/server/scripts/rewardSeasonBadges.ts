// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/rewardSeasonBadges
import Sequelize from 'sequelize';
const { Op } = Sequelize;

import models from '../sequelize/models';
import { SeasonBadge } from '../sequelize/models/SeasonBadge';
import { log } from '../utils';

const getSeasonBadge = (seasonBadges: SeasonBadge[], count: number, position: number) => {
  // Already sorted by prizePercent
  const prizePositions = seasonBadges.map((seasonBadge) => Math.floor(count * seasonBadge.prizePercent / 100));
  for (let i = 0; i < prizePositions.length; i += 1) {
    const prizePosition = prizePositions[i];
    if (position <= prizePosition) {
      return seasonBadges[i];
    }
  }

  return null;
};

(async () => {
  const season = await models.Season.findOne({
    where: {
      name: 'Late February 2023',
    },
  });

  if (!season) {
    throw new Error('Season not found');
  }

  const { id: seasonId } = season;
  await models.sequelize.transaction(async (transaction) => {
    await models.ChickenSeasonBadge.destroy({
      where: {
        seasonId,
      },
      transaction,
    });

    const seasonRankingGroups = await models.SeasonRanking.findAll({
      attributes: ['peckingOrder'],
      where: {
        seasonId,
      },
      group: ['peckingOrder'],
      transaction,
    });

    for (const { peckingOrder } of seasonRankingGroups) {
      const count = await models.SeasonRanking.count({
        where: {
          seasonId,
          peckingOrder,
        },
        transaction,
      });

      const seasonBadges = await models.SeasonBadge.findAll({
        where: {
          peckingOrder,
        },
        order: [['prizePercent', 'ASC']],
      });
      if (seasonBadges.length === 0) {
        continue;
      }

      const lastSeasonBadge = seasonBadges[seasonBadges.length - 1];
      const lastPrizePosition = Math.floor(count * lastSeasonBadge.prizePercent / 100);

      const seasonRankings = await models.SeasonRanking.findAll({
        where: {
          seasonId,
          peckingOrder,
          position: {
            [Op.lte]: lastPrizePosition,
          },
        },
        transaction,
      });

      for (const seasonRanking of seasonRankings) {
        const { chickenId, position } = seasonRanking;
        const seasonBadge = getSeasonBadge(seasonBadges, count, position);
        if (seasonBadge) {
          const { id: seasonBadgeId, toolTip } = seasonBadge;
          await models.ChickenSeasonBadge.create({
            seasonId,
            chickenId,
            seasonBadgeId,
          }, { transaction });

          log.info({
            func: 'rewardSeasonBadges',
            seasonId,
            peckingOrder,
            chickenId,
            seasonBadgeId,
          }, `Rewarded ${toolTip} to a chicken - ${chickenId}`);
        }
      }
    }
  });
})();
