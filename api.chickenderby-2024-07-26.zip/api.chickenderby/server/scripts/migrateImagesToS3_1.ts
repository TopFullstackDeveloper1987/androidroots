/* eslint-disable @typescript-eslint/no-unused-vars */
// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateImagesToS3_1
// Please run this script only one time and delete it

import * as _ from 'lodash';

import config from '../config';
import models from '../sequelize/models';
import { log, sleep } from '../utils';
import { uploadUrlToS3 } from '../services/awsService';
import { redisConnect, redisGetAsync } from '../services/redisClient';

const migrateChickenImages = async () => {
  log.info('start migration for chicken images');

  const redisClient = redisConnect();

  const limit = 100;
  const initialOffset = await redisGetAsync('migrateChickenImages');
  let offset = initialOffset ? parseInt(initialOffset, 10) : 0;

  const total = await models.Chicken.count();

  while (offset < total) {
    const chickens = await models.Chicken.findAll({
      offset,
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      const { chknId, image } = chicken;

      await uploadUrlToS3(image, {
        bucket: config.aws.s3.chickenderby.bucket,
        key: `chickens/${chknId}.png`,
        contentType: 'image/png',
      });
    }

    await sleep(1000);

    offset += chickens.length;
    redisClient.set('migrateChickenImages', `${offset}`, 'EX', 24 * 3600); // 24 hours

    log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);
  }

  redisClient.del('migrateChickenImages');

  log.info('end migration for chicken images');
};

const migrateSeasonBadges = async () => {
  log.info('start migration for season badges');

  const seasonBadges = await models.SeasonBadge.findAll();
  for (const seasonBadge of seasonBadges) {
    const { image, toolTip } = seasonBadge;
    const filename = _.snakeCase(toolTip);

    await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `badges/seasons/${filename}.png`,
      contentType: 'image/png',
    });
  }

  log.info('end migration for season badges');
};

const migrateTournamentBadges = async () => {
  log.info('start migration for tournament badges');

  const tournamentBadges = await models.TournamentBadge.findAll();
  for (const tournamentBadge of tournamentBadges) {
    const { image, toolTip } = tournamentBadge;
    const filename = _.snakeCase(toolTip);

    await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `badges/tournaments/${filename}.png`,
      contentType: 'image/png',
    });
  }

  log.info('end migration for tournament badges');
};

const migrateClothings = async () => {
  log.info('start migration for clothings');

  const clothings = await models.Clothing.findAll();
  for (const clothing of clothings) {
    const { name, type, clothingSet, image } = clothing;
    const dir = _.kebabCase(clothingSet);
    const filename = _.snakeCase(`${type} ${name}`);

    await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `clothings/${dir}/${filename}.png`,
      contentType: 'image/png',
    });
  }

  log.info('end migration for clothings');
};

const migrateTourneyOnesClothings = async () => {
  log.info('start migration for tourney ones clothings');

  const clothings = await models.TourneyOne.findAll();
  for (const clothing of clothings) {
    const { name, type, clothingSet, image } = clothing;
    const dir = _.kebabCase(clothingSet);
    const filename = _.snakeCase(`${type} ${name}`);

    await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `tourney-ones/${dir}/${filename}.png`,
      contentType: 'image/png',
    });
  }

  log.info('end migration for tourney ones clothings');
};

const migrateDecorations = async () => {
  log.info('start migration for decorations');

  const decorations = await models.Decoration.findAll();
  for (const decoration of decorations) {
    const { name, type, image } = decoration;
    const filename = _.snakeCase(`${type} ${name}`);

    await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `decorations/${filename}.png`,
      contentType: 'image/png',
    });
  }

  log.info('end migration for decorations');
};

const migrateFusionSerum = async () => {
  log.info('start migration for fusion serum');

  const image = 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/fusion%2Ffusion-serum.png?alt=media&token=4b77f625-b956-4e99-a4f4-b3bb5b7ae8b2';

  await uploadUrlToS3(image, {
    bucket: config.aws.s3.chickenderby.bucket,
    key: 'fusion/fusion_serum.png',
    contentType: 'image/png',
  });

  log.info('end migration for fusion serum');
};

const migratePrizes = async () => {
  log.info('start migration for prizes');

  const prizes = [{
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2FBaseballSets.png?alt=media&token=af65be93-9ce6-4981-a6d6-59207b59e6c2',
    filename: 'BaseballSets.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2FClansOfHogmanay.png?alt=media&token=5f8adedb-4a75-496c-9901-5d5b6977c77d',
    filename: 'ClansOfHogmanay.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2FCutTheMustardItems.png?alt=media&token=efc90c9a-3a43-4a8c-8367-3e5a67fa6d8c',
    filename: 'CutTheMustardItems.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2FFemalePilgrim.png?alt=media&token=526521d5-d4d2-4291-abba-9fefea834696',
    filename: 'FemalePilgrim.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2FHalloweenOutfits.png?alt=media&token=2490347a-bfa9-43f7-8161-8246789a2fab',
    filename: 'HalloweenOutfits.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2FMalePilgrim.png?alt=media&token=772f0b6c-f4e8-4416-ab56-fdb6fb0d2fd7',
    filename: 'MalePilgrim.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2FSantaOutfit.png?alt=media&token=c76985ed-783d-4689-b393-d19a13e441ba',
    filename: 'SantaOutfit.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2Fbaseball%20bat_icon_6.png?alt=media&token=bf45987b-c10a-4de4-92d9-2de06c815e6b',
    filename: 'baseball_bat_icon_6.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2Fbugle_icon.png?alt=media&token=2169129f-3a10-4498-98bd-58371318194b',
    filename: 'bugle_icon.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2Fbugle_icon_white.png?alt=media&token=9d98bfc2-1afe-4ecb-85dc-e4a75412b90d',
    filename: 'bugle_icon_white.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2Foktoberbest_drindl.png?alt=media&token=548d2add-2af4-4a33-a087-76d1420d0957',
    filename: 'oktoberbest_drindl.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2Foktoberbest_lederhose.png?alt=media&token=4c6dbfb5-48de-46f9-992b-cd62814fcd9a',
    filename: 'oktoberbest_lederhose.png',
  }, {
    image: 'https://firebasestorage.googleapis.com/v0/b/chicken-derby.appspot.com/o/prizes%2Fstreakybacon.png?alt=media&token=b1756800-e548-430f-afa4-92a42a750d9d',
    filename: 'streakybacon.png',
  }];

  for (const prize of prizes) {
    const { image, filename } = prize;

    await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `prizes/${filename}`,
      contentType: 'image/png',
    });
  }

  log.info('end migration for prizes');
};

(async () => {
  /*
  await migrateChickenImages();
  await migrateSeasonBadges();
  await migrateTournamentBadges();
  await migrateClothings();
  await migrateTourneyOnesClothings();
  await migrateDecorations();
  await migrateFusionSerum();
  await migratePrizes();
  */

  throw new Error('Already uploaded to S3');
})();
