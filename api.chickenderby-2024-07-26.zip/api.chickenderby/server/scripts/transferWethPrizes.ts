// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/transferWethPrizes.ts
import Web3 from 'web3';
import 'dotenv/config';

import { getWearablesOwnerAddress, getPolygonWeb3, getGasPrice, getWethContract } from '../services/contracts/web3Service';
import { sleep } from '../utils';
import races from './races-to-refund-05-08-04.json';
import config from '../config';

(async () => {
  let lastUserWalletId: string = '';
  let total: number = 0;

  try {
    const admin = getWearablesOwnerAddress();
    const polygonWeb3 = getPolygonWeb3();
    const wethContract = await getWethContract();
    const gasPrice = await getGasPrice(polygonWeb3);

    const racesToRefund = races.slice();
    for (const race of racesToRefund) {
      const {
        id,
        name,
        fee,
        userWallets,
      } = race;

      const amountWei = Web3.utils.toWei(fee.toString(), 'ether');
      for (const userWallet of userWallets) {
        const nonce = await polygonWeb3.eth.getTransactionCount(admin.publicAddress);

        const transferFunc = wethContract.methods.transfer(
          userWallet.userWalletId,
          amountWei,
        );
        // const estimatedGas = await transferFunc.estimateGas({
        //   from: admin.publicAddress,
        // });
        const data = transferFunc.encodeABI();

        const tx = {
          from: admin.publicAddress,
          to: wethContract.options.address,
          nonce,
          gas: Web3.utils.toHex(config.BICONOMY_CUSTOM_GAS_LIMIT),
          gasPrice: Web3.utils.toHex(gasPrice),
          value: '0x0',
          data,
        };

        const receipt = await polygonWeb3.eth
          .sendTransaction(tx)
          .once('transactionHash', (txhash) => {
            console.log(`Transaction hash: ${txhash}`);
          });

        total += fee;
        lastUserWalletId = userWallet.userWalletId;
        console.log('raceId', id, 'name', name, 'lastUserWalletId', lastUserWalletId, 'from', admin.publicAddress, 'fee', fee, 'amountWei', amountWei, 'gasLimit', tx.gas, 'txHash', receipt.transactionHash, 'Transfer success');

        (userWallet as any).txHash = receipt.transactionHash;

        await sleep(500);
      }
    }

    console.log('Transfer Done total', total, 'races', races);
  } catch (err) {
    console.log('lastUserWalletId', lastUserWalletId, 'Transfer error', err);
    process.exit(1);
  }

  process.exit(0);
})();
