/* eslint-disable @typescript-eslint/no-unused-vars */
// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateImagesV2
// Please run this script only one time and delete it

import * as _ from 'lodash';

import { Op } from 'sequelize';
import config from '../config';
import '../sequelize/models';
import { log, sleep } from '../utils';
import { uploadUrlToS3 } from '../services/awsService';
import { Chicken } from '../sequelize/models/Chicken';
import { SeasonBadge } from '../sequelize/models/SeasonBadge';
import { TournamentBadge } from '../sequelize/models/TournamentBadge';
import { Clothing } from '../sequelize/models/Clothing';
import { TourneyOne } from '../sequelize/models/TourneyOne';
import { Decoration } from '../sequelize/models/Decoration';
import { Serum } from '../sequelize/models/Serum';
import { Tournament } from '../sequelize/models/Tournament';
import { Lane } from '../sequelize/models/Lane';
import { RoadMap } from '../sequelize/models/RoadMap';

const migrateChickenImages = async () => {
  log.info('start migration for chicken images');

  const limit = 100;

  const total = await Chicken.count({
    where: {
      image: { [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net' },
    },
  });

  let i = 0;

  while (true) {
    const chickens = await Chicken.findAll({
      where: {
        image: { [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net' },
      },
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      const { chknId, image } = chicken;

      const url = await uploadUrlToS3(image, {
        bucket: config.aws.s3.chickenderby.bucket,
        key: `chickens/${chknId}.png`,
        contentType: 'image/png',
      });

      await chicken.update({
        image: url,
      });

      i += 1;
    }

    if (chickens.length < limit) {
      break;
    }

    await sleep(1000);

    log.info(
      `progress => current: ${i} / total: ${total} (${(
        (i / total) *
        100
      ).toFixed(2)}%)`,
    );
  }

  log.info('end migration for chicken images');
};

const migrateChickenClothingImages = async () => {
  log.info('start migration for chicken clothing images');

  const limit = 100;
  let i = 0;

  const total = await Chicken.count({
    where: {
      clothingImage: {
        [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net',
      },
    },
  });

  while (true) {
    const chickens = await Chicken.findAll({
      where: {
        clothingImage: {
          [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net',
        },
      },
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      const { clothingImage } = chicken;
      const filename = clothingImage.split('/').slice().pop();
      const url = await uploadUrlToS3(clothingImage, {
        bucket: config.aws.s3.chickenderby.bucket,
        key: `chicken-clothings/${filename}`,
        contentType: 'image/png',
      });

      await chicken.update({
        clothingImage: url,
      });

      i += 1;
    }

    if (chickens.length < limit) {
      break;
    }

    await sleep(1000);

    log.info(
      `progress => current: ${i} / total: ${total} (${(
        (i / total) *
        100
      ).toFixed(2)}%)`,
    );
  }

  log.info('end migration for chicken clothing images');
};

const migrateLaneClothingImages = async () => {
  log.info('start migration for lane clothings images');

  const limit = 100;
  let i = 0;

  const total = await Lane.count({
    where: {
      clothingImage: {
        [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net',
      },
    },
  });

  while (true) {
    const lanes = await Lane.findAll({
      where: {
        clothingImage: {
          [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net',
        },
      },
      limit,
      order: [['id', 'ASC']],
    });

    for (const lane of lanes) {
      const { clothingImage } = lane;
      const filename = clothingImage.split('/').slice().pop();
      const url = await uploadUrlToS3(clothingImage, {
        bucket: config.aws.s3.chickenderby.bucket,
        key: `chicken-clothings/${filename}`,
        contentType: 'image/png',
      });

      await lane.update({
        clothingImage: url,
      });

      i += 1;
    }

    if (lanes.length < limit) {
      break;
    }

    await sleep(1000);

    log.info(
      `progress => current: ${i} / total: ${total} (${(
        (i / total) *
        100
      ).toFixed(2)}%)`,
    );
  }
  log.info('start migration for lane clothings images');

};

const migrateSeasonBadges = async () => {
  log.info('start migration for season badges');

  const seasonBadges = await SeasonBadge.findAll({
    where: {
      image: { [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net' },
    },
  });
  for (const seasonBadge of seasonBadges) {
    const { image, toolTip } = seasonBadge;
    const filename = _.snakeCase(toolTip);

    const url = await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `badges/seasons/${filename}.png`,
      contentType: 'image/png',
    });

    await seasonBadge.update({
      image: url,
    });
  }

  log.info('end migration for season badges');
};

const migrateTournamentBadges = async () => {
  log.info('start migration for tournament badges');

  const tournamentBadges = await TournamentBadge.findAll({
    where: {
      image: { [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net' },
    },
  });

  for (const tournamentBadge of tournamentBadges) {
    const { image, toolTip } = tournamentBadge;
    const filename = _.snakeCase(toolTip);

    const url = await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `badges/tournaments/${filename}.png`,
      contentType: 'image/png',
    });

    await tournamentBadge.update({
      image: url,
    });
  }

  log.info('end migration for tournament badges');
};

const migrateClothings = async () => {
  log.info('start migration for clothings');

  const clothings = await Clothing.findAll({
    where: {
      image: { [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net' },
    },
  });
  for (const clothing of clothings) {
    const { name, type, clothingSet, image } = clothing;
    const dir = _.kebabCase(clothingSet);
    const filename = _.snakeCase(`${type} ${name}`);

    const url = await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `clothings/${dir}/${filename}.png`,
      contentType: 'image/png',
    });

    await clothing.update({
      image: url,
    });
  }

  log.info('end migration for clothings');
};

const migrateTourneyOnesClothings = async () => {
  log.info('start migration for tourney ones clothings');

  const clothings = await TourneyOne.findAll({
    where: {
      image: { [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net' },
    },
  });
  for (const clothing of clothings) {
    const { name, type, clothingSet, image } = clothing;
    const dir = _.kebabCase(clothingSet);
    const filename = _.snakeCase(`${type} ${name}`);

    const url = await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `tourney-ones/${dir}/${filename}.png`,
      contentType: 'image/png',
    });

    await clothing.update({
      image: url,
    });
  }

  log.info('end migration for tourney ones clothings');
};

const migrateDecorations = async () => {
  log.info('start migration for decorations');

  const decorations = await Decoration.findAll({
    where: {
      image: { [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net' },
    },
  });
  for (const decoration of decorations) {
    const { name, type, image } = decoration;
    const filename = _.snakeCase(`${type} ${name}`);

    const url = await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `decorations/${filename}.png`,
      contentType: 'image/png',
    });

    await decoration.update({
      image: url,
    });
  }

  log.info('end migration for decorations');
};

const migrateFusionSerum = async () => {
  log.info('start migration for fusion serum');

  const serums = await Serum.findAll({
    where: {
      image: { [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net' },
    },
  });

  for (const serum of serums) {
    const url = await uploadUrlToS3(serum.image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: 'fusion/fusion_serum.png',
      contentType: 'image/png',
    });

    await serum.update({
      image: url,
    });
  }

  log.info('end migration for fusion serum');
};

const migrateRoadMaps = async () => {
  log.info('start migration for road maps');

  const roadMaps = await RoadMap.findAll({
    where: {
      imageUrl: { [Op.startsWith]: 'https://d27f7k2pulu3i4.cloudfront.net' },
    },
  });

  for (const roadMap of roadMaps) {
    const filename = roadMap.imageUrl.split('/').slice().pop();
    const url = await uploadUrlToS3(roadMap.imageUrl, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `'roadmaps/${filename}`,
      contentType: 'image/png',
    });

    await roadMap.update({
      imageUrl: url,
    });
  }

  log.info('end migration for fusion serum');
};


const migratePrizes = async () => {
  log.info('start migration for prizes');

  const prizes = [
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/EmergencyResponseSets.png',
      fileName: 'EmergencyResponseSets.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/streakybacon.png',
      fileName: 'streakybacon.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/oktoberbest_drindl.png',
      fileName: 'oktoberbest_drindl.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/oktoberbest_lederhose.png',
      fileName: 'oktoberbest_lederhose.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/BaseballSets.png',
      fileName: 'BaseballSets.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/HalloweenOutfits.png',
      fileName: 'HalloweenOutfits.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/CutTheMustardItems.png',
      fileName: 'CutTheMustardItems.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/FemalePilgrim.png',
      fileName: 'FemalePilgrim.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/MalePilgrim.png',
      fileName: 'MalePilgrim.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/SantaOutfit.png',
      fileName: 'SantaOutfit.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/ClansOfHogmanay.png',
      fileName: 'ClansOfHogmanay.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/dorkings_and_queens.png',
      fileName: 'dorkings_and_queens.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/SportswearItemsGroups.png',
      fileName: 'SportswearItemsGroups.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/CheerleaderSets.png',
      fileName: 'CheerleaderSets.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/neck_cheerleaderchargemedak.png',
      fileName: 'neck_cheerleaderchargemedak.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/CheerleaderSets.png',
      fileName: 'CheerleaderSets.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/reggaebow.png',
      fileName: 'reggaebow.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/charliesChallenges.png',
      fileName: 'charliesChallenges.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/MutantSets.png',
      fileName: 'MutantSets.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/SportsFansWearables.png',
      fileName: 'SportsFansWearables.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/SummerWearables.png',
      fileName: 'SummerWearables.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/eyes_streakybaconglasses.png',
      fileName: 'eyes_streakybaconglasses.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/head_secondbirthdaycakehat.png',
      fileName: 'head_secondbirthdaycakehat.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/CommonBirthdayWearables.png',
      fileName: 'CommonBirthdayWearables.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/HeritageMedals.png',
      fileName: 'HeritageMedals.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/SteampunkPrizes.png',
      fileName: 'SteampunkPrizes.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/SpaceWearables_1.png',
      fileName: 'SpaceWearables_1.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/feet_streakybaconflipflops.png',
      fileName: 'feet_streakybaconflipflops.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/team-tournament-4-wearables.png',
      fileName: 'team-tournament-4-wearables.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/AquaticAnimalSuits.png',
      fileName: 'AquaticAnimalSuits.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/DanceSets.png',
      fileName: 'DanceSets.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/StreakyBaconClothing.png',
      fileName: 'StreakyBaconClothing.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/CowboyTournamentWearables.png',
      fileName: 'CowboyTournamentWearables.png',
    },
    {
      image: 'https://d27f7k2pulu3i4.cloudfront.net/prizes/ForestAnimals.png',
      fileName: 'ForestAnimals.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/style_tournament.png',
      fileName: 'style_tournament.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/3_TournamentWearables_1.png',
      fileName: '3_TournamentWearables_1.png',
    },
    {
      image:
        'https://d27f7k2pulu3i4.cloudfront.net/prizes/VampiresWerewolvesSets.png',
      fileName: 'VampiresWerewolvesSets.png',
    },
  ];

  for (const prize of prizes) {
    const { image, fileName } = prize;

    await uploadUrlToS3(image, {
      bucket: config.aws.s3.chickenderby.bucket,
      key: `prizes/${fileName}`,
      contentType: 'image/png',
    });
  }

  const tournaments = await Tournament.findAll();

  for (const tournament of tournaments) {
    const { description } = tournament;

    if (!description) {
      continue;
    }

    const regexp = new RegExp('https://d27f7k2pulu3i4.cloudfront.net', 'g');
    const newDescription = description.replace(regexp, 'https:localhost');

    await tournament.update({
      description: newDescription,
    });
  }

  log.info('end migration for prizes');
};

(async () => {
  /*
  await migrateSeasonBadges();
  await migrateTournamentBadges();
  await migrateClothings();
  await migrateTourneyOnesClothings();
  await migrateDecorations();
  await migrateFusionSerum();
  await migratePrizes();
  await migrateChickenImages();
  await migrateRoadMaps();
  await migrateChickenClothingImages();
  await migrateLaneClothingImages();
  */
})();
