// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/airdropChickens.ts
import 'dotenv/config';
import config from '../config';
import { getFusionAdminSignerAddress, getChickenContract, getPolygonWeb3, getGasPrice } from '../services/contracts/web3Service';
import models from '../sequelize/models';
import { ChickenStatus } from '../types/chickens/chickenStatus';
import { sleep } from '../utils';

(async () => {
  let lastUserWalletId: string = '';
  // Please check the last mint id on the database before running the script!
  let chickenId = 7356;

  try {
    const chickenContract = await getChickenContract();
    const fusionAdmin = getFusionAdminSignerAddress();
    const polygonWeb3 = getPolygonWeb3();
    const gasPrice = await getGasPrice(polygonWeb3);

    const mappings: {
      userWalletId: string;
      count: number;
    }[] = [
      {
        userWalletId: '0x83Dd5A88915a4e065A52930a8270C656905Eb5c8',
        count: 5,
      },
      {
        userWalletId: '0x5aeAf1a51176Ef0972d3c4be199B9BD7C79c8141',
        count: 5,
      },
      {
        userWalletId: '0x7A7a38A3bC38e7fAb3e8DFFe513d9BF6f60FDa31',
        count: 5,
      },
      {
        userWalletId: '0xdca5b37FC5C6123E926efC554d2f82DfE7f97770',
        count: 5,
      },
      {
        userWalletId: '0xF02D5224551cDa81e7d29CF8F834C78b4e6a7dE9',
        count: 5,
      },
    ];

    for (const mapping of mappings) {
      const {
        userWalletId,
        count,
      } = mapping;

      for (let i = 0; i < count; i += 1) {
        await chickenContract.methods.mint(userWalletId, chickenId).send({
          from: fusionAdmin.publicAddress,
          gas: config.BICONOMY_CUSTOM_GAS_LIMIT,
          gasPrice,
        });

        await models.Chicken.update({
          status: ChickenStatus.Active,
        }, {
          where: {
            id: chickenId,
          },
        });

        lastUserWalletId = userWalletId;
        console.log('lastUserWalletId', lastUserWalletId, 'chickenId', chickenId, 'Mint success');

        chickenId += 1;

        await sleep(500);
      }
    }
  } catch (err) {
    console.log('lastUserWalletId', lastUserWalletId, 'chickenId', chickenId, 'Mint error', err);
    process.exit(1);
  }

  process.exit(0);
})();
