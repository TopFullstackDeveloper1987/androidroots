// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateChickenPeckingOrders.ts

import Sequelize from 'sequelize';

import models from '../sequelize/models';
import { Chicken } from '../sequelize/models/Chicken';
import { log, sleep } from '../utils';
import { ChickenStatus } from '../types/chickens/chickenStatus';
import { getPeckingOrder } from '../services/peckingOrderService';

const run = async () => {
  log.info('Start migrating chicken pecking orders');

  const limit = 10000;
  let offset = 0;

  const where: Sequelize.WhereOptions<Chicken> = {
    status: [ChickenStatus.Active, ChickenStatus.FusionResult],
  };
  const total = await models.Chicken.count({
    where,
  });

  while (offset < total) {
    const chickens = await models.Chicken.unscoped().findAll({
      where,
      offset,
      limit,
      order: [['id', 'ASC']],
    });

    for (const chicken of chickens) {
      const peckingOrder = getPeckingOrder(chicken);

      await chicken.update({
        peckingOrder,
      });
    }

    await sleep(1000);

    offset += chickens.length;

    log.info(
      `progress => current: ${offset} / total: ${total} (${(
        (offset / total) *
        100
      ).toFixed(2)}%)`,
    );
  }

  log.info('End migrating chicken pecking orders');
};

(async () => {
  await run();

  process.exit(0);
})();
