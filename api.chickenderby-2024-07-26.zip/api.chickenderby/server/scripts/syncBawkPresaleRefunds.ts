// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/syncBawkPresaleRefunds.ts
require('dotenv').config();
import { Op } from 'sequelize';

import '../sequelize/models';
import { BawkPresale } from '../sequelize/models/BawkPresale';

import { redisConnect, redisGetAsync } from '../services/redisClient';
import { getUserRefunded } from '../services/contracts/bawkPresaleContractService';

import { log } from '../utils';

const limit = 100;
const redisKey = 'sync_bawk_presales_refund';

const syncBawkPresaleRefundByUser = async (bawkPresale: BawkPresale) => {
  const refunds = await getUserRefunded(bawkPresale.userWalletId);

  return bawkPresale.update({
    refunds,
    refundsSyncedAt: new Date(),
  });
};

const syncBakePresaleRefunds = async () => {
  const redisClient = redisConnect();
  const initialOffset = await redisGetAsync(redisKey);
  let offset = initialOffset ? parseInt(initialOffset, 10) : 0;
  const total = await BawkPresale.count({
    where: {
      lost: { [Op.gt]: 0 },
    },
  });

  log.info(`sync presales refund start at ${offset}`);

  while (true) {
    const bawkPresales = await BawkPresale.findAll({
      where: {
        lost: { [Op.gt]: 0 },
      },
      offset,
      limit,
      order: [['createdAt', 'ASC']],
    });

    for (const bawkPresale of bawkPresales) {
      await syncBawkPresaleRefundByUser(bawkPresale);

      offset += 1;
      redisClient.set(redisKey, offset.toString());

      log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);
    }

    if (bawkPresales.length < limit) {
      break;
    }
  }

  log.info('sync presales refund ended');
  redisClient.del(redisKey);
};

(async () => {
  await syncBakePresaleRefunds();
  process.exit(0);
})();
