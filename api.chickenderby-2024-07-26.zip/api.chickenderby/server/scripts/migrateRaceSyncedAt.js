// node server/scripts/migrateRaceSyncedAt
const models = require('../sequelize/models');
const { log } = require('../utils');
const RaceStatus = require('../types/races/raceStatus');
const PaidStatus = require('../types/transactions/transactionPaidStatus');

(async () => {
  log.info('start migration for race.syncedAt');

  const limit = 10000;
  let count = 0;

  const where = {
    status: [RaceStatus.Finished, RaceStatus.Canceled],
    paidStatus: PaidStatus.Paid,
    syncedAt: null,
  };

  const total = await models.Race.count({
    where,
  });

  while (count < total) {
    const races = await models.Race.findAll({
      where,
      limit,
      order: [['id', 'ASC']],
    });

    for (const race of races) {
      await race.update({
        syncedAt: new Date(),
      });
    }

    count += races.length;

    log.info(`progress => current: ${count} / total: ${total} (${(count / total * 100).toFixed(2)}%)`);
  }

  log.info('end migration for race.syncedAt');

  process.exit(0);
})();
