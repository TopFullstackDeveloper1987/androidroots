// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/migrateUsdToJewel.ts

import Sequelize from 'sequelize';
const { Op } = Sequelize;
import * as moment from 'moment-timezone';

import '../sequelize/models';
import { Race } from '../sequelize/models/Race';
import { Lane } from '../sequelize/models/Lane';
import { UserWallet } from '../sequelize/models/UserWallet';
import { Chicken } from '../sequelize/models/Chicken';

import { usdtToJewel } from '../services/exchangeService';

const usdtToJewelPrice = usdtToJewel();

const migrateRaces = async () => {
  console.log('Start migrating races');

  const firstRace = await Race.findOne({
    order: [['id', 'ASC']],
  });

  const now = moment.utc().endOf('month');
  let month = moment.utc(firstRace?.createdAt).startOf('month');

  while (month.isBefore(now)) {
    await Race.update({
      feeJEWEL: Sequelize.literal(`feeJEWEL * ${usdtToJewelPrice}`),
      prizePoolJEWEL: Sequelize.literal(`prizePoolJEWEL * ${usdtToJewelPrice}`),
    }, {
      where: {
        createdAt: {
          [Op.between]: [month.startOf('month').toDate(), month.endOf('month').toDate()],
        },
      },
    });

    month = month.add(1, 'month');

    console.log(`Migrated ${month.format('YYYY-MM')}, ${month.toDate()}`);
  }

  console.log('End migrating races');
};

const migrateLanes = async () => {
  console.log('Start migrating lanes');

  const firstLane = await Lane.findOne({
    order: [['id', 'ASC']],
  });

  const now = moment.utc().endOf('month');
  let month = moment.utc(firstLane?.createdAt).startOf('month');

  while (month.isBefore(now)) {
    await Lane.update({
      raceEarnings: Sequelize.literal(`raceEarnings * ${usdtToJewelPrice}`),
    }, {
      where: {
        createdAt: {
          [Op.between]: [month.startOf('month').toDate(), month.endOf('month').toDate()],
        },
      },
    });

    month = month.add(1, 'month');

    console.log(`Migrated ${month.format('YYYY-MM')}, ${month.toDate()}`);
  }

  console.log('End migrating lanes');
};

const migrateUserWallets = async () => {
  console.log('Start migrating user wallets');

  await UserWallet.update({
    winningsJEWEL: Sequelize.literal(`winningsJEWEL * ${usdtToJewelPrice}`),
  }, {
    where: {},
  });

  console.log('End migrating lanes');
};

const migrateChickens = async () => {
  console.log('Start migrating chickens');

  await Chicken.update({
    earnings: Sequelize.literal(`earnings * ${usdtToJewelPrice}`),
  }, {
    where: {},
  });

  console.log('End migrating chickens');
};

(async () => {
  await migrateRaces();

  await migrateLanes();

  await migrateUserWallets();

  await migrateChickens();
})();
