// TS_NODE_FILES=true node_modules/.bin/ts-node server/scripts/airdropBawkLotsPresale.ts
require('dotenv').config();
import { Op } from 'sequelize';

import '../sequelize/models';
import { BawkPresale } from '../sequelize/models/BawkPresale';

import { BawkEscrowContractService } from '../services/contracts/bawk-escrow-contract.service';
import { redisConnect, redisGetAsync } from '../services/redisClient';

import { log, sleep } from '../utils';

const limit = 100;
const bawksPerLot = 30000;
const redisKey = 'airdrop_bawk_lots_presales';

const airdropBawkLotsPresaleByUser = async (bawkPresale: BawkPresale) => {
  const bawkEscrowContractService = BawkEscrowContractService.getInstance();

  if (bawkPresale.airdroppedAt) {
    return;
  }

  if (!bawkPresale.won) {
    return;
  }


  const bawks = bawkPresale.won * bawksPerLot;
  const transactionHash = await bawkEscrowContractService.appendEscrowEntry(bawkPresale.userWalletId, bawks.toString());

  log.info(`${bawkPresale.userWalletId} => Airdropped ${bawks} for ${bawkPresale.won} lots: ${transactionHash}`);

  return bawkPresale.update({
    bawks,
    transactionHash,
    airdroppedAt: new Date(),
  });
};

const airdropBawkLotsPresales = async () => {
  const redisClient = redisConnect();
  const initialOffset = await redisGetAsync(redisKey);
  let offset = initialOffset ? parseInt(initialOffset, 10) : 0;
  const total = await BawkPresale.count({
    where: {
      won: { [Op.gt]: 0 },
    },
  });

  log.info(`airdrop bawk lots presales at ${offset}`);

  while (true) {
    const bawkPresales = await BawkPresale.findAll({
      where: {
        won: { [Op.gt]: 0 },
      },
      offset,
      limit,
      order: [['createdAt', 'ASC']],
    });

    for (const bawkPresale of bawkPresales) {
      await airdropBawkLotsPresaleByUser(bawkPresale);

      offset += 1;
      redisClient.set(redisKey, offset.toString());

      log.info(`progress => current: ${offset} / total: ${total} (${(offset / total * 100).toFixed(2)}%)`);

      await sleep(500);
    }

    if (bawkPresales.length < limit) {
      break;
    }
  }

  log.info('airdrop bawk lots presales ended');
  redisClient.del(redisKey);
};

(async () => {
  await airdropBawkLotsPresales();
  process.exit(0);
})();
