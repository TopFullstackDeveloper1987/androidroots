// node server/scripts/fixLanes
const Sequelize = require('sequelize');

const { Op } = Sequelize;

const models = require('../sequelize/models');
const { log } = require('../utils');

(async () => {
  const results = await models.Lane.findAll({
    attributes: [
      'raceId',
      [Sequelize.fn('COUNT', '*'), 'count'],
    ],
    group: ['raceId'],
    having: Sequelize.where(Sequelize.fn('COUNT', '*'), Op.gt, 12),
  });

  await models.sequelize.transaction(async (t) => {
    for (const result of results) {
      const { raceId, count } = result.toJSON();
      log.info({
        raceId,
        count,
      });

      const lanes = await models.Lane.findAll({
        where: {
          raceId,
        },
        order: [['id', 'ASC']],
        offset: count / 2,
        limit: count / 2,
        transaction: t,
      });

      await models.Lane.destroy({
        where: {
          id: lanes.map((lane) => lane.id),
        },
        transaction: t,
      });
    }
  });

  log.info({
    numberOfResults: results.length,
  });

  process.exit(0);
})();
