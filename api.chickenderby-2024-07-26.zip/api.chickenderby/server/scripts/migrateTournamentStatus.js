// node server/scripts/migrateTournamentStatus

const moment = require('moment-timezone');
const models = require('../sequelize/models');
const { log } = require('../utils');
const TournamentStatus = require('../types/tournaments/tournamentStatus');

(async () => {
  log.info('start migration for tournament status');

  const tournaments = await models.Tournament.findAll();

  const now = moment.utc();
  for (const tournament of tournaments) {
    const { startAt, endAt } = tournament;
    const startsAtMoment = moment.utc(startAt);
    const endsAtMoment = moment.utc(endAt);

    let status = TournamentStatus.Pending;
    if (now.isBetween(startsAtMoment, endsAtMoment, null, '()')) {
      status = TournamentStatus.Live;
    } else if (now.isAfter(endsAtMoment)) {
      status = TournamentStatus.Completed;
    }

    await tournament.update({
      status,
    });
  }

  log.info('end migration for tournament status');

  process.exit(0);
})();
