// tailwind.config.ts is not working so we couldn't import colors.ts
// To see color changes, please run `yarn start` which has --reset-cache option

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./App.{js,jsx,ts,tsx}', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // We are going to use actual colors referenced from theme (theme.ts, useColors) to customize react-native-paper components
        primary: '#5F63D7',
        secondary: '#ededfb',
        disabled: '#9FA1B8',
        success: '#01B574',
        error: '#FF5252',
        light: '#F5F7FA',
        surfaceGray: '#f9f9fd',
      },
    },
  },
  plugins: [],
};
