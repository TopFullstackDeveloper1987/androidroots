// SpecialityIcons.ts

export interface SpecialtyIcon {
  name: string;
  uri: number;
}

export const SPECIALITY_ICONS: { [key: string]: SpecialtyIcon } = {
  '1_neurology.png': {
    name: '1_neurology.png',
    uri: require('@/assets/images/speciality/png/1_neurology.png') as number
  },
  '2_general_surgery.png': {
    name: '2_general_surgery.png',
    uri: require('@/assets/images/speciality/png/2_general_surgery.png') as number
  },
  '3_otolaryngology.png': {
    name: '3_otolaryngology.png',
    uri: require('@/assets/images/speciality/png/3_otolaryngology.png') as number
  },
  '4_urology.png': {
    name: '4_urology.png',
    uri: require('@/assets/images/speciality/png/4_urology.png') as number
  },
  '5_internal_medicine.png': {
    name: '5_internal_medicine.png',
    uri: require('@/assets/images/speciality/png/5_internal_medicine.png') as number
  },
  '6_cardiology.png': {
    name: '6_cardiology.png',
    uri: require('@/assets/images/speciality/png/6_cardiology.png') as number
  },
  '7_psychiatry.png': {
    name: '7_psychiatry.png',
    uri: require('@/assets/images/speciality/png/7_psychiatry.png') as number
  },
  '8_obstetrics.png': {
    name: '8_obstetrics.png',
    uri: require('@/assets/images/speciality/png/8_obstetrics.png') as number
  },
  '9_pediatrics.png': {
    name: '9_pediatrics.png',
    uri: require('@/assets/images/speciality/png/9_pediatrics.png') as number
  },
  '10_dermatology.png': {
    name: '10_dermatology.png',
    uri: require('@/assets/images/speciality/png/10_dermatology.png') as number
  },
  '11_lungs.png': {
    name: '11_lungs.png',
    uri: require('@/assets/images/speciality/png/11_lungs.png') as number
  },
  '12_gastroenterology.png': {
    name: '12_gastroenterology.png',
    uri: require('@/assets/images/speciality/png/12_gastroenterology.png') as number
  },
  '13_physiotherapy.png': {
    name: '13_physiotherapy.png',
    uri: require('@/assets/images/speciality/png/13_physiotherapy.png') as number
  },
  '14_orthopaedic.png': {
    name: '14_orthopaedic.png',
    uri: require('@/assets/images/speciality/png/14_orthopaedic.png') as number
  },
  '15_opthalmology.png': {
    name: '15_opthalmology.png',
    uri: require('@/assets/images/speciality/png/15_opthalmology.png') as number
  },
  '16_dentistry.png': {
    name: '16_dentistry.png',
    uri: require('@/assets/images/speciality/png/16_dentistry.png') as number
  },
  '17_laboratory.png': {
    name: '17_laboratory.png',
    uri: require('@/assets/images/speciality/png/17_laboratory.png') as number
  },
  '18_radiology.png': {
    name: '18_radiology.png',
    uri: require('@/assets/images/speciality/png/18_radiology.png') as number
  },
  '19_optometry.png': {
    name: '19_optometry.png',
    uri: require('@/assets/images/speciality/png/19_optometry.png') as number
  },
  '20_plastic_surgery.png': {
    name: '20_plastic_surgery.png',
    uri: require('@/assets/images/speciality/png/20_plastic_surgery.png') as number
  },
  '21_pharmacy.png': {
    name: '21_pharmacy.png',
    uri: require('@/assets/images/speciality/png/21_pharmacy.png') as number
  },
  '22_speech_therapy.png': {
    name: '22_speech_therapy.png',
    uri: require('@/assets/images/speciality/png/22_speech_therapy.png') as number
  },
};
