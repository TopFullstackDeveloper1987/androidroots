// These theme's (and any new themes) can be generated at:
// https://callstack.github.io/react-native-paper/docs/guides/theming/#creating-dynamic-theme-colors

import {
  MD3LightTheme,
  MD3DarkTheme,
  adaptNavigationTheme,
  configureFonts,
} from 'react-native-paper';
import merge from 'deepmerge';
import { NativeStackNavigationOptions } from '@react-navigation/native-stack';

export const fonts = configureFonts({ config: { fontFamily: 'sans-serif' } });

export const navigationOptions: NativeStackNavigationOptions = {
  headerShadowVisible: false,
  headerBackTitleVisible: false,
  // headerBackImage: NavigationBackButton,
  headerStyle: { backgroundColor: 'transparent' },
  headerTitleAlign: 'center',
};

const customLightTheme = {
  ...MD3LightTheme,
  fonts,
  colors: {
    ...MD3LightTheme.colors,
    primary: 'rgb(76, 80, 196)',
    onPrimary: 'rgb(255, 255, 255)',
    primaryContainer: 'rgb(225, 224, 255)',
    onPrimaryContainer: 'rgb(5, 0, 108)',
    secondary: '#ededfb',
    onSecondary: 'rgb(255, 255, 255)',
    secondaryContainer: 'rgb(225, 224, 255)',
    onSecondaryContainer: 'rgb(9, 7, 100)',
    tertiary: 'rgb(121, 83, 106)',
    onTertiary: 'rgb(255, 255, 255)',
    tertiaryContainer: 'rgb(255, 216, 236)',
    onTertiaryContainer: 'rgb(46, 17, 37)',
    error: 'rgb(184, 29, 39)',
    onError: 'rgb(255, 255, 255)',
    errorContainer: 'rgb(255, 218, 215)',
    onErrorContainer: 'rgb(65, 0, 4)',
    background: '#ffffff',
    onBackground: '#000000',
    surface: '#f9f9fd',
    onSurface: '#10115A', // main text
    surfaceVariant: 'rgb(228, 225, 236)', // card background
    onSurfaceVariant: '#10115A', // main text on inputs
    outline: 'rgb(119, 118, 128)',
    outlineVariant: 'rgb(199, 197, 208)', // divider background
    shadow: 'rgb(0, 0, 0)',
    scrim: 'rgb(0, 0, 0)',
    inverseSurface: 'rgb(49, 48, 52)',
    inverseOnSurface: 'rgb(243, 239, 244)',
    inversePrimary: 'rgb(192, 193, 255)',
    elevation: {
      level0: 'transparent',
      level1: 'rgb(246, 242, 252)',
      level2: 'rgb(241, 237, 250)',
      level3: '#f9f9fd', // background on inputs
      level4: 'rgb(234, 231, 248)',
      level5: 'rgb(230, 227, 247)',
    },
    surfaceDisabled: 'rgba(28, 27, 31, 0.12)',
    onSurfaceDisabled: 'rgba(28, 27, 31, 0.38)',
    backdrop: 'rgba(48, 48, 56, 0.4)',

    // add custom colors
    success: 'rgb(0, 109, 68)',
    onSuccess: 'rgb(255, 255, 255)',
    successContainer: 'rgb(111, 252, 180)',
    onSuccessContainer: 'rgb(0, 33, 17)',
    surfaceGray: '#f9f9fd', // secondary background
    placeholder: 'rgb(150, 150, 150)',
  },
};

const customDarkTheme = {
  ...MD3DarkTheme,
  fonts,
  colors: {
    ...MD3DarkTheme.colors,
    // TODO: use light theme only for now
    ...customLightTheme.colors,
  },
};

const customNavigationLightTheme = {
  dark: false,
  colors: {
    primary: 'rgb(76, 80, 196)',
    background: '#f9f9fd',
    card: 'rgb(255, 255, 255)',
    text: 'rgb(28, 28, 30)',
    border: 'rgb(199, 199, 204)',
    notification: 'rgb(255, 69, 58)',
  },
};
const customNavigationDarkTheme = {
  dark: true,
  colors: {
    // TODO: use light theme only for now
    ...customNavigationLightTheme.colors,
  },
};

const { LightTheme, DarkTheme } = adaptNavigationTheme({
  reactNavigationLight: customNavigationLightTheme,
  reactNavigationDark: customNavigationDarkTheme,
  materialLight: customLightTheme,
  materialDark: customDarkTheme,
});

const CombinedDefaultTheme = merge(customLightTheme, LightTheme);
const CombinedDarkTheme = merge(customDarkTheme, DarkTheme);

export type ColorTheme = typeof CombinedDarkTheme | typeof CombinedDefaultTheme;

export const getTheme = (colorScheme: 'dark' | 'light') =>
  colorScheme === 'light' ? CombinedDefaultTheme : CombinedDarkTheme;
