import { AsyncStorageService } from '@/services';
import { Platform, NativeModules, I18nManager } from 'react-native';
import RNRestart from 'react-native-restart';
import { ModuleType } from 'i18next';

export const getDeviceLanguage = () => {
  const lang =
    Platform.OS === 'ios'
      ? NativeModules.SettingsManager.settings.AppleLocale ||
        NativeModules.SettingsManager.settings.AppleLanguages[0]
      : NativeModules.I18nManager.localeIdentifier;

  return lang.search(/-|_/g) !== -1
    ? lang.split('-')[0].split('_')[0]
    : lang;
};

export const changeLanguage = async (language: string) => {
  await AsyncStorageService.getInstance().setUserLanguage(language);

  const isLangRTL = language !== 'en';
  I18nManager.allowRTL(isLangRTL);
  I18nManager.forceRTL(isLangRTL);

  RNRestart.Restart();

};

export const languageDetector = {
  init: () => {},
  type: 'languageDetector' as ModuleType,
  async: true, // flags below detection to be async
  detect: async (callback: (lang: string) => void) => {
    const userLang = await AsyncStorageService.getInstance().getUserLanguage();

    const deviceLang = userLang || getDeviceLanguage();
    const isLangRTL = deviceLang !== 'en';
    if (isLangRTL !== I18nManager.isRTL) {
      I18nManager.allowRTL(isLangRTL);
      I18nManager.forceRTL(isLangRTL);
      // RNRestart.Restart();
    }

    callback(deviceLang);
  },
  cacheUserLanguage: () => {},
};
