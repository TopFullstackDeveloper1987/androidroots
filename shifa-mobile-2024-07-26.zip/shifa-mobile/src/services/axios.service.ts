import axios, {
  AxiosHeaders,
  AxiosInstance,
  AxiosRequestConfig,
  CreateAxiosDefaults,
  Method,
  RawAxiosRequestHeaders,
} from 'axios';

import { API_URL } from '@env';
import { AsyncStorageService } from './async-storage.service';
import { useAuthStore, useMainStore } from '@/stores';
import { getDeviceLanguage } from '@/utils';

type MethodsHeaders = Partial<{
  [Key in Method as Lowercase<Key>]: AxiosHeaders;
} & {common: AxiosHeaders}>;

class AxiosServiceFactory {
  static create() {
    const axiosConfig: CreateAxiosDefaults = {
      baseURL: API_URL,
      headers: {
        common: {
          'Content-Type': 'application/json',
        },
      },
      timeout: 30000,
    };
    const axiosInstance = axios.create(axiosConfig);

    return new AxiosService(AsyncStorageService.getInstance(), axiosInstance);
  }
}

export class AxiosService {
  private static instance: AxiosService;

  constructor(
    private readonly asyncStorageService: AsyncStorageService,
    private readonly axiosInstance: AxiosInstance,
  ) {
    this.axiosInstance.interceptors.response.use((response) => response, async (err) => {
      const error = err.response;

      if (error?.status === 401) {
        // https://github.com/pmndrs/zustand?tab=readme-ov-file#readingwriting-state-and-reacting-to-changes-outside-of-components
        useAuthStore.setState({
          user: null, isLoggedIn: false,
        });
      }

      throw error;
    });
  }

  static getInstance() {
    if (!AxiosService.instance) {
      AxiosService.instance = AxiosServiceFactory.create();
    }

    return AxiosService.instance;
  }

  private async getConfig(customConfig: AxiosRequestConfig = {}) {
    const globalHeaders: (RawAxiosRequestHeaders & MethodsHeaders) | AxiosHeaders = {};

    const accessToken = await this.asyncStorageService.getAccessToken();
    if (accessToken) {
      globalHeaders.Authorization = `JWT ${accessToken}`;
    }

    const { headers } = customConfig;

    return {
      ...customConfig,
      headers: {
        ...globalHeaders,
        ...headers,
        'Accept-Language': useMainStore.getState().userLanguage,
      },
    };
  }

  async get<T>(endPoint: string, customConfig: AxiosRequestConfig = {}) {
    const config = await this.getConfig(customConfig);
    return this.axiosInstance.get<T>(endPoint, config);
  }

  async post<T>(endPoint: string, data = {}, customConfig: AxiosRequestConfig = {}) {
    const config = await this.getConfig(customConfig);
    return this.axiosInstance.post<T>(endPoint, data, config);
  }

  async patch<T>(endPoint: string, data = {}, customConfig: AxiosRequestConfig = {}) {
    const config = await this.getConfig(customConfig);
    return this.axiosInstance.patch<T>(endPoint, data, config);
  }

  async put<T>(endPoint: string, data = {}, customConfig: AxiosRequestConfig = {}) {
    const config = await this.getConfig(customConfig);
    return this.axiosInstance.put<T>(endPoint, data, config);
  }

  async delete<T>(endPoint: string, customConfig: AxiosRequestConfig = {}) {
    const config = await this.getConfig(customConfig);
    return this.axiosInstance.delete<T>(endPoint, config);
  }
}
