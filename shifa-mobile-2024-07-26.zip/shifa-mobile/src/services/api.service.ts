import { AxiosService } from './axios.service';
import {
  ICity,
  IPaginatedResponse,
  IPractitioner,
  IPractitionerDetail,
  ISearchPractitionerQuery,
  ISpeciality,
  IOtp,
  IGenerateOtpPayload,
  IVerifyOtpPayload,
  IUser,
  IDocument,
  IUploadPayload,
  IDocumentListQuery,
  IDocumentUpdatePayload,
  IReview,
  IReviewPayload,
  IProfile,
  IProfileUpdatePayload,
} from '@/types';

export class ApiService {
  private static instance: ApiService;

  constructor(private readonly axiosService: AxiosService) {}

  static getInstance() {
    if (!ApiService.instance) {
      ApiService.instance = new ApiService(AxiosService.getInstance());
    }

    return ApiService.instance;
  }

  async generateOtp(payload: IGenerateOtpPayload) {
    return this.axiosService.post<IOtp>('generate-otp/', payload);
  }

  async verifyOtp(payload: IVerifyOtpPayload) {
    return this.axiosService.post<IOtp>('verify-otp/', payload);
  }

  async getCities(country_id: number) {
    return this.axiosService.get<ICity[]>('metadata/city/', {
      params: {
        country_id,
      },
    });
  }

  async getSpecialities(cityId: number, name?: string) {
    return this.axiosService.get<ISpeciality[]>(`speciality/city/${cityId}/`, {
      params: {
        name,
      },
    });
  }

  async searchPractitioners(params: ISearchPractitionerQuery) {
    return this.axiosService.get<IPaginatedResponse<IPractitioner>>('practitioner/search/', {
      params,
    });
  }

  async getPractitionerDetail(practitionerId: string) {
    return this.axiosService.get<IPractitionerDetail>(`practitioner/${practitionerId}/`);
  }

  async getFavoritePractitioners(userId: string) {
    return this.axiosService.get<IPractitionerDetail[]>(`user/${userId}/favorite/`);
  }

  async setFavoritePractitioner(userId: string, practitionerId: string, action: string) {
    return this.axiosService.patch<IPractitionerDetail>(`user/${userId}/favorite/${practitionerId}/?action=${action}`);
  }

  async getMe() {
    return this.axiosService.get<IUser>('me/');
  }

  async uploadDocument(payload: IUploadPayload) {
    const data = new FormData();
    data.append('file', payload.file);

    return this.axiosService.post<IDocument>(`upload/user/${payload.userId}/profile/${payload.profileId}/`, data, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  }

  async getDocuments(userId: string, profileId: string, params: IDocumentListQuery) {
    return this.axiosService.get<IPaginatedResponse<IDocument>>(`user/${userId}/profile/${profileId}/document/`, {
      params,
    });
  }

  async getDocumentDetail(userId: string, documentId: string) {
    return this.axiosService.get<IDocument>(`user/${userId}/document/${documentId}/`);
  }

  async updateDocument(userId: string, documentId: string, payload: IDocumentUpdatePayload) {
    return this.axiosService.patch<IDocument>(`user/${userId}/document/${documentId}/`, payload);
  }

  async getReviews(practitionerId: string) {
    return this.axiosService.get<IReview[]>(`practitioner/${practitionerId}/review-list/`);
  }
  async postReview(practitionerId: string, payload: IReviewPayload) {
    return this.axiosService.post<IReview>(`practitioner/${practitionerId}/review-create/`, payload);
  }

  async getProfiles(userId: string) {
    return this.axiosService.get<IProfile[]>(`user/${userId}/profile/`);
  }

  async getDefaultProfile(userId: string) {
    return this.axiosService.get<IProfile>(`user/${userId}/profile/`, {
      params: {
        default: true,
      },
    });
  }

  async getProfile(userId: string, profileId: string) {
    return this.axiosService.get<IProfile>(`user/${userId}/profile/${profileId}/`);
  }

  async createProfile(userId: string, payload: Partial<IProfile>) {
    return this.axiosService.post<IProfile>(`user/${userId}/profile/`, payload);
  }

  async updateProfile(userId: string, profileId: string, payload: IProfileUpdatePayload) {
    const data = new FormData();
    Object.keys(payload).forEach((key) => {
      if (payload[key as keyof IProfile] !== undefined) {
        data.append(key, payload[key as keyof IProfile]);
      }
    });

    return this.axiosService.patch<IProfile>(`user/${userId}/profile/${profileId}/`, data, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  }
}
