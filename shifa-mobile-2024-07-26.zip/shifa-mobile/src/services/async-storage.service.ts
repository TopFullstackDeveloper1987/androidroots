import AsyncStorage from '@react-native-async-storage/async-storage';

import { IToken } from '@/types';

export class AsyncStorageService {
  private static instance: AsyncStorageService;

  constructor() {}

  static getInstance() {
    if (!AsyncStorageService.instance) {
      AsyncStorageService.instance = new AsyncStorageService();
    }

    return AsyncStorageService.instance;
  }

  async getToken(): Promise<IToken> {
    const token = await AsyncStorage.getItem('token');
    return token && JSON.parse(token);
  }

  async setToken(token: IToken) {
    await AsyncStorage.setItem('token', JSON.stringify(token));
  }

  async getAccessToken() {
    const token = await this.getToken();
    return token?.access;
  }

  async getRefreshToken() {
    const token = await this.getToken();
    return token?.refresh;
  }

  async getUserLanguage() {
    return AsyncStorage.getItem('user-lang');
  }

  async setUserLanguage(userLang: string) {
    return AsyncStorage.setItem('user-lang', userLang);
  }

  async clear() {
    await AsyncStorage.clear();
  }
}
