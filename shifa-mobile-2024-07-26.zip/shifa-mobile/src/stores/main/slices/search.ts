import { StateCreator } from 'zustand';

import { CommonStoreState, actionWrapper } from '@/stores/common';
import { ICity, ISpeciality, ISearchPractitionerQuery, IPaginatedResponse, IPractitioner, IPractitionerDetail } from '@/types';
import { ApiService } from '@/services';

export interface SearchSliceState extends CommonStoreState {
  cities: ICity[];
  specialities: ISpeciality[];
  practitioners: IPractitioner[];
  practitionerDetail: Partial<IPractitionerDetail>;

  getCities: (countryId: number, isLoading: boolean) => Promise<ICity[]>;
  getSpecialities: (cityId: number, isLoading: boolean, name?: string) => Promise<ISpeciality[]>;
  searchPractitioners: (params: ISearchPractitionerQuery) => Promise<IPaginatedResponse<IPractitioner>>;
  updatePractionerRate:(index: number, value: string) => Promise<void>;
  getPractitionerDetail: (practitionerId: string) => Promise<IPractitionerDetail>;
}

export const createSearchSlice: StateCreator<SearchSliceState, [], [], SearchSliceState> = (
  set,
) => ({
  cities: [],
  specialities: [],
  practitioners: [],
  practitionerDetail: {},

  getCities: async (countryId: number, isLoading: boolean = true) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().getCities(countryId);
      set(() => ({ cities: res.data }));

      return res.data;
    }, isLoading);
  },

  getSpecialities: async (cityId: number, isLoading: boolean = true, name?: string) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().getSpecialities(cityId, name);
      set(() => ({ specialities: res.data }));

      return res.data;
    }, isLoading);
  },

  searchPractitioners: async (params: ISearchPractitionerQuery) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().searchPractitioners(params);
      set(() => ({ practitioners: res.data.results }));

      return res.data;
    });
  },

  updatePractionerRate: (index: number, value: string) => {
    return actionWrapper(set, async () => {
      set((state) => ({
        practitioners: state.practitioners.map((val, i) => {
          if(index === i) {
            return {
              ...val,
              average_rating: value,
            };
          }
          return val;
        }),
      }));
    });
  },

  getPractitionerDetail: async (practitionerId) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().getPractitionerDetail(practitionerId);
      set(() => ({ practitionerDetail: res.data }));

      return res.data;
    });
  },
});
