import { StateCreator } from 'zustand';

import { CommonStoreState, actionWrapper } from '@/stores/common';

export interface LanguageSliceState extends CommonStoreState {
  userLanguage: string;
  setUserLanguage: (lang: string) => void;
}

export const createLanguageSlice: StateCreator<LanguageSliceState, [], [], LanguageSliceState> = (
  set,
) => ({
  userLanguage: 'en',

  setUserLanguage: async (lang: string) => {
    return actionWrapper(set, async () => {
      set(() => ({ userLanguage: lang }));
    });
  },
});
