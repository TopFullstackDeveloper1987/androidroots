import { StateCreator } from 'zustand';

import { CommonStoreState, actionWrapper } from '@/stores/common';
import {
  IPractitionerDetail,
} from '@/types';
import { ApiService } from '@/services';

export interface FavoriteSliceState extends CommonStoreState {
    favoritePractitioners: IPractitionerDetail[];

    setFavoritePractitioner: (userId: string, practitionerId: string, action: string) => Promise<IPractitionerDetail>;
    getFavoritePractitioners: (userId: string, isLoading: boolean) => Promise<IPractitionerDetail[]>;
}

export const createFavoriteSlice: StateCreator<FavoriteSliceState, [], [], FavoriteSliceState> = (
  set,
) => ({
  favoritePractitioners: [],

  getFavoritePractitioners: async (userId: string, isLoading: boolean = true) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().getFavoritePractitioners(userId);

      set(() => ({ favoritePractitioners: res.data }));

      return res.data;
    }, isLoading);
  },
  setFavoritePractitioner: async (userId: string, practitionerId: string, action: string) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().setFavoritePractitioner(userId, practitionerId, action);
      return res.data;
    });
  },
});
