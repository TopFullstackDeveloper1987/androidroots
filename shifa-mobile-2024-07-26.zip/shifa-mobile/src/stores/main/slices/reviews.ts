import { StateCreator } from 'zustand';

import { CommonStoreState, actionWrapper } from '@/stores/common';
import {
  IReview,
  IReviewPayload,
} from '@/types';
import { ApiService } from '@/services';

export interface ReviewsSliceState extends CommonStoreState {
  reviews: IReview[];
  getReviews: (practitionerId: string) => Promise<IReview[]>;
  postReview: (practitionerId: string, payload: IReviewPayload) => Promise<IReview>;
}

export const createReviewSlice: StateCreator<ReviewsSliceState, [], [], ReviewsSliceState> = (
  set,
) => ({
  reviews: [],

  postReview: async (practitionerId: string, payload: IReviewPayload) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().postReview(practitionerId, payload);

      return res.data;
    });
  },

  getReviews: async (practitionerId: string) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().getReviews(practitionerId);

      set(() => ({ reviews: res.data }));

      return res.data;
    });
  },
});
