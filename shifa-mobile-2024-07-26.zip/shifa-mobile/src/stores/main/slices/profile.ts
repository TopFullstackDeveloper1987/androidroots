import { StateCreator } from 'zustand';

import { CommonStoreState, actionWrapper } from '@/stores/common';
import {
  IProfile, IProfileUpdatePayload,
} from '@/types';
import { ApiService } from '@/services';

export interface ProfileSliceState extends CommonStoreState {
  profiles: IProfile[] | null;
  defaultProfile: IProfile | null;
  activeProfile: IProfile | null;

  getProfiles: (userId: string) => Promise<IProfile[]>;
  getDefaultProfile: (userId: string) => Promise<IProfile | null>;
  getProfile: (userId: string, profileId: string) => Promise<IProfile | null>;
  createProfile: (userId: string, payload: Partial<IProfile>) => Promise<IProfile>;
  updateProfile: (userId: string, profileId: string, payload: IProfileUpdatePayload) => Promise<IProfile>;
  updateProfilePhoto: (profile: IProfile) => void;
  setActiveProfile: (profile: IProfile) => void;
  switchToDefaultProfile: () => void;
}

export const createProfileSlice: StateCreator<ProfileSliceState, [], [], ProfileSliceState> = (
  set, get,
) => ({
  profiles: null,
  defaultProfile: null,
  activeProfile: null,

  getProfiles: async (userId: string) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().getProfiles(userId);
      const profiles = res.data;
      const defaultProfile = profiles.find((profile) => profile.relationship?.toLowerCase() === 'self') || null;

      set(() => ({ profiles, defaultProfile }));

      return res.data;
    });
  },

  getDefaultProfile: async (userId: string) => {
    return actionWrapper(set, async () => {
      // don't propagate 404 error
      const res = await ApiService.getInstance().getDefaultProfile(userId).catch(() => null);
      const defaultProfile = res?.data || null;

      set(() => ({ defaultProfile }));

      const activeProfile = get().activeProfile;
      if (!activeProfile) {
        set(() => ({ activeProfile: defaultProfile }));
      }

      return defaultProfile;
    });
  },

  getProfile: async (userId: string, profileId: string) => {
    return actionWrapper(set, async () => {
      // don't propagate 404 error
      const res = await ApiService.getInstance().getProfile(userId, profileId).catch(() => null);
      const profile = res?.data || null;

      const { defaultProfile, activeProfile } = get();

      if (defaultProfile?.id === profile?.id) {
        set(() => ({ defaultProfile: profile }));
      }

      if (activeProfile?.id === profile?.id) {
        set(() => ({ activeProfile: profile }));
      }

      return profile;
    });
  },

  createProfile: async (userId: string, payload: Partial<IProfile>) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().createProfile(userId, payload);

      return res.data;
    });
  },

  updateProfile: async (userId: string, profileId: string, payload: IProfileUpdatePayload) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().updateProfile(userId, profileId, payload);

      return res.data;
    });
  },

  updateProfilePhoto: async (profile: IProfile) => {
    return actionWrapper(set, async () => {
      set(() => ({ activeProfile: profile }));
    });
  },

  setActiveProfile: (profile: IProfile) => {
    set(() => ({ activeProfile: profile }));
  },

  switchToDefaultProfile: () => {
    set(() => ({ activeProfile: get().defaultProfile }));
  },
});
