import { StateCreator } from 'zustand';

import { CommonStoreState, actionWrapper } from '@/stores/common';
import {
  IUploadPayload,
  IDocument,
  IPaginatedResponse,
  IDocumentListQuery,
  IDocumentUpdatePayload,
} from '@/types';
import { ApiService } from '@/services';

export interface RecordSliceState extends CommonStoreState {
  documentResults: IPaginatedResponse<IDocument> | null;
  selectedDocument: IDocument | null;

  uploadDocument: (payload: IUploadPayload) => Promise<IDocument>;
  getDocuments: (userId: string, profileId: string, params: IDocumentListQuery) => Promise<IPaginatedResponse<IDocument>>;
  getDocumentDetail: (userId: string, documentId: string) => Promise<IDocument>;
  updateDocument: (userId: string, documentId: string, payload: IDocumentUpdatePayload) => Promise<IDocument>;
}

export const createRecordSlice: StateCreator<RecordSliceState, [], [], RecordSliceState> = (
  set,
) => ({
  documentResults: null,
  selectedDocument: null,

  uploadDocument: async (payload: IUploadPayload) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().uploadDocument(payload);

      return res.data;
    });
  },

  getDocuments: async (userId: string, profileId: string, params: IDocumentListQuery) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().getDocuments(userId, profileId, params);

      set(() => ({ documentResults: res.data }));

      return res.data;
    });
  },

  getDocumentDetail: async (userId: string, documentId: string) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().getDocumentDetail(userId, documentId);

      set(() => ({ selectedDocument: res.data }));

      return res.data;
    });
  },

  updateDocument: async (userId: string, documentId: string, payload: IDocumentUpdatePayload) => {
    return actionWrapper(set, async () => {
      const res = await ApiService.getInstance().updateDocument(userId, documentId, payload);

      set((state) => ({ selectedDocument: {
        ...state.selectedDocument,
        ...res.data,
      } }));

      return res.data;
    });
  },
});
