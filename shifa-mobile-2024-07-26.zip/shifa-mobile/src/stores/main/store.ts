import { create } from 'zustand';

import {
  SearchSliceState,
  RecordSliceState,
  FavoriteSliceState,
  ReviewsSliceState,
  ProfileSliceState,
  LanguageSliceState,
} from './slices';

import {
  createSearchSlice,
  createRecordSlice,
  createReviewSlice,
  createFavoriteSlice,
  createProfileSlice,
  createLanguageSlice,
} from './slices';

export const useMainStore = create<SearchSliceState & RecordSliceState & FavoriteSliceState & ReviewsSliceState & ProfileSliceState & LanguageSliceState>((...a) => ({
  ...createSearchSlice(...a),
  ...createRecordSlice(...a),
  ...createReviewSlice(...a),
  ...createFavoriteSlice(...a),
  ...createProfileSlice(...a),
  ...createLanguageSlice(...a),
}));
