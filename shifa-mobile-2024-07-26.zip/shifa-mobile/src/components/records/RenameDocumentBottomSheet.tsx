/* eslint-disable react/display-name */
import React, { forwardRef, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { BottomSheetWrapper, Button, TextInput } from '@/components';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { IRenameDocumentBottomSheetProps } from '@/types';
import { useAuthStore, useMainStore } from '@/stores';
import { useTranslation } from 'react-i18next';
import { isEmpty } from 'lodash';

export const RenameDocumentBottomSheet = forwardRef<BottomSheetModal, IRenameDocumentBottomSheetProps>((props, bottomSheetModalRef) => {

  const {
    updateDocument,
  } = useMainStore();

  const {
    user,
  } = useAuthStore();

  const { t } = useTranslation('', { keyPrefix: 'records' });

  const [documentName, setDocumentName] = useState<string>('');

  const onSubmit = async () => {
    if(!isEmpty(user))
      await updateDocument(user?.id, props.document_id, { file_name: documentName });
    props.onFinish();
  };

  return (
    <BottomSheetWrapper
      ref={bottomSheetModalRef}
      snapPoints={['50%']}
    >
      <ScrollView>
        <View className='px-6 py-2 flex-col justify-between h-full'>
          <View>
            <Text className="text-2xl font-bold ml-2 pb-3">{t('rename_document')}</Text>
            <TextInput
              onChangeText={setDocumentName}
              className={'pt-3 text-sm'}
              placeholder={t('write_here')}
              returnKeyType="done"
            />
          </View>
          <View>
            <Divider className='mx-3 my-3' />
            <Button
              mode="contained"
              label={t('submit')}
              className="p-1 mt-2"
              onPress={onSubmit}
            />
            <Button
              mode="contained"
              label={<Text className={'text-primary'}>{t('cancel')}</Text>}
              className="p-1 mt-2 bg-secondary"
              onPress={() => (bottomSheetModalRef as React.RefObject<BottomSheetModal>)?.current?.dismiss()}
            />
          </View>
        </View>
      </ScrollView>
    </BottomSheetWrapper>
  );
});
