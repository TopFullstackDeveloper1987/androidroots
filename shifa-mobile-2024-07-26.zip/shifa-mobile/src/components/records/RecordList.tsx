import React, { useRef, useState } from 'react';
import { FlatList, View, TouchableOpacity, Image } from 'react-native';
import { Text } from 'react-native-paper';
import * as moment from 'moment-timezone';

import { IDocument } from '@/types';
import { useColors } from '@/hooks';
import { IconButton } from '../common';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { RenameDocumentBottomSheet } from './RenameDocumentBottomSheet';

interface IProps {
  data: IDocument[];
  onItemPress: (document: IDocument) => void;
  onReload: () => void;
}

export const RecordList = (props: IProps) => {
  const colors = useColors();
  const reviewBottomSheetModalRef = useRef<BottomSheetModal>(null);

  const [documentId, setDocumentId] = useState<string>('');
  const [documentName, setDocumentName] = useState<string>('');

  const onDocumentRenamed = () => {
    reviewBottomSheetModalRef.current?.dismiss();
    props.onReload();
  };

  const renderItem = ({ item }: { item: IDocument }) => (
    <TouchableOpacity
      className="flex-row items-center my-2 bg-light rounded-xl p-2"
      onPress={() => props.onItemPress(item)}
    >
      <Image
        className="rounded-xl"
        width={50}
        height={50}
        source={{
          uri: item.thumbnail_signed_url,
        }}
      />
      <View className="flex-1 mx-4">
        <Text className="font-bold text-base">
          {item.file_name}
        </Text>
        <Text className="font-medium text-[#65688F]">
          {moment.utc(item.upload_date).format('MMM DD, YYYY')}
        </Text>
      </View>

      <IconButton icon='pencil' iconColor={colors.primary} onPress={() => {
        setDocumentId(item.id);
        setDocumentName(item.file_name);
        reviewBottomSheetModalRef.current?.present();
      }}>
      </IconButton>
    </TouchableOpacity>
  );

  return (
    <View className="flex-1 mt-2">
      <FlatList
        {...props}
        keyExtractor={item => `${item.id}`}
        renderItem={renderItem}
      />
      <RenameDocumentBottomSheet
        ref={reviewBottomSheetModalRef}
        document_id={documentId}
        document_name={documentName}
        onFinish={onDocumentRenamed}
      />
    </View>
  );
};
