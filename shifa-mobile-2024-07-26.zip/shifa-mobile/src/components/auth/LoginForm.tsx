import React from 'react';
import { I18nManager, View } from 'react-native';
import { TextInput as PaperTextInput } from 'react-native-paper';
import { useTranslation } from 'react-i18next';

import { Button, showToast, TextInput } from '@/components';
import { useAuthStore } from '@/stores';
import { PHONE_PREFIX } from '@env';

interface IProps {
  onConfirm: (phone_number: string) => void;
}

export const LoginForm = (props: IProps) => {
  const {
    generateOtp,
  } = useAuthStore();

  const { t } = useTranslation('', { keyPrefix: 'auth' });

  const [mobile, setMobile] = React.useState<string>('');
  const [loading, setLoading] = React.useState<boolean>(false);

  const onChangeMobileText = (phone_number: string) => {
    setMobile(phone_number);
  };

  const logIn = async () => {
    if (mobile.length !== 10) {
      showToast({
        type: 'error',
        title: 'Warning',
        text: t('invalid_phone_number'),
      });

      return;
    }

    setLoading(true);

    const response = await generateOtp({ phone_number: `${PHONE_PREFIX}${mobile}` });
    showToast({
      type: 'info',
      title: 'Success',
      text: response?.message || '',
    });

    setLoading(false);
    props.onConfirm(`${PHONE_PREFIX}${mobile}`);
  };

  return (
    <View className="flex-column items-center justify-center pb-2 w-full bg-white">
      <TextInput
        value={mobile}
        placeholder={t('whatsapp_number')}
        className="w-full mb-3 bg-surfaceGray"
        style={{ borderRadius: 9999 }}
        right={I18nManager.isRTL ? <PaperTextInput.Affix text={PHONE_PREFIX} /> : <PaperTextInput.Icon icon="whatsapp" />}
        left={I18nManager.isRTL ? <PaperTextInput.Icon icon="whatsapp" /> : <PaperTextInput.Affix text={PHONE_PREFIX} />}
        keyboardType="phone-pad"
        onChangeText={onChangeMobileText}
      />
      <Button
        label={t('submit')}
        mode="contained"
        className="w-full rounded-full"
        onPress={logIn}
        loading={loading}
      />
    </View>
  );
};
