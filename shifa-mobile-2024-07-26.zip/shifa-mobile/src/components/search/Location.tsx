import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import { useTranslation } from 'react-i18next';

interface IProps {
  full_address: string;
  latitude: number;
  longitude: number;
}

export const Location = (props: IProps) => {
  const { t } = useTranslation('', { keyPrefix: 'search' });

  return (
    <View className="mt-6">
      <Text className="font-bold mt-2">
        {t('location')}
      </Text>
      <Text className="my-2">
        {props.full_address}
      </Text>

      <MapView
        provider={PROVIDER_GOOGLE}
        className="w-full h-96"
        initialRegion={{
          latitude: props.latitude || 0,
          longitude: props.longitude || 0,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
      >
        <Marker
          coordinate={{
            latitude: props.latitude || 0,
            longitude: props.longitude || 0,
          }}
        />
      </MapView>
    </View>
  );
};
