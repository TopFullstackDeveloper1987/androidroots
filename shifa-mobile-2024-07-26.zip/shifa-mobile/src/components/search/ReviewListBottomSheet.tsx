/* eslint-disable react/display-name */
import React, { forwardRef, useEffect } from 'react';
import { View } from 'react-native';
import { Text, Divider, IconButton } from 'react-native-paper';
import { BottomSheetWrapper, Button, StarWidget } from '@/components';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { IReview, IReviewListBottomSheetProps } from '@/types';
import { ScrollView } from 'react-native-gesture-handler';
import { useMainStore, useAuthStore } from '@/stores';
import * as moment from 'moment-timezone';
import { useTranslation } from 'react-i18next';

const Item = (review: IReview) => (
  <View className={'flex-col my-2'}>
    <Divider />
    <View className={'flex-row justify-between my-2'}>
      <StarWidget value={review.star_rating/10} starSize={20} />
      <Text className={'text-md font-semibold w-1/3 text-right'}>{moment.utc(review.created_date).format('DD.MM.YYYY')}</Text>
    </View>
    <Text className={'font-semibold my-2'}>{review.review_body}</Text>
  </View>
);

export const ReviewListBottomSheet = forwardRef<BottomSheetModal, IReviewListBottomSheetProps>((props, bottomSheetModalRef) => {

  const {
    isLoggedIn,
  } = useAuthStore();

  const {
    reviews,
    getReviews,
  } = useMainStore();

  const { t } = useTranslation('', { keyPrefix: 'reviews' });

  useEffect(() => {
    getReviews(props.practitionerId);
  }, [getReviews]);


  return (
    <BottomSheetWrapper
      ref={bottomSheetModalRef}
      snapPoints={['90%']}
    >
      <View className='px-6 py-2 flex-col justify-between h-full'>
        <View className={'flex-row'}>
          <IconButton icon={'arrow-left'} size={30} className={'bg-secondary'} onPress={() => props.onBack()} />
          <View className={'flex-col ml-5'}>
            <Text className={'text-lg font-bold'}>{props.averageRate}</Text>
            <StarWidget value={props.averageRate} starSize={20} />
          </View>
        </View>
        <ScrollView className={'h-full mb-12 relative'} contentContainerStyle={!reviews?.length ? { flex: 1, alignItems: 'center', justifyContent: 'center' } : {}}>
          {
            reviews?.length ?
              reviews?.map((review: IReview) => {
                return <Item {...review} key={review.id} />;
              })
              :
              <Text>{t('no_review_found')}</Text>
          }
        </ScrollView>
        <View className={'absolute bottom-2 left-6 w-full'}>
          <Divider className='mx-3 my-3' />
          <Button
            mode="contained"
            label={t('write_a_review')}
            className="p-1 mt-2"
            disabled={!isLoggedIn}
            onPress={() => props.onWriteReview()}
          />
          { !isLoggedIn && <Text className={'text-xs text-slate-400 text-center'}>{t('only_loggedin_writes_review')}</Text>}

        </View>
      </View>
    </BottomSheetWrapper>
  );
});
