import React from 'react';
import { Image, View } from 'react-native';

import { SPECIALITY_ICONS } from '@/assets/SpecialityIcons';

interface IProps {
  name: string;
}

export const SpecialityIcon = (props: IProps) => {
  const { name } = props;

  const iconUri = name && SPECIALITY_ICONS[name] ? SPECIALITY_ICONS[name].uri : undefined;

  return (
    <View className="bg-secondary p-2 rounded-xl">
      {iconUri ? (

        <Image source={iconUri} style={{ width: 24, height: 24 }} />
      ) : (
        // Use a default icon image
        <Image
          source={require('@/assets/images/speciality/png/1_neurology.png')}
          style={{ width: 24, height: 24 }}
        />
      )}
    </View>
  );
};

