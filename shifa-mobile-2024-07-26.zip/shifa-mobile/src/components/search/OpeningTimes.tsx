import React, { useMemo } from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';

import { IBusinessHour } from '@/types';
import { useTranslation } from 'react-i18next';

interface IProps {
  businessHours: IBusinessHour[];
}

export const OpeningTimes = (props: IProps) => {
  const { t } = useTranslation('', { keyPrefix: 'search' });

  const days = [t('sunday'), t('monday'), t('tuesday'), t('wednesday'), t('thursday'), t('friday'), t('saturday')];


  const businessHours = useMemo(() => {
    return days.map((day, index) => {
      const businessHour = props.businessHours?.find((bh) => bh.day === index + 1);

      return {
        day_name: day || businessHour?.day_name,
        open_time: businessHour?.open_time,
        close_time: businessHour?.close_time,
      };
    });
  }, [props.businessHours]);

  return (
    <View className="mt-6">
      <Text className="font-bold">
        {t('opening_times')}
      </Text>
      <View className="bg-surfaceGray rounded-xl mt-2 px-4 pt-2 pb-4">
        {businessHours.map((businessHour) => (
          <View
            className="flex-row justify-between mt-2"
            key={businessHour.day_name}
          >
            <Text className="text-sm">
              {businessHour.day_name}
            </Text>
            <Text className="text-sm">
              {businessHour.open_time ? `${businessHour.open_time} - ${businessHour.close_time}` : 'Closed'}
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
};
