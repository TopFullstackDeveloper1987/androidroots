import React from 'react';
import { FlatList, View, TouchableOpacity } from 'react-native';
import { Text, Chip } from 'react-native-paper';
import { useTranslation } from 'react-i18next';

import { SpecialityIcon } from './SpecialityIcon';
import { ISpeciality } from '@/types';
import { useColors } from '@/hooks';

interface IProps {
  data: ISpeciality[];
  onItemPress: (speciality: ISpeciality) => void
}

export const SpecialityList = (props: IProps) => {
  const colors = useColors();
  const { t } = useTranslation('', { keyPrefix: 'search' });

  const renderItem = ({ item }: { item: ISpeciality }) => (
    <TouchableOpacity
      className="flex-row items-center my-2"
      onPress={() => props.onItemPress(item)}
    >
      <SpecialityIcon
        name={item.speciality_icon!}
      />
      <Text className="flex-1 mx-4">
        {item.speciality_name}
      </Text>
      <Chip style={{
        backgroundColor: colors.surfaceGray,
      }}>
        {item.count}
      </Chip>
    </TouchableOpacity>
  );

  return (
    <View className="mt-4 flex-1">
      <Text className="text-center mb-4 font-semibold text-base">
        {t('select_speciality')}
      </Text>
      <FlatList
        {...props}
        keyExtractor={item => `${item.speciality_id}`}
        renderItem={renderItem}
      />
    </View>
  );
};
