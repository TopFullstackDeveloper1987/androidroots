/* eslint-disable react/display-name */
import React, { forwardRef, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { BottomSheetWrapper, Button, StarWidget, TextInput } from '@/components';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { IReviewBottomSheetProps } from '@/types';
import { useMainStore } from '@/stores';
import { useTranslation } from 'react-i18next';

export const ReviewBottomSheet = forwardRef<BottomSheetModal, IReviewBottomSheetProps>((props, bottomSheetModalRef) => {

  const {
    postReview,
    getReviews,
  } = useMainStore();

  const { t } = useTranslation('', { keyPrefix: 'reviews' });

  const [review, setReview] = useState<string>('');
  const [startRate, setStarRate] = useState<number>(1);

  const onSubmit = async () => {

    const payload  = {
      review_body: review,
      star_rating: startRate * 10,
    };

    await postReview(props.practitionerId, payload);
    (bottomSheetModalRef as React.RefObject<BottomSheetModal>)?.current?.dismiss();
    getReviews(props.practitionerId);
  };

  return (
    <BottomSheetWrapper
      ref={bottomSheetModalRef}
      snapPoints={['90%']}
    >
      <ScrollView>
        <View className='px-6 py-2 flex-col justify-between h-full'>
          <View>
            <Text className="text-2xl font-bold ml-2 pb-3">{t('write_your_review')}</Text>
            <StarWidget value={startRate} onChange={setStarRate} hideValue={true} starStyle={{ padding: 8 }} />
            <Text className="text-base font-bold ml-2 py-3">{t('review')}*</Text>
            <TextInput
              onChangeText={setReview}
              className={'pt-3 text-sm'}
              outlineStyle={{ borderRadius: 8 }}
              multiline={true}
              numberOfLines={6}
              placeholder={t('write_your_review_here')}
              returnKeyType="done"
            />
          </View>
          <View>
            <Divider className='mx-3 my-3' />
            <Button
              mode="contained"
              label={t('submit_your_review')}
              className="p-1 mt-2"
              onPress={onSubmit}
            />
            <Button
              mode="contained"
              label={<Text className={'text-primary'}>{t('cancel')}</Text>}
              className="p-1 mt-2 bg-secondary"
              onPress={() => (bottomSheetModalRef as React.RefObject<BottomSheetModal>)?.current?.dismiss()}
            />
          </View>
        </View>
      </ScrollView>
    </BottomSheetWrapper>
  );
});
