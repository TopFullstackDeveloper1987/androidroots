import React from 'react';
import { View, Image, ImageSourcePropType } from 'react-native';
import { Text } from 'react-native-paper';

interface IProps {
  imageSource: ImageSourcePropType;
  title: string;
  description: string;
  titleHasAction: boolean,
  titleAction: () => void;
}

export const Intro = (props: IProps) => {
  return (
    <View className="items-center justify-center gap-2 w-full">
      <Image
        className="h-60 w-60"
        source={props.imageSource}
      />

      <Text className={`text-lg font-bold ${!props.titleHasAction || 'underline'}`} onPress={() => props.titleAction()}>
        {props.title}
      </Text>

      <Text className="text-center text-md font-light px-6">
        {props.description}
      </Text>
    </View>
  );
};
