import React from 'react';
import StarRating from 'react-native-star-rating-widget';
import { StyleProp, View, ViewStyle } from 'react-native';
import { Text } from 'react-native-paper';

interface IProps {
  value: number,
  enableHalfStar?: boolean;
  starSize?: number;
  starStyle?: StyleProp<ViewStyle>;
  disabled?: boolean;
  hideValue?: boolean;
  onChange?: (value: number) => void;
}

export const StarWidget = (props: IProps) => {
  return (
    <View
      className="flex-row items-center"
      pointerEvents={props.disabled ? 'none' : 'auto'}
    >
      <StarRating
        rating={props.value}
        onChange={props.onChange || (() => {})}
        enableHalfStar={props.enableHalfStar ||false}
        starSize={props.starSize || 25}
        starStyle={props.starStyle || {
          padding: 0,
          left: -8,
        }}
      />
      {!props.hideValue && (
        <Text className="font-medium text-[#65688F]">
          {`(${props.value})`}
        </Text>
      )}
    </View>
  );
};
