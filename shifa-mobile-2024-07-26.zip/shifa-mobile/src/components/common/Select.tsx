import React, { ReactNode, useCallback, useRef, useState } from 'react';
import { StyleProp, TouchableOpacity, View, ViewStyle } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { BottomSheetModal, BottomSheetFlatList } from '@gorhom/bottom-sheet';

import { BottomSheetWrapper } from './BottomSheetWrapper';
import { ISelect } from '@/types';
import { useColors } from '@/hooks';

interface IProps<T> {
  label?: string | ReactNode;
  placeholder?: string;
  leftIcon?: string;
  rightIcon?: string;
  titleClass?: string;
  noBorderOnFocus?: boolean,
  items: ISelect<T>[];
  value?: ISelect<T>;
  snapPoints?: string[];
  style?: StyleProp<ViewStyle>,
  onChange: (item: ISelect<T>) => void;
}

export const Select = <T extends string | number>(props: IProps<T>) => {
  const colors = useColors();
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const [open, setOpen] = useState(false);

  const onPress = () => {
    bottomSheetModalRef.current?.present();
  };

  const onItemPress = useCallback((item: ISelect<T>) => {
    bottomSheetModalRef.current?.dismiss();
    props.onChange(item);
  }, [props.onChange]);

  const onPositionChange = (position: number) => {
    setOpen(position < 0 ? false : true);
  };

  const renderItem = useCallback(({ item }: { item: ISelect<T> }) => (
    <View>
      <TouchableOpacity
        onPress={() => onItemPress(item)}
      >
        <Text className="px-6 py-2 text-base">
          {item.title}
        </Text>
        <Divider className="mx-6"/>
      </TouchableOpacity>
    </View>
  ), [onItemPress]);

  return (
    <View>
      {props.label && (
        <Text className="px-4 mb-1">
          {props.label}
        </Text>
      )}

      <TouchableOpacity
        className={`flex-row items-center bg-surfaceGray h-14 rounded-full px-4 ${(open && !props.noBorderOnFocus) && 'border-primary border-[1.5px]'}`}
        style={props.style}
        onPress={onPress}
      >
        {props.leftIcon && (
          <View className="mr-4">
            <Icon
              name={props.leftIcon}
              color={colors.onSurface}
              size={22}
            />
          </View>
        )}
        <Text className={`flex-1 mr-4 text-base ${props.titleClass}`}>
          {props.value?.title || props.placeholder}
        </Text>
        <Icon
          name={props.rightIcon || 'chevron-down'}
          color={colors.primary}
          size={24}
        />
      </TouchableOpacity>

      <BottomSheetWrapper
        ref={bottomSheetModalRef}
        snapPoints={props.snapPoints}
        onChange={onPositionChange}
      >
        <BottomSheetFlatList
          data={props.items}
          keyExtractor={item => `${item.value}`}
          renderItem={renderItem}
        />
      </BottomSheetWrapper>
    </View>
  );
};
