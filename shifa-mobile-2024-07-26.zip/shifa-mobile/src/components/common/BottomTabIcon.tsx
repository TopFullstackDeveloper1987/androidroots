import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { View } from 'react-native';
import { Badge, Text } from 'react-native-paper';

interface IProps {
  focused: boolean;
  color: string;
  size?: number;
  name: string;
  label: string;
  hasBadge?: boolean;
}

export const BottomTabIcon = (props: IProps) => {
  return (
    <View className="items-center">
      <View className={`${props.focused ? 'bg-secondary' : ''} items-center p-2 rounded-xl`}>
        <Icon
          {...props}
          size={props.size || 24}
        />
      </View>
      <Text className={`text-xs ${props.focused ? 'text-primary' : ''}`}>
        {props.label}
      </Text>
      {
        props.hasBadge && <Badge className={'absolute'}>3</Badge>
      }
    </View>
  );
};
