import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { TouchableOpacity } from 'react-native';

interface IProps {
  icon: string;
  iconColor?: string;
  iconSize?: number;
  padding?: string;
  backgroundColor?: string;
  rounded?: boolean;
  onPress: () => void;
}

export const IconButton = (props: IProps) => {
  return (
    <TouchableOpacity
      className={`${props.padding ? props.padding : 'p-3'} ${props.rounded ? 'rounded-full' : ''}`}
      onPress={props.onPress}
      style={{
        backgroundColor: props.backgroundColor,
      }}
    >
      <Icon
        name={props.icon}
        size={props.iconSize || 24}
        color={props.iconColor || 'black'}
      />
    </TouchableOpacity>
  );
};
