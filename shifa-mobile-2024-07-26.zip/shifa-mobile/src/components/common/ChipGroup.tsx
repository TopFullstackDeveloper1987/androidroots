import { useColors } from '@/hooks';
import { ISelect } from '@/types';
import React from 'react';
import { View } from 'react-native';
import { Chip } from 'react-native-paper';

interface IProps {
  items: ISelect<string | null>[];
  value: string | null;
  onItemPress: (item: ISelect<string | null>) => void;
}

export const ChipGroup = (props: IProps) => {
  const colors = useColors();

  return (
    <View className="flex-row flex-wrap">
      {
        props.items.map((item) => (
          <Chip
            className="mr-2 my-1"
            selected={(props.value || null) === item.value}
            style={{
              backgroundColor: colors.surfaceGray,
            }}
            key={item.value}
            onPress={() => props.onItemPress(item)}
          >
            {item.title}
          </Chip>
        ))
      }
    </View>
  );
};
