import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { View, Image, ImageSourcePropType, TouchableOpacity, useWindowDimensions, StyleProp, ImageStyle } from 'react-native';
import { useColors } from '@/hooks';

interface IProps {
  source?: ImageSourcePropType;
  size?: number;
  icon?: string;
  gender: string;
  iconSize?: number;
  iconAlign?: 'right' | 'center'
  imageStyle?: StyleProp<ImageStyle>;
  disabled?: boolean;
  onPress?: () => void;
}

export const Avatar = (props: IProps) => {
  const colors = useColors();
  const size = props.size || 64;
  const iconSize = props.iconSize || 16;
  const iconRight = props.iconAlign === 'center' ? size / 2 - iconSize / 2 : -iconSize / 2;
  const layout = useWindowDimensions();

  return (
    <TouchableOpacity
      disabled={props.disabled || !props.onPress}
      onPress={() => props.onPress ? props.onPress() : {}}
    >
      <View>
        {
          props.source ? (
            <Image
              className="rounded-xl"
              style={!props.size ? props.imageStyle || {
                width: layout.width - 50,
                height: 250,
              } : undefined}
              width={props.size ? props.size : undefined}
              height={props.size ? props.size : undefined}
              source={props.source}
            />
          ) : (
            <Image
              className="rounded-xl"
              width={size}
              height={size}
              source={props.gender === 'M' ? require('@/assets/images/profile-avatar-male.png') : require('@/assets/images/profile-avatar-female.png')}
            />
          )
        }
      </View>
      {
        props.icon && (
          <View
            className="bg-white p-1 rounded-lg absolute border-secondary"
            style={{
              borderWidth: 1,
              right: iconRight,
              bottom: -iconSize / 2,
            }}
          >
            <Icon
              name={props.icon}
              size={iconSize}
              color={colors.primary}
            />
          </View>
        )
      }
    </TouchableOpacity>
  );
};
