import React from 'react';

import { IconButton } from './IconButton';
import { useColors } from '@/hooks';

interface IProps {
  value: boolean;
  padding?: string;
  onPress: () => void;
}

export const FavoriteToggleButton = (props: IProps) => {
  const colors = useColors();
  const { value, padding } = props;

  const onPress = () => {
    props.onPress();
  };

  return (
    <IconButton
      icon={value ? 'heart' : 'heart-outline'}
      iconColor={value ? colors.primary : 'black'}
      padding={padding}
      onPress={onPress}
    />
  );
};
