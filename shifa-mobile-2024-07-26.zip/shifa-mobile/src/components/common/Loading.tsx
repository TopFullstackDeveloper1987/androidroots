import React from 'react';
import { View } from 'react-native';
import { ActivityIndicator } from 'react-native-paper';

export const Loading = () => {
  return (
    <View className="flex-1 justify-center items-center bg-[#00000040]">
      <ActivityIndicator />
    </View>
  );
};
