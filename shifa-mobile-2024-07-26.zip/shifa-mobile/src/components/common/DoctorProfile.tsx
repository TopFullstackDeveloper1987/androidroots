import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';

import { Avatar } from './Avatar';
import { StarWidget } from './StarWidget';
import { IPractitioner } from '@/types';
import { Button } from '@/components';
import { useTranslation } from 'react-i18next';

interface IProps {
  practitioner: IPractitioner;
  icon: string;
  phoneNumber: string;
  onStarPress: () => void;
}

export const DoctorProfile = (props: IProps) => {

  const { t } = useTranslation('', { keyPrefix: 'profile' });

  return (
    <View className="items-center">
      <Avatar
        source={props.practitioner.photo ? {
          uri: props.practitioner.photo,
        }: props.practitioner.gender === 'M' ? require('@/assets/images/doctor-avatar-male-medium.png') : require('@/assets/images/doctor-avatar-female-medium.png')}
        gender={props.practitioner.gender}
        size={props.practitioner.photo ? undefined : 64}
        icon={'diabetes'}
      />

      <Text className="text-lg font-bold mt-1">
        {props.practitioner.name}
      </Text>

      <Text className="my-2">
        {props.practitioner.tagline}
      </Text>
      <View onTouchEnd={() => props.onStarPress()}>
        <StarWidget
          value={Number(props.practitioner.average_rating)/10}
        />
      </View>
      <Button className={'mt-2 bg-secondary w-full h-10'} label={<Text className={'font-bold text-primary'}>{ props.phoneNumber }</Text>} onPress={()=>{}}></Button>
      <Button className={'mt-2 bg-primary w-full h-10'} label={<Text className={'text-white'}>{t('book_an_appointment')}</Text>} onPress={()=>{}}></Button>
    </View>
  );
};
