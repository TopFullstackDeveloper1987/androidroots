/* eslint-disable react/display-name */
import React, { forwardRef } from 'react';
import { BottomSheetModalProps, BottomSheetModal, BottomSheetBackdrop } from '@gorhom/bottom-sheet';

export const BottomSheetWrapper = forwardRef<BottomSheetModal, BottomSheetModalProps>((props, ref) => {
  return (
    <BottomSheetModal
      {...props}
      snapPoints={props.snapPoints || ['30%']}
      ref={ref}
      backdropComponent={_props => {
        return (
          <BottomSheetBackdrop
            {..._props}
            pressBehavior="close"
            disappearsOnIndex={-1}
            appearsOnIndex={0}
          />
        );
      }}
    >
      {props.children}
    </BottomSheetModal>
  );
});
