import React from 'react';
import { View, ViewStyle } from 'react-native';
import { TextInput as PaperTextInput, TextInputProps, Text } from 'react-native-paper';

import { useColors } from '@/hooks';

export interface IProps extends TextInputProps {
  errorMessage?: string;
  outlineStyle?: ViewStyle | null;
}

export const TextInput = (props: IProps) => {
  const colors = useColors();
  const { style, label, errorMessage, multiline, numberOfLines, ...other } = props;

  return (
    <View
      className="w-full rounded-full"
      style={style}
    >
      {label && (
        <Text className="px-4 mb-1">
          {label}
        </Text>
      )}

      <PaperTextInput
        {...other}
        className={`bg-surfaceGray focus:border-primary focus:border-[1.5px] ${props.outlineStyle?.borderRadius ? `rounded-[${props.outlineStyle?.borderRadius}px]` : 'rounded-full'}`}
        mode={props.mode || 'outlined'}
        activeOutlineColor={props.activeOutlineColor || 'transparent'}
        outlineColor={props.outlineColor || 'transparent'}
        outlineStyle={props.outlineStyle || {
          borderRadius: 9999,
        }}
        cursorColor={colors.primary}
        selectionColor={colors.primary}
        placeholderTextColor={colors.placeholder}
        multiline={multiline}
        numberOfLines={numberOfLines}
      />

      {errorMessage && (
        <Text className="px-4 text-error text-sm">
          {errorMessage}
        </Text>
      )}
    </View>
  );
};
