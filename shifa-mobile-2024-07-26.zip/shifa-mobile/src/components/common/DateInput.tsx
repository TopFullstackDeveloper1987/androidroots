import React, { useState } from 'react';
import { View, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import DatePicker from 'react-native-date-picker';
import * as moment from 'moment-timezone';

interface IProps {
  label?: string;
  value?: Date;
  mode?: 'datetime' | 'date' | 'time';
  title?: string | null;
  confirmText?: string;
  cancelText?: string;
  maximumDate?: Date,
  onChange: (date: Date) => void;
}

export const DateInput = (props: IProps) => {
  const [open, setOpen] = useState(false);

  const onConfirm = (date: Date) => {
    setOpen(false);

    props.onChange && props.onChange(date);
  };

  return (
    <View>
      {props.label && (
        <Text className="px-4 mb-1">
          {props.label}
        </Text>
      )}

      <TouchableOpacity
        className={`flex-row items-center bg-surfaceGray h-14 rounded-full px-4 ${open && 'border-primary border-[1.5px]'}`}
        onPress={() => setOpen(true)}
      >
        <Text className="flex-1 text-base">
          {props.value ? moment.utc(props.value).format('YYYY-MM-DD') : ''}
        </Text>
      </TouchableOpacity>

      <DatePicker
        modal
        mode={props.mode || 'date'}
        open={open}
        date={props.value || moment.utc().toDate()}
        title={props.title}
        maximumDate={props.maximumDate}
        confirmText={props.confirmText}
        cancelText={props.cancelText}
        onConfirm={onConfirm}
        onCancel={() => setOpen(false)}
      />
    </View>
  );
};
