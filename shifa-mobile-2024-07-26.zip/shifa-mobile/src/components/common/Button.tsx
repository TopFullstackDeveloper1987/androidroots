import React, { ReactNode } from 'react';
import { StyleProp, ViewStyle } from 'react-native';
import { Button as PaperButton } from 'react-native-paper';

interface IProps {
  label?: string | ReactNode,
  className?: string,
  icon?: string,
  mode?: 'text' | 'outlined' | 'contained' | 'elevated' | 'contained-tonal' | undefined,
  loading?: boolean,
  disabled?: boolean,
  contentStyle?: StyleProp<ViewStyle>,
  onPress?: () => void;
}

export const Button = (props: IProps) => {
  return (
    <PaperButton
      {...props}
    >
      {props.label}
    </PaperButton>
  );
};
