/* eslint-disable react/display-name */
import React, { forwardRef } from 'react';
import { TouchableOpacity, View } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import { BottomSheetWrapper, showToast } from '@/components';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { useColors } from '@/hooks';
import { useDevicePermission } from '@/providers';
import { IFile, MediaPickerType } from '@/types';
import { useTranslation } from 'react-i18next';

interface IProps {
  title: string;
  onMedia: (mediaPickerType: MediaPickerType, file: IFile) => Promise<void>;
}

export const MediaBottomSheet = forwardRef<BottomSheetModal, IProps>((props, bottomSheetModalRef) => {
  const colors = useColors();
  const {
    openCameraPicker,
    openGalleryPicker,
    openFilePicker,
  } = useDevicePermission();

  const { t } = useTranslation('', { keyPrefix: 'records' });

  const onCamera = async () => {
    try {
      const file = await openCameraPicker();
      if (file) {
        await props.onMedia(MediaPickerType.Camera, file);
      }

      (bottomSheetModalRef as React.RefObject<BottomSheetModal>)?.current?.dismiss();
    } catch (err: unknown) {
      showToast({
        type: 'error',
        title: 'Camera Error',
        text: (err as Error).message,
      });
    }
  };

  const onGallery = async () => {
    try {
      const file = await openGalleryPicker();
      if (file) {
        await props.onMedia(MediaPickerType.Gallery, file);
      }

      (bottomSheetModalRef as React.RefObject<BottomSheetModal>)?.current?.dismiss();
    } catch (err: unknown) {
      showToast({
        type: 'error',
        title: 'Gallery Error',
        text: (err as Error).message,
      });
    }
  };

  const onFile = async () => {
    try {
      const file = await openFilePicker();
      if (file) {
        await props.onMedia(MediaPickerType.File, file);
      }

      (bottomSheetModalRef as React.RefObject<BottomSheetModal>)?.current?.dismiss();
    } catch (err: unknown) {
      showToast({
        type: 'error',
        title: 'File Error',
        text: (err as Error).message,
      });
    }
  };

  return (
    <BottomSheetWrapper
      ref={bottomSheetModalRef}
      snapPoints={['30%']}
    >
      <View className='px-6'>
        <Text className="text-base font-bold">
          {props.title}
        </Text>

        <TouchableOpacity
          className="flex-row items-center py-4"
          onPress={onCamera}
        >
          <Icon
            name="camera-outline"
            color={colors.primary}
            size={24}
          />
          <Text className="text-base ml-2">
            { t('camera') }
          </Text>
        </TouchableOpacity>
        <Divider />

        <TouchableOpacity
          className="flex-row items-center py-4"
          onPress={onGallery}
        >
          <Icon
            name="image-outline"
            color={colors.primary}
            size={24}
          />
          <Text className="text-base ml-2">
            { t('gallery') }
          </Text>
        </TouchableOpacity>
        <Divider />

        <TouchableOpacity
          className="flex-row items-center py-4"
          onPress={onFile}
        >
          <Icon
            name="file-outline"
            color={colors.primary}
            size={24}
          />
          <Text className="text-base ml-2">
            { t('file') }
          </Text>
        </TouchableOpacity>
      </View>
    </BottomSheetWrapper>
  );
});
