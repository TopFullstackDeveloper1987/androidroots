import React from 'react';
import { TextInput as PaperTextInput } from 'react-native-paper';

import { TextInput, IProps } from './TextInput';

export const Searchbar = (props: IProps) => {
  return (
    <TextInput
      left={<PaperTextInput.Icon icon="magnify" />}
      {...props}
    />
  );
};
