import React from 'react';
import ToastMessage, { ToastProps, ToastShowParams } from 'react-native-toast-message';

interface ToastParams extends ToastShowParams {
  title: string;
  text: string;
}

export const Toast = (props: ToastProps) => {
  return (
    <ToastMessage
      {...props}
    />
  );
};

export const showToast = (params: ToastParams) => {
  const {
    title,
    text,
    text1,
    text2,
    ...rest
  } = params;

  ToastMessage.show({
    text1: title || text1,
    text2: text || text2,
    ...rest,
  });
};
