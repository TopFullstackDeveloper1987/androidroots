/* eslint-disable react/display-name */
import React, { forwardRef } from 'react';
import { View } from 'react-native';
import { Text, RadioButton, Divider } from 'react-native-paper';
import { BottomSheetWrapper, Button } from '@/components';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { ISortByBottomSheetProps } from '@/types';
import { useTranslation } from 'react-i18next';

export const SortByBottomSheet = forwardRef<BottomSheetModal, ISortByBottomSheetProps>((props, bottomSheetModalRef) => {
  const { t } = useTranslation('', { keyPrefix: 'search' });

  return (
    <BottomSheetWrapper
      ref={bottomSheetModalRef}
      snapPoints={['35%']}
    >
      <View className='px-6'>
        <Text className="text-base font-bold ml-2 pb-3">{t('sort_by')}</Text>
        <RadioButton.Group
          value={props.value}
          onValueChange={(value) => props.onChange(value)}
        >
          { props.sortByOptions.map((option, index) => {
            return <View key={index} className="flex-row items-center">
              <RadioButton value={option.value} />
              <Text className="font-bold">{ option.title }</Text>
            </View>;
          }) }
        </RadioButton.Group>
        <Divider className='mx-3 my-4' />
        <Button
          mode="contained"
          label={t('confirm')}
          className="p-1 mt-2"
          onPress={() => (bottomSheetModalRef as React.RefObject<BottomSheetModal>)?.current?.dismiss()}
        />
      </View>
    </BottomSheetWrapper>
  );
});
