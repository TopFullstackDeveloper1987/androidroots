import React, { useState, useEffect } from 'react';
import { Text } from 'react-native-paper';

interface IProps {
  time: number;
  onEnd: () => void;
  step: number;
}

export const Timer = (props: IProps) => {
  const [timer, setTimer] = useState<number>(props.time);

  useEffect(() => {
    if (props.time === 0) {
      props.onEnd();
      return;
    }
    setTimeout(() => {

      if (timer > 0) {
        setTimer(timer - 1);
      } else {
        props.onEnd();
      }
    }, props.step);
  }, [timer]);

  return <Text>{timer > 9 ? timer : `0${timer}`}</Text>;
};
