import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { RootStackParamList, Stack } from '@/types';
import { MainStackNavigator } from './main';
import { AuthStackNavigator } from './auth';

const RootStack = createNativeStackNavigator<RootStackParamList>();

export const RootStackNavigator = () => {
  return (
    <RootStack.Navigator
      initialRouteName={Stack.MainStack}
      screenOptions={{
        headerShown: false,
      }}
    >
      <RootStack.Screen
        name={Stack.MainStack}
        component={MainStackNavigator}
      />
      <RootStack.Screen
        name={Stack.AuthStack}
        component={AuthStackNavigator}
      />
    </RootStack.Navigator>
  );
};
