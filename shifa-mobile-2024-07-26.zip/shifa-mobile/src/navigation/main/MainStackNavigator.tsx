import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { MainStackParamList, BottomTab, HomeStackParamList, Screen } from '@/types';
import {
  FavoriteStackNavigator,
  HomeStackNavigator,
  SearchStackNavigator,
  RecordStackNavigator,
  ProfileStackNavigator,
} from './bottom-tabs';
import { BottomTabIcon, showToast } from '@/components';
import { useAuthStore } from '@/stores';
import { useTranslation } from 'react-i18next';
import { NavigationProp, useNavigation } from '@react-navigation/native';

const Tab = createBottomTabNavigator<MainStackParamList>();

export const MainStackNavigator = () => {
  const {
    isLoggedIn,
  } = useAuthStore();

  const { t } = useTranslation('', { keyPrefix: 'bottom' });

  const navigation = useNavigation<NavigationProp<HomeStackParamList>>();

  return (
    <Tab.Navigator
      initialRouteName={BottomTab.HomeStack}
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarInactiveTintColor: 'black',
        tabBarStyle: {
          backgroundColor: 'transparent',
          height: 104,
        },
      }}
    >
      <Tab.Screen
        name={BottomTab.HomeStack}
        component={HomeStackNavigator}
        options={{
          tabBarIcon: (props) => <BottomTabIcon {...props} name="home-outline" label={t('home')} />,
        }}
      />

      <Tab.Screen
        name={BottomTab.SearchStack}
        component={SearchStackNavigator}
        options={{
          tabBarIcon: (props) => <BottomTabIcon {...props} name="account-search-outline" label={t('doctors')} />,
        }}
      />

      <Tab.Screen
        name={BottomTab.FavoriteStack}
        component={FavoriteStackNavigator}
        options={{
          tabBarIcon: (props) => <BottomTabIcon {...props} name="heart-outline" label={t('favorites')} />,
        }}
      />

      <Tab.Screen
        name={BottomTab.RecordStack}
        component={RecordStackNavigator}
        options={{
          tabBarIcon: (props) => <BottomTabIcon {...props} name="folder-plus-outline" label={t('records')} />,
        }}
      />

      <Tab.Screen
        name={BottomTab.ProfileStack}
        component={ProfileStackNavigator}
        options={{
          tabBarIcon: (props) => <BottomTabIcon {...props} name="account-circle-outline" label={t('profile')} hasBadge={false} />,
        }}
        listeners={{
          tabPress: (event) => {
            if (!isLoggedIn) {
              showToast({
                type: 'error',
                title: 'Warning',
                text: t('login_to_setup_profile'),
              });
              navigation.navigate(Screen.Home);
              event.preventDefault();
            }
          },
        }}
      />
    </Tab.Navigator>
  );
};
