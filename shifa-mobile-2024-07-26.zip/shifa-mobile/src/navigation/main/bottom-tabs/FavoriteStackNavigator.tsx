import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { FavoriteStackRoutesType, FavoriteStackParamList, Screen } from '@/types';
import { FavoritesScreen, PractitionerDetailsScreen } from '@/screens';
import { navigationOptions } from '@/utils';
import { useTranslation } from 'react-i18next';


const Stack = createNativeStackNavigator<FavoriteStackParamList>();

export const FavoriteStackNavigator = () => {

  const { t } = useTranslation('', { keyPrefix: 'screen' });

  const routes: FavoriteStackRoutesType = [
    {
      name: Screen.Favorites,
      component: FavoritesScreen,
      options: {
        title: t('favorites'),
      },
    },
    {
      name: Screen.PractitionerDetails,
      component: PractitionerDetailsScreen,
      options: {
        title: t('practitioner_details'),
      },
    },
  ];

  return (
    <Stack.Navigator
      initialRouteName={Screen.Favorites}
      screenOptions={navigationOptions}
    >
      {routes.map((route) => (
        <Stack.Screen
          key={route.name}
          {...route}
        />
      ))}
    </Stack.Navigator>
  );
};
