import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { ProfileStackRoutesType, ProfileStackParamList, Screen } from '@/types';
import { PersonalInformation, ProfileScreen, FamilyProfilesScreen, Notifications, Settings } from '@/screens';
import { navigationOptions } from '@/utils';
import { useTranslation } from 'react-i18next';

const Stack = createNativeStackNavigator<ProfileStackParamList>();

export const ProfileStackNavigator = () => {
  const { t } = useTranslation('', { keyPrefix: 'screen' });

  const routes: ProfileStackRoutesType = [
    {
      name: Screen.Profile,
      component: ProfileScreen,
      options: {
        title: t('profile'),
      },
    },
    {
      name: Screen.PersonalInformation,
      component: PersonalInformation,
      options: {
        title: t('personal_information'),
      },
    },
    {
      name: Screen.FamilyProfiles,
      component: FamilyProfilesScreen,
      options: {
        title: t('family_profiles'),
      },
    },
    {
      name: Screen.Notifications,
      component: Notifications,
      options: {
        title: t('notifications'),
      },
    },
    {
      name: Screen.Settings,
      component: Settings,
      options: {
        title: t('settings'),
      },
    },
  ];

  return (
    <Stack.Navigator
      initialRouteName={Screen.Profile}
      screenOptions={navigationOptions}
    >
      {routes.map((route) => (
        <Stack.Screen
          key={route.name}
          {...route}
        />
      ))}
    </Stack.Navigator>
  );
};
