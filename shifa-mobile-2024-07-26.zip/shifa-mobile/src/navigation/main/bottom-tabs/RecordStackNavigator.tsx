import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { RecordStackRoutesType, RecordStackParamList, Screen } from '@/types';
import { RecordDetailsScreen, RecordsScreen } from '@/screens';
import { navigationOptions } from '@/utils';
import { useTranslation } from 'react-i18next';


const Stack = createNativeStackNavigator<RecordStackParamList>();

export const RecordStackNavigator = () => {

  const { t } = useTranslation('', { keyPrefix: 'screen' });

  const routes: RecordStackRoutesType = [
    {
      name: Screen.Records,
      component: RecordsScreen,
      options: {
        title: t('medical_records'),
      },
    },
    {
      name: Screen.RecordDetails,
      component: RecordDetailsScreen,
      options: {
        title: t('record_details'),
      },
    },
  ];

  return (
    <Stack.Navigator
      initialRouteName={Screen.Records}
      screenOptions={navigationOptions}
    >
      {routes.map((route) => (
        <Stack.Screen
          key={route.name}
          {...route}
        />
      ))}
    </Stack.Navigator>
  );
};
