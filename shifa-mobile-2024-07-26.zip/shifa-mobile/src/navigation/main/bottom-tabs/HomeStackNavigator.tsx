import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { HomeStackRoutesType, HomeStackParamList, Screen } from '@/types';
import { HomeScreen } from '@/screens';
import { navigationOptions } from '@/utils';
import { useTranslation } from 'react-i18next';


const Stack = createNativeStackNavigator<HomeStackParamList>();

export const HomeStackNavigator = () => {

  const { t } = useTranslation('', { keyPrefix: 'screen' });

  const routes: HomeStackRoutesType = [
    {
      name: Screen.Home,
      component: HomeScreen,
      options: {
        title: t('home'),
      },
    },
  ];

  return (
    <Stack.Navigator
      initialRouteName={Screen.Home}
      screenOptions={navigationOptions}
    >
      {routes.map((route) => (
        <Stack.Screen
          key={route.name}
          {...route}
          options={route.options}
        />
      ))}
    </Stack.Navigator>
  );
};
