import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { SearchStackRoutesType, SearchStackParamList, Screen } from '@/types';
import { SearchResultsScreen, SearchScreen, SearchDetailsScreen } from '@/screens';
import { navigationOptions } from '@/utils';
import { useTranslation } from 'react-i18next';

const Stack = createNativeStackNavigator<SearchStackParamList>();

export const SearchStackNavigator = () => {

  const { t } = useTranslation('', { keyPrefix: 'screen' });

  const routes: SearchStackRoutesType = [
    {
      name: Screen.Search,
      component: SearchScreen,
      options: {
        title: t('search'),
      },
    },
    {
      name: Screen.SearchResults,
      component: SearchResultsScreen,
      options: {
        title: t('search_results'),
      },
    },
    {
      name: Screen.SearchDetails,
      component: SearchDetailsScreen,
      options: {
        title: t('search_details'),
      },
    },
  ];
  return (
    <Stack.Navigator
      initialRouteName={Screen.Search}
      screenOptions={navigationOptions}
    >
      {routes.map((route) => (
        <Stack.Screen
          key={route.name}
          {...route}
        />
      ))}
    </Stack.Navigator>
  );
};
