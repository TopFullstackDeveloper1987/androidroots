import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { AuthStackRoutesType, AuthStackParamList, Screen } from '@/types';
import { OtpScreen } from '@/screens';
import { navigationOptions } from '@/utils';

const routes: AuthStackRoutesType = [
  {
    name: Screen.Otp,
    component: OtpScreen,
  },
];

const Stack = createNativeStackNavigator<AuthStackParamList>();

export const AuthStackNavigator = () => {
  return (
    <Stack.Navigator
      initialRouteName={Screen.Otp}
      screenOptions={navigationOptions}
    >
      {routes.map((route) => (
        <Stack.Screen
          key={route.name}
          {...route}
        />
      ))}
    </Stack.Navigator>
  );
};
