import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import translationEN from './locales/en.json';
import translationAR from './locales/ar.json';
import translationCKB from './locales/ckb.json';
import translationKU from './locales/ku.json';
import translationES from './locales/es.json';
import { languageDetector } from '@/utils';

const resources = {
  en: {
    translation: translationEN,
  },
  ar: {
    translation: translationAR,
  },
  ckb: {
    translation: translationCKB,
  },
  ku: {
    translation: translationKU,
  },
  es: {
    translation: translationES,
  },
};

i18n
  .use(languageDetector)
  .use(initReactI18next)
  .init({
    compatibilityJSON: 'v3',
    resources,
    interpolation: {
      escapeValue: false,
    },
    react: {
      transSupportBasicHtmlNodes: true,
      transKeepBasicHtmlNodesFor: ['br'],
      useSuspense: false,
    },
    fallbackLng: 'en',
  });

export default i18n;
