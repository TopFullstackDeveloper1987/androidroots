/* eslint-disable */
const fs = require('fs');
const path = require('path');
const { Parser } = require('i18next-scanner');

const i18n_resource_dir = 'src/i18n/locales/';
const i18n_target_resource_dir = 'src/i18n/locales/';
if (!fs.existsSync(i18n_target_resource_dir)) {
  fs.mkdirSync(i18n_target_resource_dir);
}
const scan_list = require('./scan-list.json');

const resource_file_list = fs.readdirSync(i18n_resource_dir).filter((file) => path.extname(file).toLowerCase() === '.json');

Object.byString = function (obj, str) {
  str = str.replace(/\[(\w+)\]/g, '.$1');
  str = str.replace(/^\./, '');
  const nested_path = str.split('.');
  for (let i = 0, n = nested_path.length; i < n; i++) {
    const k = nested_path[i];
    if (k in obj) {
      obj = obj[k];
    } else {
      return null;
    }
  }
  return obj;
};

const needToBeAdded = (obj, key) => {
  if (key.includes('plural')) return false; // should ignore plural suffix keys cuz it unexpectedly appears for interpolation translation
  if (!Object.keys(obj).includes(key)) return true; // this is when resource file drops key out
  return false;
};

const scanI18n = () => {
  for (resource_file_idx in resource_file_list) {
    const resource_file = resource_file_list[resource_file_idx];
    const resource = JSON.parse(fs.readFileSync(i18n_resource_dir + resource_file, 'utf-8'));

    for (idx in scan_list) {
      const file = scan_list[idx];
      const content = fs.readFileSync(file.src, 'utf-8');
      const parser = new Parser();
      parser.parseFuncFromString(content, { list: ['t'] }); // override `func.list`

      const parseResult = parser.get();

      const obj = Object.byString(resource, file.path);
      if (!obj) {
        const error_msg = `[resoure]: resource file(${resource_file}) has not object named ${file.path}`;
        console.log(error_msg);
        console_error += (`${error_msg}\n`);
        continue;
      }

      const keys = Object.keys(parseResult?.en?.translation);
      keys.forEach((key) => {
        if (needToBeAdded(obj, key)) obj[key] = '';
      });
    }
    if (fs.existsSync(i18n_target_resource_dir + resource_file)) {
      fs.appendFile(i18n_target_resource_dir + resource_file, '', (err) => {
        if (err) throw err;
      });
    }
    fs.writeFile(i18n_target_resource_dir + resource_file, JSON.stringify(resource, null, '\t') + '\n', (err, data) => {
      if (err) {
        console.log(error);
      } else {
      }
    });
  }
};

const checkResourcePath = () => {
  for (idx in scan_list) {
    const file = scan_list[idx];
    const content = fs.readFileSync(file.src, 'utf-8');
    if (!content.includes(file.path)) {
      const error_msg = `[scan_list]: ${file.src} doesn't use ${file.path}`;
      console_error += (`${error_msg}\n`);
      console.log(error_msg);
    }
  }
};

const log_errors = () => {
  const log_file = 'src/i18n/scanner/log.txt';
  if (fs.existsSync(log_file)) {
    fs.appendFile(log_file, '', (err) => {
      if (err) throw err;
    });
  }
  const date_ob = new Date();
  fs.writeFile(log_file, `${date_ob}\n${console_error}`, (err, data) => {
    if (err) {
      console.log(error);
    } else {
    }
  });
};

let console_error = '';
checkResourcePath();
scanI18n();
log_errors();
