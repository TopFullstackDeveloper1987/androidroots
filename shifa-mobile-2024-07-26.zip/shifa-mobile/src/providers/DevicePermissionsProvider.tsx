import React, { createContext, useContext } from 'react';
import { Platform, Alert } from 'react-native';
import {
  openSettings,
  request,
  PERMISSIONS,
  Permission,
  PermissionStatus,
} from 'react-native-permissions';
import ImagePicker, { Image } from 'react-native-image-crop-picker';
import DocumentPicker, { types, DocumentPickerResponse } from 'react-native-document-picker';

import { IFile, MediaPickerType } from '@/types';

interface IProps {
  children: React.ReactNode;
}

interface DevicePermissionContextType {
  openDeviceSettings: () => void;
  requestCameraPermission: () => Promise<PermissionStatus>;
  requestMediaPermission: () => PermissionStatus | Promise<PermissionStatus>;

  openCameraPicker: () => Promise<IFile | null>;
  openGalleryPicker: () => Promise<IFile | null>;
  openFilePicker: () => Promise<IFile | null>;
}

const DevicePermissionContext = createContext<
  DevicePermissionContextType | undefined
>(undefined);

export const useDevicePermission = () => {
  const userContext = useContext(DevicePermissionContext);
  if (userContext === undefined) {
    throw new Error(
      'useDevicePermission must be used within a DevicePermissionsProvider',
    );
  }
  return userContext;
};

export const DevicePermissionsProvider = ({ children }: IProps) => {
  const openDeviceSettings = () => {
    openSettings().catch(() => console.warn('Cannot open settings'));
  };

  const requestDevicePermission = (permission: Permission): Promise<PermissionStatus> => {
    return new Promise((resolve, reject) => {
      request(permission).then((cameraResult) => {
        if (['granted', 'limited'].includes(cameraResult)) {
          resolve(cameraResult);
        } else {
          reject(new Error(cameraResult));
        }
      });
    });
  };

  const requestCameraPermission = () => {
    const permission = Platform.OS === 'ios' ? PERMISSIONS.IOS.CAMERA : PERMISSIONS.ANDROID.CAMERA;
    return requestDevicePermission(permission);
  };

  const requestMediaPermission = () => {
    if (Platform.OS === 'android') {
      return 'granted';
    }

    // const permission = Platform.OS === 'ios' ? PERMISSIONS.IOS.PHOTO_LIBRARY : PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE;
    return requestDevicePermission(PERMISSIONS.IOS.PHOTO_LIBRARY);
  };

  const handleDevicePermissionError = (pickerType: MediaPickerType, permissionStatus: PermissionStatus) => {
    if (permissionStatus?.includes('cancelled')) {
      return;
    }

    const message = `Access to ${pickerType} is ${permissionStatus}, would you like to go to settings?`;
    Alert.alert('Error', message, [
      { text: 'Cancel' },
      { text: 'Settings', onPress: openDeviceSettings },
    ]);
  };

  const buildFileObjectFromImage = (image: Image) => {
    if (!image) {
      return null;
    }

    const { path, mime } = image;

    const name = path.substring(path.lastIndexOf('/') + 1);
    const uri = Platform.OS === 'ios' ? path.replace('file://', '') : path;

    const file: IFile = {
      name,
      type: mime,
      uri,
    };

    return file;
  };

  const buildFileObjectFromDocument = (document: DocumentPickerResponse) => {
    if (!document) {
      return null;
    }

    const { name, type } = document;
    const uri = Platform.OS === 'ios' ? document.uri.replace('file://', '') : document.uri;

    const file: IFile = {
      name: name!,
      type: type!,
      uri,
    };

    return file;
  };

  const openCameraPicker = async () => {
    try {
      await requestCameraPermission();
      const image = await ImagePicker.openCamera({
        compressImageQuality: .8,
        mediaType: 'photo',
        cropping: true,
        forceJpg: true,
      });

      return buildFileObjectFromImage(image);
    } catch (err: unknown) {
      console.log('openCameraPicker err', err);

      handleDevicePermissionError(MediaPickerType.Camera, (err as Error).message as PermissionStatus);

      return null;
    }
  };

  const openGalleryPicker = async () => {
    try {
      await requestMediaPermission();
      const image = await ImagePicker.openPicker({
        compressImageQuality: .8,
        mediaType: 'photo',
        cropping: true,
        forceJpg: true,
      });

      return buildFileObjectFromImage(image);
    } catch (err: unknown) {
      console.log('openGalleryPicker err', err);

      handleDevicePermissionError(MediaPickerType.Gallery, (err as Error).message as PermissionStatus);

      return null;
    }
  };

  const openFilePicker = async () => {
    try {
      const document = await DocumentPicker.pickSingle({
        type: [types.pdf, types.images],
      });

      return buildFileObjectFromDocument(document);
    } catch (err: unknown) {
      console.log('openFilePicker err', err);

      return null;
    }
  };

  return (
    <DevicePermissionContext.Provider
      value={{
        openDeviceSettings,
        requestCameraPermission,
        requestMediaPermission,
        openCameraPicker,
        openGalleryPicker,
        openFilePicker,
      }}
    >
      {children}
    </DevicePermissionContext.Provider>
  );
};
