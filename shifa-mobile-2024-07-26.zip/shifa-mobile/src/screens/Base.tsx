import React from 'react';
import { Keyboard, KeyboardAvoidingView, Platform, SafeAreaView, TouchableWithoutFeedback, View } from 'react-native';
import { Portal, Text } from 'react-native-paper';
import { useTranslation } from 'react-i18next';
import { useHeaderHeight } from '@react-navigation/elements';

import { Loading, Button } from '../components';
import { useMainStore } from '@/stores';

export const BaseScreen = ({
  isLoading = false,
  children,
}: {
  isLoading?: boolean;
  children?: React.ReactNode;
}) => {
  const height = useHeaderHeight();
  const { t } = useTranslation('', { keyPrefix: 'base' });

  const {
    activeProfile,
    defaultProfile,

    switchToDefaultProfile,
  } = useMainStore();

  return (
    <SafeAreaView className="flex-1">
      <KeyboardAvoidingView
        className='flex-1'
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={height}
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View className="flex-1">
            {
              activeProfile && defaultProfile && activeProfile.id !== defaultProfile.id && (
                <View className="bg-orange-200 p-2 items-center">
                  <Text>
                    {t('acting_for', { name: activeProfile.name })}
                  </Text>
                  <Button
                    label={<Text className={'underline text-primary'}>{t('switch_back_to_your_profile')}</Text>}
                    onPress={() => switchToDefaultProfile()}
                  />
                </View>
              )
            }
            {children}
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>

      <Portal>
        {isLoading && <Loading />}
      </Portal>
    </SafeAreaView>
  );
};
