import React, { useCallback, useEffect, useMemo } from 'react';
import { View, useWindowDimensions, Linking, ImageSourcePropType, I18nManager } from 'react-native';
import { TabView, SceneMap, TabBarProps, TabBar, Route } from 'react-native-tab-view';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { Text } from 'react-native-paper';
import { NavigationProp, useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';

import { Button, Intro } from '@/components/common';
import { LoginForm } from '@/components/auth';
import { useColors } from '@/hooks';
import { Screen, RootStackParamList, Stack, BottomTab } from '@/types';
import { useAuthStore, useMainStore } from '@/stores';
import { BaseScreen } from '@/screens/Base';
import { AsyncStorageService } from '@/services';

type ScreenProps = NativeStackScreenProps<RootStackParamList, Stack.MainStack>;

type SlideItem = {
  key: string,
  title: string,
  description: string,
  imageSource: ImageSourcePropType,
  linkText: string;
  onLink: () => void;
}

export const HomeScreen = (props: ScreenProps | unknown) => {
  const { navigation } = props as ScreenProps;
  const { navigate } = useNavigation<NavigationProp<RootStackParamList>>();
  const layout = useWindowDimensions();
  const colors = useColors();
  const { t } = useTranslation('', { keyPrefix: 'home' });

  const {
    isLoggedIn,
    isLoading,
  } = useAuthStore();

  const { setUserLanguage } = useMainStore();

  useEffect(() => {
    getUserLanguage();
  }, []);

  const getUserLanguage = async () => {
    const lang = await AsyncStorageService.getInstance().getUserLanguage();
    setUserLanguage(lang || 'en');
  };

  const [slideIndex, setSlideIndex] = React.useState(0);
  const [routes] = React.useState([
    { key: '0' },
    { key: '1' },
    { key: '2' },
  ]);

  const slides = useMemo<SlideItem[]>(() => {
    return [
      {
        key: '0',
        title: t('find_doctors'),
        description: t('discover_health_professionals'),
        imageSource: require('@/assets/images/searching.png'),
        linkText: t('find_doctors'),
        onLink: () => navigate(Stack.MainStack, { screen: BottomTab.SearchStack, params: null! }),
      },
      {
        key: '1',
        title: t('manage_your_medical_records'),
        description: t('store_and_share_medical_records'),
        imageSource: require('@/assets/images/medical_record.png'),
        linkText: t('manage_medical_records'),
        onLink: () => navigate(Stack.MainStack, { screen: BottomTab.RecordStack, params: null! }),
      },
      {
        key: '2',
        title: t('do_you_manage_a_clinic'),
        description: t('list_your_clinic'),
        imageSource: require('@/assets/images/doctor-nurse.png'),
        linkText: t('register_clinic'),
        onLink: () => Linking.openURL('https://clinic.shifa.net/'),
      },
    ];
  }, [navigate, t]);

  const Scene = ({ slide }: { slide: SlideItem }) => (
    <View className="flex-column items-center justify-center flex-1">
      <Intro
        imageSource={slide.imageSource}
        title={slide.title}
        titleHasAction={true}
        titleAction={slide.onLink}
        description={slide.description}
      />

      <View className={'flex-row items-center justify-center w-full'}>
        <Button
          className={'mt-2 ml-auto absolute'}
          label={<Text className={'underline'}>{slide.linkText}</Text>}
          onPress={() => slide.onLink()}
        />
        <Button
          className={'mt-2 mr-2 ml-auto'}
          icon={slide.key === '2' ? 'check' : (I18nManager.isRTL ? 'arrow-left' : 'arrow-right')}
          onPress={() => setSlideIndex((Number(slide.key) + 1) % 3)}
        />
      </View>
    </View>
  );

  const renderScene = useCallback(() => {
    const scenes: Record<string, React.ComponentType> = {};

    slides.forEach((slide) => {
      scenes[slide.key] = () => <Scene slide={slide} />;
    });

    return SceneMap(scenes);
  }, [slides]);

  const renderTabBar = (props: TabBarProps<Route>) => (
    <TabBar
      {...props}
      indicatorStyle={{ backgroundColor: colors.primary, height: 4, borderRadius: 10 }}
      style={{ backgroundColor: '#fff', height: 6 }}
    />
  );

  return (
    <BaseScreen isLoading={isLoading}>
      <View className="flex-1">
        <TabView
          navigationState={{ index: slideIndex, routes }}
          renderScene={renderScene()}
          renderTabBar={renderTabBar}
          onIndexChange={setSlideIndex}
          swipeEnabled={true}
          initialLayout={{ width: layout.width }}
        />

        {!isLoggedIn && (
          <View className="px-6">
            <LoginForm
              onConfirm={
                (phone_number) => navigation.navigate(Stack.AuthStack, {
                  screen: Screen.Otp,
                  params: {
                    phone_number,
                  },
                })}
            />
          </View>
        )}
      </View>
    </BaseScreen>
  );
};
