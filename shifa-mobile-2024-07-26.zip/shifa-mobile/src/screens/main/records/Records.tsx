import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { View } from 'react-native';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { BaseScreen } from '@/screens/Base';
import { useAuthStore, useMainStore } from '@/stores';
import { ChipGroup, IconButton, RecordList, MediaBottomSheet, Intro, LoginForm } from '@/components';
import { useColors } from '@/hooks';
import { BottomTab, DocumentType, IDocument, IFile, ISelect, RootStackParamList, Stack, Screen, MediaPickerType } from '@/types';
import { useTranslation } from 'react-i18next';

type ScreenProps = NativeStackScreenProps<RootStackParamList, Stack.MainStack>;

export const RecordsScreen = (props: ScreenProps | unknown) => {
  const { navigation } = props as ScreenProps;
  const { t } = useTranslation('', { keyPrefix: 'records' });

  const DocumentTypes: ISelect<DocumentType | null>[] = [
    {
      title: t('all'),
      value: null,
    },
    {
      title: t('imaging'),
      value: DocumentType.Imaging,
    },
    {
      title: t('lab'),
      value: DocumentType.Lab,
    },
    {
      title: t('medication'),
      value: DocumentType.Medication,
    },
    {
      title: t('other'),
      value: DocumentType.Other,
    },
  ];

  const { isLoggedIn, user } = useAuthStore();
  const {
    isLoading,
    activeProfile,
    documentResults,

    uploadDocument,
    getDocuments,
    getDefaultProfile,
  } = useMainStore();

  const colors = useColors();

  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const [documentType, setDocumentType] = useState<DocumentType | null>(DocumentTypes[0].value);

  const documents = useMemo(() => {
    return documentResults?.results || [];
  }, [documentResults]);

  const uploadRecord = useCallback((file: IFile) => {
    if (user && activeProfile) {
      return uploadDocument({
        userId: user.id,
        profileId: activeProfile.id,
        file,
      });
    }
  }, [user, activeProfile]);

  const fetchDocuments = useCallback(() => {

    if (user && !activeProfile) {
      return getDefaultProfile(user.id);
    }

    if (user && activeProfile) {
      return getDocuments(user.id, activeProfile.id, {
        document_type: documentType!,
      });
    }

  }, [user, activeProfile, documentType]);

  useEffect(() => {
    fetchDocuments();
  }, [fetchDocuments]);

  const onMedia = async (mediaPickerType: MediaPickerType, file: IFile) => {
    if (file) {
      await uploadRecord(file);
      fetchDocuments();
    }
  };

  const onDocumentType = (selectedRecordType: ISelect<string | null>) => {
    setDocumentType(selectedRecordType.value as DocumentType);
  };

  const onDocumentPress = (document: IDocument) => {
    navigation.navigate(
      Stack.MainStack,
      {
        screen: BottomTab.RecordStack,
        params: {
          screen: Screen.RecordDetails,
          params: {
            document,
          },
        },
      },
    );
  };

  return (
    <BaseScreen isLoading={isLoading}>
      <View className="mt-2 px-6 flex-1">
        {
          isLoggedIn && (
            <ChipGroup
              items={DocumentTypes}
              value={documentType as string}
              onItemPress={onDocumentType}
            />
          )
        }
        {
          documents.length > 0 ? (
            <RecordList
              data={documents}
              onItemPress={onDocumentPress}
              onReload={fetchDocuments}
            />
          ) : (
            <Intro
              imageSource={require('@/assets/images/medical_record.png')}
              title={t('manage_your_medical_records')}
              description={isLoggedIn ? t('manage_medical_record_desc_1') : t('manage_medical_record_desc_2')}
              titleHasAction={false}
              titleAction={() => { }}
            />
          )
        }

        {
          isLoggedIn ? (
            <View className="absolute right-6 bottom-6">
              <IconButton
                backgroundColor={colors.primary}
                icon="plus"
                iconColor="white"
                iconSize={40}
                rounded
                onPress={() => bottomSheetModalRef.current?.present()}
              />
            </View>
          ) : (
            <View className="absolute w-full right-6 bottom-0">
              <LoginForm
                onConfirm={
                  (phone_number) => navigation.navigate(Stack.AuthStack, {
                    screen: Screen.Otp,
                    params: {
                      phone_number,
                    },
                  })}
              />
            </View>
          )
        }

        <MediaBottomSheet
          title={t('choose_options_to_add_documents')}
          ref={bottomSheetModalRef}
          onMedia={onMedia}
        />
      </View>
    </BaseScreen>
  );
};
