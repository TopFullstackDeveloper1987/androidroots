import React, { useCallback, useEffect } from 'react';
import { Image, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { Text } from 'react-native-paper';
import PDFView from 'react-native-view-pdf';
import { useTranslation } from 'react-i18next';

import { BaseScreen } from '@/screens/Base';
import { Screen, RecordStackParamList, ISelect, DocumentType } from '@/types';
import { useAuthStore, useMainStore } from '@/stores';
import { ChipGroup } from '@/components';

type ScreenProps = NativeStackScreenProps<RecordStackParamList, Screen.RecordDetails>;

export const RecordDetailsScreen = (props: ScreenProps | unknown) => {
  const { route } = props as ScreenProps;
  const { user } = useAuthStore();
  const { t } = useTranslation('', { keyPrefix: 'records' });

  const DocumentTypes: ISelect<DocumentType | null>[] = [
    {
      title: t('all'),
      value: null,
    },
    {
      title: t('imaging'),
      value: DocumentType.Imaging,
    },
    {
      title: t('lab'),
      value: DocumentType.Lab,
    },
    {
      title: t('medication'),
      value: DocumentType.Medication,
    },
    {
      title: t('other'),
      value: DocumentType.Other,
    },
  ];

  const {
    isLoading,
    selectedDocument,

    getDocumentDetail,
    updateDocument,
  } = useMainStore();

  const getDocumentDetailCallback = useCallback(() => {
    if (user && route.params.document.id) {
      return getDocumentDetail(user.id, route.params.document.id);
    }

  }, [user, route]);

  const updateDocumentCallback = useCallback((documentType: DocumentType) => {
    if (user && selectedDocument) {
      return updateDocument(user.id, selectedDocument.id, {
        document_type: documentType,
      });
    }
  }, [user, selectedDocument]);

  useEffect(() => {
    getDocumentDetailCallback();
  }, [getDocumentDetailCallback]);

  const onDocumentType = (selectedDocumentType: ISelect<string | null>) => {
    updateDocumentCallback(selectedDocumentType.value as DocumentType);
  };

  return (
    <BaseScreen isLoading={isLoading}>
      <View className="flex-1 py-4 px-6">
        {
          selectedDocument?.file && selectedDocument?.file_format === 'pdf' && (
            <PDFView
              fadeInDuration={250.0}
              style={{
                flex: 1,
              }}
              resource={selectedDocument.file}
              resourceType="url"
            />
          )
        }
        {
          selectedDocument?.file && selectedDocument?.file_format !== 'pdf' && (
            <Image
              className="rounded mb-2"
              height={300}
              source={{
                uri: selectedDocument.file,
              }}
            />
          )
        }

        <View className="mt-4">
          <Text className="text-base my-2">
            {t('update_document_type')}
          </Text>

          <ChipGroup
            items={DocumentTypes}
            value={selectedDocument?.document_type as string}
            onItemPress={onDocumentType}
          />
        </View>
      </View>
    </BaseScreen>
  );
};
