import React, { useState, useMemo, useEffect } from 'react';
import { View } from 'react-native';
import { useTranslation } from 'react-i18next';
import { Divider } from 'react-native-paper';
import * as _ from 'lodash';
import { useNavigation, NavigationProp } from '@react-navigation/native';

import { BaseScreen } from '@/screens/Base';
import { Searchbar, Select, SpecialityList } from '@/components';
import { ISelect, ISpeciality, Screen, SearchStackParamList } from '@/types';
import { useMainStore } from '@/stores';

export const SearchScreen = () => {
  const { t } = useTranslation('', { keyPrefix: 'search' });

  const {
    isLoading,
    cities,
    specialities,

    getCities,
    getSpecialities,
  } = useMainStore();

  const navigation = useNavigation<NavigationProp<SearchStackParamList>>();

  const [doctor, setDoctor] = useState('');
  const [doctorChange, setDoctorChange] = useState('');
  const [city, setCity] = useState<ISelect<number>>();

  const cityList: ISelect<number>[] = useMemo(() => cities.map((city) => ({
    title: city.name,
    value: city.id,
  })), [cities]);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      getCities(1, false);
    });

    return unsubscribe;
  }, [getCities, navigation]);

  useEffect(() => {
    if (cityList.length > 0) {
      setCity(city || cityList[0]);
    }
  }, [cityList]);

  useEffect(() => {
    if (city) {
      getSpecialities(city.value, false, doctorChange);
    }
  }, [doctorChange, city]);

  const doctorChanged = _.debounce(async (query: string) => {
    setDoctorChange(query);
  }, 600);
  const onChangeDoctor = (query: string) => {
    setDoctor(query);
    doctorChanged(query);
  };

  const navigateToSearchResults = (speciality: ISpeciality) => {
    navigation.navigate(Screen.SearchResults, {
      speciality,
      city_id: city?.value || 1,
      name: doctor,
    });
  };

  return (
    <BaseScreen isLoading={isLoading}>
      <View className="px-6 mt-4 flex-1">
        <Searchbar
          placeholder={t('search_doctors')}
          onChangeText={onChangeDoctor}
          value={doctor}
        />

        <View className="my-4">
          <Select
            placeholder={t('select_location')}
            leftIcon="map-marker-radius-outline"
            items={cityList.sort((a, b) => a.value - b.value)}
            value={city}
            snapPoints={cityList.length >= 10 ? ['60%'] : ['30%']}
            onChange={setCity}
          />
        </View>

        <Divider />

        <SpecialityList
          data={specialities}
          onItemPress={(speciality) => {
            navigateToSearchResults(speciality);
          }}
        />
      </View>
    </BaseScreen>
  );
};
