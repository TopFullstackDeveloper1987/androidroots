import React, { useRef, useEffect } from 'react';
import { View, FlatList, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { Avatar, IconButton, StarWidget, SortByBottomSheet } from '@/components';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { BottomSheetModal } from '@gorhom/bottom-sheet';

import { BaseScreen } from '@/screens/Base';
import { IPractitioner, Screen, SearchStackParamList } from '@/types';
import { useMainStore } from '@/stores';
import { useTranslation } from 'react-i18next';

type ScreenProps = NativeStackScreenProps<SearchStackParamList, Screen.SearchResults>;


export const SearchResultsScreen = (props: ScreenProps | unknown) => {
  const {
    navigation,
    route,
  } = props as ScreenProps;

  const { t } = useTranslation('', { keyPrefix: 'search' });

  const {
    isLoading,
    practitioners,

    searchPractitioners,
  } = useMainStore();

  const sortByOptions = [
    {
      title: t('rating'),
      value: 'rating',
    },
    {
      title: t('name'),
      value: 'name',
    },
  ];

  useEffect(() => {
    const { speciality, name, city_id } = route.params;
    searchPractitioners({
      speciality_id: speciality.speciality_id,
      name,
      city_id,
    });
  }, []);

  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const [sortBy, setSortBy] = React.useState('rating');

  React.useEffect(() => {
    navigation.setOptions({
      title: t('search'),
      headerRight: () =>
        <IconButton
          icon="swap-vertical"
          iconSize={25}
          onPress={() => bottomSheetModalRef.current?.present()}
        />,
      // headerLeft: () =>
      //   <IconButton
      //     icon="tune"
      //     iconSize={25}
      //     onPress={() => navigation.goBack()}
      //   />,
    });
  }, []);

  const navigateToDetailsPage = (practitioner: IPractitioner) => navigation.navigate(Screen.SearchDetails, {
    speciality: route.params.speciality,
    practitioner,
  });

  const Item = (practitioner: IPractitioner) => {
    const { name, average_rating, tagline, photo, gender } = practitioner;

    return (
      <TouchableOpacity onPress={() => navigateToDetailsPage(practitioner)}>
        <View
          className="flex-row p-[15] my-2 rounded-2xl bg-light"
        >
          <Avatar
            source={photo ? {
              uri: photo,
            }: (gender === 'M' ? require('@/assets/images/doctor-avatar-male.png') : require('@/assets/images/doctor-avatar-female.png'))}
            gender={gender}
            size={64}
            icon="diabetes"
          />
          <View className="flex-column justify-between h-75 mx-[14]">
            <View>
              <Text className="font-bold text-base">{name}</Text>
              <Text className="font-medium text-[#65688F]">{tagline}</Text>
            </View>
            <StarWidget
              value={Number(average_rating)/10}
              hideValue={false}
            />
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <BaseScreen isLoading={isLoading}>
      <View className="flex-1">
        <View className="flex-row justify-between mx-1">
        </View>
        <FlatList
          data={practitioners}
          renderItem={({ item, index }) => <Item {...item} index={index} />}
          keyExtractor={item => item.id}
          className="mx-4 my-2"
        />
      </View>
      <SortByBottomSheet
        ref={bottomSheetModalRef}
        value={sortBy}
        onChange={(value) => setSortBy(value)}
        sortByOptions={sortByOptions}
      />
    </BaseScreen>
  );
};
