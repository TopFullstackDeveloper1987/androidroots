import React, { useCallback, useEffect, useRef } from 'react';
import { View, SectionList, SectionListData, TouchableOpacity, I18nManager } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { Text } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import QRCode from 'react-native-qrcode-svg';

import { IFile, ISelect, MediaPickerType, ProfileStackParamList, Screen } from '@/types';
import { BaseScreen } from '@/screens/Base';
import { useAuthStore, useMainStore } from '@/stores';
import { Avatar, MediaBottomSheet, IconButton } from '@/components';
import { useColors } from '@/hooks';
import { useTranslation } from 'react-i18next';

type ScreenProps = NativeStackScreenProps<ProfileStackParamList, Screen.Profile>;

export const ProfileScreen = (props: ScreenProps | unknown) => {
  const { navigation } = props as ScreenProps;

  const colors = useColors();

  const { t } = useTranslation('', { keyPrefix: 'profile' });

  const sections: SectionListData<ISelect<string>>[] = [
    {
      title: '',
      data: [
        {
          title: t('personal_information'),
          value: 'personal-information',
        },
        {
          title: t('family_profiles'),
          value: 'family_profiles',
        },
        {
          title: t('notifications'),
          value: 'notifications',
        },
        {
          title: t('settings'),
          value: 'settings',
        },
      ],
      footer: null,
    },
  ];

  const {
    isLoading: isAuthLoading,
    user,
  } = useAuthStore();

  const {
    isLoading: isMainLoading,
    activeProfile,

    getDefaultProfile,
    updateProfile,
    updateProfilePhoto,
  } = useMainStore();

  const bottomSheetModalRef = useRef<BottomSheetModal>(null);

  const navigateToPersonalInformation = useCallback(() => {
    navigation.navigate(Screen.PersonalInformation, {
      profile: activeProfile,
    });
  }, [navigation, activeProfile]);

  const navigateToFamilyProfiles = useCallback(() => {
    navigation.navigate(Screen.FamilyProfiles);
  }, [navigation]);

  const navigateToNotifications = useCallback(() => {
    navigation.navigate(Screen.Notifications);
  }, [navigation]);

  const navigateToSettings = useCallback(() => {
    navigation.navigate(Screen.Settings);
  }, [navigation]);

  const fetchDefaultProfile = useCallback(() => {
    if (user && !activeProfile) {
      return getDefaultProfile(user.id);
    }
  }, [user, activeProfile]);

  useEffect(() => {
    fetchDefaultProfile();
  }, [fetchDefaultProfile]);

  const onItem = (value: string) => {
    switch (value) {
      case 'personal-information':
        navigateToPersonalInformation();
        break;
      case 'family_profiles':
        navigateToFamilyProfiles();
        break;
      case 'notifications':
        navigateToNotifications();
        break;
      case 'settings':
        navigateToSettings();
        break;
    }
  };

  const renderItem = ({ item }: { item: ISelect<string> }) => (
    <TouchableOpacity
      className="flex-row items-center justify-center py-2"
      onPress={() => onItem(item.value)}
    >
      <Text className="flex-1 mr-4">
        {item.title}
      </Text>

      {/* { item.value === 'notifications'
       &&
        <Badge className={'mb-[1]'}>3</Badge>
      } */}

      <Icon
        name={I18nManager.isRTL ? 'chevron-left' : 'chevron-right'}
        size={24}
        color={colors.primary}
      />
    </TouchableOpacity>
  );

  const renderSectionHeader = ({ section }: { section: SectionListData<ISelect<string>> }) => (
    <Text className="text-disabled mb-2">
      {section.title}
    </Text>
  );

  const onMedia = async (mediaPickerType: MediaPickerType, file: IFile) => {
    if (file && user && activeProfile) {
      await updateProfile(user.id, activeProfile.id, {
        photo: file,
      });

      const profile = await getDefaultProfile(user.id);
      updateProfilePhoto(profile!);
    }
  };
  return (
    <BaseScreen isLoading={isAuthLoading || isMainLoading}>
      <View className="px-6 mt-4 flex-1">
        <View className="items-center">
          <Avatar
            source={activeProfile?.photo ? {
              uri: activeProfile.photo,
            } : undefined}
            gender={activeProfile?.gender || 'M'}
            imageStyle={{
              width: 64,
              height: 64,
            }}
            icon={'pencil-outline'}
            disabled={!activeProfile}
            onPress={() => bottomSheetModalRef.current?.present()}
          />

          <Text className="text-lg font-bold mt-1">
            {activeProfile?.name || ''}
          </Text>
        </View>

        <View
          className="mt-4"
        >
          <SectionList
            sections={sections}
            keyExtractor={(item, index) => item.value + index}
            renderItem={renderItem}
            renderSectionHeader={renderSectionHeader}
          />
        </View>

        <View className={'flex-row justify-center items-center flex-1'}>
          <QRCode
            value={`https://clinic.shifa.net/${user?.id}/`}
            size={150}
          />
        </View>

        {!activeProfile && (
          <View className="absolute right-6 bottom-6">
            <IconButton
              backgroundColor={colors.primary}
              icon="plus"
              iconColor="white"
              iconSize={40}
              rounded
              onPress={() => navigateToPersonalInformation()}
            />
          </View>
        )}

        <MediaBottomSheet
          title={t('choose_options_to_add_photo')}
          ref={bottomSheetModalRef}
          onMedia={onMedia}
        />
      </View>

    </BaseScreen>
  );
};
