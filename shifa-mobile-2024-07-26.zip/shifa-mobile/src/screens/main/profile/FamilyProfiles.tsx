import React, { useEffect, useCallback } from 'react';
import { View, FlatList, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { Avatar, IconButton, Button } from '@/components';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import * as moment from 'moment-timezone';
import { useTranslation } from 'react-i18next';

import { BaseScreen } from '@/screens/Base';
import { Screen, ProfileStackParamList, IProfile } from '@/types';
import { useAuthStore, useMainStore } from '@/stores';
import { useColors } from '@/hooks';

type ScreenProps = NativeStackScreenProps<ProfileStackParamList, Screen.FamilyProfiles>;

export const FamilyProfilesScreen = (props: ScreenProps | unknown) => {
  const { navigation } = props as ScreenProps;

  const { t } = useTranslation('', { keyPrefix: 'family_profiles' });
  const colors = useColors();

  const {
    isLoading: isAuthLoading,
    user,
  } = useAuthStore();

  const {
    isLoading: isMainLoading,
    profiles,
    activeProfile,

    getProfiles,
    setActiveProfile,
  } = useMainStore();

  const onSwitchToProfile = useCallback((profile: IProfile) => {
    if (activeProfile && profile && activeProfile.id !== profile.id) {
      setActiveProfile(profile);
    }
  }, [activeProfile]);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      if (user?.id) {
        getProfiles(user.id);
      }
    });

    return unsubscribe;
  }, [getProfiles, user, navigation]);

  const navigateToPersonalInformation = useCallback((profile: IProfile | null) => {
    navigation.navigate(Screen.PersonalInformation, {
      profile,
    });
  }, [navigation]);

  const renderItem = ({ item }: {item: IProfile}) => {
    const { name, photo, gender, date_of_birth, relationship } = item;

    return (
      <TouchableOpacity onPress={() => navigateToPersonalInformation(item)}>
        <View
          className="flex-row p-4 my-2 rounded-2xl bg-light"
        >
          <Avatar
            source={photo ? {
              uri: photo,
            }: undefined}
            gender={gender}
            size={75}
            icon="diabetes"
          />
          <View className="flex-column justify-center px-3">
            <Text className="ml-3 font-bold text-base">
              {`${name} (${moment.utc().diff(moment.utc(date_of_birth), 'years')})`}
            </Text>
            <Text className="ml-3 font-medium text-[#65688F]">
              {relationship}
            </Text>
            {
              relationship?.toLowerCase() !== 'self'
              &&
              <Button
                label={<Text className={'underline text-primary'}>{t('switch_to_profile')}</Text>}
                onPress={() => onSwitchToProfile(item)}
              />
            }

          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <BaseScreen isLoading={isAuthLoading || isMainLoading}>
      <View className="px-6 mt-4 flex-1">
        <FlatList
          data={profiles}
          renderItem={renderItem}
          keyExtractor={item => item.id}
        />

        <View className="absolute right-6 bottom-6">
          <IconButton
            backgroundColor={colors.primary}
            icon="plus"
            iconColor="white"
            iconSize={40}
            rounded
            onPress={() => navigateToPersonalInformation(null)}
          />
        </View>
      </View>
    </BaseScreen>
  );
};
