import React from 'react';
import { Image, ScrollView, Text, View } from 'react-native';
// import { useTranslation } from 'react-i18next';

import { BaseScreen } from '@/screens/Base';
import { useAuthStore, useMainStore } from '@/stores';
import { Divider, Icon } from 'react-native-paper';
import { INotificationItem } from '@/types';
import { TouchableOpacity } from 'react-native-gesture-handler';


export const Notifications = () => {

  // const { t } = useTranslation('', { keyPrefix: 'profile' });

  const {
    isLoading: isMainLoading,
  } = useMainStore();

  const {
    isLoading: isAuthLoading,
  } = useAuthStore();

  const notifications: INotificationItem[] = [
    // {
    //   id: 1,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 2,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 3,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 4,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 5,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 6,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 7,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 8,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 9,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 10,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 11,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 12,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 13,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 14,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 15,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 16,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 17,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 18,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 19,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 20,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 21,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '3h(s) ago',
    //   isOpened: true,
    // },
    // {
    //   id: 23,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 24,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 25,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 26,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 27,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 28,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 29,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 30,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
    // {
    //   id: 31,
    //   content: 'Your appontment has been confirmed by the clinic',
    //   created_date: '1h(s) ago',
    //   isOpened: false,
    // },
  ];

  const onItemPress = (item: INotificationItem) => {
    console.log('Notification clicked', item);
  };

  return (
    <BaseScreen isLoading={isAuthLoading || isMainLoading}>
      <ScrollView className={'h-full'}>
        {
          notifications.map((item: INotificationItem) => {
            return (
              <View key={item.id} className={`h-24 relative ${!item.isOpened ? 'bg-secondary' : ''}`}>
                <Text className={'text-grey text-xs absolute right-2 top-2'}>3hs ago</Text>
                <TouchableOpacity
                  className="flex-column px-6"
                  onPress={() => onItemPress(item)}
                >
                  <View className="flex-row justify-center items-center h-24">
                    <Image source={require('@/assets/images/shifa-icon.png')} className={'rounded-full'} style={{ height: 50, width: 50 }} />
                    <Text className="flex-1 px-6 py-2 text-base">
                      {item.content}
                    </Text>
                    {
                      !item.isOpened && <Icon source={'checkbox-blank-circle'} size={12}  />
                    }
                  </View>
                  <Divider className={'bg-secondary'} />
                </TouchableOpacity>
              </View>
            );
          })
        }
      </ScrollView>
    </BaseScreen>
  );
};
