import React, { useCallback, useEffect, useMemo } from 'react';
import { ScrollView, View, TouchableWithoutFeedback } from 'react-native';
import { useFormik } from 'formik';
import * as yup from 'yup';
import * as moment from 'moment-timezone';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useTranslation } from 'react-i18next';

import { IProfile, IProfileUpdatePayload, ISelect, ProfileStackParamList, Screen } from '@/types';
import { BaseScreen } from '@/screens/Base';
import { useAuthStore, useMainStore } from '@/stores';
import { TextInput, Button, Select, DateInput, showToast } from '@/components';
import { getDeviceLanguage } from '@/utils';

type ScreenProps = NativeStackScreenProps<ProfileStackParamList, Screen.PersonalInformation>;

interface IForm {
  name: string,
  date_of_birth: Date,
  gender: ISelect<string>,
  relationship: ISelect<string>,
  city?: ISelect<number>,
  language: ISelect<string>,
}

const mapToProfilePayload = (values: IForm): Partial<IProfile> => {
  const payload: Partial<IProfile> = {
    name: values.name,
    date_of_birth: moment.utc(values.date_of_birth).format('YYYY-MM-DD'),
    gender: values.gender.value,
    relationship: values.relationship.value,
    city: values.city?.value,
    language: values.language.value,
  };

  return payload;
};

export const PersonalInformation = (props: ScreenProps | unknown) => {
  const { route, navigation } = props as ScreenProps;
  const { profile } = route.params;

  const {
    isLoading: isAuthLoading,
    user,
  } = useAuthStore();

  const { t } = useTranslation('', { keyPrefix: 'profile' });

  const genders: ISelect<string>[] = [
    {
      title: t('male'),
      value: 'M',
    },
    {
      title: t('female'),
      value: 'F',
    },
  ];

  const languages: ISelect<string>[] = [
    {
      title: t('en'),
      value: 'EN',
    },
    {
      title: t('ar'),
      value: 'AR',
    },
    {
      title: t('ckb'),
      value: 'CKB',
    },
    {
      title: t('ku'),
      value: 'KU',
    },
  ];

  const relationships: ISelect<string>[] = [
    {
      title: t('self'),
      value: 'self',
    },
    {
      title: t('mother'),
      value: 'mother',
    },
    {
      title: t('father'),
      value: 'father',
    },
    {
      title: t('brother'),
      value: 'brother',
    },
    {
      title: t('sister'),
      value: 'sister',
    },
    {
      title: t('child'),
      value: 'child',
    },
    {
      title: t('spouse'),
      value: 'spouse',
    },
    {
      title: t('other'),
      value: 'other',
    },
  ];

  const {
    isLoading: isMainLoading,
    cities,

    getCities,
    getProfile,
    createProfile,
    updateProfile,
  } = useMainStore();

  const cityList: ISelect<number>[] = useMemo(() => cities.map((city) => ({
    title: city.name,
    value: city.id,
  })), [cities]);

  const onSubmit = useCallback(async (values: IForm) => {
    if (!user) {
      return;
    }

    const payload = mapToProfilePayload(values);
    payload.user = user.id;

    let profileResult: IProfile;

    if (profile) {
      profileResult = await updateProfile(user.id, profile.id, payload as IProfileUpdatePayload);
    } else {
      profileResult = await createProfile(user.id, payload);
    }

    const text = profile ? t('successfully_updated_profile') : t('successfully_created_profile');
    showToast({
      type: 'success',
      title: 'Success',
      text,
    });

    navigation.goBack();
    return getProfile(user.id, profileResult.id);
  }, [user, profile]);

  useEffect(() => {
    getCities(1, true);
  }, []);

  useEffect(() => {
    if (cityList.length > 0 && !values.city) {
      setFieldValue('city', cityList[0]);
    }
  }, [cityList]);

  useEffect(() => {

    if (profile) {
      setFieldValue('name', profile.name);
      setFieldValue('date_of_birth', moment.utc(profile.date_of_birth).toDate());

      const gender = genders.find((g) => g.value === profile.gender);
      setFieldValue('gender', gender);

      const relationship = relationships.find((r) => r.value === profile.relationship);
      setFieldValue('relationship', relationship);

      const city = cityList?.find((c) => c.value === profile.city);
      setFieldValue('city', city);

      const language = languages.find((lang) => lang.value === profile.language);

      setFieldValue('language', language);

    } else {
      setFieldValue('name', '');
      setFieldValue('date_of_birth', moment.utc().toDate());
      setFieldValue('gender', values.gender || undefined);
      setFieldValue('relationship', relationships[0]);
      setFieldValue('city', values.city || undefined);

      const defaultLanguage = languages.find((lang) => lang.value.toLowerCase() === getDeviceLanguage());
      setFieldValue('language', defaultLanguage);
    }
  }, [profile]);

  const validationSchema = yup.object().shape({
    name: yup.string().required('Field is required'),
  });

  const { values, errors, touched, setFieldValue, submitForm } = useFormik<IForm>({
    initialValues: {
      name: '',
      date_of_birth: moment.utc().toDate(),
      gender: genders[0],
      relationship: relationships[0],
      city: undefined,
      language: undefined!,
    },
    validationSchema,
    validateOnBlur: true,
    validateOnChange: true,
    onSubmit,
  });

  return (
    <BaseScreen isLoading={isAuthLoading || isMainLoading}>
      <ScrollView
        contentContainerStyle={{
          paddingVertical: 16,
          paddingHorizontal: 24,
        }}
      >
        <TouchableWithoutFeedback>
          <View>
            <View className="gap-3">
              <View>
                <TextInput
                  label={t('name')}
                  value={values.name}
                  errorMessage={touched.name ? errors.name : ''}
                  onChangeText={(value) => setFieldValue('name', value)}
                />
              </View>

              <View>
                <DateInput
                  label={t('date_of_birth')}
                  value={values.date_of_birth}
                  maximumDate={moment.utc().toDate()}
                  onChange={(value) => setFieldValue('date_of_birth', value)}
                />
              </View>

              <View>
                <Select
                  label={t('gender')}
                  items={genders}
                  value={values.gender}
                  placeholder={t('please_select')}
                  onChange={(value) => setFieldValue('gender', value)}
                />
              </View>

              <View>
                <Select
                  label={t('relationship')}
                  items={relationships}
                  value={values.relationship}
                  snapPoints={['50%']}
                  onChange={(value) => setFieldValue('relationship', value)}
                />
              </View>

              <View>
                <Select
                  label={t('city')}
                  items={cityList}
                  value={values.city}
                  placeholder={t('please_select')}
                  onChange={(value) => setFieldValue('city', value)}
                />
              </View>

              <View>
                <Select
                  label={t('language')}
                  items={languages}
                  value={values.language}
                  placeholder={t('please_select')}
                  onChange={(value) => setFieldValue('language', value)}
                />
              </View>
            </View>

            <Button
              label={t('submit')}
              mode="contained"
              className="w-full rounded-full mt-8"
              loading={isMainLoading}
              disabled={isMainLoading}
              onPress={() => submitForm()}
            />
          </View>
        </TouchableWithoutFeedback>
      </ScrollView>
    </BaseScreen>
  );
};
