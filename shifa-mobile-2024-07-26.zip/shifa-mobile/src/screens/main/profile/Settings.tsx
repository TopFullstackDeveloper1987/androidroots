import React, { useEffect, useState } from 'react';
import { View, I18nManager } from 'react-native';

import { ISelect } from '@/types';
import { BaseScreen } from '@/screens/Base';
import { useAuthStore, useMainStore } from '@/stores';
import { Select } from '@/components';
import { useTranslation } from 'react-i18next';
import { changeLanguage } from '@/utils';
import { AsyncStorageService } from '@/services';

// type ScreenProps = NativeStackScreenProps<ProfileStackParamList, Screen.Profile>;

export const Settings = () => {

  const { t } = useTranslation('', { keyPrefix: 'profile' });

  const [ language, setLanguage] = useState<ISelect<string>>();

  const languages: ISelect<string>[] = [
    {
      title: t('en'),
      value: 'EN',
    },
    {
      title: t('ar'),
      value: 'AR',
    },
    {
      title: t('ckb'),
      value: 'CKB',
    },
    {
      title: t('ku'),
      value: 'KU',
    },
  ];

  const {
    isLoading: isAuthLoading,
  } = useAuthStore();

  const {
    isLoading: isMainLoading,
  } = useMainStore();



  useEffect(() => {
    const getUserLanguage = async () => {
      const userLanguage = await AsyncStorageService.getInstance().getUserLanguage();
      const currentLanguage = languages.find((lang) => lang.value.toLowerCase() === userLanguage);

      setLanguage(currentLanguage);
    };

    getUserLanguage();
  }, []);

  const updateAppLanguage = async (lang: ISelect<string>) => {
    setLanguage(lang);
    changeLanguage(lang.value.toLowerCase());
  };

  return (
    <BaseScreen isLoading={isAuthLoading || isMainLoading}>
      <View className="px-6 mt-4 flex-1">
        <Select
          placeholder={t('language')}
          items={languages}
          value={language}
          style={{
            backgroundColor: '#fff',
            paddingLeft: I18nManager.isRTL ? 2 : 0,
            paddingRight: I18nManager.isRTL ? 0 : 2,
          }}
          titleClass={'text-sm'}
          noBorderOnFocus={true}
          onChange={updateAppLanguage}
        />
      </View>
    </BaseScreen>
  );
};
