import React, { useEffect } from 'react';
import { FlatList, RefreshControl, TouchableOpacity, View } from 'react-native';
import { BaseScreen } from '@/screens/Base';
import { useAuthStore, useMainStore } from '@/stores';
import { Text } from 'react-native-paper';
import { Intro, Avatar, StarWidget, FavoriteToggleButton, LoginForm } from '@/components';
import { ActionType, BottomTab, IPractitioner, RootStackParamList, Screen, Stack } from '@/types';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useTranslation } from 'react-i18next';

type ScreenProps = NativeStackScreenProps<RootStackParamList, Stack.MainStack>;

export const FavoritesScreen = (props: ScreenProps | unknown) => {
  const { navigation } = props as ScreenProps;
  const { t } = useTranslation('', { keyPrefix: 'favorites' });

  const [refreshing, setRefreshing] = React.useState(false);

  const {
    isLoggedIn,
    user,
  } = useAuthStore();

  const {
    favoritePractitioners,
    isLoading,

    getFavoritePractitioners,
    setFavoritePractitioner,
  } = useMainStore();

  const navigateToDetailsPage = (practitioner: IPractitioner) => navigation.navigate(Stack.MainStack, {
    screen: BottomTab.FavoriteStack,
    params: {
      screen: Screen.PractitionerDetails,
      params: {
        practitioner,
      },
    },
  });

  const onFavorite = async (practitioner: IPractitioner) => {
    if(user?.id) {
      await setFavoritePractitioner(user.id, practitioner.id, ActionType.RemoveFavorite);
      getFavoritePractitioners(user.id, false);
    }
  };

  useEffect(() => {

    const unsubscribe = navigation.addListener('focus', () => {
      if(user?.id) {
        getFavoritePractitioners(user.id, false);
      }
    });

    return unsubscribe;
  }, []);

  const onRefresh = React.useCallback(async () => {
    setRefreshing(true);
    if(user?.id) {
      await getFavoritePractitioners(user.id, false);
    }
    setRefreshing(false);
  }, []);


  const png = require('@/assets/images/thumb-up.png');

  const Item = (practitioner: IPractitioner) => {
    const { name, average_rating, tagline, photo, gender } = practitioner;

    return (
      <TouchableOpacity onPress={() =>
        navigateToDetailsPage(practitioner)
      }>
        <View
          className="flex-row justify-between p-[15] my-2 rounded-2xl bg-light"
        >
          <View className={'flex-row w-[90%]'} >
            <Avatar
              source={photo ? {
                uri: photo,
              }: gender === 'M' ? require('@/assets/images/doctor-avatar-male.png') : require('@/assets/images/doctor-avatar-female.png')}
              gender={gender}
              size={64}
              icon="diabetes"
            />
            <View className="flex-column justify-between h-75 mx-[14]">
              <View className={'w-[95%]'}>
                <Text className="font-bold text-base truncate">{name}</Text>
                <Text className="font-medium text-[#65688F] truncate">{tagline}</Text>
              </View>
              <StarWidget
                value={Number(average_rating)/10}
                hideValue={false}
                onChange={(val) => {
                  console.log(val);
                  // updatePractionerRate(index!, val.toString());
                }}
              />
            </View>
          </View>
          <View className={'w-[10%]'}><FavoriteToggleButton value={true} padding={'p-1'} onPress={() => onFavorite(practitioner)} /></View>
        </View>
      </TouchableOpacity>
    );
  };

  return <BaseScreen isLoading={isLoading}>
    <View className="px-4 flex-1">
      {
        favoritePractitioners.length === 0
          ?
          <Intro
            imageSource={png}
            title={t('no_favourite_doctor')}
            description={!isLoggedIn ? t('sign_in_save_favourite_doctor') : t('looks_like_no_favourite_doctors_added')}
            titleHasAction={false}
            titleAction={() => {}}
          />
          :
          <FlatList
            data={favoritePractitioners}
            renderItem={({ item, index }) => <Item name_arabic={''} name_kurdish={''} {...item} index={index} />}
            keyExtractor={item => item.id}
            className="my-2 w-full"
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          />
      }

      {
        !isLoggedIn && (
          <View className="absolute w-screen px-6 bottom-0">
            <LoginForm
              onConfirm={
                (phone_number) => navigation.navigate(Stack.AuthStack, {
                  screen: Screen.Otp,
                  params: {
                    phone_number,
                  },
                })}
            />
          </View>
        )
      }
    </View>
  </BaseScreen>;
};
