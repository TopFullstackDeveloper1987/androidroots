import React, { useEffect, useRef, useState } from 'react';
import { View, ScrollView, Share, Linking } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { Text } from 'react-native-paper';

import { BaseScreen } from '@/screens/Base';
import {
  DoctorProfile,
  IconButton,
  FavoriteToggleButton,
  OpeningTimes,
  Location,
} from '@/components';
import { ActionType, BottomTab, RootStackParamList, Screen, SearchStackParamList, Stack } from '@/types';
import { useAuthStore, useMainStore } from '@/stores';
import { ReviewBottomSheet, ReviewListBottomSheet } from '@/components';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { NavigationProp, useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import { useColors } from '@/hooks';




type ScreenProps = NativeStackScreenProps<SearchStackParamList, Screen.SearchDetails>;

export const PractitionerDetailsScreen = (props: ScreenProps | unknown) => {
  const { route } = props as ScreenProps;
  const { navigate, setOptions } = useNavigation<NavigationProp<RootStackParamList>>();
  const { t } = useTranslation('', { keyPrefix: 'favorites' });

  const [isFavorite, setIsFavorite] = useState(true);
  const reviewBottomSheetModalRef = useRef<BottomSheetModal>(null);
  const reviewListBottomSheetModalRef = useRef<BottomSheetModal>(null);

  const colors = useColors();

  const {
    isLoading,
    practitionerDetail,

    getPractitionerDetail,
    setFavoritePractitioner,
  } = useMainStore();

  const {
    user,
    isLoggedIn,
  } = useAuthStore();

  const onFavorite = () => {
    if(!isLoggedIn) {
      navigate(Stack.MainStack, { screen: BottomTab.HomeStack, params: null! });
      return;
    }

    const favorited = !isFavorite;
    if(user?.id)
      setFavoritePractitioner(user.id, route.params.practitioner.id, favorited ? ActionType.AddFavorite : ActionType.RemoveFavorite);
    setIsFavorite(favorited);
  };

  const onShare = async () => {
    try {
      await Share.share({
        message:
          `https://clinic.shifa.net/practitioner/${route.params.practitioner.id}/`,
      });
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    setOptions({
      headerRight: () =>
        <View className="flex-row">
          <IconButton
            icon="tray-arrow-up"
            onPress={onShare}
          />
          <FavoriteToggleButton
            value={isFavorite}
            onPress={onFavorite}
          />
        </View>,
    });
  }, []);

  useEffect(() => {
    if (route.params.practitioner.id) {
      getPractitionerDetail(route.params.practitioner.id);
    }
  }, [route.params.practitioner]);

  return (
    <ScrollView
      contentContainerStyle={{
        marginTop: 16,
        paddingHorizontal: 24,
      }}
    >
      <BaseScreen isLoading={isLoading}>
        <DoctorProfile
          icon={''}
          practitioner={route.params.practitioner}
          phoneNumber={practitionerDetail.telephone_1!}
          onStarPress={() => {
            reviewListBottomSheetModalRef.current?.present();
          }}
        />

        <View className="mt-6">
          <Text className="font-bold">
            { t('about_me') }
          </Text>
          <Text className="mt-2 leading-5">
            {practitionerDetail.description}
          </Text>
        </View>

        <OpeningTimes
          businessHours={practitionerDetail.business_hours!}
        />

        <Location
          full_address={practitionerDetail.full_address!}
          latitude={Number(practitionerDetail.latitude)}
          longitude={Number(practitionerDetail.longitude)}
        />

        <View className="mt-6">
          <Text className="font-bold">
            { t('contact_information') }
          </Text>

          <View className="flex-row justify-between mt-2">
            <Text>
              { t('email') }
            </Text>
            <Text>
              {practitionerDetail.email}
            </Text>
          </View>
        </View>

        <View className="my-6 flex-row justify-center">
          <IconButton
            icon="facebook"
            iconColor={ practitionerDetail.facebook && colors.primary}
            onPress={() => Linking.openURL(practitionerDetail.facebook!)}
          />
          <IconButton
            icon="instagram"
            iconColor={ practitionerDetail.instagram && colors.primary}
            onPress={() => Linking.openURL(practitionerDetail.instagram!)}
          />


        </View>
        <ReviewListBottomSheet
          ref={reviewListBottomSheetModalRef}
          practitionerId={route.params.practitioner.id}
          averageRate={Number(route.params.practitioner.average_rating)/10}
          onWriteReview={() => reviewBottomSheetModalRef.current?.present()}
          onBack={() => reviewListBottomSheetModalRef.current?.dismiss()}
        />
        <ReviewBottomSheet
          ref={reviewBottomSheetModalRef}
          practitionerId={route.params.practitioner.id}
        />
      </BaseScreen>
    </ScrollView>
  );
};
