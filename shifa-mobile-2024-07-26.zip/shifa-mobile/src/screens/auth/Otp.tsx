import React, { useState, useEffect } from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useTranslation } from 'react-i18next';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { Button, showToast } from '@/components';
import { useColors } from '@/hooks';
import { AuthStackParamList, Screen } from '@/types';
import { Timer } from '@/components';
import { useAuthStore } from '@/stores';
import { BaseScreen } from '@/screens/Base';

type ScreenProps = NativeStackScreenProps<AuthStackParamList, Screen.Otp>;

export const OtpScreen = (props: ScreenProps | unknown) => {

  const { route, navigation } = props as ScreenProps;

  const {
    verifyOtp,
    generateOtp,
    getMe,
    isLoading,
  } = useAuthStore();

  const { t } = useTranslation('', { keyPrefix: 'auth' });

  useEffect(() => {
    navigation.setOptions({
      title: '',
    });
  }, []);

  const [hasTimer, setHasTimer] = useState<boolean>(true);

  const colors = useColors();

  const otpConfirmation = async (code: string) => {
    await verifyOtp({
      phone_number: route.params.phone_number,
      otp: code,
    });
    await getMe();

    navigation.goBack();
  };

  const otpRegeneration = async () => {
    const response = await generateOtp({ phone_number: route.params.phone_number });
    showToast({
      type: 'info',
      title: 'Success',
      text: response?.message || '',
    });
  };

  return (
    <BaseScreen isLoading={isLoading}>
      <View className="flex-column items-center justify-center gap-y-5 h-full px-5">
        <View className="bg-secondary rounded-full p-5 mb-5">
          <Icon name="account" size={75} color={colors.primary} />
        </View>
        <OTPInputView
          style={{ height: 50, marginHorizontal: 16, marginVertical: 20 }}
          pinCount={6}
          autoFocusOnLoad
          codeInputFieldStyle={{ height: 45, width: 45, borderRadius: 8, borderWidth: 1, color: colors.primary  }}
          codeInputHighlightStyle={{ borderWidth: 1, borderColor: colors.primary }}
          onCodeFilled={(code) => {
            otpConfirmation(code);
          }}
        />
        {
          hasTimer
            ?
            <Text className="h-10">00:<Timer time={60} onEnd={() => setHasTimer(false)} step={1000} /></Text>
            :
            <Button
              label={t('resend_sms')}
              onPress={() => {
                otpRegeneration();
                setHasTimer(true);
              }}
            />
        }
      </View>
    </BaseScreen>
  );
};
