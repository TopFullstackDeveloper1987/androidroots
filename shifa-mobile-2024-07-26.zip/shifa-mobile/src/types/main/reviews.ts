export interface IReview {
  id: string,
  review_headline: string;
  review_body: string;
  star_rating: number;
  created_date: Date;
}

export interface IReviewPayload {
  review_body: string;
  star_rating: number;
}
