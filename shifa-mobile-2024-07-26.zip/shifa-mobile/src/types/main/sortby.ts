export interface ISortByOption {
    title: string,
    value: string,
}

export interface ISortByBottomSheetProps {
    value: string,
    sortByOptions: ISortByOption[],
    onChange: (value: string) => void;
}
