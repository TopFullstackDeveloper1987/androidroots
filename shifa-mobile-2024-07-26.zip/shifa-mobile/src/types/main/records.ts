import { IFile } from '../common';

export enum DocumentType {
  Imaging = 'imaging',
  Lab = 'lab',
  Medication = 'medication',
  Other = 'other',
}

export interface IDocument {
  id: string;
  document_type: DocumentType;
  user: string;
  upload_date: string;
  file: string;
  thumbnail: string;
  file_name: string;
  file_format: string;
  mime_type: string;
  thumbnail_signed_url?: string; // list only
  // detail only
  created_date?: string,
  is_active?: boolean;
  soft_delete?: boolean;
  deleted_date?: string;
  notes?: string;
  created_by_user?: number;
  deleted_by_user?: number;
  file_signed_url?: string;
}

export interface IUploadPayload {
  userId: string;
  profileId: string;
  file: IFile;
}

export interface IDocumentListQuery {
  document_type?: DocumentType;
}

export interface IDocumentUpdatePayload {
  document_type?: DocumentType;
  file_name?: string;
}

export interface IRenameDocumentBottomSheetProps {
  document_id: string;
  document_name: string;
  onFinish: () => void;
}

