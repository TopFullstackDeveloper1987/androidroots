export interface ISpeciality {
  speciality_id: number;
  speciality_name: string;
  speciality_icon: string | null;
  count: number;
}

export interface ICity {
  id: number;
  name: string;
  name_arabic: string;
  name_kurdish: string;
  name_turkish: string;
  name_persian: string;
  location_city_centre: string;
  country: number;
}

export interface IBusinessHour {
  id: number;
  day: number;
  day_name: string;
  open_time: string | null;
  close_time: string | null;
}

export interface IPractitioner {
  id: string;
  name: string;
  name_arabic: string;
  name_kurdish: string;
  gender: 'M' | 'F';
  photo: string;
  practice_name: string;
  review_count: number;
  average_rating: string; // TODO: should be number
  tagline: string;
  index?: number;
  telephone_1?: string;
  favourite_count?: number;
}

export interface IPractitionerDetail {
  id: string;
  title: string;
  gender: 'M' | 'F';

  name: string;
  tagline: string;
  description: string;
  photo: string;
  whatsapp: string;
  viber: string;
  twitter: string;
  facebook: string;
  instagram: string;
  linkedin: string;
  review_count: number;
  average_rating: string; // TODO: should be number
  practice_name: string;
  speciaity_name: string[];
  business_hours: IBusinessHour[];
  location: string;
  latitude: string; // TODO: should be number
  longitude: string; // TODO: should be number
  full_address: string;
  telephone_1?: string;
  email: string;
}

export interface ISearchPractitionerQuery {
  city_id: number;
  speciality_id: number;
  name?: string;
}

export interface IReviewBottomSheetProps {
  practitionerId: string,
  value?: string,
  onChange?: (value: string) => void;
}

export interface IReviewListBottomSheetProps {
  practitionerId: string,
  averageRate: number;
  onWriteReview: () => void;
  onBack: () => void;
}
