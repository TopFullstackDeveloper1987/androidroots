export enum ActionType {
    AddFavorite = 'add-favourite',
    RemoveFavorite = 'remove-favourite',
  }