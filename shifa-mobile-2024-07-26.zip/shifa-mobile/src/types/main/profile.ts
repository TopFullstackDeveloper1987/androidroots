import { IFile } from '../common';

export interface IProfile {
  id: string;
  name: string;
  date_of_birth: string;
  gender: string;
  relationship: string;
  profile_colour: string;
  photo: string;
  user: string;
  city: number;
  language: string;
}

export interface IProfileUpdatePayload extends Partial<Omit<IProfile, 'photo'>> {
  photo?: IFile;
}


export interface INotificationItem {
  id: number;
  content: string;
  created_date: string;
  isOpened: boolean;
}
