export interface SpaceProps {
  marginTop?: number,
  marginBottom?: number,
  marginLeft?: number,
  marginRight?: number,
  marginVertical?: number,
  marginHorizontal?: number,
  paddingTop?: number,
  paddingBottom?: number,
  paddingLeft?: number,
  paddingRight?: number,
  paddingVertical?: number,
  paddingHorizontal?: number,
}
