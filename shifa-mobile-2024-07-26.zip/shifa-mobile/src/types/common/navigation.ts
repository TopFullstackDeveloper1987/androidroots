import {
  RouteConfig,
  StackNavigationState,
  ParamListBase,
  DefaultNavigatorOptions,
  NavigatorScreenParams,
} from '@react-navigation/native';
import {
  NativeStackNavigationOptions,
  NativeStackNavigationEventMap,
} from '@react-navigation/native-stack';

import { IDocument, IPractitioner, IProfile, ISpeciality } from '../main';

export enum Stack {
  AuthStack = 'AuthStack',
  MainStack = 'MainStack',
}

export enum BottomTab {
  HomeStack = 'HomeStack',
  SearchStack = 'SearchStack',
  FavoriteStack = 'FavoriteStack',
  RecordStack = 'RecordStack',
  ProfileStack = 'ProfileStack',
}

export enum Screen {
  // auth
  Otp = 'Otp',

  // main
  // home
  Home = 'Home',

  // search
  Search = 'Search',
  SearchResults = 'Search Results',
  SearchDetails = 'Search Details',

  // favorites
  Favorites = 'Favorites',
  PractitionerDetails = 'Practitioner Details',

  // records
  Records = 'Records',
  RecordDetails = 'Record Details',

  // Profile
  Profile = 'Profile',
  PersonalInformation = 'Personal Information',
  FamilyProfiles = 'Family Profiles',
  Notifications = 'Notifications',
  Settings = 'Settings',
}

export type AuthStackParamList = {
  [Screen.Otp]: {
    phone_number: string,
  };
}

export type HomeStackParamList = {
  [Screen.Home]: undefined;
}

export type SearchStackParamList = {
  [Screen.Search]: undefined;
  [Screen.SearchResults]: {
    speciality: ISpeciality;
    city_id: number,
    name: string,
  };
  [Screen.SearchDetails]: {
    speciality: ISpeciality;
    practitioner: IPractitioner;
  };
}

export type FavoriteStackParamList = {
  [Screen.Favorites]: undefined;
  [Screen.PractitionerDetails]: {
    practitioner: IPractitioner;
  };
}

export type RecordStackParamList = {
  [Screen.Records]: undefined;
  [Screen.RecordDetails]: {
    document: IDocument;
  };
}

export type ProfileStackParamList = {
  [Screen.Profile]: undefined;
  [Screen.PersonalInformation]: {
    profile: IProfile | null;
  };
  [Screen.FamilyProfiles]: undefined;
  [Screen.Notifications]: undefined;
  [Screen.Settings]: undefined;
}

export type MainStackParamList = {
  [BottomTab.HomeStack]: NavigatorScreenParams<HomeStackParamList>;
  [BottomTab.SearchStack]: NavigatorScreenParams<SearchStackParamList>;
  [BottomTab.FavoriteStack]: NavigatorScreenParams<FavoriteStackParamList>;
  [BottomTab.RecordStack]: NavigatorScreenParams<RecordStackParamList>;
  [BottomTab.ProfileStack]: NavigatorScreenParams<ProfileStackParamList>;
}

export type RootStackParamList = {
  [Stack.AuthStack]: NavigatorScreenParams<AuthStackParamList>;
  [Stack.MainStack]: NavigatorScreenParams<MainStackParamList>;
};

type StackRoutesType<ParamList extends ParamListBase> = Array<
  RouteConfig<
    ParamList,
    keyof ParamList,
    StackNavigationState<ParamList>,
    NativeStackNavigationOptions,
    NativeStackNavigationEventMap
  >
>;

export type AuthStackRoutesType = StackRoutesType<AuthStackParamList>;

export type HomeStackRoutesType = StackRoutesType<HomeStackParamList>;
export type SearchStackRoutesType = StackRoutesType<SearchStackParamList>;
export type FavoriteStackRoutesType = StackRoutesType<FavoriteStackParamList>;
export type RecordStackRoutesType = StackRoutesType<RecordStackParamList>;
export type ProfileStackRoutesType = StackRoutesType<ProfileStackParamList>;

export type MainStackRoutesType = StackRoutesType<MainStackParamList>;

export type RootStackRoutesType = StackRoutesType<RootStackParamList>;

export type StackNavigatorOptions<ParamList extends ParamListBase> =
  DefaultNavigatorOptions<
    ParamList,
    StackNavigationState<ParamList>,
    NativeStackNavigationOptions,
    NativeStackNavigationEventMap
  >;
