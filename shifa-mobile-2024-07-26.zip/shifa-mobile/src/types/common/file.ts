export interface IFile {
  name: string;
  type: string;
  uri: string;
}

export enum MediaPickerType {
  Camera = 'camera',
  Gallery = 'gallery',
  File = 'file',
}
