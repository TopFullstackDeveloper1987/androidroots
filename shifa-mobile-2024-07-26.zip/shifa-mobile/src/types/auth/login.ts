export interface IToken {
  access: string;
  refresh?: string;
}

export interface IOtp {
  message?: string;
  access_token?: string;
}

export interface IGenerateOtpPayload {
  phone_number: string;
}

export interface IVerifyOtpPayload {
  phone_number: string;
  otp: string;
}
