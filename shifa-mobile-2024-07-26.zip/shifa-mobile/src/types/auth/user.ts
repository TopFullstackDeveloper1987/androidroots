export interface IUser {
  id: string;
  username: string; // phone number
  is_active: boolean;
  account_type: number;
}
