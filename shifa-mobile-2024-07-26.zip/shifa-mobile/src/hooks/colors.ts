import { useTheme } from 'react-native-paper';
import { ColorTheme } from '../utils';

export const useColors = () => useTheme<ColorTheme>().colors;
