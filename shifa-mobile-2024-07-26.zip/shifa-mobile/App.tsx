import 'reflect-metadata';
import React, { useEffect } from 'react';
import {
  StatusBar,
  useColorScheme,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import SplashScreen from 'react-native-splash-screen';
import { PaperProvider } from 'react-native-paper';
import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

import '@/i18n';

import { RootStackNavigator } from '@/navigation';
import { Toast } from '@/components/common';
import { getTheme } from '@/utils';
import { DevicePermissionsProvider } from '@/providers';

function App(): JSX.Element {
  const colorScheme = useColorScheme() || 'light';
  const isDarkMode = colorScheme === 'dark';

  useEffect(() => {
    setTimeout(() => {
      SplashScreen.hide();
    }, 2000);
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <PaperProvider theme={getTheme(colorScheme)}>
        <SafeAreaProvider>
          <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
          <NavigationContainer theme={getTheme(colorScheme)}>
            <BottomSheetModalProvider>
              <DevicePermissionsProvider>
                <RootStackNavigator />
              </DevicePermissionsProvider>
            </BottomSheetModalProvider>
          </NavigationContainer>
          <Toast />
        </SafeAreaProvider>
      </PaperProvider>
    </GestureHandlerRootView>
  );
}

export default App;
